-- Adwerk schema
create extension if not exists pgcrypto;

-- Alleen @daar-om.nl accounts toestaan
create or replace function public.adwerk_check_domain() returns trigger
language plpgsql security definer set search_path = public as $$
begin
  if new.email is null or lower(new.email) not like '%@daar-om.nl' then
    raise exception 'Alleen @daar-om.nl accounts hebben toegang tot Adwerk';
  end if;
  return new;
end $$;
drop trigger if exists adwerk_domain_guard on auth.users;
create trigger adwerk_domain_guard before insert on auth.users
  for each row execute function public.adwerk_check_domain();

create table if not exists public.profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  email text,
  full_name text,
  avatar_url text,
  color text,
  created_at timestamptz default now()
);

create or replace function public.adwerk_new_user() returns trigger
language plpgsql security definer set search_path = public as $$
begin
  insert into public.profiles (id, email, full_name, avatar_url, color)
  values (new.id, new.email,
    coalesce(new.raw_user_meta_data->>'full_name', new.raw_user_meta_data->>'name', split_part(new.email,'@',1)),
    new.raw_user_meta_data->>'avatar_url',
    (array['#CC4A25','#5B3FD9','#0E8C6C','#A15C00','#C2185B','#1A5FC4','#6D4AE8','#00797A'])[1 + floor(random()*8)::int])
  on conflict (id) do nothing;
  return new;
end $$;
drop trigger if exists adwerk_on_auth_user on auth.users;
create trigger adwerk_on_auth_user after insert on auth.users
  for each row execute function public.adwerk_new_user();

-- Projectmappen (bijv. per klant)
create table if not exists public.folders (
  id uuid primary key default gen_random_uuid(),
  name text not null,
  owner_id uuid not null references auth.users(id) on delete cascade default auth.uid(),
  visibility text not null default 'team' check (visibility in ('private','team')),
  created_at timestamptz default now()
);

create table if not exists public.designs (
  id uuid primary key default gen_random_uuid(),
  title text not null default 'Naamloos ontwerp',
  owner_id uuid not null references auth.users(id) on delete cascade default auth.uid(),
  folder_id uuid references public.folders(id) on delete set null,
  visibility text not null default 'private' check (visibility in ('private','team')),
  is_template boolean not null default false,
  data jsonb not null default '{}'::jsonb,
  thumbnail text,
  updated_by uuid references auth.users(id),
  created_at timestamptz default now(),
  updated_at timestamptz default now()
);
create index if not exists designs_owner_idx on public.designs(owner_id);
create index if not exists designs_folder_idx on public.designs(folder_id);

create table if not exists public.design_members (
  design_id uuid references public.designs(id) on delete cascade,
  user_id uuid references auth.users(id) on delete cascade,
  primary key (design_id, user_id)
);

create table if not exists public.brand_kits (
  id uuid primary key default gen_random_uuid(),
  name text not null,
  owner_id uuid not null references auth.users(id) on delete cascade default auth.uid(),
  colors jsonb not null default '[]'::jsonb,
  fonts jsonb not null default '[]'::jsonb,
  logos jsonb not null default '[]'::jsonb,
  created_at timestamptz default now()
);

create table if not exists public.assets (
  id uuid primary key default gen_random_uuid(),
  owner_id uuid not null references auth.users(id) on delete cascade default auth.uid(),
  url text not null,
  path text not null,
  name text,
  width int, height int,
  shared boolean not null default false,
  created_at timestamptz default now()
);

create or replace function public.adwerk_can_access(d public.designs) returns boolean
language sql stable security definer set search_path = public as $$
  select d.owner_id = auth.uid()
      or d.visibility = 'team'
      or d.is_template
      or exists (select 1 from public.folders f where f.id = d.folder_id and f.visibility = 'team')
      or exists (select 1 from public.design_members m where m.design_id = d.id and m.user_id = auth.uid());
$$;

alter table public.profiles enable row level security;
alter table public.folders enable row level security;
alter table public.designs enable row level security;
alter table public.design_members enable row level security;
alter table public.brand_kits enable row level security;
alter table public.assets enable row level security;

drop policy if exists "profiles read" on public.profiles;
create policy "profiles read" on public.profiles for select to authenticated using (true);
drop policy if exists "profiles self" on public.profiles;
create policy "profiles self" on public.profiles for update to authenticated using (id = auth.uid());

drop policy if exists "folders read" on public.folders;
create policy "folders read" on public.folders for select to authenticated using (visibility = 'team' or owner_id = auth.uid());
drop policy if exists "folders insert" on public.folders;
create policy "folders insert" on public.folders for insert to authenticated with check (owner_id = auth.uid());
drop policy if exists "folders update" on public.folders;
create policy "folders update" on public.folders for update to authenticated using (owner_id = auth.uid() or visibility = 'team');
drop policy if exists "folders delete" on public.folders;
create policy "folders delete" on public.folders for delete to authenticated using (owner_id = auth.uid());

drop policy if exists "designs read" on public.designs;
create policy "designs read" on public.designs for select to authenticated using (public.adwerk_can_access(designs));
drop policy if exists "designs insert" on public.designs;
create policy "designs insert" on public.designs for insert to authenticated with check (owner_id = auth.uid());
drop policy if exists "designs update" on public.designs;
create policy "designs update" on public.designs for update to authenticated using (public.adwerk_can_access(designs));
drop policy if exists "designs delete" on public.designs;
create policy "designs delete" on public.designs for delete to authenticated using (owner_id = auth.uid());

drop policy if exists "members read" on public.design_members;
create policy "members read" on public.design_members for select to authenticated using (true);
drop policy if exists "members write" on public.design_members;
create policy "members write" on public.design_members for all to authenticated
  using (exists (select 1 from public.designs d where d.id = design_id and d.owner_id = auth.uid()))
  with check (exists (select 1 from public.designs d where d.id = design_id and d.owner_id = auth.uid()));

drop policy if exists "kits read" on public.brand_kits;
create policy "kits read" on public.brand_kits for select to authenticated using (true);
drop policy if exists "kits write" on public.brand_kits;
create policy "kits write" on public.brand_kits for all to authenticated using (true) with check (true);

drop policy if exists "assets read" on public.assets;
create policy "assets read" on public.assets for select to authenticated using (owner_id = auth.uid() or shared);
drop policy if exists "assets insert" on public.assets;
create policy "assets insert" on public.assets for insert to authenticated with check (owner_id = auth.uid());
drop policy if exists "assets update" on public.assets;
create policy "assets update" on public.assets for update to authenticated using (owner_id = auth.uid());
drop policy if exists "assets delete" on public.assets;
create policy "assets delete" on public.assets for delete to authenticated using (owner_id = auth.uid());

grant select, insert, update, delete on public.profiles, public.folders, public.designs, public.design_members, public.brand_kits, public.assets to authenticated;

-- Opslag voor uploads (openbaar leesbaar via onraadbare URL, alleen ingelogd uploaden)
insert into storage.buckets (id, name, public, file_size_limit)
values ('assets', 'assets', true, 20971520)
on conflict (id) do update set public = true, file_size_limit = 20971520;

drop policy if exists "adwerk upload" on storage.objects;
create policy "adwerk upload" on storage.objects for insert to authenticated
  with check (bucket_id = 'assets' and (storage.foldername(name))[1] = auth.uid()::text);
drop policy if exists "adwerk read" on storage.objects;
create policy "adwerk read" on storage.objects for select to authenticated using (bucket_id = 'assets');
drop policy if exists "adwerk delete" on storage.objects;
create policy "adwerk delete" on storage.objects for delete to authenticated
  using (bucket_id = 'assets' and (storage.foldername(name))[1] = auth.uid()::text);

-- Realtime voor lijstweergaven
do $$ begin
  begin alter publication supabase_realtime add table public.designs; exception when others then null; end;
end $$;
