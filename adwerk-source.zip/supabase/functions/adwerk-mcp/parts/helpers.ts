/* ------------------------------------------------------------------ slim meeschalen (zelfde als de editor) */
function smartResize(src: Frame, target: { w: number; h: number }): El[] {
  const sx = target.w / src.w, sy = target.h / src.h, s = Math.min(sx, sy), sMax = Math.max(sx, sy)
  const textK = () => Math.min(Math.max(s, Math.sqrt(sx * sy) * 0.85), sMax)
  const story = target.h / target.w > 1.7 && !(src.h / src.w > 1.7)
  const mapY = (cy: number) => (story ? target.h * 0.14 + (cy / src.h) * target.h * 0.66 : cy * sy)
  const pairK = new Map<string, { k: number; cx: number; cy: number }>()
  for (const e of src.elements) {
    if (e.type === 'text' || e.width * e.height > src.w * src.h * 0.3) continue
    const t = src.elements.find((t) => t.type === 'text' && t.x + t.width / 2 > e.x && t.x + t.width / 2 < e.x + e.width && t.y + t.height / 2 > e.y && t.y + t.height / 2 < e.y + e.height && t.width <= e.width * 1.2)
    if (t) pairK.set(e.id, { k: textK(), cx: t.x + t.width / 2, cy: t.y + t.height / 2 })
  }
  return src.elements.map((e) => {
    const n: El = clone(e)
    n.id = uid()
    if (e.width >= src.w * 0.9 && e.height >= src.h * 0.9) {
      const k = e.type === 'image' ? sMax : 1
      n.width = e.type === 'image' ? e.width * k : e.width * sx
      n.height = e.type === 'image' ? e.height * k : e.height * sy
      n.x = (target.w - n.width) / 2; n.y = (target.h - n.height) / 2
      return n
    }
    const pair = pairK.get(e.id), ocx = e.x + e.width / 2, ocy = e.y + e.height / 2
    const cx = pair ? pair.cx * sx + (ocx - pair.cx) * pair.k : ocx * sx
    const cy = pair ? mapY(pair.cy) + (ocy - pair.cy) * pair.k : mapY(ocy)
    let k = s
    if (e.type === 'text') k = textK()
    if (pair) k = pair.k
    n.width = e.width * k; n.height = e.height * k
    if (e.type === 'text') { n.fontSize = Math.max(8, Math.round((Number(e.fontSize) || 24) * k)); n.width = Math.min(n.width, target.w * 0.94) }
    n.strokeWidth = e.strokeWidth * s; n.cornerRadius = e.cornerRadius * s
    const sh = e.shadow as { blur: number; x: number; y: number }
    n.shadow = { ...e.shadow, blur: (sh.blur || 0) * s, x: (sh.x || 0) * s, y: (sh.y || 0) * s }
    n.x = cx - n.width / 2; n.y = cy - n.height / 2
    n.x = Math.min(Math.max(n.x, -n.width * 0.4), target.w - n.width * 0.6)
    n.y = Math.min(Math.max(n.y, -n.height * 0.4), target.h - n.height * 0.6)
    return n
  })
}

/* ------------------------------------------------------------------ controle: veelgemaakte fouten */
function lum(hex: string) {
  const m = hex.replace('#', '').match(/^([0-9a-f]{6}|[0-9a-f]{3})/i)
  if (!m) return 0.5
  const h = m[1].length === 3 ? m[1].split('').map((c) => c + c).join('') : m[1]
  const c = [0, 2, 4].map((i) => parseInt(h.slice(i, i + 2), 16) / 255).map((x) => (x <= 0.03928 ? x / 12.92 : ((x + 0.055) / 1.055) ** 2.4))
  return 0.2126 * c[0] + 0.7152 * c[1] + 0.0722 * c[2]
}
const contrast = (a: string, b: string) => { const x = lum(a), y = lum(b); return (Math.max(x, y) + 0.05) / (Math.min(x, y) + 0.05) }

async function checkFrame(f: Frame): Promise<string[]> {
  const out: string[] = []
  const minSide = Math.min(f.w, f.h), story = f.h / f.w > 1.7, banner = minSide <= 320
  const box = new Map<string, { x: number; y: number; w: number; h: number }>()
  for (const e of f.elements) {
    let h = e.height
    if (e.type === 'text') { try { h = (await layoutText(e)).height } catch { /* schatting */ } }
    box.set(e.id, { x: e.x, y: e.y, w: e.width, h })
  }
  const label = (e: El) => `${e.type === 'text' ? `tekst "${String(e.text || '').replace(/\n/g, ' ').slice(0, 28)}"` : `${e.type} "${e.name}"`} (${e.id})`
  const inside = (p: { x: number; y: number }, b: { x: number; y: number; w: number; h: number }) => p.x >= b.x && p.x <= b.x + b.w && p.y >= b.y && p.y <= b.y + b.h
  const overlap = (a: { x: number; y: number; w: number; h: number }, b: { x: number; y: number; w: number; h: number }) => Math.max(0, Math.min(a.x + a.w, b.x + b.w) - Math.max(a.x, b.x)) * Math.max(0, Math.min(a.y + a.h, b.y + b.h) - Math.max(a.y, b.y))
  let words = 0
  f.elements.forEach((e, i) => {
    if (!e.visible) return
    const b = box.get(e.id)!
    const outPart = (Math.max(0, -b.x) + Math.max(0, b.x + b.w - f.w)) / Math.max(1, b.w) + (Math.max(0, -b.y) + Math.max(0, b.y + b.h - f.h)) / Math.max(1, b.h)
    if (e.type === 'text') {
      words += String(e.text || '').split(/\s+/).filter(Boolean).length
      if (!String(e.text || '').trim()) out.push(`${label(e)} is leeg`)
      if (outPart > 0.01) out.push(`${label(e)} valt (deels) buiten het formaat`)
      const fs = Number(e.fontSize) || 24
      const minFs = banner ? 11 : Math.round(minSide * 0.028)
      if (fs < minFs) out.push(`${label(e)} is ${fs}px: te klein om op mobiel te lezen, minimaal ongeveer ${minFs}px`)
      const m = minSide * 0.04
      if (outPart <= 0.01 && (b.x < m || b.y < m || b.x + b.w > f.w - m || b.y + b.h > f.h - m)) out.push(`${label(e)} staat te dicht op de rand; houd minstens ${Math.round(m)}px marge`)
      if (story && (b.y < f.h * 0.14 || b.y + b.h > f.h * 0.8)) out.push(`${label(e)} staat in de veilige zone van de story (boven 14% of onder 20%); daar vallen profielnaam en knoppen overheen`)
      // contrast met wat eronder ligt
      const c = { x: b.x + b.w / 2, y: b.y + b.h / 2 }
      let under: string[] | null = null, onPhoto = false
      for (let j = i - 1; j >= 0; j--) {
        const o = f.elements[j]
        if (!o.visible || o.type === 'text' || o.type === 'icon' || o.type === 'line') continue
        if (!inside(c, box.get(o.id)!)) continue
        if (o.type === 'image') { onPhoto = !!o.src; under = o.src ? null : [o.fill]; break }
        if ((o.opacity ?? 1) > 0.6) { under = [o.fill]; break }
      }
      if (!under && !onPhoto) under = f.background.type === 'gradient' ? [f.background.color, f.background.color2] : f.background.type === 'image' ? null : [f.background.color]
      if (f.background.type === 'image' && !under) onPhoto = true
      if (onPhoto) out.push(`${label(e)} staat op een foto: controleer in de preview de leesbaarheid en of er geen gezicht of product achter de tekst valt; gebruik zo nodig een vlak of verloop eronder`)
      else if (under) {
        const large = fs >= minSide * 0.05 || (Number(e.fontWeight) >= 700 && fs >= minSide * 0.035)
        const worst = Math.min(...under.map((u) => contrast(String(e.fill), u)))
        if (worst < (large ? 3 : 4.5)) out.push(`${label(e)} heeft te weinig contrast (${worst.toFixed(1)}:1 met ${under.join(' / ')}); minimaal ${large ? '3' : '4,5'}:1`)
      }
      // tekst die buiten zijn knop of vlak steekt
      for (let j = i - 1; j >= 0; j--) {
        const o = f.elements[j]
        if (!o.visible || o.type !== 'rect') continue
        const ob = box.get(o.id)!
        if (inside(c, ob) && ob.w * ob.h < f.w * f.h * 0.3 && (b.x < ob.x - 1 || b.x + b.w > ob.x + ob.w + 1 || b.y < ob.y - 1 || b.y + b.h > ob.y + ob.h + 1)) { out.push(`${label(e)} steekt buiten het vlak "${o.name}" (${o.id}) eronder`); break }
        if (inside(c, ob) && ob.w * ob.h < f.w * f.h * 0.3) {
          const dy = Math.abs((b.y + b.h / 2) - (ob.y + ob.h / 2)), dx = e.align === 'center' ? Math.abs((b.x + b.w / 2) - (ob.x + ob.w / 2)) : 0
          if (dy > ob.h * 0.12 || dx > ob.w * 0.06) out.push(`${label(e)} staat niet in het midden van "${o.name}" (${o.id}); centreer de tekst in de knop (zelfde x en breedte, align center, y = knop.y + (knop.hoogte - teksthoogte) / 2)`)
          break
        }
      }
      for (let j = i + 1; j < f.elements.length; j++) {
        const o = f.elements[j]
        if (o.visible && o.type === 'text' && overlap(b, box.get(o.id)!) > 4) out.push(`${label(e)} overlapt met ${label(o)}`)
      }
    } else if (e.type === 'image') {
      if (!e.src) out.push(`${label(e)} is een leeg fotokader`)
      if (outPart > 0.35) out.push(`${label(e)} valt grotendeels buiten het formaat`)
    } else if (e.type === 'icon') {
      if (outPart > 0.01) out.push(`${label(e)} valt (deels) buiten het formaat`)
      if (story && (b.y < f.h * 0.14 || b.y + b.h > f.h * 0.8) && b.w < f.w * 0.5) out.push(`${label(e)} staat in de veilige zone van de story`)
    }
  })
  const area = f.elements.filter((e) => e.visible && e.type === 'text').reduce((sum, t) => { const bb = box.get(t.id)!; return sum + bb.w * bb.h }, 0) / (f.w * f.h)
  if (area > 0.25) out.push(`tekst bedekt ongeveer ${Math.round(area * 100)}% van het beeld; minder tekst presteert meestal beter`)
  if (banner && words > 20) out.push(`${words} woorden in een banner van ${f.w}×${f.h}: te veel, houd het bij een korte kop, één voordeel en een knop`)
  if (!banner && words > 40) out.push(`${words} woorden: veel tekst voor een advertentie; kort in tot kop, ondersteuning en call to action`)
  if (f.platform === 'Google Display' && f.duration > 30) out.push(`animatie duurt ${f.duration}s; Google Ads staat maximaal 30s toe`)
  if (!f.elements.some((e) => e.type === 'text')) out.push('er staat geen tekst in dit formaat')
  return out
}

/* ------------------------------------------------------------------ live beelden */
/** Vraagt een open editor om een pixel-exacte render; anders null. */
async function clientRender(designId: string, frameIds: string[], t: number | null, maxSide: number): Promise<Map<string, { bytes: Uint8Array; mime: string }> | null> {
  const reqId = crypto.randomUUID()
  await broadcast(designId, [{ event: 'render-request', payload: { reqId, frameIds, time: t, maxSide } }])
  const start = Date.now()
  let files: { name: string }[] = [], acked = false
  while (Date.now() - start < 12000) {
    await sleep(300)
    const { data } = await db.storage.from('assets').list(`previews/${reqId}`)
    const all = (data || []) as { name: string }[]
    acked = all.some((f) => f.name === '_ack')
    files = all.filter((f) => f.name !== '_ack')
    if (files.length >= frameIds.length) break
    if (!acked && Date.now() - start > 2500) break
  }
  const paths = [...files.map((f) => `previews/${reqId}/${f.name}`), `previews/${reqId}/_ack`]
  if (!files.length) { if (acked) db.storage.from('assets').remove(paths).then(() => {}); return null }
  const map = new Map<string, { bytes: Uint8Array; mime: string }>()
  for (const f of files) {
    const { data } = await db.storage.from('assets').download(`previews/${reqId}/${f.name}`)
    if (data) map.set(f.name.replace(/\.\w+$/, ''), { bytes: new Uint8Array(await data.arrayBuffer()), mime: f.name.endsWith('.png') ? 'image/png' : 'image/jpeg' })
  }
  db.storage.from('assets').remove(paths).then(() => {})
  return map
}

async function previewContent(designId: string, ctx: Ctx, opts: { frame_id?: string; time?: number | null; size?: number; checks?: boolean }) {
  const row = await loadDesign(designId, ctx)
  const frames = (opts.frame_id ? pickFrames(row.data, opts.frame_id) : row.data.frames).slice(0, 8)
  const t = typeof opts.time === 'number' ? opts.time : null
  const size = Math.max(200, Math.min(1400, opts.size || 900))
  const live = await clientRender(designId, frames.map((f) => f.id), t, size)
  const content: Json[] = []
  for (const f of frames) {
    let img = live?.get(f.id)
    let src = 'pixel-exact uit de open editor'
    if (!img) { img = { bytes: await renderFramePng(f, t, size), mime: 'image/png' }; src = 'serverrender (lettertypes en beelden benaderen de editor)' }
    const checks = opts.checks === false ? [] : await checkFrame(f)
    content.push({ type: 'text', text: `${f.name} · frame_id ${f.id} · ${f.w}×${f.h}px${t !== null ? ` · op ${t}s van de animatie` : ''} · ${src}\n${opts.checks === false ? '' : checks.length ? 'Controle, los dit op:\n- ' + checks.join('\n- ') : 'Controle: geen veelgemaakte fouten gevonden. Kijk zelf nog naar uitsnede, hiërarchie en balans.'}` })
    content.push({ type: 'image', data: b64(img.bytes), mimeType: img.mime })
  }
  return content
}
