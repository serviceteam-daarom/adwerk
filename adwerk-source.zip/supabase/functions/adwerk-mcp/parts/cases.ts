    /* ---------------- kijken en controleren */
    case 'get_preview': return { content: await previewContent(String(a.design_id), ctx, { frame_id: a.frame_id as string | undefined, time: a.time as number | undefined, size: a.size as number | undefined, checks: a.checks as boolean | undefined }) }

    case 'check_design': {
      const row = await loadDesign(String(a.design_id), ctx)
      const frames = a.frame_id ? pickFrames(row.data, String(a.frame_id)) : row.data.frames
      const out: string[] = []
      for (const f of frames) { const c = await checkFrame(f); out.push(`${f.name} (${f.id}): ${c.length ? '\n- ' + c.join('\n- ') : 'geen problemen gevonden'}`) }
      return ok(out.join('\n\n'))
    }

    case 'view_image': {
      let src = a.url ? String(a.url) : ''
      if (!src && a.element_id) { const row = await loadDesign(String(a.design_id), ctx); src = String(findEl(row.data, String(a.element_id)).el.src || '') }
      if (!src) throw new Error('Geef een element_id van een afbeelding of een url')
      const r = await renderImageGrid(src, Math.max(300, Math.min(1400, num(a.size, 900))))
      return { content: [{ type: 'text', text: `Volledige foto, ${r.w}×${r.h}px (verhouding ${(r.w / r.h).toFixed(2)}). Rasterlijnen per 0,1; de roze lijnen zijn het midden. Gebruik deze waarden als focus_x en focus_y in set_image_crop.` }, { type: 'image', data: b64(r.png), mimeType: 'image/png' }] }
    }

    case 'set_image_crop': {
      const id = String(a.design_id), elId = String(a.element_id)
      const row = await loadDesign(id, ctx)
      const { frame, el } = findEl(row.data, elId)
      if (el.type !== 'image' || !el.src) throw new Error('Dit is geen afbeelding met een foto')
      const d = await imageDims(String(el.src))
      if (!d) throw new Error('Foto kon niet worden geladen')
      const zoom = Math.max(1, num(a.zoom, Number(el.cropZoom) || 1))
      const s = Math.max(el.width / d.w, el.height / d.h) * zoom, cw = el.width / s, ch = el.height / s
      const fx = num(a.focus_x, 0.5), fy = num(a.focus_y, 0.5)
      const cropX = d.w - cw > 0.5 ? Math.min(1, Math.max(0, (fx * d.w - cw / 2) / (d.w - cw))) : 0.5
      const cropY = d.h - ch > 0.5 ? Math.min(1, Math.max(0, (fy * d.h - ch / 2) / (d.h - ch))) : 0.5
      const live = new Live(id, ctx, frame.id)
      await live.moveTo(el.x + el.width / 2, el.y + el.height / 2, 'uitsnede kiezen')
      await live.click([elId])
      await editDesign(id, ctx, (doc) => { Object.assign(findEl(doc, elId).el, { cropZoom: zoom, cropX: r1(cropX * 1000) / 1000, cropY: r1(cropY * 1000) / 1000, ...(a.flip_x !== undefined ? { flipX: !!a.flip_x } : {}) }) })
      await live.status('klaar', [elId])
      const visible = { left: r1(((d.w - cw) * cropX) / d.w * 100) / 100, top: r1(((d.h - ch) * cropY) / d.h * 100) / 100, width: r1(cw / d.w * 100) / 100, height: r1(ch / d.h * 100) / 100 }
      return ok({ element_id: elId, zoom, visible_part_of_photo: visible, tip: 'Controleer met get_preview of hoofden, handen en het product helemaal in beeld zijn.' })
    }

    case 'fit_image': {
      const id = String(a.design_id), elId = String(a.element_id)
      const row = await loadDesign(id, ctx)
      const { el, frame } = findEl(row.data, elId)
      const d = el.src ? await imageDims(String(el.src)) : null
      if (!d) throw new Error('Foto kon niet worden geladen')
      const live = new Live(id, ctx, frame.id)
      await live.moveTo(el.x + el.width / 2, el.y + el.height / 2, 'kader passend maken')
      await live.click([elId])
      await editDesign(id, ctx, (doc) => {
        const { el: e, frame: f, index } = findEl(doc, elId)
        if (a.mode === 'cover_frame') { Object.assign(e, { x: 0, y: 0, width: f.w, height: f.h, cropZoom: 1, cropX: 0.5, cropY: 0.5, mask: 'none', cornerRadius: 0 }); f.elements.splice(index, 1); f.elements.unshift(e) }
        else { const h = e.width * d.h / d.w; Object.assign(e, { y: e.y + (e.height - h) / 2, height: Math.round(h), cropZoom: 1, cropX: 0.5, cropY: 0.5 }) }
      })
      await live.status('klaar', [elId])
      return ok('Kader aangepast')
    }

    case 'list_fonts': return ok({ fonts: FONTS, tip: 'Poppins (koppen vet, tekst regular) en Caveat (handgeschreven accent) zijn de huisstijl van daar-om.nl. Combineer maximaal twee lettertypes.' })

    /* ---------------- meerdere dingen tegelijk */
    case 'add_many': {
      const results: unknown[] = []
      for (const it of (Array.isArray(a.items) ? a.items as Json[] : [])) {
        const tool = String(it.tool)
        if (!['add_text', 'add_shape', 'add_image', 'add_icon'].includes(tool)) { results.push({ error: `Onbekende tool ${tool}` }); continue }
        try { const r = await call(tool, { ...it, design_id: a.design_id }, ctx) as { content: { text: string }[] }; results.push({ tool, ...JSON.parse(r.content[0].text) }) }
        catch (e) { results.push({ tool, error: (e as Error).message }) }
      }
      return ok(results)
    }

    case 'update_many': {
      const results: unknown[] = []
      for (const u of (Array.isArray(a.updates) ? a.updates as Json[] : [])) {
        try { await call('update_element', { design_id: a.design_id, element_id: u.element_id, props: u.props }, ctx); results.push({ element_id: u.element_id, ok: true }) }
        catch (e) { results.push({ element_id: u.element_id, error: (e as Error).message }) }
      }
      return ok(results)
    }

    case 'duplicate_element': {
      const id = String(a.design_id), elId = String(a.element_id)
      const row = await loadDesign(id, ctx)
      const { frame, el } = findEl(row.data, elId)
      const live = new Live(id, ctx, frame.id)
      await live.moveTo(el.x + el.width / 2, el.y + el.height / 2, 'dupliceren')
      await live.click([elId])
      let newId = ''
      await editDesign(id, ctx, (doc) => {
        const { el: e, frame: f } = findEl(doc, elId)
        const target = a.to_frame_id ? pickFrames(doc, String(a.to_frame_id))[0] : f
        const n = clone(e); n.id = uid(); newId = n.id
        if (target.id !== f.id) { const b = mapBox(f, target, e); Object.assign(n, { x: b.x, y: b.y, width: b.width, height: b.height }); if (n.type === 'text') n.fontSize = Math.max(6, Math.round(Number(n.fontSize) * b.k)) }
        n.x += num(a.dx, target.id === f.id ? 24 : 0); n.y += num(a.dy, target.id === f.id ? 24 : 0)
        target.elements.push(n)
      })
      await live.status('klaar', [newId])
      return ok({ element_id: newId })
    }

    case 'align_elements': case 'distribute_elements': {
      const id = String(a.design_id), ids = (a.element_ids || []) as string[]
      if (!ids.length) throw new Error('Geef element_ids')
      const row = await loadDesign(id, ctx)
      const first = findEl(row.data, ids[0])
      const live = new Live(id, ctx, first.frame.id)
      await live.moveTo(first.el.x + first.el.width / 2, first.el.y + first.el.height / 2, name === 'align_elements' ? 'uitlijnen' : 'verdelen', ids)
      await live.click(ids)
      await editDesign(id, ctx, (doc) => {
        const els = ids.map((i) => findEl(doc, i).el), f = findEl(doc, ids[0]).frame
        if (name === 'align_elements') {
          const sel = a.relative_to === 'selection' && els.length > 1, m = num(a.margin, 0)
          const minX = sel ? Math.min(...els.map((e) => e.x)) : m, maxX = sel ? Math.max(...els.map((e) => e.x + e.width)) : f.w - m
          const minY = sel ? Math.min(...els.map((e) => e.y)) : m, maxY = sel ? Math.max(...els.map((e) => e.y + e.height)) : f.h - m
          for (const e of els) {
            if (a.align === 'left') e.x = minX
            if (a.align === 'right') e.x = maxX - e.width
            if (a.align === 'center') e.x = (minX + maxX) / 2 - e.width / 2
            if (a.align === 'top') e.y = minY
            if (a.align === 'bottom') e.y = maxY - e.height
            if (a.align === 'middle') e.y = (minY + maxY) / 2 - e.height / 2
          }
        } else {
          const hor = a.axis !== 'vertical'
          const sorted = [...els].sort((p, q) => (hor ? p.x - q.x : p.y - q.y))
          const start = hor ? sorted[0].x : sorted[0].y
          const end = hor ? sorted[sorted.length - 1].x + sorted[sorted.length - 1].width : sorted[sorted.length - 1].y + sorted[sorted.length - 1].height
          const total = sorted.reduce((s, e) => s + (hor ? e.width : e.height), 0)
          const gap = (end - start - total) / Math.max(1, sorted.length - 1)
          let pos = start
          for (const e of sorted) { if (hor) e.x = pos; else e.y = pos; pos += (hor ? e.width : e.height) + gap }
        }
      })
      await live.status('klaar', ids)
      return ok('Klaar')
    }

    /* ---------------- formaten */
    case 'copy_to_all_formats': {
      const id = String(a.design_id), from = String(a.from_frame_id)
      const live = new Live(id, ctx, from)
      await live.status('formaten omzetten')
      let count = 0
      await editDesign(id, ctx, (doc) => {
        const src = pickFrames(doc, from)[0]
        const targets = doc.frames.filter((f) => f.id !== src.id && (!Array.isArray(a.to_frame_ids) || (a.to_frame_ids as string[]).includes(f.id)))
        for (const t of targets) { t.elements = smartResize(src, t); t.background = clone(src.background); t.duration = src.duration; count++ }
      })
      return ok({ converted_formats: count, tip: 'Bekijk elk formaat met get_preview; vooral smalle banners (728×90, 320×50) en stories hebben vaak een eigen indeling nodig.' })
    }

    case 'delete_format': {
      const id = String(a.design_id)
      await editDesign(id, ctx, (doc) => {
        if (doc.frames.length <= 1) throw new Error('Een ontwerp heeft minstens één formaat nodig')
        const f = pickFrames(doc, String(a.frame_id))[0]
        doc.frames = doc.frames.filter((x) => x.id !== f.id)
      })
      return ok('Formaat verwijderd')
    }

    case 'export_image': {
      const row = await loadDesign(String(a.design_id), ctx)
      const f = pickFrames(row.data, String(a.frame_id))[0]
      const scale = Math.max(0.25, Math.min(3, num(a.scale, 1)))
      const live = await clientRender(row.id, [f.id], null, Math.round(Math.max(f.w, f.h) * scale))
      const got = live?.get(f.id)
      const bytes = got?.mime === 'image/png' ? got.bytes : await renderFramePng(f, null, Math.max(f.w, f.h) * scale)
      const path = `${ctx.userId}/exports/${crypto.randomUUID()}.png`
      await db.storage.from('assets').upload(path, bytes, { contentType: 'image/png' })
      return ok({ url: db.storage.from('assets').getPublicUrl(path).data.publicUrl, width: Math.round(f.w * scale), height: Math.round(f.h * scale) })
    }

    /* ---------------- ontwerpen en projecten */
    case 'rename_design': {
      const d = await loadDesign(String(a.design_id), ctx)
      await db.from('designs').update({ title: String(a.title), updated_by: ctx.userId }).eq('id', d.id)
      return ok('Naam aangepast')
    }
    case 'duplicate_design': {
      const d = await loadDesign(String(a.design_id), ctx)
      const doc = clone(d.data)
      for (const f of doc.frames) { f.id = uid(); f.elements.forEach((e) => { e.id = uid() }) }
      const { data, error } = await db.from('designs').insert({ title: String(a.title || `${d.title} (kopie)`), data: doc, owner_id: ctx.userId, updated_by: ctx.userId, visibility: d.visibility, folder_id: a.project_id || (d as unknown as { folder_id: string | null }).folder_id || null }).select('id').single()
      if (error) throw new Error('Kopiëren mislukt')
      return ok({ id: data.id, url: designUrl(data.id) })
    }
    case 'share_design': {
      const d = await loadDesign(String(a.design_id), ctx)
      if (a.with_team !== undefined) {
        if (d.owner_id !== ctx.userId) throw new Error('Alleen de eigenaar kan de zichtbaarheid aanpassen')
        await db.from('designs').update({ visibility: a.with_team ? 'team' : 'private' }).eq('id', d.id)
      }
      const emails = [...((a.add_emails || []) as string[]), ...((a.remove_emails || []) as string[])]
      if (emails.length) {
        if (d.owner_id !== ctx.userId) throw new Error('Alleen de eigenaar kan collega\'s toevoegen')
        const { data: profs } = await db.from('profiles').select('id,email').in('email', emails.map((e) => e.toLowerCase()))
        const byMail = new Map((profs || []).map((p: { id: string; email: string }) => [p.email.toLowerCase(), p.id]))
        for (const e of (a.add_emails || []) as string[]) { const uidp = byMail.get(e.toLowerCase()); if (uidp) await db.from('design_members').upsert({ design_id: d.id, user_id: uidp }) }
        for (const e of (a.remove_emails || []) as string[]) { const uidp = byMail.get(e.toLowerCase()); if (uidp) await db.from('design_members').delete().eq('design_id', d.id).eq('user_id', uidp) }
      }
      return ok('Delen bijgewerkt')
    }
    case 'set_template': {
      const d = await loadDesign(String(a.design_id), ctx)
      await db.from('designs').update({ is_template: !!a.is_template }).eq('id', d.id)
      return ok(a.is_template ? 'Staat nu bij de teamtemplates' : 'Geen template meer')
    }
    case 'delete_design': {
      if (a.confirm !== true) throw new Error('Zet confirm op true, en alleen als de gebruiker dit expliciet vroeg')
      const d = await loadDesign(String(a.design_id), ctx)
      if (d.owner_id !== ctx.userId) throw new Error('Je kunt alleen je eigen ontwerpen verwijderen')
      await db.from('designs').delete().eq('id', d.id)
      return ok('Ontwerp verwijderd')
    }
    case 'list_projects': {
      const { data } = await db.from('folders').select('id,name,owner_id,visibility').order('name')
      const rows = (data || []).filter((f: { owner_id: string; visibility: string }) => f.owner_id === ctx.userId || f.visibility === 'team')
      const out = []
      for (const f of rows as { id: string; name: string; owner_id: string; visibility: string }[]) {
        const { count } = await db.from('designs').select('id', { count: 'exact', head: true }).eq('folder_id', f.id)
        out.push({ id: f.id, name: f.name, mine: f.owner_id === ctx.userId, shared_with_team: f.visibility === 'team', designs: count || 0 })
      }
      return ok(out)
    }
    case 'create_project': {
      const { data, error } = await db.from('folders').insert({ name: String(a.name), owner_id: ctx.userId, visibility: a.share_with_team === false ? 'private' : 'team' }).select('id,name').single()
      if (error) throw new Error('Project aanmaken mislukt')
      return ok(data)
    }
    case 'update_project': {
      const { data: f } = await db.from('folders').select('*').eq('id', String(a.project_id)).maybeSingle()
      if (!f || (f.owner_id !== ctx.userId && f.visibility !== 'team')) throw new Error('Project niet gevonden')
      const patch: Json = {}
      if (a.name) patch.name = String(a.name)
      if (a.share_with_team !== undefined) { if (f.owner_id !== ctx.userId) throw new Error('Alleen de eigenaar kan de zichtbaarheid aanpassen'); patch.visibility = a.share_with_team ? 'team' : 'private' }
      await db.from('folders').update(patch).eq('id', f.id)
      return ok('Project bijgewerkt')
    }
    case 'delete_project': {
      if (a.confirm !== true) throw new Error('Zet confirm op true, en alleen als de gebruiker dit expliciet vroeg')
      const { data: f } = await db.from('folders').select('*').eq('id', String(a.project_id)).maybeSingle()
      if (!f || f.owner_id !== ctx.userId) throw new Error('Je kunt alleen je eigen projecten verwijderen')
      await db.from('designs').update({ folder_id: null }).eq('folder_id', f.id)
      await db.from('folders').delete().eq('id', f.id)
      return ok('Project verwijderd; de ontwerpen staan nu zonder project')
    }
    case 'move_design': {
      const d = await loadDesign(String(a.design_id), ctx)
      if (a.project_id) { const { data: f } = await db.from('folders').select('id,owner_id,visibility').eq('id', String(a.project_id)).maybeSingle(); if (!f || (f.owner_id !== ctx.userId && f.visibility !== 'team')) throw new Error('Project niet gevonden') }
      await db.from('designs').update({ folder_id: a.project_id || null }).eq('id', d.id)
      return ok(a.project_id ? 'Verplaatst naar het project' : 'Uit het project gehaald')
    }

    /* ---------------- uploads */
    case 'update_asset': {
      const { data: as } = await db.from('assets').select('id,owner_id').eq('id', String(a.asset_id)).maybeSingle()
      if (!as || as.owner_id !== ctx.userId) throw new Error('Alleen je eigen uploads')
      const patch: Json = {}
      if (a.name) patch.name = String(a.name)
      if (a.shared !== undefined) patch.shared = !!a.shared
      await db.from('assets').update(patch).eq('id', as.id)
      return ok('Upload bijgewerkt')
    }
    case 'delete_asset': {
      if (a.confirm !== true) throw new Error('Zet confirm op true, en alleen als de gebruiker dit expliciet vroeg')
      const { data: as } = await db.from('assets').select('id,owner_id,path').eq('id', String(a.asset_id)).maybeSingle()
      if (!as || as.owner_id !== ctx.userId) throw new Error('Alleen je eigen uploads')
      await db.storage.from('assets').remove([as.path])
      await db.from('assets').delete().eq('id', as.id)
      return ok('Upload verwijderd')
    }

    /* ---------------- animatie */
    case 'set_animations': {
      const results: unknown[] = []
      for (const it of (Array.isArray(a.items) ? a.items as Json[] : [])) {
        try { await call('animate_element', { ...it, design_id: a.design_id }, ctx); results.push({ element_id: it.element_id, ok: true }) }
        catch (e) { results.push({ element_id: it.element_id, error: (e as Error).message }) }
      }
      return ok(results)
    }
    case 'clear_animations': {
      const id = String(a.design_id)
      const none = () => ({ in: { type: 'none', delay: 0, duration: 0.6 }, out: { type: 'none', delay: 0, duration: 0.5 }, emph: { type: 'none', speed: 1 } })
      await editDesign(id, ctx, (doc) => {
        if (a.element_id) findEl(doc, String(a.element_id)).el.anim = none()
        else for (const f of pickFrames(doc, String(a.frame_id || 'all'))) f.elements.forEach((e) => { e.anim = none() })
      })
      return ok('Animaties uitgezet')
    }
    case 'animation_preset': {
      const id = String(a.design_id), preset = String(a.preset)
      await editDesign(id, ctx, (doc) => {
        for (const f of pickFrames(doc, String(a.frame_id || 'all'))) {
          if (a.duration) f.duration = Math.max(1, Math.min(30, num(a.duration, f.duration)))
          const els = f.elements.filter((e) => e.visible)
          const big = (e: El) => e.width * e.height > f.w * f.h * 0.5
          const isCta = (e: El) => e.type === 'rect' && e.cornerRadius > 0 && e.width < f.w * 0.7 && e.height < f.h * 0.25
          const ctaText = (e: El) => e.type === 'text' && els.some((c) => isCta(c) && e.x + e.width / 2 > c.x && e.x + e.width / 2 < c.x + c.width && e.y + e.height / 2 > c.y && e.y + e.height / 2 < c.y + c.height)
          let step = 0
          const order = [...els].sort((p, q) => (big(q) ? 1 : 0) - (big(p) ? 1 : 0) || p.y - q.y)
          for (const e of order) {
            const an = { in: { type: 'none', delay: 0, duration: 0.6 }, out: { type: 'none', delay: 0, duration: 0.5 }, emph: { type: 'none', speed: 1 } }
            if (preset === 'stagger_up') an.in = big(e) ? { type: 'fade', delay: 0, duration: 0.5 } : { type: 'slideUp', delay: r1(0.15 + step++ * 0.18), duration: 0.6 }
            if (preset === 'fade_in') an.in = { type: 'fade', delay: r1(step++ * 0.12), duration: 0.7 }
            if (preset === 'pop_cta') {
              if (isCta(e) || ctaText(e)) { an.in = { type: 'pop', delay: 1.2, duration: 0.5 }; an.emph = { type: 'pulse', speed: 1 } }
              else an.in = big(e) ? { type: 'fade', delay: 0, duration: 0.4 } : { type: 'slideUp', delay: r1(0.1 + step++ * 0.2), duration: 0.6 }
            }
            if (preset === 'ken_burns') {
              if (e.type === 'image' && big(e)) { an.in = { type: 'zoomOut', delay: 0, duration: Math.max(1, f.duration - 0.2) } }
              else an.in = { type: 'fade', delay: r1(0.4 + step++ * 0.2), duration: 0.6 }
            }
            e.anim = an
          }
        }
      })
      return ok('Animatie ingesteld. Bekijk het resultaat met preview_animation.')
    }
    case 'preview_animation': {
      const row = await loadDesign(String(a.design_id), ctx)
      const f = pickFrames(row.data, String(a.frame_id))[0]
      const times = (Array.isArray(a.times) && a.times.length ? a.times as number[] : [0.3, 0.8, 1.5, f.duration / 2, f.duration]).slice(0, 8)
      const content: Json[] = [{ type: 'text', text: `Filmstrip van ${f.name} (${f.duration}s)` }]
      for (const t of times) content.push(...(await previewContent(row.id, ctx, { frame_id: f.id, time: t, size: num(a.size, 600), checks: false })))
      return { content }
    }
