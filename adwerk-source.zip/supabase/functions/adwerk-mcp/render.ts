// ===== SERVER-RENDER (begin) =====
// Rendert een formaat naar PNG zonder browser: SVG opbouwen (tekst als paden via opentype.js) en rasteren met resvg.
// Wordt gebruikt als niemand het ontwerp open heeft; anders levert de editor een pixel-exacte render.
import opentype from 'npm:opentype.js@1.3.4'
import { initWasm, Resvg } from 'npm:@resvg/resvg-wasm@2.6.2'

// deno-lint-ignore no-explicit-any
type AnyEl = Record<string, any>
// deno-lint-ignore no-explicit-any
type AnyFrame = { w: number; h: number; duration: number; background: { type: string; color: string; color2: string; angle: number; src?: string }; elements: AnyEl[] }

let wasm: Promise<void> | null = null
const ensureWasm = () => (wasm ??= initWasm(fetch('https://unpkg.com/@resvg/resvg-wasm@2.6.2/index_bg.wasm')))

/* ---------- fonts ---------- */
const fontCache = new Map<string, Promise<opentype.Font | null>>()
const WEIGHTS = [100, 200, 300, 400, 500, 600, 700, 800, 900]
async function fetchFont(family: string, weight: number, italic: boolean): Promise<opentype.Font | null> {
  const key = `${family}|${weight}|${italic}`
  if (!fontCache.has(key)) {
    fontCache.set(key, (async () => {
      const slug = family.toLowerCase().trim().replace(/\s+/g, '-')
      const r = await fetch(`https://cdn.jsdelivr.net/fontsource/fonts/${slug}@latest/latin-${weight}-${italic ? 'italic' : 'normal'}.woff`)
      if (!r.ok) return null
      return opentype.parse(await r.arrayBuffer())
    })().catch(() => null))
  }
  return fontCache.get(key)!
}
export async function loadFont(family: string, weight: number, italic: boolean): Promise<opentype.Font> {
  const order = [...WEIGHTS].sort((a, b) => Math.abs(a - weight) - Math.abs(b - weight) || b - a)
  for (const fam of [family, 'Poppins']) {
    for (const it of italic ? [true, false] : [false]) {
      for (const w of order.slice(0, 4)) { const f = await fetchFont(fam, w, it); if (f) return f }
    }
  }
  throw new Error('Lettertype niet beschikbaar')
}

/* ---------- beelden ---------- */
const imgCache = new Map<string, Promise<{ uri: string; w: number; h: number; svg: boolean } | null>>()
function dims(bytes: Uint8Array, type: string) {
  const dv = new DataView(bytes.buffer, bytes.byteOffset, bytes.byteLength)
  try {
    if (bytes[0] === 0x89 && bytes[1] === 0x50) return { w: dv.getUint32(16), h: dv.getUint32(20) }
    if (bytes[0] === 0x47 && bytes[1] === 0x49) return { w: dv.getUint16(6, true), h: dv.getUint16(8, true) }
    if (bytes[0] === 0xff && bytes[1] === 0xd8) {
      let i = 2
      while (i < bytes.length) {
        if (bytes[i] !== 0xff) { i++; continue }
        const m = bytes[i + 1], len = dv.getUint16(i + 2)
        if (m >= 0xc0 && m <= 0xcf && ![0xc4, 0xc8, 0xcc].includes(m)) return { h: dv.getUint16(i + 5), w: dv.getUint16(i + 7) }
        i += 2 + len
      }
    }
    if (String.fromCharCode(...bytes.slice(8, 12)) === 'WEBP') {
      const c = String.fromCharCode(...bytes.slice(12, 16))
      if (c === 'VP8X') return { w: 1 + (bytes[24] | (bytes[25] << 8) | (bytes[26] << 16)), h: 1 + (bytes[27] | (bytes[28] << 8) | (bytes[29] << 16)) }
      if (c === 'VP8L') { const b = dv.getUint32(21, true); return { w: (b & 0x3fff) + 1, h: ((b >> 14) & 0x3fff) + 1 } }
      if (c === 'VP8 ') return { w: dv.getUint16(26, true) & 0x3fff, h: dv.getUint16(28, true) & 0x3fff }
    }
    if (type.includes('svg')) {
      const t = new TextDecoder().decode(bytes.slice(0, 4000))
      const vb = t.match(/viewBox="\s*[-\d.]+[\s,]+[-\d.]+[\s,]+([\d.]+)[\s,]+([\d.]+)/)
      if (vb) return { w: +vb[1], h: +vb[2] }
    }
  } catch { /* onbekend */ }
  return { w: 1000, h: 1000 }
}
const b64 = (bytes: Uint8Array) => { let s = ''; for (let i = 0; i < bytes.length; i += 0x8000) s += String.fromCharCode(...bytes.subarray(i, i + 0x8000)); return btoa(s) }
function loadImg(src: string) {
  if (!imgCache.has(src)) {
    imgCache.set(src, (async () => {
      let bytes: Uint8Array, type: string
      if (src.startsWith('data:')) {
        const m = src.match(/^data:([^;,]+)(;base64)?,(.*)$/s)
        if (!m) return null
        type = m[1]
        bytes = m[2] ? Uint8Array.from(atob(m[3]), (c) => c.charCodeAt(0)) : new TextEncoder().encode(decodeURIComponent(m[3]))
      } else {
        const r = await fetch(src)
        if (!r.ok) return null
        type = (r.headers.get('content-type') || '').split(';')[0] || (src.endsWith('.svg') ? 'image/svg+xml' : 'image/png')
        bytes = new Uint8Array(await r.arrayBuffer())
      }
      if (/\.svg(\?|$)/i.test(src)) type = 'image/svg+xml'
      const d = dims(bytes, type)
      return { uri: `data:${type};base64,${b64(bytes)}`, w: d.w, h: d.h, svg: type.includes('svg') }
    })().catch(() => null))
  }
  return imgCache.get(src)!
}

async function iconifySvg(name: string): Promise<string | null> {
  try {
    const r = await fetch(`https://api.iconify.design/lucide/${name}.svg?height=256`)
    return r.ok ? await r.text() : null
  } catch { return null }
}

/* ---------- animatie (zelfde als de editor) ---------- */
interface St { dx: number; dy: number; scale: number; rotation: number; opacity: number }
const clamp01 = (v: number) => Math.max(0, Math.min(1, v))
const eoc = (t: number) => 1 - Math.pow(1 - t, 3)
const eob = (t: number) => { const c1 = 1.70158, c3 = c1 + 1; return 1 + c3 * Math.pow(t - 1, 3) + c1 * Math.pow(t - 1, 2) }
function inState(type: string, p: number, dist: number): St {
  const e = eoc(p), s: St = { dx: 0, dy: 0, scale: 1, rotation: 0, opacity: 1 }
  switch (type) {
    case 'fade': s.opacity = e; break
    case 'slideUp': s.dy = (1 - e) * dist; s.opacity = e; break
    case 'slideDown': s.dy = -(1 - e) * dist; s.opacity = e; break
    case 'slideLeft': s.dx = (1 - e) * dist; s.opacity = e; break
    case 'slideRight': s.dx = -(1 - e) * dist; s.opacity = e; break
    case 'zoomIn': s.scale = 0.6 + 0.4 * e; s.opacity = e; break
    case 'zoomOut': s.scale = 1.4 - 0.4 * e; s.opacity = e; break
    case 'pop': s.scale = Math.max(0, eob(p)); s.opacity = clamp01(p * 3); break
    case 'spin': s.rotation = -120 * (1 - e); s.scale = 0.3 + 0.7 * e; s.opacity = e; break
  }
  return s
}
function emph(type: string, t: number, speed: number): St {
  const s: St = { dx: 0, dy: 0, scale: 1, rotation: 0, opacity: 1 }, ph = (t * speed * Math.PI * 2) / 1.6
  if (type === 'pulse') s.scale = 1 + 0.06 * (0.5 - 0.5 * Math.cos(ph))
  if (type === 'wiggle') s.rotation = 4 * Math.sin(ph * 2)
  if (type === 'float') s.dy = -8 * (0.5 - 0.5 * Math.cos(ph))
  if (type === 'blink') s.opacity = 0.35 + 0.65 * (0.5 + 0.5 * Math.cos(ph))
  return s
}
function stateAt(el: AnyEl, f: AnyFrame, t: number): St {
  const a = el.anim, st: St = { dx: 0, dy: 0, scale: 1, rotation: 0, opacity: 1 }
  if (!a) return st
  const dist = Math.round(Math.min(f.w, f.h) * 0.18), parts: St[] = []
  let inEnd = 0
  if (a.in?.type !== 'none') { parts.push(inState(a.in.type, clamp01((t - a.in.delay) / Math.max(0.01, a.in.duration)), dist)); inEnd = a.in.delay + a.in.duration }
  if (a.emph?.type !== 'none' && t > inEnd) parts.push(emph(a.emph.type, t - inEnd, a.emph.speed || 1))
  if (a.out?.type !== 'none') { const start = f.duration - a.out.duration - a.out.delay, q = clamp01((t - start) / Math.max(0.01, a.out.duration)); if (q > 0) parts.push(inState(a.out.type, 1 - q, dist)) }
  for (const p of parts) { st.dx += p.dx; st.dy += p.dy; st.scale *= p.scale; st.rotation += p.rotation; st.opacity *= p.opacity }
  return st
}

/* ---------- tekst ---------- */
const esc = (s: string) => s.replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/"/g, '&quot;')
function advance(font: opentype.Font, s: string, fs: number, ls: number) {
  const glyphs = font.stringToGlyphs(s), k = fs / font.unitsPerEm
  let w = 0
  glyphs.forEach((g: opentype.Glyph, i: number) => { w += (g.advanceWidth || 0) * k + ls; if (i < glyphs.length - 1) w += font.getKerningValue(g, glyphs[i + 1]) * k })
  return w
}
function pathFor(font: opentype.Font, s: string, x: number, y: number, fs: number, ls: number) {
  const glyphs = font.stringToGlyphs(s), k = fs / font.unitsPerEm
  let d = '', cx = x
  glyphs.forEach((g: opentype.Glyph, i: number) => { d += g.getPath(cx, y, fs).toPathData(2); cx += (g.advanceWidth || 0) * k + ls; if (i < glyphs.length - 1) cx += font.getKerningValue(g, glyphs[i + 1]) * k })
  return d
}
/** Zelfde opmaak als het canvas: woordafbreking, regelafstand, uitlijning, en kleiner als één woord niet past. */
export async function layoutText(el: AnyEl) {
  const font = await loadFont(el.fontFamily || 'Poppins', el.fontWeight || 400, !!el.italic)
  const text = String(el.uppercase ? (el.text || '').toUpperCase() : el.text || '')
  const ls = el.letterSpacing || 0, w = el.width
  let fs = el.fontSize || 24
  const words = text.split(/\s+/).filter(Boolean)
  if (words.length) { const widest = Math.max(...words.map((x) => advance(font, x, fs, ls))); if (widest > w && w > 0) fs = Math.max(4, fs * (w / widest) * 0.98) }
  const lines: string[] = []
  for (const para of text.split('\n')) {
    let line = ''
    for (const word of para.split(' ')) {
      const test = line ? line + ' ' + word : word
      if (line && advance(font, test, fs, ls) > w) { lines.push(line); line = word } else line = test
    }
    lines.push(line)
  }
  const lh = fs * (el.lineHeight || 1.2)
  const mid = ((font.ascender + font.descender) / 2) * (fs / font.unitsPerEm)
  let d = '', under = ''
  lines.forEach((ln, i) => {
    const lw = advance(font, ln, fs, ls) - (ln ? ls : 0)
    const x = el.align === 'center' ? (w - lw) / 2 : el.align === 'right' ? w - lw : 0
    const base = lh * i + lh / 2 + mid
    d += pathFor(font, ln, x, base, fs, ls)
    if (el.underline && ln) under += `<rect x="${x.toFixed(1)}" y="${(base + fs * 0.12).toFixed(1)}" width="${lw.toFixed(1)}" height="${(fs * 0.06).toFixed(1)}"/>`
  })
  return { d, under, height: Math.ceil(lines.length * lh), fontSize: fs, lines }
}

/* ---------- formaat naar SVG ---------- */
function star(w: number, h: number, n: number, ratio: number) {
  const p: string[] = []
  for (let i = 0; i < n * 2; i++) { const r = i % 2 === 0 ? 1 : ratio, a = (Math.PI * i) / n - Math.PI / 2; p.push(`${(w / 2 + Math.cos(a) * (w / 2) * r).toFixed(2)},${(h / 2 + Math.sin(a) * (h / 2) * r).toFixed(2)}`) }
  return p.join(' ')
}
function cover(iw: number, ih: number, w: number, h: number, zoom = 1, fx = 0.5, fy = 0.5) {
  const s = Math.max(w / iw, h / ih) * Math.max(1, zoom), cw = w / s, ch = h / s
  return { x: (iw - cw) * clamp01(fx), y: (ih - ch) * clamp01(fy), w: cw, h: ch }
}

export async function frameSvg(f: AnyFrame, t: number | null = null) {
  let defs = '', body = '', uid = 0
  const id = () => `x${uid++}`
  const b = f.background
  if (b.type === 'gradient') {
    const a = ((b.angle || 0) * Math.PI) / 180, cx = f.w / 2, cy = f.h / 2, r = Math.abs((f.w / 2) * Math.cos(a)) + Math.abs((f.h / 2) * Math.sin(a))
    defs += `<linearGradient id="bg" gradientUnits="userSpaceOnUse" x1="${cx - Math.cos(a) * r}" y1="${cy - Math.sin(a) * r}" x2="${cx + Math.cos(a) * r}" y2="${cy + Math.sin(a) * r}"><stop offset="0" stop-color="${b.color}"/><stop offset="1" stop-color="${b.color2}"/></linearGradient>`
    body += `<rect width="${f.w}" height="${f.h}" fill="url(#bg)"/>`
  } else body += `<rect width="${f.w}" height="${f.h}" fill="${b.color || '#FFFFFF'}"/>`
  if (b.type === 'image' && b.src) {
    const im = await loadImg(b.src)
    if (im) { const c = cover(im.w, im.h, f.w, f.h); body += `<svg width="${f.w}" height="${f.h}" viewBox="${c.x} ${c.y} ${c.w} ${c.h}" preserveAspectRatio="none"><image width="${im.w}" height="${im.h}" href="${im.uri}"/></svg>` }
  }

  for (const el of f.elements) {
    if (el.visible === false) continue
    const w = el.width, st = t === null ? null : stateAt(el, f, t)
    let inner = '', h = el.height
    const fill = el.fill || '#000', stroke = el.strokeWidth > 0 ? ` stroke="${el.stroke}" stroke-width="${el.strokeWidth}"` : ''
    switch (el.type) {
      case 'text': {
        const L = await layoutText(el)
        h = L.height
        inner = `<path d="${L.d}" fill="${fill}"${stroke}/>${L.under ? `<g fill="${fill}">${L.under}</g>` : ''}`
        break
      }
      case 'ellipse': inner = `<ellipse cx="${w / 2}" cy="${h / 2}" rx="${w / 2}" ry="${h / 2}" fill="${fill}"${stroke}/>`; break
      case 'triangle': inner = `<polygon points="${w / 2},0 ${w},${h} 0,${h}" fill="${fill}"${stroke} stroke-linejoin="round"/>`; break
      case 'star': inner = `<polygon points="${star(w, h, el.points || 5, el.innerRatio || 0.45)}" fill="${fill}"${stroke} stroke-linejoin="round"/>`; break
      case 'image': {
        const m = el.mask || 'none', cid = id()
        const rr = Math.min(el.cornerRadius || 0, w / 2, h / 2)
        let clip = `<rect width="${w}" height="${h}" rx="${rr}"/>`
        if (m === 'circle') clip = `<circle cx="${w / 2}" cy="${h / 2}" r="${Math.min(w, h) / 2}"/>`
        if (m === 'oval') clip = `<ellipse cx="${w / 2}" cy="${h / 2}" rx="${w / 2}" ry="${h / 2}"/>`
        if (m === 'arch') { const r = Math.min(w / 2, h); clip = `<path d="M0 ${h} L0 ${r} A${w / 2} ${r} 0 0 1 ${w} ${r} L${w} ${h} Z"/>` }
        if (m === 'leaf') { const r = Math.min(w, h) * 0.45; clip = `<path d="M${r} 0 H${w} V${h - r} A${r} ${r} 0 0 1 ${w - r} ${h} H0 V${r} A${r} ${r} 0 0 1 ${r} 0 Z"/>` }
        if (m === 'blob') clip = `<ellipse cx="${w * 0.66}" cy="${h * 0.66}" rx="${w * 0.8}" ry="${h * 0.8}"/>`
        defs += `<clipPath id="${cid}">${clip}</clipPath>`
        const im = el.src ? await loadImg(el.src) : null
        if (im) {
          const c = cover(im.w, im.h, w, h, el.cropZoom, el.cropX ?? 0.5, el.cropY ?? 0.5)
          const flip = el.flipX || el.flipY ? ` transform="translate(${el.flipX ? w : 0} ${el.flipY ? h : 0}) scale(${el.flipX ? -1 : 1} ${el.flipY ? -1 : 1})"` : ''
          inner = `<g clip-path="url(#${cid})"><g${flip}><svg width="${w}" height="${h}" viewBox="${c.x} ${c.y} ${c.w} ${c.h}" preserveAspectRatio="none"><image width="${im.w}" height="${im.h}" href="${im.uri}"/></svg></g></g>`
        } else {
          const s = Math.max(16, Math.min(w, h) * 0.16)
          inner = `<g clip-path="url(#${cid})"><rect width="${w}" height="${h}" fill="${el.fill || '#D9D6E3'}"/></g><g transform="translate(${w / 2 - s / 2} ${h / 2 - s / 2}) scale(${s / 24})" fill="none" stroke="#fff" stroke-opacity=".75" stroke-width="1.6" stroke-linecap="round"><path d="M21 15l-5-5L5 21 M3 5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2v14a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z"/><circle cx="9" cy="9" r="2"/></g>`
        }
        break
      }
      case 'icon': {
        let svg: string | null = el.iconSvg || null
        if (!svg && el.icon) svg = await iconifySvg(el.icon)
        if (svg) {
          if (!el.iconMulti) svg = svg.replace(/currentColor/g, fill)
          inner = `<image width="${w}" height="${h}" href="data:image/svg+xml;base64,${b64(new TextEncoder().encode(svg))}"/>`
        }
        break
      }
      default: inner = `<rect width="${w}" height="${h}" rx="${Math.min(el.cornerRadius || 0, w / 2, h / 2)}" fill="${fill}"${stroke}/>`
    }
    const cx = el.x + w / 2 + (st?.dx || 0), cy = el.y + h / 2 + (st?.dy || 0)
    const rot = (el.rotation || 0) + (st?.rotation || 0), sc = st?.scale ?? 1, op = (el.opacity ?? 1) * (st?.opacity ?? 1)
    let filter = ''
    if (el.shadow?.enabled) {
      const fid = id(), s = el.shadow
      defs += `<filter id="${fid}" x="-50%" y="-50%" width="200%" height="200%"><feDropShadow dx="${s.x}" dy="${s.y}" stdDeviation="${s.blur / 2}" flood-color="${s.color}" flood-opacity="${s.opacity}"/></filter>`
      filter = ` filter="url(#${fid})"`
    }
    if (op <= 0.001) continue
    body += `<g transform="translate(${cx.toFixed(2)} ${cy.toFixed(2)}) rotate(${rot}) scale(${sc}) translate(${(-w / 2).toFixed(2)} ${(-h / 2).toFixed(2)})" opacity="${op}"${filter}>${inner}</g>`
  }
  return `<svg xmlns="http://www.w3.org/2000/svg" width="${f.w}" height="${f.h}" viewBox="0 0 ${f.w} ${f.h}"><defs><clipPath id="frame"><rect width="${f.w}" height="${f.h}"/></clipPath>${defs}</defs><g clip-path="url(#frame)">${body}</g></svg>`
}

export async function renderFramePng(f: AnyFrame, t: number | null, maxSide: number): Promise<Uint8Array> {
  await ensureWasm()
  const svg = await frameSvg(f, t)
  const scale = Math.min(2, maxSide / Math.max(f.w, f.h))
  const r = new Resvg(svg, { fitTo: { mode: 'zoom', value: scale }, font: { loadSystemFonts: false }, imageRendering: 0 })
  const png = r.render().asPng()
  r.free()
  return png
}
void esc
/** Toont een volledige (niet uitgesneden) foto met een raster van 10%, zodat de agent het focuspunt kan bepalen. */
export async function renderImageGrid(src: string, maxSide: number): Promise<{ png: Uint8Array; w: number; h: number }> {
  await ensureWasm()
  const im = await loadImg(src)
  if (!im) throw new Error('Afbeelding kon niet worden geladen')
  const W = im.w, H = im.h, sw = Math.max(1, Math.min(W, H) / 400), fs = Math.max(10, Math.min(W, H) / 32)
  let grid = ''
  for (let i = 1; i < 10; i++) {
    const x = (W * i) / 10, y = (H * i) / 10, strong = i === 5
    grid += `<line x1="${x}" y1="0" x2="${x}" y2="${H}" stroke="${strong ? '#FF2E88' : '#FFFFFF'}" stroke-opacity="${strong ? 0.9 : 0.55}" stroke-width="${sw}"/><line x1="0" y1="${y}" x2="${W}" y2="${y}" stroke="${strong ? '#FF2E88' : '#FFFFFF'}" stroke-opacity="${strong ? 0.9 : 0.55}" stroke-width="${sw}"/>`
  }
  const font = await loadFont('Poppins', 600, false)
  let labels = ''
  for (let i = 1; i < 10; i++) {
    const v = (i / 10).toFixed(1)
    labels += `<path d="${pathFor(font, v, (W * i) / 10 + fs * 0.2, fs * 1.1, fs, 0)}"/><path d="${pathFor(font, v, fs * 0.3, (H * i) / 10 - fs * 0.25, fs, 0)}"/>`
  }
  const svg = `<svg xmlns="http://www.w3.org/2000/svg" width="${W}" height="${H}" viewBox="0 0 ${W} ${H}"><image width="${W}" height="${H}" href="${im.uri}"/>${grid}<g fill="#FFFFFF" stroke="#000" stroke-opacity=".6" stroke-width="${sw * 2}" paint-order="stroke">${labels}</g></svg>`
  const r = new Resvg(svg, { fitTo: { mode: 'zoom', value: Math.min(1, maxSide / Math.max(W, H)) }, font: { loadSystemFonts: false } })
  const png = r.render().asPng()
  r.free()
  return { png, w: W, h: H }
}
export async function imageDims(src: string) { const im = await loadImg(src); return im ? { w: im.w, h: im.h } : null }
export { b64 }
// ===== SERVER-RENDER (einde) =====
