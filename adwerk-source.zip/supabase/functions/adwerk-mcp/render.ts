// ===== SERVER-RENDER (begin) =====
// Rendert een formaat naar PNG zonder browser: SVG opbouwen (tekst als paden via opentype.js) en rasteren met resvg.
// Wordt gebruikt als niemand het ontwerp open heeft; anders levert de editor een pixel-exacte render.
import opentype from 'npm:opentype.js@1.3.4'
import { initWasm, Resvg } from 'npm:@resvg/resvg-wasm@2.6.2'

// deno-lint-ignore no-explicit-any
type AnyEl = Record<string, any>
// deno-lint-ignore no-explicit-any
type AnyFrame = { w: number; h: number; duration: number; groups?: { id: string; name: string; anim?: AnyEl }[]; background: { type: string; color: string; color2: string; angle: number; src?: string }; elements: AnyEl[] }

let wasm: Promise<void> | null = null
const ensureWasm = () => (wasm ??= initWasm(fetch('https://unpkg.com/@resvg/resvg-wasm@2.6.2/index_bg.wasm')))

/* ---------- fonts ---------- */
const fontCache = new Map<string, Promise<opentype.Font | null>>()
const WEIGHTS = [100, 200, 300, 400, 500, 600, 700, 800, 900]
async function fetchFont(family: string, weight: number, italic: boolean): Promise<opentype.Font | null> {
  const key = `${family}|${weight}|${italic}`
  if (!fontCache.has(key)) {
    fontCache.set(key, (async () => {
      const slug = family.toLowerCase().trim().replace(/\s+/g, '-')
      const r = await fetch(`https://cdn.jsdelivr.net/fontsource/fonts/${slug}@latest/latin-${weight}-${italic ? 'italic' : 'normal'}.woff`)
      if (!r.ok) return null
      return opentype.parse(await r.arrayBuffer())
    })().catch(() => null))
  }
  return fontCache.get(key)!
}
export async function loadFont(family: string, weight: number, italic: boolean): Promise<opentype.Font> {
  const order = [...WEIGHTS].sort((a, b) => Math.abs(a - weight) - Math.abs(b - weight) || b - a)
  for (const fam of [family, 'Poppins']) {
    for (const it of italic ? [true, false] : [false]) {
      for (const w of order.slice(0, 4)) { const f = await fetchFont(fam, w, it); if (f) return f }
    }
  }
  throw new Error('Lettertype niet beschikbaar')
}

/* ---------- beelden ---------- */
const imgCache = new Map<string, Promise<{ uri: string; w: number; h: number; svg: boolean } | null>>()
function dims(bytes: Uint8Array, type: string) {
  const dv = new DataView(bytes.buffer, bytes.byteOffset, bytes.byteLength)
  try {
    if (bytes[0] === 0x89 && bytes[1] === 0x50) return { w: dv.getUint32(16), h: dv.getUint32(20) }
    if (bytes[0] === 0x47 && bytes[1] === 0x49) return { w: dv.getUint16(6, true), h: dv.getUint16(8, true) }
    if (bytes[0] === 0xff && bytes[1] === 0xd8) {
      let i = 2
      while (i < bytes.length) {
        if (bytes[i] !== 0xff) { i++; continue }
        const m = bytes[i + 1], len = dv.getUint16(i + 2)
        if (m >= 0xc0 && m <= 0xcf && ![0xc4, 0xc8, 0xcc].includes(m)) return { h: dv.getUint16(i + 5), w: dv.getUint16(i + 7) }
        i += 2 + len
      }
    }
    if (String.fromCharCode(...bytes.slice(8, 12)) === 'WEBP') {
      const c = String.fromCharCode(...bytes.slice(12, 16))
      if (c === 'VP8X') return { w: 1 + (bytes[24] | (bytes[25] << 8) | (bytes[26] << 16)), h: 1 + (bytes[27] | (bytes[28] << 8) | (bytes[29] << 16)) }
      if (c === 'VP8L') { const b = dv.getUint32(21, true); return { w: (b & 0x3fff) + 1, h: ((b >> 14) & 0x3fff) + 1 } }
      if (c === 'VP8 ') return { w: dv.getUint16(26, true) & 0x3fff, h: dv.getUint16(28, true) & 0x3fff }
    }
    if (type.includes('svg')) {
      const t = new TextDecoder().decode(bytes.slice(0, 4000))
      const vb = t.match(/viewBox="\s*[-\d.]+[\s,]+[-\d.]+[\s,]+([\d.]+)[\s,]+([\d.]+)/)
      if (vb) return { w: +vb[1], h: +vb[2] }
    }
  } catch { /* onbekend */ }
  return { w: 1000, h: 1000 }
}

/* ---------- data-URL's en svg's robuust lezen ---------- */
export function parseDataUrl(src: string): { type: string; bytes: Uint8Array } | null {
  const i = src.indexOf(',')
  if (!src.startsWith('data:') || i < 0) return null
  const meta = src.slice(5, i), body = src.slice(i + 1)
  const type = (meta.split(';')[0] || 'text/plain').trim().toLowerCase()
  if (/;base64/i.test(meta)) { try { return { type, bytes: Uint8Array.from(atob(body.replace(/\s+/g, '')), (c) => c.charCodeAt(0)) } } catch { return null } }
  let text: string
  try { text = decodeURIComponent(body) } catch { text = body }
  return { type, bytes: new TextEncoder().encode(text) }
}
export function normalizeSvg(text: string, longSide?: number): { svg: string; w: number; h: number } | null {
  let s = text.replace(/^﻿/, '').trim()
  const start = s.search(/<svg[\s>]/i)
  if (start < 0) return null
  s = s.slice(start)
  s = s.replace(/<script[\s\S]*?<\/script>/gi, '').replace(/\son[a-z]+\s*=\s*("[^"]*"|'[^']*')/gi, '')
  const open = s.match(/<svg\b[^>]*>/i)
  if (!open) return null
  let tag = open[0]
  const attr = (n: string) => { const m = tag.match(new RegExp(`\\s${n}\\s*=\\s*("([^"]*)"|'([^']*)')`, 'i')); return m ? (m[2] ?? m[3]) : null }
  const num = (v: string | null) => { if (!v || /%$/.test(v.trim())) return 0; const n = parseFloat(v); if (!isFinite(n) || n <= 0) return 0; const u = v.trim().replace(/^[-+]?[\d.]+(e[-+]?\d+)?/i, '').trim().toLowerCase(); return n * ({ pt: 4 / 3, pc: 16, mm: 3.7795, cm: 37.795, in: 96, em: 16, rem: 16 } as Record<string, number>)[u] || n }
  const vb = (attr('viewBox') || '').trim().split(/[\s,]+/).map(Number)
  const hasVb = vb.length === 4 && vb.every(isFinite) && vb[2] > 0 && vb[3] > 0
  let w = num(attr('width')), h = num(attr('height'))
  if (hasVb) { if (!w && !h) { w = vb[2]; h = vb[3] } else if (!w) w = h * vb[2] / vb[3]; else if (!h) h = w * vb[3] / vb[2] }
  if (!w || !h) { w = w || 1000; h = h || 1000 }
  const strip = (n: string) => { tag = tag.replace(new RegExp(`\\s${n}\\s*=\\s*("[^"]*"|'[^']*')`, 'i'), '') }
  strip('width'); strip('height')
  const extra: string[] = []
  if (!hasVb) extra.push(`viewBox="0 0 ${+w.toFixed(3)} ${+h.toFixed(3)}"`)
  if (!/\sxmlns\s*=/.test(tag)) extra.push('xmlns="http://www.w3.org/2000/svg"')
  if (/xlink:/.test(s) && !/xmlns:xlink/.test(tag)) extra.push('xmlns:xlink="http://www.w3.org/1999/xlink"')
  const k = longSide ? longSide / Math.max(w, h) : 1
  const W = Math.round(w * k * 100) / 100, H = Math.round(h * k * 100) / 100
  if (!/\spreserveAspectRatio\s*=/.test(tag) && !hasVb) extra.push('preserveAspectRatio="xMidYMid meet"')
  tag = tag.replace(/^<svg\b/i, `<svg width="${W}" height="${H}" ${extra.join(' ')}`).replace(/\s+>$/, '>').replace(/\s{2,}/g, ' ')
  s = s.replace(open[0], tag)
  return { svg: s, w, h }
}


const b64 = (bytes: Uint8Array) => { let s = ''; for (let i = 0; i < bytes.length; i += 0x8000) s += String.fromCharCode(...bytes.subarray(i, i + 0x8000)); return btoa(s) }
function loadImg(src: string) {
  if (!imgCache.has(src)) {
    imgCache.set(src, (async () => {
      let bytes: Uint8Array, type: string
      if (src.startsWith('data:')) {
        const d = parseDataUrl(src)
        if (!d) return null
        type = d.type; bytes = d.bytes
      } else {
        const r = await fetch(src)
        if (!r.ok) return null
        type = (r.headers.get('content-type') || '').split(';')[0] || (src.endsWith('.svg') ? 'image/svg+xml' : 'image/png')
        bytes = new Uint8Array(await r.arrayBuffer())
      }
      if (/\.svg(\?|$)/i.test(src) || /^\s*(<\?xml|<svg)/i.test(new TextDecoder().decode(bytes.slice(0, 200)))) type = 'image/svg+xml'
      if (type.includes('svg')) { const n = normalizeSvg(new TextDecoder().decode(bytes)); if (n) { bytes = new TextEncoder().encode(n.svg); return { uri: `data:image/svg+xml;base64,${b64(bytes)}`, w: n.w, h: n.h, svg: true } } }
      const d = dims(bytes, type)
      return { uri: `data:${type};base64,${b64(bytes)}`, w: d.w, h: d.h, svg: type.includes('svg') }
    })().catch(() => null))
  }
  return imgCache.get(src)!
}

async function iconifySvg(name: string): Promise<string | null> {
  try {
    const r = await fetch(`https://api.iconify.design/lucide/${name}.svg?height=256`)
    return r.ok ? await r.text() : null
  } catch { return null }
}

/* ---------- animatie (zelfde als de editor) ---------- */
interface St { dx: number; dy: number; scale: number; rotation: number; opacity: number }
const clamp01 = (v: number) => Math.max(0, Math.min(1, v))
const eoc = (t: number) => 1 - Math.pow(1 - t, 3)
const eob = (t: number) => { const c1 = 1.70158, c3 = c1 + 1; return 1 + c3 * Math.pow(t - 1, 3) + c1 * Math.pow(t - 1, 2) }
function inState(type: string, p: number, dist: number): St {
  const e = eoc(p), s: St = { dx: 0, dy: 0, scale: 1, rotation: 0, opacity: 1 }
  switch (type) {
    case 'fade': s.opacity = e; break
    case 'slideUp': s.dy = (1 - e) * dist; s.opacity = e; break
    case 'slideDown': s.dy = -(1 - e) * dist; s.opacity = e; break
    case 'slideLeft': s.dx = (1 - e) * dist; s.opacity = e; break
    case 'slideRight': s.dx = -(1 - e) * dist; s.opacity = e; break
    case 'zoomIn': s.scale = 0.6 + 0.4 * e; s.opacity = e; break
    case 'zoomOut': s.scale = 1.4 - 0.4 * e; s.opacity = e; break
    case 'pop': s.scale = Math.max(0, eob(p)); s.opacity = clamp01(p * 3); break
    case 'spin': s.rotation = -120 * (1 - e); s.scale = 0.3 + 0.7 * e; s.opacity = e; break
  }
  return s
}
function emph(type: string, t: number, speed: number): St {
  const s: St = { dx: 0, dy: 0, scale: 1, rotation: 0, opacity: 1 }, ph = (t * speed * Math.PI * 2) / 1.6
  if (type === 'pulse') s.scale = 1 + 0.06 * (0.5 - 0.5 * Math.cos(ph))
  if (type === 'wiggle') s.rotation = 4 * Math.sin(ph * 2)
  if (type === 'float') s.dy = -8 * (0.5 - 0.5 * Math.cos(ph))
  if (type === 'blink') s.opacity = 0.35 + 0.65 * (0.5 + 0.5 * Math.cos(ph))
  return s
}
function stateAt(el: AnyEl, f: AnyFrame, t: number): St { return animAt(el.anim, f, t) }
// deno-lint-ignore no-explicit-any
function animAt(a: any, f: AnyFrame, t: number): St {
  const st: St = { dx: 0, dy: 0, scale: 1, rotation: 0, opacity: 1 }
  if (!a) return st
  const dist = Math.round(Math.min(f.w, f.h) * 0.18), parts: St[] = []
  let inEnd = 0
  if (a.in?.type !== 'none') { parts.push(inState(a.in.type, clamp01((t - a.in.delay) / Math.max(0.01, a.in.duration)), dist)); inEnd = a.in.delay + a.in.duration }
  if (a.emph?.type !== 'none' && t > inEnd) parts.push(emph(a.emph.type, t - inEnd, a.emph.speed || 1))
  if (a.out?.type !== 'none') { const start = f.duration - a.out.duration - a.out.delay, q = clamp01((t - start) / Math.max(0.01, a.out.duration)); if (q > 0) parts.push(inState(a.out.type, 1 - q, dist)) }
  for (const p of parts) { st.dx += p.dx; st.dy += p.dy; st.scale *= p.scale; st.rotation += p.rotation; st.opacity *= p.opacity }
  return st
}

/* ---------- tekst ---------- */
const esc = (s: string) => s.replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/"/g, '&quot;')
function advance(font: opentype.Font, s: string, fs: number, ls: number) {
  const glyphs = font.stringToGlyphs(s), k = fs / font.unitsPerEm
  let w = 0
  glyphs.forEach((g: opentype.Glyph, i: number) => { w += (g.advanceWidth || 0) * k + ls; if (i < glyphs.length - 1) w += font.getKerningValue(g, glyphs[i + 1]) * k })
  return w
}
function pathFor(font: opentype.Font, s: string, x: number, y: number, fs: number, ls: number) {
  const glyphs = font.stringToGlyphs(s), k = fs / font.unitsPerEm
  let d = '', cx = x
  glyphs.forEach((g: opentype.Glyph, i: number) => { d += g.getPath(cx, y, fs).toPathData(2); cx += (g.advanceWidth || 0) * k + ls; if (i < glyphs.length - 1) cx += font.getKerningValue(g, glyphs[i + 1]) * k })
  return d
}
/* ---------- tekst met opmaak per stukje (zelfde regels als de app) ---------- */
export type Run = { t: string; b?: 1 | 0; i?: 1 | 0; u?: 1 | 0; c?: string }
const runKey = (r: Run) => `${r.b ?? ''}|${r.i ?? ''}|${r.u ?? ''}|${r.c || ''}`
export function normalizeRuns(runs?: Run[]): Run[] | undefined {
  if (!runs?.length) return undefined
  const out: Run[] = []
  for (const r of runs) {
    if (!r?.t) continue
    const c: Run = { t: String(r.t) }
    if (r.b !== undefined && r.b !== null) c.b = r.b ? 1 : 0
    if (r.i !== undefined && r.i !== null) c.i = r.i ? 1 : 0
    if (r.u !== undefined && r.u !== null) c.u = r.u ? 1 : 0
    if (r.c) c.c = String(r.c).toUpperCase()
    const last = out[out.length - 1]
    if (last && runKey(last) === runKey(c)) last.t += c.t; else out.push(c)
  }
  if (!out.length || out.every((r) => runKey(r) === '|||')) return undefined
  return out
}
function charStyles(text: string, runs?: Run[]): Omit<Run, 't'>[] {
  const out: Omit<Run, 't'>[] = []
  if (runs) for (const r of runs) for (let k = 0; k < r.t.length; k++) { const { t: _t, ...st } = r; out.push(st) }
  while (out.length < text.length) out.push({})
  return out.slice(0, text.length)
}
export function remapRuns(oldText: string, newText: string, runs?: Run[]): Run[] | undefined {
  if (!runs || oldText === newText) return runs
  const st = charStyles(oldText, runs)
  let p = 0
  while (p < oldText.length && p < newText.length && oldText[p] === newText[p]) p++
  let s = 0
  while (s < oldText.length - p && s < newText.length - p && oldText[oldText.length - 1 - s] === newText[newText.length - 1 - s]) s++
  const inherit = st[p - 1] || st[p] || {}
  const next = [...st.slice(0, p), ...Array(newText.length - p - s).fill(inherit), ...st.slice(oldText.length - s)]
  return normalizeRuns(newText.split('').map((ch, k) => ({ t: ch, ...next[k] })))
}
export function applyRunStyle(text: string, runs: Run[] | undefined, start: number, end: number, patch: { b?: boolean | null; i?: boolean | null; u?: boolean | null; c?: string | null }): Run[] | undefined {
  const st = charStyles(text, runs).map((x, k) => {
    if (k < start || k >= end) return x
    const n = { ...x }
    for (const key of ['b', 'i', 'u'] as const) if (key in patch) { const v = patch[key]; if (v === null || v === undefined) delete n[key]; else n[key] = v ? 1 : 0 }
    if ('c' in patch) { if (patch.c) n.c = String(patch.c).toUpperCase(); else delete n.c }
    return n
  })
  return normalizeRuns(text.split('').map((ch, k) => ({ t: ch, ...st[k] })))
}
function textSegments(text: string, runs?: Run[]): Run[] {
  if (!runs?.length) return [{ t: text }]
  const joined = runs.map((r) => r.t).join('')
  return joined === text ? runs : remapRuns(joined, text, runs) || [{ t: text }]
}
const runWeight = (base: number, r: Omit<Run, 't'>) => (r.b === undefined ? base : r.b ? Math.min(900, Math.max(700, base + 200)) : Math.min(base, 400))

/** Zelfde opmaak als het canvas: woordafbreking, regelafstand, uitlijning, kleiner als één woord niet past, en opmaak per woord. */
export async function layoutText(el: AnyEl) {
  const base = el.fontWeight || 400, fam = el.fontFamily || 'Poppins'
  const ls = el.letterSpacing || 0, W = el.width
  const up = (x: string) => (el.uppercase ? x.toUpperCase() : x)
  const styleOf = (r: Run) => ({ weight: runWeight(base, r), italic: r.i === undefined ? !!el.italic : !!r.i, underline: r.u === undefined ? !!el.underline : !!r.u, color: r.c || el.fill || '#000' })
  const fonts = new Map<string, opentype.Font>()
  const fontFor = async (r: Run) => { const s = styleOf(r); const k = `${s.weight}|${s.italic}`; if (!fonts.has(k)) fonts.set(k, await loadFont(fam, s.weight, s.italic)); return fonts.get(k)! }
  type Tok = { kind: 'word' | 'space' | 'nl'; parts: { t: string; r: Run; f: opentype.Font }[] }
  const toks: Tok[] = []
  for (const r of textSegments(String(el.text || ''), el.runs as Run[] | undefined)) {
    const f = await fontFor(r)
    for (const m of r.t.match(/\n| +|[^ \n]+/g) || []) {
      const kind = m === '\n' ? 'nl' : m[0] === ' ' ? 'space' : 'word'
      const last = toks[toks.length - 1]
      if (kind === 'word' && last?.kind === 'word') last.parts.push({ t: m, r, f }); else toks.push({ kind, parts: [{ t: m, r, f }] })
    }
  }
  const tokW = (k: Tok, fs: number) => k.parts.reduce((a, p) => a + advance(p.f, up(p.t), fs, ls), 0)
  let fs = el.fontSize || 24
  const widest = Math.max(0, ...toks.filter((k) => k.kind === 'word').map((k) => tokW(k, fs)))
  if (widest > W && W > 0) fs = Math.max(4, fs * (W / widest) * 0.98)
  type Piece = { t: string; x: number; w: number; f: opentype.Font; r: Run }
  const lines: { pieces: Piece[]; width: number }[] = []
  let cur: { pieces: Piece[]; width: number } = { pieces: [], width: 0 }
  let space: Tok | null = null
  const push = (k: Tok) => { for (const p of k.parts) { const w = advance(p.f, up(p.t), fs, ls); cur.pieces.push({ t: up(p.t), x: cur.width, w, f: p.f, r: p.r }); cur.width += w } }
  for (const k of toks) {
    if (k.kind === 'nl') { lines.push(cur); cur = { pieces: [], width: 0 }; space = null; continue }
    if (k.kind === 'space') { if (cur.pieces.length) space = k; continue }
    const ww = tokW(k, fs), sw = space ? tokW(space, fs) : 0
    if (cur.pieces.length && cur.width + sw + ww > W + 0.5) { lines.push(cur); cur = { pieces: [], width: 0 } } else if (space) push(space)
    space = null
    push(k)
  }
  lines.push(cur)
  const lh = fs * (el.lineHeight || 1.2)
  // per kleur één pad, zodat de SVG compact blijft
  const byColor = new Map<string, { d: string; under: string }>()
  lines.forEach((ln, i) => {
    const x0 = el.align === 'center' ? (W - ln.width) / 2 : el.align === 'right' ? W - ln.width : 0
    for (const p of ln.pieces) {
      const s = styleOf(p.r)
      const mid = ((p.f.ascender + p.f.descender) / 2) * (fs / p.f.unitsPerEm)
      const y = lh * i + lh / 2 + mid
      const o = byColor.get(s.color) || { d: '', under: '' }
      o.d += pathFor(p.f, p.t, x0 + p.x, y, fs, ls)
      if (s.underline) o.under += `<rect x="${(x0 + p.x).toFixed(1)}" y="${(y + fs * 0.12).toFixed(1)}" width="${p.w.toFixed(1)}" height="${(fs * 0.06).toFixed(1)}"/>`
      byColor.set(s.color, o)
    }
  })
  const fills = [...byColor.entries()].map(([color, o]) => ({ color, ...o }))
  return { fills, d: fills.map((x) => x.d).join(''), height: Math.ceil(lines.length * lh), fontSize: fs, lines: lines.map((l) => l.pieces.map((p) => p.t).join('')) }
}

/* ---------- formaat naar SVG ---------- */
function star(w: number, h: number, n: number, ratio: number) {
  const p: string[] = []
  for (let i = 0; i < n * 2; i++) { const r = i % 2 === 0 ? 1 : ratio, a = (Math.PI * i) / n - Math.PI / 2; p.push(`${(w / 2 + Math.cos(a) * (w / 2) * r).toFixed(2)},${(h / 2 + Math.sin(a) * (h / 2) * r).toFixed(2)}`) }
  return p.join(' ')
}
function cover(iw: number, ih: number, w: number, h: number, zoom = 1, fx = 0.5, fy = 0.5) {
  const s = Math.max(w / iw, h / ih) * Math.max(1, zoom), cw = w / s, ch = h / s
  return { x: (iw - cw) * clamp01(fx), y: (ih - ch) * clamp01(fy), w: cw, h: ch }
}

export async function frameSvg(f: AnyFrame, t: number | null = null) {
  let defs = '', body = '', uid = 0
  const id = () => `x${uid++}`
  const b = f.background
  if (b.type === 'gradient') {
    const a = ((b.angle || 0) * Math.PI) / 180, cx = f.w / 2, cy = f.h / 2, r = Math.abs((f.w / 2) * Math.cos(a)) + Math.abs((f.h / 2) * Math.sin(a))
    defs += `<linearGradient id="bg" gradientUnits="userSpaceOnUse" x1="${cx - Math.cos(a) * r}" y1="${cy - Math.sin(a) * r}" x2="${cx + Math.cos(a) * r}" y2="${cy + Math.sin(a) * r}"><stop offset="0" stop-color="${b.color}"/><stop offset="1" stop-color="${b.color2}"/></linearGradient>`
    body += `<rect width="${f.w}" height="${f.h}" fill="url(#bg)"/>`
  } else body += `<rect width="${f.w}" height="${f.h}" fill="${b.color || '#FFFFFF'}"/>`
  if (b.type === 'image' && b.src) {
    const im = await loadImg(b.src)
    if (im) { const c = cover(im.w, im.h, f.w, f.h); body += `<svg width="${f.w}" height="${f.h}" viewBox="${c.x} ${c.y} ${c.w} ${c.h}" preserveAspectRatio="none"><image width="${im.w}" height="${im.h}" href="${im.uri}"/></svg>` }
  }

  // groepen met een eigen animatie: draaipunt = midden van de groep
  const gstate = new Map<string, { s: St; px: number; py: number }>()
  if (t !== null) for (const g of (f.groups || [])) {
    if (!g.anim) continue
    const m = f.elements.filter((e) => e.groupId === g.id)
    if (!m.length) continue
    const x0 = Math.min(...m.map((e) => e.x)), y0 = Math.min(...m.map((e) => e.y)), x1 = Math.max(...m.map((e) => e.x + e.width)), y1 = Math.max(...m.map((e) => e.y + e.height))
    gstate.set(g.id, { s: animAt(g.anim, f, t), px: (x0 + x1) / 2, py: (y0 + y1) / 2 })
  }
  for (const el of f.elements) {
    if (el.visible === false) continue
    const w = el.width, st = t === null ? null : stateAt(el, f, t)
    let inner = '', h = el.height
    const fill = el.fill || '#000', stroke = el.strokeWidth > 0 ? ` stroke="${el.stroke}" stroke-width="${el.strokeWidth}"` : ''
    switch (el.type) {
      case 'text': {
        const L = await layoutText(el)
        h = L.height
        inner = L.fills.map((x) => `<path d="${x.d}" fill="${x.color}"${stroke}/>${x.under ? `<g fill="${x.color}">${x.under}</g>` : ''}`).join('')
        break
      }
      case 'ellipse': inner = `<ellipse cx="${w / 2}" cy="${h / 2}" rx="${w / 2}" ry="${h / 2}" fill="${fill}"${stroke}/>`; break
      case 'triangle': inner = `<polygon points="${w / 2},0 ${w},${h} 0,${h}" fill="${fill}"${stroke} stroke-linejoin="round"/>`; break
      case 'star': inner = `<polygon points="${star(w, h, el.points || 5, el.innerRatio || 0.45)}" fill="${fill}"${stroke} stroke-linejoin="round"/>`; break
      case 'image': {
        const m = el.mask || 'none', cid = id()
        const rr = Math.min(el.cornerRadius || 0, w / 2, h / 2)
        let clip = `<rect width="${w}" height="${h}" rx="${rr}"/>`
        if (m === 'circle') clip = `<circle cx="${w / 2}" cy="${h / 2}" r="${Math.min(w, h) / 2}"/>`
        if (m === 'oval') clip = `<ellipse cx="${w / 2}" cy="${h / 2}" rx="${w / 2}" ry="${h / 2}"/>`
        if (m === 'arch') { const r = Math.min(w / 2, h); clip = `<path d="M0 ${h} L0 ${r} A${w / 2} ${r} 0 0 1 ${w} ${r} L${w} ${h} Z"/>` }
        if (m === 'leaf') { const r = Math.min(w, h) * 0.45; clip = `<path d="M${r} 0 H${w} V${h - r} A${r} ${r} 0 0 1 ${w - r} ${h} H0 V${r} A${r} ${r} 0 0 1 ${r} 0 Z"/>` }
        if (m === 'blob') clip = `<ellipse cx="${w * 0.66}" cy="${h * 0.66}" rx="${w * 0.8}" ry="${h * 0.8}"/>`
        defs += `<clipPath id="${cid}">${clip}</clipPath>`
        const im = el.src ? await loadImg(el.src) : null
        if (im) {
          const c = cover(im.w, im.h, w, h, el.cropZoom, el.cropX ?? 0.5, el.cropY ?? 0.5)
          const flip = el.flipX || el.flipY ? ` transform="translate(${el.flipX ? w : 0} ${el.flipY ? h : 0}) scale(${el.flipX ? -1 : 1} ${el.flipY ? -1 : 1})"` : ''
          inner = `<g clip-path="url(#${cid})"><g${flip}><svg width="${w}" height="${h}" viewBox="${c.x} ${c.y} ${c.w} ${c.h}" preserveAspectRatio="none"><image width="${im.w}" height="${im.h}" href="${im.uri}"/></svg></g></g>`
        } else {
          const s = Math.max(16, Math.min(w, h) * 0.16)
          inner = `<g clip-path="url(#${cid})"><rect width="${w}" height="${h}" fill="${el.fill || '#D9D6E3'}"/></g><g transform="translate(${w / 2 - s / 2} ${h / 2 - s / 2}) scale(${s / 24})" fill="none" stroke="#fff" stroke-opacity=".75" stroke-width="1.6" stroke-linecap="round"><path d="M21 15l-5-5L5 21 M3 5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2v14a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z"/><circle cx="9" cy="9" r="2"/></g>`
        }
        break
      }
      case 'icon': {
        let svg: string | null = el.iconSvg || null
        if (!svg && el.icon) svg = await iconifySvg(el.icon)
        if (svg) {
          if (!el.iconMulti) svg = svg.replace(/currentColor/g, fill)
          inner = `<image width="${w}" height="${h}" href="data:image/svg+xml;base64,${b64(new TextEncoder().encode(svg))}"/>`
        }
        break
      }
      default: inner = `<rect width="${w}" height="${h}" rx="${Math.min(el.cornerRadius || 0, w / 2, h / 2)}" fill="${fill}"${stroke}/>`
    }
    let cx = el.x + w / 2 + (st?.dx || 0), cy = el.y + h / 2 + (st?.dy || 0)
    let rot = (el.rotation || 0) + (st?.rotation || 0), sc = st?.scale ?? 1, op = (el.opacity ?? 1) * (st?.opacity ?? 1)
    const gs = el.groupId ? gstate.get(el.groupId) : undefined
    if (gs) {
      const r = (gs.s.rotation * Math.PI) / 180, vx = (cx - gs.px) * gs.s.scale, vy = (cy - gs.py) * gs.s.scale
      cx = gs.px + vx * Math.cos(r) - vy * Math.sin(r) + gs.s.dx; cy = gs.py + vx * Math.sin(r) + vy * Math.cos(r) + gs.s.dy
      sc *= gs.s.scale; rot += gs.s.rotation; op *= gs.s.opacity
    }
    let filter = ''
    if (el.shadow?.enabled) {
      const fid = id(), s = el.shadow
      defs += `<filter id="${fid}" x="-50%" y="-50%" width="200%" height="200%"><feDropShadow dx="${s.x}" dy="${s.y}" stdDeviation="${s.blur / 2}" flood-color="${s.color}" flood-opacity="${s.opacity}"/></filter>`
      filter = ` filter="url(#${fid})"`
    }
    if (op <= 0.001) continue
    body += `<g transform="translate(${cx.toFixed(2)} ${cy.toFixed(2)}) rotate(${rot}) scale(${sc}) translate(${(-w / 2).toFixed(2)} ${(-h / 2).toFixed(2)})" opacity="${op}"${filter}>${inner}</g>`
  }
  return `<svg xmlns="http://www.w3.org/2000/svg" width="${f.w}" height="${f.h}" viewBox="0 0 ${f.w} ${f.h}"><defs><clipPath id="frame"><rect width="${f.w}" height="${f.h}"/></clipPath>${defs}</defs><g clip-path="url(#frame)">${body}</g></svg>`
}

export async function renderFramePng(f: AnyFrame, t: number | null, maxSide: number): Promise<Uint8Array> {
  await ensureWasm()
  const svg = await frameSvg(f, t)
  const scale = Math.min(2, maxSide / Math.max(f.w, f.h))
  const r = new Resvg(svg, { fitTo: { mode: 'zoom', value: scale }, font: { loadSystemFonts: false }, imageRendering: 0 })
  const png = r.render().asPng()
  r.free()
  return png
}
void esc
/** Toont een volledige (niet uitgesneden) foto met een raster van 10%, zodat de agent het focuspunt kan bepalen. */
export async function renderImageGrid(src: string, maxSide: number): Promise<{ png: Uint8Array; w: number; h: number }> {
  await ensureWasm()
  const im = await loadImg(src)
  if (!im) throw new Error('Afbeelding kon niet worden geladen')
  const W = im.w, H = im.h, sw = Math.max(1, Math.min(W, H) / 400), fs = Math.max(10, Math.min(W, H) / 32)
  let grid = ''
  for (let i = 1; i < 10; i++) {
    const x = (W * i) / 10, y = (H * i) / 10, strong = i === 5
    grid += `<line x1="${x}" y1="0" x2="${x}" y2="${H}" stroke="${strong ? '#FF2E88' : '#FFFFFF'}" stroke-opacity="${strong ? 0.9 : 0.55}" stroke-width="${sw}"/><line x1="0" y1="${y}" x2="${W}" y2="${y}" stroke="${strong ? '#FF2E88' : '#FFFFFF'}" stroke-opacity="${strong ? 0.9 : 0.55}" stroke-width="${sw}"/>`
  }
  const font = await loadFont('Poppins', 600, false)
  let labels = ''
  for (let i = 1; i < 10; i++) {
    const v = (i / 10).toFixed(1)
    labels += `<path d="${pathFor(font, v, (W * i) / 10 + fs * 0.2, fs * 1.1, fs, 0)}"/><path d="${pathFor(font, v, fs * 0.3, (H * i) / 10 - fs * 0.25, fs, 0)}"/>`
  }
  const svg = `<svg xmlns="http://www.w3.org/2000/svg" width="${W}" height="${H}" viewBox="0 0 ${W} ${H}"><image width="${W}" height="${H}" href="${im.uri}"/>${grid}<g fill="#FFFFFF" stroke="#000" stroke-opacity=".6" stroke-width="${sw * 2}" paint-order="stroke">${labels}</g></svg>`
  const r = new Resvg(svg, { fitTo: { mode: 'zoom', value: Math.min(1, maxSide / Math.max(W, H)) }, font: { loadSystemFonts: false } })
  const png = r.render().asPng()
  r.free()
  return { png, w: W, h: H }
}
export async function imageDims(src: string) { const im = await loadImg(src); return im ? { w: im.w, h: im.h } : null }
export { b64 }
// ===== SERVER-RENDER (einde) =====

/** Probeert een svg te rasteren; geeft een foutmelding terug als dat niet lukt. */
export async function checkSvg(svg: string): Promise<string | null> {
  await ensureWasm()
  try { const r = new Resvg(svg, { fitTo: { mode: 'width', value: 64 }, font: { loadSystemFonts: false } }); r.render().asPng(); return null } catch (e) { return String((e as Error)?.message || e).slice(0, 200) }
}
