// Adwerk brand-scan: haalt van een website de huisstijl op (kleuren, lettertypes, logo's, beelden).
// Ook een kleine beeld-proxy, zodat logo's van andere sites in Adwerk opgeslagen kunnen worden.
const CORS = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
  'Access-Control-Allow-Methods': 'POST, OPTIONS',
}
const UA = 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0 Safari/537.36 AdwerkBrandScan/1.0'

const json = (b: unknown, status = 200) => new Response(JSON.stringify(b), { status, headers: { ...CORS, 'Content-Type': 'application/json' } })

function safeUrl(u: string, base?: string): URL | null {
  try {
    const x = new URL(u, base)
    if (!/^https?:$/.test(x.protocol)) return null
    if (/^(localhost|127\.|10\.|192\.168\.|169\.254\.|0\.|\[)/.test(x.hostname)) return null
    return x
  } catch { return null }
}

async function get(u: URL, accept = 'text/html,*/*', max = 3_000_000): Promise<Response | null> {
  try {
    const r = await fetch(u, { headers: { 'User-Agent': UA, Accept: accept, 'Accept-Language': 'nl-NL,nl;q=0.9,en;q=0.8' }, redirect: 'follow', signal: AbortSignal.timeout(12000) })
    if (!r.ok) return null
    const len = Number(r.headers.get('content-length') || 0)
    if (len > max) return null
    return r
  } catch { return null }
}

const toHex = (r: number, g: number, b: number) => '#' + [r, g, b].map((v) => Math.max(0, Math.min(255, Math.round(v))).toString(16).padStart(2, '0')).join('').toUpperCase()
function normHex(h: string) {
  h = h.replace('#', '')
  if (h.length === 3 || h.length === 4) h = h.slice(0, 3).split('').map((c) => c + c).join('')
  return '#' + h.slice(0, 6).toUpperCase()
}
function sat(hex: string) {
  const [r, g, b] = [1, 3, 5].map((i) => parseInt(hex.slice(i, i + 2), 16) / 255)
  const mx = Math.max(r, g, b), mn = Math.min(r, g, b)
  return { s: mx === 0 ? 0 : (mx - mn) / mx, l: (mx + mn) / 2 }
}
function dist(a: string, b: string) {
  const pa = [1, 3, 5].map((i) => parseInt(a.slice(i, i + 2), 16)), pb = [1, 3, 5].map((i) => parseInt(b.slice(i, i + 2), 16))
  return Math.hypot(pa[0] - pb[0], pa[1] - pb[1], pa[2] - pb[2])
}

function scanColors(css: string, weights: Map<string, number>, boost = 1) {
  // regels per selector, zodat knoppen, koppen en header zwaarder tellen
  const rules = css.split('}')
  for (const rule of rules) {
    const [sel, body = ''] = rule.split('{')
    const sl = (sel || '').toLowerCase()
    let w = boost
    if (/btn|button|cta|primary|accent|brand|highlight/.test(sl)) w *= 4
    if (/header|nav|menu|hero|banner|footer/.test(sl)) w *= 2
    if (/:root|--/.test(sl + body) && /color|kleur|brand|primary/.test(body.toLowerCase())) w *= 3
    for (const m of body.matchAll(/#([0-9a-fA-F]{3,8})\b/g)) {
      if (![3, 4, 6, 8].includes(m[1].length)) continue
      const hex = normHex(m[1])
      weights.set(hex, (weights.get(hex) || 0) + w)
    }
    for (const m of body.matchAll(/rgba?\(\s*(\d{1,3})[\s,]+(\d{1,3})[\s,]+(\d{1,3})(?:[\s,/]+([\d.]+%?))?\s*\)/g)) {
      if (m[4] && parseFloat(m[4]) < 0.6) continue
      const hex = toHex(+m[1], +m[2], +m[3])
      weights.set(hex, (weights.get(hex) || 0) + w)
    }
  }
}

function scanFonts(css: string, counts: Map<string, number>) {
  for (const m of css.matchAll(/font-family\s*:\s*([^;}{]+)/gi)) {
    const fam = m[1].split(',')[0].replace(/["']/g, '').replace(/!important/i, '').trim()
    if (!fam || /^(inherit|initial|var\(|-apple-system|system-ui|sans-serif|serif|monospace|arial|helvetica|times|font ?awesome|dashicons|eticons|etmodules|icomoon|swiper-icons|star|material icons|material symbols|courier|consolas|menlo|monaco|georgia|verdana|tahoma|segoe|roboto mono)/i.test(fam)) continue
    counts.set(fam, (counts.get(fam) || 0) + 1)
  }
}

const attr = (tag: string, name: string) => { const m = tag.match(new RegExp(`\\b${name}\\s*=\\s*(?:"([^"]*)"|'([^']*)'|([^\\s>]+))`, 'i')); return m ? (m[1] ?? m[2] ?? m[3] ?? '') : '' }

async function scan(target: URL) {
  const r = await get(target)
  if (!r) throw new Error('De website kon niet worden geladen.')
  const html = await r.text()
  const base = r.url
  const host = new URL(base).hostname.replace(/^www\./, '').split('.')[0].toLowerCase()

  const title = (html.match(/<title[^>]*>([^<]*)<\/title>/i) || [])[1]?.trim() || host
  const meta = (n: string) => { const t = html.match(new RegExp(`<meta[^>]+(?:name|property)=["']${n}["'][^>]*>`, 'i')); return t ? attr(t[0], 'content') : '' }
  const themeColor = meta('theme-color')
  const ogImage = meta('og:image')
  const siteName = meta('og:site_name') || title.split(/[|\-–]/)[0].trim()

  // stylesheets
  const cssParts: string[] = []
  for (const m of html.matchAll(/<style[^>]*>([\s\S]*?)<\/style>/gi)) cssParts.push(m[1])
  const inline = [...html.matchAll(/style\s*=\s*"([^"]*)"/gi)].map((m) => `x{${m[1]}}`).join('\n')
  const links = [...html.matchAll(/<link[^>]+>/gi)].map((m) => m[0])
  const sheetUrls = links.filter((l) => /rel=["']?stylesheet/i.test(l)).map((l) => safeUrl(attr(l, 'href'), base)).filter(Boolean).slice(0, 8) as URL[]
  const sheets = await Promise.all(sheetUrls.map(async (u) => { const x = await get(u, 'text/css,*/*', 2_500_000); return x ? (await x.text()).slice(0, 1_500_000) : '' }))
  const googleFonts = new Set<string>()
  for (const l of links) {
    const href = attr(l, 'href')
    if (/fonts\.googleapis\.com/.test(href)) for (const m of href.matchAll(/family=([^&:]+)/g)) googleFonts.add(decodeURIComponent(m[1]).replace(/\+/g, ' ').split('|')[0])
  }
  for (const s of sheets) for (const m of s.matchAll(/@import\s+url\(["']?([^"')]+fonts\.googleapis[^"')]+)/g)) for (const f of m[1].matchAll(/family=([^&:]+)/g)) googleFonts.add(decodeURIComponent(f[1]).replace(/\+/g, ' '))

  const weights = new Map<string, number>()
  for (const s of sheets) scanColors(s, weights)
  for (const s of cssParts) scanColors(s, weights, 2)
  scanColors(inline, weights, 2)
  if (themeColor) { const h = themeColor.startsWith('#') ? normHex(themeColor) : ''; if (h) weights.set(h, (weights.get(h) || 0) + 50) }

  // kleuren groeperen: merk (verzadigd) en neutraal
  const sorted = [...weights.entries()].sort((a, b) => b[1] - a[1])
  const brand: { hex: string; score: number }[] = []
  const neutral: { hex: string; score: number }[] = []
  // standaardkleuren van thema's en frameworks (Divi, WordPress, Bootstrap) niet als merkkleur zien
  const DEFAULTS = new Set(['#2EA3F2', '#0073AA', '#21759B', '#007BFF', '#0D6EFD', '#337AB7', '#0A58CA', '#CF2E2E', '#FF6900', '#FCB900', '#7BDCB5', '#00D084', '#8ED1FC', '#0693E3', '#9B51E0', '#F78DA7', '#ABB8C3'])
  for (const [hex, score] of sorted) {
    if (DEFAULTS.has(hex)) continue
    const { s, l } = sat(hex)
    const bucket = s > 0.22 && l > 0.08 && l < 0.94 ? brand : neutral
    if (bucket.some((c) => dist(c.hex, hex) < 38)) continue
    if (bucket.length < (bucket === brand ? 8 : 6)) bucket.push({ hex, score: Math.round(score) })
  }

  const fontCounts = new Map<string, number>()
  for (const s of [...sheets, ...cssParts]) scanFonts(s, fontCounts)
  const fonts = [...new Set([...googleFonts, ...[...fontCounts.entries()].sort((a, b) => b[1] - a[1]).map(([f]) => f)])].slice(0, 6)

  // logo's
  const logos: { url?: string; svg?: string; source: string; score: number }[] = []
  const headerHtml = (html.match(/<header[\s\S]*?<\/header>/i) || [''])[0]
  for (const m of html.matchAll(/<img[^>]+>/gi)) {
    const tag = m[0]
    const src = attr(tag, 'src') || attr(tag, 'data-src') || (attr(tag, 'srcset').split(',')[0] || '').trim().split(' ')[0]
    const u = safeUrl(src, base)
    if (!u) continue
    const t = (src + ' ' + attr(tag, 'alt') + ' ' + attr(tag, 'class') + ' ' + attr(tag, 'id')).toLowerCase()
    let score = 0
    if (/logo|brand|beeldmerk|wordmark/.test(t)) score += 5
    if (t.includes(host)) score += 3
    if (headerHtml.includes(src)) score += 4
    if (/\.svg(\?|$)/i.test(u.pathname)) score += 1
    if (/icon|avatar|flag|payment|review|trustpilot|kiyoh|google|facebook|instagram|linkedin/.test(t)) score -= 4
    if (score >= 4) logos.push({ url: u.href, source: 'img', score })
  }
  for (const m of headerHtml.matchAll(/<svg[\s\S]*?<\/svg>/gi)) {
    const svg = m[0]
    if (svg.length > 60_000 || svg.length < 200) continue
    const t = svg.slice(0, 400).toLowerCase()
    logos.push({ svg: svg.includes('xmlns=') ? svg : svg.replace('<svg', '<svg xmlns="http://www.w3.org/2000/svg"'), source: 'header-svg', score: /logo|brand/.test(t) ? 7 : 3 })
  }
  for (const l of links) {
    if (/rel=["'][^"']*(apple-touch-icon|icon)/i.test(l)) { const u = safeUrl(attr(l, 'href'), base); if (u) logos.push({ url: u.href, source: 'icon', score: /apple/.test(l) ? 2 : 1 }) }
  }
  const seen = new Set<string>()
  const logoList = logos.sort((a, b) => b.score - a.score).filter((l) => { const k = l.url || l.svg!.slice(0, 200); if (seen.has(k)) return false; seen.add(k); return true }).slice(0, 8)

  const images: string[] = []
  if (ogImage) { const u = safeUrl(ogImage, base); if (u) images.push(u.href) }
  for (const m of html.matchAll(/<img[^>]+>/gi)) {
    if (images.length >= 8) break
    const src = attr(m[0], 'src') || attr(m[0], 'data-src')
    const u = safeUrl(src, base)
    const w = parseInt(attr(m[0], 'width') || '0')
    if (u && /\.(jpe?g|webp|png)(\?|$)/i.test(u.pathname) && (w === 0 || w > 400) && !/logo|icon/i.test(src) && !images.includes(u.href)) images.push(u.href)
  }

  return { url: base, name: siteName, title, themeColor, brandColors: brand, neutralColors: neutral, fonts, logos: logoList, images }
}

Deno.serve(async (req) => {
  if (req.method === 'OPTIONS') return new Response('ok', { headers: CORS })
  try {
    const { url, proxy } = await req.json()
    if (proxy) {
      const u = safeUrl(proxy)
      if (!u) return json({ error: 'Ongeldige afbeelding-URL' }, 400)
      const r = await get(u, 'image/*', 15_000_000)
      if (!r) return json({ error: 'Afbeelding niet bereikbaar' }, 404)
      const type = r.headers.get('content-type') || ''
      if (!/^image\//.test(type)) return json({ error: 'Geen afbeelding' }, 415)
      return new Response(await r.arrayBuffer(), { headers: { ...CORS, 'Content-Type': type, 'Cache-Control': 'max-age=3600' } })
    }
    let u = safeUrl(String(url || '').trim())
    if (!u) u = safeUrl('https://' + String(url || '').trim().replace(/^\/+/, ''))
    if (!u) return json({ error: 'Vul een geldige website in, bijvoorbeeld www.voorbeeld.nl' }, 400)
    return json(await scan(u))
  } catch (e) {
    return json({ error: (e as Error).message || 'Scannen mislukt' }, 500)
  }
})
