# Opdracht: Canva-ontwerpen nabouwen als Adwerk-templates

Je leest bestaande Canva-ontwerpen van daar-om.nl (alleen lezen!) en bouwt de opmaak exact na als JSON-templates voor Adwerk.

## Canva gebruiken (strikt alleen lezen)
- `mcp__Canva__read-design` met `filter.fields: ["design_metadata","page_metadata","thumbnails"]` om pagina's en formaten te zien.
- Voor de echte opbouw: `mcp__Canva__read-design` met `open_transaction: true` en `filter: {fields:["design_content","thumbnails"], page_indices:[N], thumbnail_pages:[N]}`. Dit geeft per element top/left/width/height/rotation/opacity, tekst + fontSize/fontWeight/color/textAlign/lineHeight/letterSpacing, shapes met paden en kleuren, en afbeeldingen.
- SLUIT ELKE TRANSACTIE DIRECT daarna met `mcp__Canva__edit-design` `{transaction_id, finalize:"cancel"}`. Nooit "commit", nooit operaties uitvoeren. Niets aanpassen in Canva.
- Kies per ontwerp de 1 tot 3 sterkste, meest verschillende pagina's (verschillende opmaak of formaat). Sla lege pagina's en pagina's die alleen een label tonen ("Meta", "LinkedIn") over.

## Neutraliseren
- Geen echte klantnamen, logo's, URL's of slogans van klanten. Vervang door fictieve, branchepassende Nederlandse tekst van vergelijkbare lengte (bijv. "Bakkerij Van Dijk", "jouwwebsite.nl"). Geen gedachtestreepjes (—, –, " - ") in teksten.
- Logo's worden een afbeeldingsvak met name "Logo".
- Foto's worden een afbeeldingsvak (zonder src) met name "Foto: <korte beschrijving>" en fill = gemiddelde kleur van die foto (schatting uit de thumbnail).
- Kleuren, posities, maten, lettergroottes, hoeken, transparantie en lagenvolgorde houd je EXACT aan (afronden op 1 decimaal). Dat is de kern: de opmaak moet er hetzelfde uitzien.

## Uitvoer
Schrijf één JSON-bestand (pad staat in je opdracht) met een array van templates:
```json
[{
  "key": "kort-uniek-slug",
  "name": "Korte Nederlandse naam (max 22 tekens)",
  "branche": "een van: Retail en webshop | Interieur en wonen | Food en horeca | Mode en beauty | Auto en mobiliteit | Bouw en installatie | Zakelijke dienstverlening | Software en tech | Recruitment | Zorg en welzijn | Events en opleidingen | Lokaal ondernemen | Energie en duurzaamheid",
  "segment": "B2C | B2B | B2B en B2C",
  "type": "Afbeelding | Carrousel | Story en Reels | Leadadvertentie",
  "source": "Canva design id + paginanummer(s)",
  "frames": [{
    "w": 1080, "h": 1080,
    "background": {"type":"solid","color":"#FFFFFF"}  // of {"type":"gradient","color":"#..","color2":"#..","angle":90}
    "elements": [ /* van achter naar voor, zoals in Canva */ ]
  }]
}]
```
Een Carrousel heeft meerdere frames van hetzelfde formaat (de kaarten). Andere types: 1 frame, maar als het Canva-ontwerp hetzelfde concept in feed én story heeft, mag je beide formaten als frames meegeven.

### Elementen (alle getallen in px van het frame)
- Tekst: `{"type":"text","x":..,"y":..,"width":..,"height":..,"text":"..","fontFamily":"..","fontSize":..,"fontWeight":400|500|700|800|900,"italic":false,"fill":"#hex","align":"left|center|right","lineHeight":1.2,"letterSpacing":0,"uppercase":false,"rotation":0,"opacity":1}`
  fontFamily kies je uit (dichtstbijzijnde look, kijk naar de thumbnail): Figtree, Inter, Poppins, Montserrat, DM Sans, Plus Jakarta Sans, Manrope, Outfit, Sora, Roboto, Open Sans, Lato, Nunito, Rubik, Work Sans, Raleway, Barlow, Barlow Condensed, Josefin Sans, Quicksand, Kanit, Space Grotesk, Bricolage Grotesque, Syne, Unbounded, Archivo Black, Anton, Bebas Neue, Oswald, Teko, Bungee, Righteous, Fredoka, Alfa Slab One, Abril Fatface, Playfair Display, DM Serif Display, Fraunces, Instrument Serif, Lora, Merriweather, Libre Baskerville, Pacifico, Caveat, Permanent Marker, Lobster.
  Een tekst met meerdere opmaak (bijv. één woord vet of andere kleur) splits je in losse tekstelementen op de juiste plek.
- Rechthoek: `{"type":"rect","x","y","width","height","fill":"#hex","cornerRadius":0,"rotation":0,"opacity":1,"stroke":"#hex","strokeWidth":0}`
- Cirkel/ellips: `{"type":"ellipse",...zelfde velden}`
- Vrije vorm (pad, golf, blob, pijl, tekstballon, beeldmerk): `{"type":"shape","x","y","width","height","fill":"#hex","path":"<SVG d>","viewBox":"0 0 W H","rotation":0,"opacity":1}`
- Afbeeldingsvak: `{"type":"image","x","y","width","height","name":"Foto: ...","fill":"#hex","cornerRadius":0,"mask":"none|circle|arch|oval|leaf|blob","rotation":0,"opacity":1}`
- Lijn: gebruik een dunne rect.
- Optioneel per element `"anim": {"in":"fade|slideUp|slideDown|slideLeft|slideRight|zoomIn|zoomOut|pop","delay":0.3}` en `"emph":"pulse"` voor de knop. Geef de belangrijkste elementen een rustige, logische animatie in leesvolgorde.
- Optioneel `"name"` voor herkenbare lagen ("Kop", "Knop", "Knoptekst", "Prijslabel").

## Kwaliteit
- Controleer per template dat alle elementen binnen het frame logisch staan en dat tekst-hoogtes passen bij fontSize × regels × lineHeight.
- Doelen: 8 tot 10 templates totaal in jouw bestand, verspreid over de ontwerpen in je lijst, zo divers mogelijk (opmaak, formaat 1080×1080, 1080×1350, 1080×1920, 1200×628).
- Antwoord aan het eind met: het pad van je JSON-bestand en een lijst key, naam, branche, type, formaat(en), bron.
