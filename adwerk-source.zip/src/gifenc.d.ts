declare module 'gifenc';
