import { useEffect, useState } from 'react'
import { supabase, ALLOWED_DOMAIN } from './lib/supabase'
import { getProfile } from './lib/api'
import { useSession } from './store/session'
import { TooltipProvider } from './ui/ui'
import Login from './pages/Login'
import Home from './pages/Home'
import Editor from './editor/Editor'

function useHashRoute() {
  const [hash, setHash] = useState(window.location.hash)
  useEffect(() => {
    const on = () => setHash(window.location.hash)
    window.addEventListener('hashchange', on)
    return () => window.removeEventListener('hashchange', on)
  }, [])
  return hash.replace(/^#/, '') || '/'
}

export function navigate(path: string) {
  window.location.hash = path
}

export default function App() {
  const { user, ready, set } = useSession()
  const route = useHashRoute()
  const [authError, setAuthError] = useState<string | null>(null)

  useEffect(() => {
    const params = new URLSearchParams(window.location.search)
    const err = params.get('error_description')
    if (err) {
      setAuthError(/daar-om/i.test(err) || /Database error/i.test(err) ? `Alleen accounts van @${ALLOWED_DOMAIN} hebben toegang.` : err)
      window.history.replaceState(null, '', window.location.pathname + window.location.hash)
    }
    const apply = async (u: typeof user) => {
      if (u && !u.email?.toLowerCase().endsWith('@' + ALLOWED_DOMAIN)) {
        await supabase.auth.signOut()
        setAuthError(`Alleen accounts van @${ALLOWED_DOMAIN} hebben toegang.`)
        set({ user: null, profile: null, ready: true })
        return
      }
      set({ user: u, ready: true, profile: u ? await getProfile(u.id) : null })
      if (u && window.location.search.includes('code=')) window.history.replaceState(null, '', window.location.pathname + window.location.hash)
    }
    supabase.auth.getSession().then(({ data }) => apply(data.session?.user ?? null))
    const { data: sub } = supabase.auth.onAuthStateChange((_e, session) => {
      if ((session?.user?.id ?? null) !== (useSession.getState().user?.id ?? null)) apply(session?.user ?? null)
    })
    return () => sub.subscription.unsubscribe()
  }, [set])

  if (!ready) {
    return <div className="grid h-full place-items-center"><div className="h-8 w-8 animate-spin rounded-full border-[3px] border-line border-t-accent" /></div>
  }

  return (
    <TooltipProvider>
      {!user ? <Login error={authError} /> : route.startsWith('/d/') ? <Editor key={route} id={route.slice(3)} /> : <Home route={route} />}
    </TooltipProvider>
  )
}
