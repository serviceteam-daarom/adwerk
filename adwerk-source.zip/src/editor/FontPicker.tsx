import { useEffect, useMemo, useRef, useState } from 'react'
import { Check, ChevronDown, HardDrive, Search, X, Plus, Info } from 'lucide-react'
import { FONTS, addLocalFonts, canQueryLocalFonts, isInstalled, loadFont, localFonts, queryInstalledFonts, removeLocalFont, type LocalFont } from '../lib/fonts'
import { Popover, PopoverContent, PopoverTrigger, cn } from '../ui/ui'

const CATS = { sans: 'Schreefloos', display: 'Opvallend', serif: 'Schreef', script: 'Handschrift' } as const

function useLocalFonts() {
  const [list, setList] = useState<LocalFont[]>(localFonts)
  useEffect(() => { const on = () => setList(localFonts()); window.addEventListener('adwerk-local-fonts', on); return () => window.removeEventListener('adwerk-local-fonts', on) }, [])
  return list
}

/** Lettertypekiezer: Google Fonts plus lettertypes die op deze computer staan. */
export function FontPicker({ value, onChange }: { value: string; onChange: (name: string) => void }) {
  const [open, setOpen] = useState(false)
  const [q, setQ] = useState('')
  const [scan, setScan] = useState<LocalFont[] | null>(null)
  const [msg, setMsg] = useState<string | null>(null)
  const local = useLocalFonts()
  const input = useRef<HTMLInputElement>(null)
  useEffect(() => { if (open) { setQ(''); setMsg(null); setTimeout(() => input.current?.focus(), 30); FONTS.forEach((f) => loadFont(f.name)) } }, [open])

  const ql = q.trim().toLowerCase()
  const match = (n: string) => !ql || n.toLowerCase().includes(ql)
  const google = FONTS.filter((f) => match(f.name))
  const mine = local.filter((f) => match(f.name))
  const found = (scan || []).filter((f) => match(f.name) && !local.some((l) => l.name === f.name) && !FONTS.some((g) => g.name === f.name)).slice(0, 60)
  const exact = q.trim() && !FONTS.some((f) => f.name.toLowerCase() === ql) && !local.some((f) => f.name.toLowerCase() === ql)
  const isLocal = useMemo(() => !FONTS.some((f) => f.name === value), [value])

  const pick = (name: string) => { loadFont(name).then(() => onChange(name)); setOpen(false) }
  const useLocal = (f: LocalFont) => { addLocalFonts([f]); pick(f.name) }
  const scanFonts = async () => {
    setMsg(null)
    try { const r = await queryInstalledFonts(); setScan(r); if (!r.length) setMsg('Geen lettertypes gevonden. Typ de naam hierboven.') }
    catch (e) { setMsg((e as Error).message === 'unsupported' ? 'Je browser kan geen lijst geven (alleen Chrome en Edge). Typ de exacte naam van het lettertype hierboven.' : 'Geen toestemming gekregen. Typ de exacte naam van het lettertype hierboven.') }
  }
  const typed = () => {
    const name = q.trim()
    if (!name) return
    if (!isInstalled(name)) { setMsg(`"${name}" staat niet op deze computer, of de naam wijkt af. Controleer de naam zoals je hem in Word of Figma ziet.`); return }
    useLocal({ name, weights: [] })
  }

  const Item = ({ name, sub, onClick, onRemove }: { name: string; sub?: string; onClick: () => void; onRemove?: () => void }) => (
    <div className={cn('group/f flex min-w-0 items-center gap-1 rounded-lg pr-1 hover:bg-sunk', value === name && 'bg-accent-soft')}>
      <button onClick={onClick} className="flex min-w-0 flex-1 items-center gap-2 px-2.5 py-1.5 text-left" title={name}>
        <span className="min-w-0 flex-1 truncate text-[15px]" style={{ fontFamily: `"${name}", system-ui` }}>{name}</span>
        {sub && <span className="shrink-0 text-[11px] text-muted">{sub}</span>}
        {value === name && <Check size={14} className="shrink-0 text-accent-fg" />}
      </button>
      {onRemove && <button onClick={onRemove} className="grid h-6 w-6 shrink-0 place-items-center rounded-md text-muted opacity-0 transition hover:bg-surface hover:text-ink group-hover/f:opacity-100" aria-label={`${name} uit de lijst halen`}><X size={13} /></button>}
    </div>
  )

  return (
    <Popover open={open} onOpenChange={setOpen}>
      <PopoverTrigger className="flex h-9 w-full min-w-0 items-center gap-2 rounded-lg bg-sunk px-2.5 text-left text-sm outline-none transition hover:bg-line/60 focus-visible:ring-2 focus-visible:ring-violet" aria-label="Lettertype">
        {isLocal && <HardDrive size={13} className="shrink-0 text-muted" aria-label="Lokaal lettertype" />}
        <span className="min-w-0 flex-1 truncate" style={{ fontFamily: `"${value}", system-ui` }} title={value}>{value || 'Kies een lettertype'}</span>
        <ChevronDown size={14} className="shrink-0 text-muted" />
      </PopoverTrigger>
      <PopoverContent className="w-[300px] p-0" align="start">
        <div className="border-b border-line p-2">
          <label className="relative block">
            <Search size={15} className="pointer-events-none absolute left-2.5 top-1/2 -translate-y-1/2 text-muted" />
            <input ref={input} value={q} onChange={(e) => { setQ(e.target.value); setMsg(null) }} onKeyDown={(e) => { e.stopPropagation(); if (e.key === 'Enter') { const first = google[0] || mine[0]; if (exact) typed(); else if (first) pick(first.name) } }}
              placeholder="Zoek of typ een lokaal lettertype" className="h-9 w-full rounded-lg bg-sunk pl-8 pr-2 text-sm outline-none ring-violet placeholder:text-muted focus:ring-2" />
          </label>
        </div>
        <div className="max-h-[min(420px,60vh)] overflow-y-auto overscroll-contain p-1.5">
          {exact && (
            <button onClick={typed} className="mb-1 flex w-full min-w-0 items-center gap-2 rounded-lg px-2.5 py-2 text-left text-sm hover:bg-sunk">
              <Plus size={15} className="shrink-0 text-accent-fg" /><span className="min-w-0 flex-1 truncate">Gebruik <strong style={{ fontFamily: `"${q.trim()}", system-ui` }}>{q.trim()}</strong> van deze computer</span>
            </button>
          )}
          {msg && <p className="mx-1 mb-2 flex gap-2 rounded-lg bg-mist p-2.5 text-xs leading-relaxed text-muted"><Info size={14} className="mt-0.5 shrink-0" />{msg}</p>}

          <div className="flex items-center justify-between px-2.5 pb-1 pt-1.5"><span className="text-[11px] font-semibold uppercase tracking-wide text-muted">Op deze computer</span>
            {canQueryLocalFonts() && !scan && <button onClick={scanFonts} className="text-xs font-semibold text-violet hover:underline">Lettertypes ophalen</button>}
          </div>
          {mine.map((f) => <Item key={f.name} name={f.name} sub="lokaal" onClick={() => pick(f.name)} onRemove={() => removeLocalFont(f.name)} />)}
          {found.map((f) => <Item key={f.name} name={f.name} sub="toevoegen" onClick={() => useLocal(f)} />)}
          {!mine.length && !found.length && !scan && <p className="px-2.5 pb-2 text-xs leading-relaxed text-muted">Gebruik een lettertype dat op je computer staat, zoals een betaald merkfont. {canQueryLocalFonts() ? 'Klik op Lettertypes ophalen of typ de naam.' : 'Typ de exacte naam hierboven.'}</p>}
          {(mine.length > 0 || found.length > 0) && <p className="mx-2.5 mb-1 mt-1 text-[11px] leading-relaxed text-muted">Lokale lettertypes zie je alleen op computers waar ze geïnstalleerd zijn. Exporteer daarom als PNG, JPG of video; HTML5 valt elders terug op een standaardletter.</p>}

          {(['sans', 'display', 'serif', 'script'] as const).map((cat) => {
            const fs = google.filter((f) => f.category === cat)
            if (!fs.length) return null
            return (
              <div key={cat} className="mt-2">
                <div className="px-2.5 pb-1 text-[11px] font-semibold uppercase tracking-wide text-muted">{CATS[cat]}</div>
                {fs.map((f) => <Item key={f.name} name={f.name} onClick={() => pick(f.name)} />)}
              </div>
            )
          })}
        </div>
      </PopoverContent>
    </Popover>
  )
}
