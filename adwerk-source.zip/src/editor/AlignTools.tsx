import { AlignStartVertical, AlignCenterVertical, AlignEndVertical, AlignStartHorizontal, AlignCenterHorizontal, AlignEndHorizontal, AlignHorizontalDistributeCenter, AlignVerticalDistributeCenter, Group, Ungroup } from 'lucide-react'
import { useEditor } from '../store/editor'
import { unitsOf, selectedGroup } from '../lib/groups'
import { Tip, cn } from '../ui/ui'
import type { AlignMode } from '../lib/groups'

const ALIGN: { m: AlignMode; label: string; key: string; icon: React.ReactNode }[] = [
  { m: 'left', label: 'Links uitlijnen', key: 'Alt Ctrl L', icon: <AlignStartVertical size={17} /> },
  { m: 'center', label: 'Horizontaal centreren', key: 'Alt Ctrl H', icon: <AlignCenterVertical size={17} /> },
  { m: 'right', label: 'Rechts uitlijnen', key: 'Alt Ctrl R', icon: <AlignEndVertical size={17} /> },
  { m: 'top', label: 'Boven uitlijnen', key: 'Alt Ctrl T', icon: <AlignStartHorizontal size={17} /> },
  { m: 'middle', label: 'Verticaal centreren', key: 'Alt Ctrl V', icon: <AlignCenterHorizontal size={17} /> },
  { m: 'bottom', label: 'Onder uitlijnen', key: 'Alt Ctrl B', icon: <AlignEndHorizontal size={17} /> },
]

/** Uitlijnen, verdelen en groeperen voor de huidige selectie. */
export function AlignTools({ compact, onDone }: { compact?: boolean; onDone?: () => void }) {
  const ids = useEditor((s) => s.selectedIds)
  const frame = useEditor((s) => s.doc.frames.find((f) => f.id === s.activeFrameId))
  if (!frame || !ids.length) return null
  const units = unitsOf(frame, ids)
  const st = useEditor.getState
  const toFrame = units.length < 2
  const btn = cn('grid place-items-center rounded-lg text-ink transition hover:bg-sunk active:scale-95 disabled:opacity-35 disabled:hover:bg-transparent', compact ? 'h-8 w-8' : 'h-9')
  const grp = selectedGroup(frame, ids)
  const anyGrouped = frame.elements.some((e) => ids.includes(e.id) && e.groupId)
  return (
    <div className="grid gap-2">
      <div className="grid grid-cols-6 gap-0.5">
        {ALIGN.map((a) => <Tip key={a.m} label={`${a.label}${toFrame ? ' op het formaat' : ''} (${a.key})`}><button className={btn} onClick={() => { st().alignSelected(a.m); onDone?.() }} aria-label={a.label}>{a.icon}</button></Tip>)}
      </div>
      {(!toFrame || anyGrouped) && <div className="grid grid-cols-2 gap-1">
        <Tip label="Gelijke ruimte horizontaal (min. 3 blokken)"><button className={cn(btn, 'flex gap-1.5 whitespace-nowrap px-2 text-xs font-medium')} disabled={units.length < 3} onClick={() => st().distributeSelected('horizontal')}><AlignHorizontalDistributeCenter size={16} /> Verdeel ↔</button></Tip>
        <Tip label="Gelijke ruimte verticaal (min. 3 blokken)"><button className={cn(btn, 'flex gap-1.5 whitespace-nowrap px-2 text-xs font-medium')} disabled={units.length < 3} onClick={() => st().distributeSelected('vertical')}><AlignVerticalDistributeCenter size={16} /> Verdeel ↕</button></Tip>
      </div>}
      <p className="px-1 text-[11px] leading-snug text-muted">{toFrame ? 'Eén element of groep: uitlijnen op het formaat.' : `${units.length} ${grp ? 'onderdelen' : 'blokken'} onderling uitlijnen. Een groep telt als één blok.`}</p>
      {(!toFrame || anyGrouped) && <div className="grid grid-cols-2 gap-1">
        <button className={cn(btn, 'flex gap-1.5 px-2 text-xs font-semibold')} disabled={ids.length < 2 || !!grp} onClick={() => { st().groupSelected(); onDone?.() }}><Group size={16} /> Groeperen</button>
        <button className={cn(btn, 'flex gap-1.5 px-2 text-xs font-semibold')} disabled={!anyGrouped} onClick={() => { st().ungroupSelected(); onDone?.() }}><Ungroup size={16} /> Opheffen</button>
      </div>}
    </div>
  )
}
