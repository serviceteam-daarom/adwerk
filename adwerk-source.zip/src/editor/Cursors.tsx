import { useEffect, useRef } from 'react'
import type { Peer } from '../store/editor'

interface Track {
  x: number; y: number
  // agent: beweging langs een gebogen pad
  from?: { x: number; y: number }; ctrl?: { x: number; y: number }; to?: { x: number; y: number }; t0?: number; dur?: number
  clickAt?: number
  el?: HTMLDivElement | null
}

const ease = (t: number) => (t < 0.5 ? 4 * t * t * t : 1 - Math.pow(-2 * t + 2, 3) / 2)

/**
 * Cursors van collega's en van AI-agents. Collega's volgen we vloeiend (met demping),
 * agents bewegen als een mens: een licht gebogen pad, versnellen en afremmen, en een klik.
 */
export default function Cursors({ peers, ox, oy, zoom }: { peers: [string, Peer][]; ox: number; oy: number; zoom: number }) {
  const tracks = useRef(new Map<string, Track>())
  const view = useRef({ ox, oy, zoom })
  view.current = { ox, oy, zoom }

  // nieuwe doelen verwerken
  for (const [key, p] of peers) {
    if (!p.cursor) continue
    let t = tracks.current.get(key)
    if (!t) { t = { x: p.cursor.x, y: p.cursor.y }; tracks.current.set(key, t) }
    if (p.agent) {
      const last = t.to || { x: t.x, y: t.y }
      if (Math.abs(last.x - p.cursor.x) > 0.5 || Math.abs(last.y - p.cursor.y) > 0.5) {
        const from = { x: t.x, y: t.y }, to = { ...p.cursor }
        const dx = to.x - from.x, dy = to.y - from.y, dist = Math.hypot(dx, dy)
        // boog naar één kant, zoals een hand die de muis beweegt
        const bend = Math.min(160, dist * 0.22) * (Math.sin(to.x * 0.013 + to.y * 0.007) > 0 ? 1 : -1)
        const ctrl = { x: from.x + dx * 0.55 - (dy / (dist || 1)) * bend, y: from.y + dy * 0.55 + (dx / (dist || 1)) * bend }
        Object.assign(t, { from, ctrl, to, t0: performance.now(), dur: Math.min(1100, 280 + Math.sqrt(dist) * 22) })
      }
      if (p.action === 'click' && (!t.clickAt || performance.now() - t.clickAt > 500)) t.clickAt = performance.now() + (t.dur || 0)
    }
  }

  useEffect(() => {
    let raf = 0
    const loop = () => {
      const now = performance.now()
      const { ox, oy, zoom } = view.current
      for (const [key, t] of tracks.current) {
        const p = peersRef.current.get(key)
        if (!p?.cursor) continue
        if (p.agent && t.to && t.from && t.ctrl && t.t0 !== undefined) {
          const k = Math.min(1, (now - t.t0) / (t.dur || 1)), e = ease(k), u = 1 - e
          t.x = u * u * t.from.x + 2 * u * e * t.ctrl.x + e * e * t.to.x
          t.y = u * u * t.from.y + 2 * u * e * t.ctrl.y + e * e * t.to.y
        } else {
          t.x += (p.cursor.x - t.x) * 0.32
          t.y += (p.cursor.y - t.y) * 0.32
        }
        if (t.el) {
          t.el.style.transform = `translate(${ox + t.x * zoom}px, ${oy + t.y * zoom}px)`
          const ring = t.el.querySelector<HTMLElement>('[data-click]')
          if (ring) {
            const c = t.clickAt ? (now - t.clickAt) / 420 : 2
            ring.style.opacity = c >= 0 && c < 1 ? String(1 - c) : '0'
            ring.style.transform = `translate(-50%, -50%) scale(${c >= 0 && c < 1 ? 0.4 + c * 1.2 : 0.4})`
          }
        }
      }
      raf = requestAnimationFrame(loop)
    }
    raf = requestAnimationFrame(loop)
    return () => cancelAnimationFrame(raf)
  }, [])

  const peersRef = useRef(new Map<string, Peer>())
  peersRef.current = new Map(peers)
  for (const k of [...tracks.current.keys()]) if (!peersRef.current.has(k)) tracks.current.delete(k)

  return (
    <>
      {peers.filter(([, p]) => p.cursor).map(([key, p]) => (
        <div key={key} ref={(n) => { const t = tracks.current.get(key); if (t) t.el = n }} className="pointer-events-none absolute left-0 top-0 z-30 will-change-transform" aria-hidden
          style={{ transform: `translate(${ox + (tracks.current.get(key)?.x ?? p.cursor!.x) * zoom}px, ${oy + (tracks.current.get(key)?.y ?? p.cursor!.y) * zoom}px)` }}>
          <span data-click className="absolute left-[3px] top-[3px] h-9 w-9 rounded-full border-2 opacity-0" style={{ borderColor: p.color }} />
          <svg width="20" height="22" viewBox="0 0 20 22" style={{ filter: 'drop-shadow(0 1px 2px rgba(0,0,0,.35))' }}>
            <path d="M2 1.5 L2 17.5 L6.4 13.6 L9.3 20.2 L12.4 18.8 L9.6 12.4 L15.6 12.2 Z" fill={p.color} stroke="#fff" strokeWidth="1.6" strokeLinejoin="round" />
          </svg>
          <span className="absolute left-4 top-[18px] flex items-center gap-1.5 whitespace-nowrap rounded-[6px] rounded-tl-[2px] py-[3px] pl-[3px] pr-2 text-[12px] font-semibold text-white shadow-md" style={{ background: p.color }}>
            {p.agent ? (
              <span className="grid h-[18px] w-[18px] place-items-center rounded-full bg-white/25">
                <svg width="11" height="11" viewBox="0 0 24 24" fill="#fff" aria-hidden><path d="M12 2l1.9 6.1L20 10l-6.1 1.9L12 18l-1.9-6.1L4 10l6.1-1.9z" /></svg>
              </span>
            ) : p.avatar ? <img src={p.avatar} alt="" referrerPolicy="no-referrer" className="h-[18px] w-[18px] rounded-full border border-white/60" /> : <span className="grid h-[18px] w-[18px] place-items-center rounded-full bg-white/25 text-[9px]">{p.name.slice(0, 1)}</span>}
            {p.agent ? p.name : p.name.split(' ')[0]}
            {p.agent && p.action && p.action !== 'click' && p.action !== 'move' && <span className="font-normal text-white/85">· {p.action}</span>}
          </span>
        </div>
      ))}
    </>
  )
}
