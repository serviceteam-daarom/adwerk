import { useEffect, useLayoutEffect, useRef, useState } from 'react'
import { Bold, Italic, Underline, RotateCcw } from 'lucide-react'
import { useEditor } from '../store/editor'
import { nearestWeight } from '../lib/fonts'
import { applyStyle, normalizeRuns, runWeight, segments, styleRange, type Run, type StylePatch } from '../lib/richtext'
import type { El } from '../lib/types'
import { cn } from '../ui/ui'

type Val = { text: string; runs?: Run[] }

/* ---------- DOM <-> tekst + opmaak ---------- */

function styleFromNode(n: Node | null, root: HTMLElement): Run {
  const el = (n?.nodeType === 1 ? n : n?.parentElement) as HTMLElement | null
  const span = el?.closest<HTMLElement>('[data-r]')
  if (!span || !root.contains(span)) return { t: '' }
  try { return { t: '', ...JSON.parse(span.dataset.r || '{}') } } catch { return { t: '' } }
}

/** Leest de inhoud terug als platte tekst met opmaakstukjes. */
function serialize(root: HTMLElement): Val {
  const runs: Run[] = []
  let text = ''
  const walk = (n: Node, first: boolean) => {
    if (n.nodeType === 3) { const t = n.nodeValue || ''; if (t) { text += t; runs.push({ ...styleFromNode(n, root), t }) } return }
    const e = n as HTMLElement
    if (e.dataset?.sentinel) return
    if (e.tagName === 'BR') { text += '\n'; runs.push({ ...styleFromNode(e, root), t: '\n' }); return }
    // een browser maakt soms zelf blokken (div/p) bij Enter: die gelden als nieuwe regel
    if ((e.tagName === 'DIV' || e.tagName === 'P') && e !== root && !first) { text += '\n'; runs.push({ t: '\n' }) }
    e.childNodes.forEach((c, i) => walk(c, i === 0 && first))
  }
  root.childNodes.forEach((c, i) => walk(c, i === 0))
  return { text, runs: normalizeRuns(runs) }
}

/** Positie (in tekens) van een punt in de DOM, op dezelfde manier geteld als serialize. */
function offsetOf(root: HTMLElement, node: Node, off: number): number {
  const r = document.createRange()
  r.setStart(root, 0)
  try { r.setEnd(node, off) } catch { return 0 }
  const tmp = document.createElement('div')
  tmp.appendChild(r.cloneContents())
  return serialize(tmp).text.length
}

function getSel(root: HTMLElement): [number, number] | null {
  const s = window.getSelection()
  if (!s || !s.rangeCount || !root.contains(s.anchorNode)) return null
  const a = offsetOf(root, s.anchorNode!, s.anchorOffset), b = offsetOf(root, s.focusNode!, s.focusOffset)
  return a <= b ? [a, b] : [b, a]
}

function setSel(root: HTMLElement, start: number, end: number) {
  const pos = (target: number): [Node, number] => {
    let count = 0
    const tw = document.createTreeWalker(root, NodeFilter.SHOW_TEXT | NodeFilter.SHOW_ELEMENT)
    let n: Node | null = tw.nextNode()
    let last: [Node, number] = [root, 0]
    while (n) {
      if (n.nodeType === 3) {
        const len = (n.nodeValue || '').length
        if (target <= count + len) return [n, target - count]
        count += len; last = [n, len]
      } else if ((n as HTMLElement).tagName === 'BR' && !(n as HTMLElement).dataset.sentinel) {
        if (target <= count) return [n.parentNode!, Array.prototype.indexOf.call(n.parentNode!.childNodes, n)]
        count += 1
        last = [n.parentNode!, Array.prototype.indexOf.call(n.parentNode!.childNodes, n) + 1]
      }
      n = tw.nextNode()
    }
    return last
  }
  const [sn, so] = pos(start), [en, eo] = pos(end)
  const r = document.createRange()
  r.setStart(sn, so); r.setEnd(en, eo)
  const s = window.getSelection(); s?.removeAllRanges(); s?.addRange(r)
}

/** Bouwt de DOM opnieuw op uit tekst + opmaak. */
function paint(root: HTMLElement, v: Val, el: El) {
  root.textContent = ''
  const fam = el.fontFamily || 'Poppins', base = el.fontWeight || 400
  for (const r of segments(v.text, v.runs)) {
    const span = document.createElement('span')
    const st: Partial<Run> = {}
    if (r.b !== undefined) st.b = r.b
    if (r.i !== undefined) st.i = r.i
    if (r.u !== undefined) st.u = r.u
    if (r.c) st.c = r.c
    span.dataset.r = JSON.stringify(st)
    span.style.fontWeight = String(nearestWeight(fam, runWeight(base, r)))
    span.style.fontStyle = (r.i === undefined ? el.italic : !!r.i) ? 'italic' : 'normal'
    span.textContent = r.t
    root.appendChild(span)
  }
  // laatste lege regel zichtbaar maken (een afsluitende \n toont anders geen nieuwe regel)
  const br = document.createElement('br'); br.dataset.sentinel = '1'
  root.appendChild(br)
}

const wordAt = (text: string, i: number): [number, number] => {
  let a = i, b = i
  while (a > 0 && /[\p{L}\p{N}%€$@#'’\-]/u.test(text[a - 1])) a--
  while (b < text.length && /[\p{L}\p{N}%€$@#'’\-]/u.test(text[b])) b++
  return [a, b]
}

/* ---------- Editor ---------- */

export function RichTextEditor({ el, zoom, ox, oy, onDone, onLive, measure }: {
  el: El; zoom: number; ox: number; oy: number
  onDone: (v: Val) => void; onLive: (v: Val) => void; measure: () => { h: number; fontSize: number }
}) {
  const ref = useRef<HTMLDivElement>(null)
  const bar = useRef<HTMLDivElement>(null)
  const val = useRef<Val>({ text: el.text || '', runs: el.runs })
  const lastSel = useRef<[number, number]>([0, (el.text || '').length])
  const [box, setBox] = useState(() => measure())
  const [sel, setSelState] = useState<[number, number]>([0, (el.text || '').length])
  const [, force] = useState(0)
  const [palette, setPalette] = useState(false)
  const done = useRef(false)
  const live = useEditor((s) => s.frame()?.elements.find((e) => e.id === el.id)) || el
  const docColors = useEditor((s) => s.doc.colors) || []

  useLayoutEffect(() => {
    const r = ref.current!
    paint(r, val.current, el)
    r.focus()
    setSel(r, 0, val.current.text.length)
  }, []) // eslint-disable-line react-hooks/exhaustive-deps

  // selectie bijhouden (voor de knoppen en de kleurkeuze, die de focus even overnemen)
  useEffect(() => {
    const on = () => { const r = ref.current; if (!r) return; const s = getSel(r); if (s) { lastSel.current = s; setSelState(s) } }
    document.addEventListener('selectionchange', on)
    return () => document.removeEventListener('selectionchange', on)
  }, [])

  const push = (v: Val, repaint: boolean, selection?: [number, number]) => {
    val.current = v
    const r = ref.current!
    if (repaint) { paint(r, v, live); if (selection) setSel(r, selection[0], selection[1]) }
    onLive(v)
    requestAnimationFrame(() => setBox(measure()))
    force((x) => x + 1)
  }

  const finish = () => { if (done.current) return; done.current = true; onDone(val.current) }

  const replaceSel = (ins: string) => {
    const r = ref.current!
    const [a, b] = getSel(r) || lastSel.current
    const { text, runs } = val.current
    const t2 = text.slice(0, a) + ins + text.slice(b)
    // opmaak: het ingevoegde stuk krijgt de opmaak van het teken ervoor
    const chars: Run[] = []
    for (const s of segments(text, runs)) for (const ch of s.t) chars.push({ ...s, t: ch })
    const inherit = chars[a - 1] || chars[b] || { t: '' }
    const next = [...chars.slice(0, a), ...ins.split('').map((ch) => ({ ...inherit, t: ch })), ...chars.slice(b)]
    push({ text: t2, runs: normalizeRuns(next) }, true, [a + ins.length, a + ins.length])
  }

  const baseStyle = { b: (live.fontWeight || 400) >= 600, i: !!live.italic, u: !!live.underline, c: live.fill }
  const range = (): [number, number] => {
    const [a, b] = lastSel.current
    return a === b ? wordAt(val.current.text, a) : [a, b]
  }
  const cur = (() => { const [a, b] = range(); return styleRange(val.current.text, val.current.runs, a, b, baseStyle) })()

  const style = (patch: StylePatch) => {
    const [a, b] = range()
    if (a === b) return
    const keep = lastSel.current
    const runs = applyStyle(val.current.text, val.current.runs, a, b, patch)
    push({ text: val.current.text, runs }, true, keep)
    ref.current?.focus()
    setSel(ref.current!, keep[0], keep[1])
  }
  const toggle = (k: 'b' | 'i' | 'u') => {
    const on = cur[k] === true
    // terug naar de stand van het tekstvak zelf als dat hetzelfde oplevert, zodat er geen onnodige opmaak blijft hangen
    const want = !on
    style({ [k]: want === baseStyle[k] ? null : want })
  }

  const onKey = (e: React.KeyboardEvent) => {
    e.stopPropagation()
    const now = ref.current && getSel(ref.current)
    if (now) lastSel.current = now
    if (palette) setPalette(false)
    const mod = e.metaKey || e.ctrlKey
    if (e.key === 'Escape' || (e.key === 'Enter' && mod)) { e.preventDefault(); finish(); return }
    if (e.key === 'Enter') { e.preventDefault(); replaceSel('\n'); return }
    if (mod && !e.shiftKey && !e.altKey) {
      const k = e.key.toLowerCase()
      if (k === 'b' || k === 'i' || k === 'u') { e.preventDefault(); toggle(k === 'b' ? 'b' : k === 'i' ? 'i' : 'u') }
    }
  }

  const onBlur = (e: React.FocusEvent) => {
    const to = e.relatedTarget as Node | null
    if (to && (bar.current?.contains(to) || ref.current?.contains(to))) return
    finish()
  }

  const fsBase = (box.fontSize || live.fontSize || 24)
  const fs = fsBase * zoom
  const h = Math.max(box.h || live.height, 1) * zoom
  const fam = live.fontFamily || 'Poppins'
  const ls = (live.letterSpacing || 0) * zoom * (box.fontSize && live.fontSize ? box.fontSize / live.fontSize : 1)
  const top = oy + live.y * zoom
  const colors = [...new Set([live.fill, ...docColors, '#FFFFFF', '#000000'].filter(Boolean).map((c) => c.toUpperCase()))].slice(0, 12)
  const hasSel = sel[0] !== sel[1] || wordAt(val.current.text, sel[0])[0] !== wordAt(val.current.text, sel[0])[1]
  const btn = (on: unknown) => cn('grid h-8 w-8 place-items-center rounded-lg text-ink transition-colors hover:bg-sunk disabled:opacity-40', on === true && 'bg-violet/10 text-violet')

  return (
    <>
      <div aria-hidden className="pointer-events-none absolute z-20 rounded-[2px] outline outline-2 outline-violet" style={{ left: ox + live.x * zoom - 2, top: top - 2, width: live.width * zoom + 4, height: h + 4, transform: `rotate(${live.rotation}deg)`, transformOrigin: 'center center' }} />
      {/* opmaakbalk: vet, cursief, onderstreept en kleur voor de geselecteerde woorden */}
      <div ref={bar} data-text-toolbar onMouseDown={(e) => { if ((e.target as HTMLElement).tagName !== 'INPUT') e.preventDefault() }}
        className="absolute z-30 flex items-center gap-0.5 rounded-xl border border-line bg-surface p-1 shadow-pop"
        style={{ left: ox + live.x * zoom, top: Math.max(4, top - 48) }} onBlur={onBlur}>
        <button type="button" title="Vet (Ctrl+B)" aria-pressed={cur.b === true} disabled={!hasSel} className={btn(cur.b)} onClick={() => toggle('b')}><Bold className="h-4 w-4" /></button>
        <button type="button" title="Cursief (Ctrl+I)" aria-pressed={cur.i === true} disabled={!hasSel} className={btn(cur.i)} onClick={() => toggle('i')}><Italic className="h-4 w-4" /></button>
        <button type="button" title="Onderstrepen (Ctrl+U)" aria-pressed={cur.u === true} disabled={!hasSel} className={btn(cur.u)} onClick={() => toggle('u')}><Underline className="h-4 w-4" /></button>
        <span className="mx-1 h-5 w-px bg-line" />
        <div className="relative">
          <button type="button" title="Tekstkleur" disabled={!hasSel} className={btn(palette)} onClick={() => setPalette((p) => !p)}>
            <span className="flex flex-col items-center leading-none">
              <span className="text-[13px] font-bold">A</span>
              <span className="mt-0.5 h-1 w-4 rounded-full border border-black/10" style={{ background: cur.c === 'mixed' ? 'linear-gradient(90deg,#E5484D,#5B3FD9,#1A5FC4)' : cur.c }} />
            </span>
          </button>
          {palette && (
            <div className="absolute left-0 top-10 z-40 w-[188px] rounded-xl border border-line bg-surface p-2 shadow-pop">
              <div className="grid grid-cols-6 gap-1.5">
                {colors.map((c) => (
                  <button key={c} type="button" title={c} onClick={() => { style({ c: c === live.fill.toUpperCase() ? null : c }); setPalette(false) }}
                    className={cn('h-6 w-6 rounded-md border border-black/10', cur.c !== 'mixed' && cur.c.toUpperCase() === c && 'ring-2 ring-violet ring-offset-1')} style={{ background: c }} />
                ))}
              </div>
              <label className="mt-2 flex h-8 cursor-pointer items-center gap-2 rounded-lg px-1.5 text-xs text-ink-2 hover:bg-sunk">
                <span className="h-5 w-5 rounded-md border border-black/10" style={{ background: 'conic-gradient(red,yellow,lime,cyan,blue,magenta,red)' }} />
                Andere kleur
                <input type="color" className="sr-only" tabIndex={-1} defaultValue={cur.c === 'mixed' ? live.fill : cur.c} onChange={(e) => style({ c: e.target.value.toUpperCase() })} />
              </label>
            </div>
          )}
        </div>
        <button type="button" title="Opmaak van selectie wissen" disabled={!hasSel} className={btn(false)} onClick={() => style({ b: null, i: null, u: null, c: null })}><RotateCcw className="h-3.5 w-3.5" /></button>
      </div>
      <div
        ref={ref}
        contentEditable
        suppressContentEditableWarning
        role="textbox"
        aria-multiline
        aria-label="Tekst bewerken"
        spellCheck={false}
        onInput={() => { const r = ref.current!; const v = serialize(r); push(v, false) }}
        onPaste={(e) => { e.preventDefault(); replaceSel(e.clipboardData.getData('text/plain').replace(/\r\n?/g, '\n')) }}
        onDrop={(e) => e.preventDefault()}
        onBlur={onBlur}
        onKeyDown={onKey}
        className="text-edit absolute z-20 overflow-hidden whitespace-pre-wrap break-words border-0 bg-transparent p-0 outline-none"
        style={{
          left: ox + live.x * zoom, top, width: live.width * zoom, minHeight: h,
          transform: `rotate(${live.rotation}deg)`, transformOrigin: 'center center',
          fontFamily: `"${fam}", sans-serif`, fontSize: fs, fontWeight: nearestWeight(fam, live.fontWeight || 400), fontStyle: live.italic ? 'italic' : 'normal',
          lineHeight: live.lineHeight || 1.2, letterSpacing: ls, textAlign: live.align || 'left',
          textTransform: live.uppercase ? 'uppercase' : 'none', caretColor: '#5B3FD9', color: 'transparent', WebkitTextFillColor: 'transparent', outline: 'none',
        }}
      />
    </>
  )
}
