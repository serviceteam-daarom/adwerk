import { useEffect, useState } from 'react'
import { create } from 'zustand'
import { Check, ChevronDown, Copy, Eye, History, Send, X, RotateCcw, ExternalLink, CheckCircle2, AlertCircle, Loader2, Columns2 } from 'lucide-react'
import { useEditor } from '../store/editor'
import { useSession, displayName } from '../store/session'
import { useLiveReload } from '../lib/live'
import { STATUSES, statusOf, setStatus, sendToClient, listVersions, listApprovals, getVersion, addApproval } from '../lib/workflow'
import type { Approval, DesignStatus, DesignVersion, Frame } from '../lib/types'
import { thumbnail } from '../lib/export'
import { StatusDot } from '../ui/StatusDot'
export { StatusDot }
import { AdPreviewer, useFrameImages } from '../ui/AdPreview'
import { timeAgo } from '../ui/CommentUI'
import { Button, Dialog, Label, Menu, MenuContent, MenuItem, MenuSep, MenuTrigger, Tip, cn } from '../ui/ui'
import { listFolders } from '../lib/api'
import { useComments } from '../lib/comments'

export const useWorkflow = create<{ versions: boolean; preview: boolean; send: boolean; compare: DesignVersion | null }>(() => ({ versions: false, preview: false, send: false, compare: null }))


/** Status van het ontwerp in de kopbalk, met de vervolgstappen. */
export function StatusMenu() {
  const design = useEditor((s) => s.design)
  const { user } = useSession()
  if (!design) return null
  const st = statusOf(design.status)
  const change = async (k: DesignStatus) => {
    useEditor.setState({ design: { ...design, status: k, status_at: new Date().toISOString() } })
    try { await setStatus(design.id, k, user!.id) } catch (e) { useEditor.getState().notify((e as Error).message) }
  }
  return (
    <Menu>
      <Tip label="Status, versies en goedkeuring">
        <MenuTrigger className="flex h-9 shrink-0 items-center gap-2 rounded-full border border-white/15 pl-3 pr-2 text-[13px] font-semibold text-white transition hover:bg-white/10" aria-label={`Status: ${st.label}`}>
          <StatusDot status={design.status} /><span className="hidden md:inline">{st.label}</span><ChevronDown size={14} className="text-white/60" />
        </MenuTrigger>
      </Tip>
      <MenuContent align="end">
        <div className="px-2.5 pb-1 pt-1.5"><Label>Status</Label></div>
        {STATUSES.map((s) => (
          <MenuItem key={s.key} onSelect={() => change(s.key)}>
            <StatusDot status={s.key} /><span className="min-w-0 flex-1"><span className="block font-medium">{s.label}</span><span className="block text-xs text-muted">{s.hint}</span></span>{s.key === st.key && <Check size={15} className="text-accent-fg" />}
          </MenuItem>
        ))}
        <MenuSep />
        <MenuItem onSelect={() => useWorkflow.setState({ send: true })}><Send size={15} /> Versie naar de klant…</MenuItem>
        <MenuItem onSelect={() => { useComments.setState({ panel: false, mode: false }); useWorkflow.setState({ versions: true }) }}><History size={15} /> Versies en goedkeuring</MenuItem>
        <MenuItem onSelect={() => useWorkflow.setState({ preview: true })}><Eye size={15} /> Advertentievoorbeeld</MenuItem>
      </MenuContent>
    </Menu>
  )
}

/** Versie vastzetten en klaarzetten in de feedbacklink. */
export function SendDialog() {
  const open = useWorkflow((s) => s.send)
  const design = useEditor((s) => s.design)
  const { user } = useSession()
  const [note, setNote] = useState('')
  const [busy, setBusy] = useState(false)
  const [done, setDone] = useState<{ n: number; url: string } | null>(null)
  const [copied, setCopied] = useState(false)
  const [next, setNext] = useState(1)
  useEffect(() => { if (open && design) { setDone(null); setNote(''); listVersions(design.id).then((v) => setNext((v[0]?.number || 0) + 1)) } }, [open, design?.id]) // eslint-disable-line react-hooks/exhaustive-deps
  if (!design) return null
  const close = () => useWorkflow.setState({ send: false })
  const go = async () => {
    setBusy(true)
    try {
      const doc = useEditor.getState().doc
      const thumb = doc.frames[0] ? await thumbnail(doc.frames[0], 360).catch(() => null) : null
      const r = await sendToClient(design.id, doc, note, thumb, user!.id)
      useEditor.setState({ design: { ...design, status: 'klant', status_at: new Date().toISOString() } })
      setDone({ n: r.version.number, url: r.url })
      try { await navigator.clipboard.writeText(r.url); setCopied(true) } catch { /* */ }
    } catch (e) { alert((e as Error).message) } finally { setBusy(false) }
  }
  return (
    <Dialog open={open} onOpenChange={(o) => !o && close()} title={done ? `Versie ${done.n} staat klaar` : 'Versie naar de klant'} description={done ? 'De klant ziet deze versie in de feedbacklink en kan feedback geven of goedkeuren.' : 'Zet de huidige stand vast als nieuwe versie. Je kunt daarna gewoon verder werken; de klant ziet alleen deze versie.'}>
      {done ? (
        <div className="grid gap-4">
          <div className="flex gap-2"><input readOnly value={done.url} className="h-10 min-w-0 flex-1 rounded-lg bg-sunk px-3 text-sm" onFocus={(e) => e.target.select()} />
            <Button onClick={async () => { try { await navigator.clipboard.writeText(done.url); setCopied(true) } catch { /* */ } }}>{copied ? <Check size={16} /> : <Copy size={16} />} {copied ? 'Gekopieerd' : 'Kopieer'}</Button></div>
          <div className="flex flex-wrap justify-end gap-2"><a href={done.url} target="_blank" rel="noreferrer" className="inline-flex h-10 items-center gap-2 rounded-full px-4 text-sm font-semibold hover:bg-sunk"><ExternalLink size={16} /> Bekijk als klant</a><Button variant="primary" onClick={close}>Klaar</Button></div>
        </div>
      ) : (
        <div className="grid gap-4">
          <label className="grid gap-1.5"><span className="text-sm font-semibold">Wat is er nieuw of veranderd? <span className="font-normal text-muted">(optioneel, ziet de klant)</span></span>
            <textarea value={note} onChange={(e) => setNote(e.target.value)} rows={3} placeholder={next > 1 ? 'Bijv. kop groter gemaakt en foto vervangen zoals besproken' : 'Bijv. eerste ontwerp voor de remarketingcampagne'} className="resize-none rounded-lg bg-sunk px-3 py-2 text-sm outline-none ring-violet focus:ring-2" onKeyDown={(e) => e.stopPropagation()} /></label>
          <div className="flex items-center justify-between gap-3 rounded-xl bg-mist p-3 text-sm"><span>Wordt <strong>versie {next}</strong>, status gaat naar <strong>Bij klant</strong>.</span><StatusDot status="klant" /></div>
          <div className="flex justify-end gap-2"><Button onClick={close}>Annuleren</Button><Button variant="primary" disabled={busy} onClick={go}>{busy ? <Loader2 size={16} className="animate-spin" /> : <Send size={16} />} Klaarzetten en link kopiëren</Button></div>
        </div>
      )}
    </Dialog>
  )
}

/** Paneel met versies, goedkeuringen en terugzetten. */
export function VersionsPanel() {
  const open = useWorkflow((s) => s.versions)
  const design = useEditor((s) => s.design)
  const { user, profile } = useSession()
  const [versions, setVersions] = useState<DesignVersion[] | null>(null)
  const [approvals, setApprovals] = useState<Approval[]>([])
  const load = () => { if (design) { listVersions(design.id).then(setVersions); listApprovals(design.id).then(setApprovals) } }
  useEffect(() => { if (open) load() }, [open, design?.id]) // eslint-disable-line react-hooks/exhaustive-deps
  useLiveReload(['design_versions', 'approvals'], () => { if (open) load() })
  if (!open || !design) return null
  const st = statusOf(design.status)
  const restore = async (v: DesignVersion) => {
    if (!confirm(`Versie ${v.number} terugzetten? De huidige stand blijft bewaard in ongedaan maken (Ctrl Z).`)) return
    const full = await getVersion(v.id)
    if (full?.data) { useEditor.getState().setDoc(full.data); useEditor.getState().notify(`Versie ${v.number} teruggezet`) }
  }
  const approveSelf = async (decision: 'approved' | 'changes') => {
    const note = decision === 'changes' ? prompt('Wat moet er anders? (optioneel)') || '' : ''
    await addApproval(design.id, { version: versions?.[0]?.number ?? null, decision, name: displayName(profile, user), note }, user!.id)
    useEditor.setState({ design: { ...design, status: decision === 'approved' ? 'goedgekeurd' : 'aanpassen' } })
    load()
  }
  return (
    <aside className="anim-panel absolute inset-y-0 right-0 z-30 flex w-[340px] max-w-full flex-col border-l border-line bg-surface shadow-pop" aria-label="Versies en goedkeuring">
      <div className="flex h-12 shrink-0 items-center gap-2 border-b border-line pl-4 pr-2"><History size={17} className="text-muted" /><span className="flex-1 text-sm font-semibold">Versies en goedkeuring</span><button onClick={() => useWorkflow.setState({ versions: false })} className="grid h-8 w-8 place-items-center rounded-lg text-muted hover:bg-sunk hover:text-ink" aria-label="Sluiten"><X size={17} /></button></div>
      <div className="grid gap-2 border-b border-line p-3">
        <div className="flex items-center gap-2.5 rounded-xl px-1 py-1"><StatusDot status={design.status} size={10} /><span className="flex-1"><span className="block text-sm font-semibold">{st.label}</span><span className="block text-xs text-muted">{design.status_at ? `sinds ${timeAgo(design.status_at)}` : st.hint}</span></span></div>
        <Button variant="primary" onClick={() => useWorkflow.setState({ send: true })}><Send size={16} /> Nieuwe versie naar de klant</Button>
        <div className="grid grid-cols-2 gap-1.5"><Button size="sm" onClick={() => approveSelf('approved')}><CheckCircle2 size={15} /> Akkoord vastleggen</Button><Button size="sm" onClick={() => approveSelf('changes')}><AlertCircle size={15} /> Aanpassingen</Button></div>
        <p className="px-1 text-[11px] leading-snug text-muted">Akkoord gekregen per mail of telefoon? Leg het hier vast met je eigen naam.</p>
      </div>
      <div className="min-h-0 flex-1 overflow-auto p-2">
        {versions === null && <div className="grid place-items-center py-10"><Loader2 className="animate-spin text-muted" /></div>}
        {versions?.length === 0 && <div className="px-6 py-10 text-center"><p className="text-sm font-semibold">Nog geen versies</p><p className="mt-1 text-xs leading-relaxed text-muted">Zet een versie klaar voor de klant; de feedbacklink toont dan die versie, ook als jij verder werkt.</p></div>}
        <ul className="grid gap-1.5">
          {versions?.map((v, i) => {
            const ap = approvals.filter((a) => a.version === v.number)
            return (
              <li key={v.id} className="anim-rise rounded-xl border border-line p-2.5">
                <div className="flex gap-3">
                  <div className="grid h-16 w-16 shrink-0 place-items-center overflow-hidden rounded-lg bg-sunk">{v.thumbnail ? <img src={v.thumbnail} alt="" className="max-h-full max-w-full object-contain" /> : <History size={18} className="text-muted" />}</div>
                  <div className="min-w-0 flex-1">
                    <div className="flex items-center gap-2"><span className="text-sm font-bold">Versie {v.number}</span>{i === 0 && <span className="text-[10px] font-bold uppercase tracking-wide text-[#1A5FC4]">in feedbacklink</span>}</div>
                    <p className="text-xs text-muted">{timeAgo(v.created_at)}</p>
                    {v.note && <p className="mt-1 line-clamp-2 text-xs leading-snug">{v.note}</p>}
                  </div>
                </div>
                {ap.length > 0 && <ul className="mt-2 grid gap-1">{ap.map((a) => (
                  <li key={a.id} className={cn('flex items-start gap-1.5 rounded-lg px-2 py-1.5 text-xs', a.decision === 'approved' ? 'bg-[#13A06B]/10 text-[#0E7A52]' : 'bg-[#CC4A25]/10 text-[#A33A1C]')}>
                    {a.decision === 'approved' ? <CheckCircle2 size={14} className="mt-px shrink-0" /> : <AlertCircle size={14} className="mt-px shrink-0" />}
                    <span className="min-w-0 break-words"><strong>{a.name}</strong> {a.decision === 'approved' ? 'keurde goed' : 'vraagt aanpassingen'} · {timeAgo(a.created_at)}{a.note && <span className="block text-ink/80">{a.note}</span>}</span>
                  </li>
                ))}</ul>}
                <div className="mt-2 flex gap-1">
                  <button onClick={() => useWorkflow.setState({ compare: v })} className="flex h-8 items-center gap-1.5 rounded-lg px-2 text-xs font-semibold hover:bg-sunk"><Columns2 size={14} /> Vergelijk met nu</button>
                  <button onClick={() => restore(v)} className="flex h-8 items-center gap-1.5 rounded-lg px-2 text-xs font-semibold hover:bg-sunk"><RotateCcw size={14} /> Terugzetten</button>
                </div>
              </li>
            )
          })}
        </ul>
      </div>
    </aside>
  )
}

/** Versie naast de huidige stand. */
export function CompareDialog() {
  const v = useWorkflow((s) => s.compare)
  const doc = useEditor((s) => s.doc)
  const [old, setOld] = useState<Frame[] | null>(null)
  const [fid, setFid] = useState<string | null>(null)
  useEffect(() => { setOld(null); if (v) getVersion(v.id).then((x) => setOld(x?.data?.frames || [])) }, [v?.id]) // eslint-disable-line react-hooks/exhaustive-deps
  const frames = doc.frames
  const cur = frames.find((f) => f.id === fid) || frames[0]
  const prev = old ? old.find((f) => f.id === cur?.id) || old.find((f) => f.w === cur?.w && f.h === cur?.h) || null : null
  const imgsNow = useFrameImages(cur ? [cur] : [])
  const imgsOld = useFrameImages(prev ? [prev] : [])
  if (!v) return null
  return (
    <Dialog xl open={!!v} onOpenChange={(o) => !o && useWorkflow.setState({ compare: null })} title={`Versie ${v.number} en nu`} description={v.note || 'Links de versie die de klant zag, rechts de huidige stand.'}>
      {frames.length > 1 && <div className="mb-4 flex flex-wrap gap-1">{frames.map((f) => <button key={f.id} onClick={() => setFid(f.id)} title={f.name} className={cn('max-w-[180px] truncate rounded-lg px-3 py-1.5 text-xs font-semibold transition', f.id === cur?.id ? 'bg-navy text-white' : 'bg-sunk text-muted hover:text-ink')}>{f.name}</button>)}</div>}
      <div className="grid gap-4 sm:grid-cols-2">
        {[['Versie ' + v.number, prev, imgsOld], ['Nu', cur, imgsNow]].map(([label, f, imgs]) => {
          const fr = f as Frame | null, im = imgs as Record<string, string>
          return (
            <figure key={label as string} className="grid gap-2">
              <figcaption className="text-xs font-bold uppercase tracking-[0.08em] text-muted">{label as string}</figcaption>
              <div className="checker grid min-h-[200px] place-items-center overflow-hidden rounded-xl border border-line p-3">
                {!old && label !== 'Nu' ? <Loader2 className="animate-spin text-muted" /> : !fr ? <p className="text-sm text-muted">Dit formaat bestond nog niet</p> : im[fr.id] ? <img src={im[fr.id]} alt="" className="max-h-[56vh] max-w-full shadow-card" /> : <Loader2 className="animate-spin text-muted" />}
              </div>
            </figure>
          )
        })}
      </div>
    </Dialog>
  )
}

/** Advertentievoorbeeld van het huidige ontwerp. */
export function PreviewDialog() {
  const open = useWorkflow((s) => s.preview)
  const doc = useEditor((s) => s.doc)
  const design = useEditor((s) => s.design)
  const [project, setProject] = useState<string | null>(null)
  useEffect(() => { if (open && design?.folder_id) listFolders().then((fs) => setProject(fs.find((f) => f.id === design.folder_id)?.name || null)) }, [open, design?.folder_id])
  if (!design) return null
  return (
    <Dialog xl open={open} onOpenChange={(o) => !o && useWorkflow.setState({ preview: false })} title="Advertentievoorbeeld" description="Zo ziet de advertentie eruit op het platform, met de koppen en teksten uit de brief. Paginanaam aanpassen? Voeg in de brief het veld Pagina toe.">
      {open && <AdPreviewer frames={doc.frames} brief={doc.brief} pageName={project || design.title} />}
    </Dialog>
  )
}
