import { Copy, Trash2, Lock, Unlock, ChevronsUp, ChevronsDown, Sparkles, Type, MoreHorizontal, FlipHorizontal2, AlignCenter } from 'lucide-react'
import { useEditor } from '../store/editor'
import { Tip, Menu, MenuTrigger, MenuContent, MenuItem, MenuSep, cn } from '../ui/ui'

/** Zwevende werkbalk boven de selectie (zoals in Canva): de meest gebruikte acties direct op het canvas. */
export default function SelectionToolbar({ box, onEdit }: { box: { x: number; y: number; width: number; height: number }; onEdit: () => void }) {
  const ids = useEditor((s) => s.selectedIds)
  const frame = useEditor((s) => s.doc.frames.find((f) => f.id === s.activeFrameId))
  const els = (frame?.elements || []).filter((e) => ids.includes(e.id))
  if (!els.length) return null
  const st = useEditor.getState
  const locked = els.every((e) => e.locked)
  const single = els.length === 1 ? els[0] : null
  const above = box.y > 64
  const top = above ? box.y - 52 : box.y + box.height + 34
  const btn = 'grid h-8 w-8 place-items-center rounded-lg text-ink transition hover:bg-sunk active:scale-95'
  const center = () => {
    const f = st().frame()
    st().updateEls(ids, (e) => ({ x: Math.round((f.w - e.width) / 2) }))
  }
  return (
    <div className="anim-pop absolute z-30 flex -translate-x-1/2 items-center gap-0.5 rounded-xl border border-line bg-surface p-1 shadow-pop" style={{ left: box.x + box.width / 2, top }} role="toolbar" aria-label="Acties voor de selectie" onMouseDown={(e) => e.stopPropagation()}>
      {single?.type === 'text' && !locked && <Tip label="Tekst bewerken (dubbelklik)"><button className={btn} onClick={onEdit} aria-label="Tekst bewerken"><Type size={16} /></button></Tip>}
      {!locked && <Tip label="Dupliceren (Ctrl D)"><button className={btn} onClick={() => st().duplicateSelected()} aria-label="Dupliceren"><Copy size={16} /></button></Tip>}
      <Tip label={locked ? 'Ontgrendelen' : 'Vergrendelen'}><button className={cn(btn, locked && 'text-accent-fg')} onClick={() => st().updateEls(ids, { locked: !locked })} aria-label={locked ? 'Ontgrendelen' : 'Vergrendelen'}>{locked ? <Lock size={16} /> : <Unlock size={16} />}</button></Tip>
      {!locked && single && <Tip label="Naar voren"><button className={btn} onClick={() => st().reorder(single.id, 'top')} aria-label="Helemaal naar voren"><ChevronsUp size={16} /></button></Tip>}
      {!locked && single && <Tip label="Naar achteren"><button className={btn} onClick={() => st().reorder(single.id, 'bottom')} aria-label="Helemaal naar achteren"><ChevronsDown size={16} /></button></Tip>}
      {!locked && <Tip label="Animeren"><button className={btn} onClick={() => st().setLeftTab('animate')} aria-label="Animeren"><Sparkles size={16} /></button></Tip>}
      {!locked && (
        <Menu>
          <MenuTrigger className={btn} aria-label="Meer"><MoreHorizontal size={16} /></MenuTrigger>
          <MenuContent>
            <MenuItem onSelect={center}><AlignCenter size={15} /> Horizontaal centreren</MenuItem>
            {single && ['image', 'icon'].includes(single.type) && <MenuItem onSelect={() => st().updateEls([single.id], { flipX: !single.flipX })}><FlipHorizontal2 size={15} /> Spiegelen</MenuItem>}
            <MenuItem onSelect={() => st().copy()}><Copy size={15} /> Kopiëren</MenuItem>
            <MenuSep />
            <MenuItem danger onSelect={() => st().removeSelected()}><Trash2 size={15} /> Verwijderen</MenuItem>
          </MenuContent>
        </Menu>
      )}
      {!locked && <span className="mx-0.5 h-5 w-px bg-line" />}
      {!locked && <Tip label="Verwijderen (Delete)"><button className={cn(btn, 'hover:text-accent-fg')} onClick={() => st().removeSelected()} aria-label="Verwijderen"><Trash2 size={16} /></button></Tip>}
    </div>
  )
}
