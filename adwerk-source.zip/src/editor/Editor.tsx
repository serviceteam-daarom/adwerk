import { useCallback, useEffect, useRef, useState } from 'react'
import { ChevronLeft, Undo2, Redo2, Minus, Plus, Maximize, Share2, Download, Cloud, CloudOff, Loader2, Copy as CopyIcon, Check } from 'lucide-react'
import { useEditor } from '../store/editor'
import { useSession, displayName } from '../store/session'
import { addMember, getDesign, getMembers, listFolders, listProfiles, removeMember, saveDesign } from '../lib/api'
import { startCollab, stopCollab } from '../lib/collab'
import { thumbnail } from '../lib/export'
import type { Folder, Profile } from '../lib/types'
import { Avatar, Button, Dialog, IconBtn, Label, Segmented, Select, Tip, Toast } from '../ui/ui'
import { navigate } from '../App'
import Canvas from './Canvas'
import { LeftPanel, LeftRail, addImageFromUrl } from './LeftPanels'
import Inspector from './Inspector'
import { FormatStrip, Timeline } from './Bottom'
import ExportDialog from './ExportDialog'
import { uploadAsset } from '../lib/api'
import { docFromFormats } from '../lib/factory'

function ShareDialog({ open, onOpenChange }: { open: boolean; onOpenChange: (o: boolean) => void }) {
  const design = useEditor((s) => s.design)
  const { user } = useSession()
  const [profiles, setProfiles] = useState<Profile[]>([])
  const [members, setMembers] = useState<string[]>([])
  const [folders, setFolders] = useState<Folder[]>([])
  const [copied, setCopied] = useState(false)
  useEffect(() => {
    if (!open || !design) return
    listProfiles().then(setProfiles); getMembers(design.id).then(setMembers); listFolders().then(setFolders)
  }, [open, design])
  if (!design) return null
  const mine = design.owner_id === user!.id
  const setMeta = async (patch: Partial<typeof design>) => {
    useEditor.setState({ design: { ...design, ...patch } })
    await saveDesign(design.id, patch, user!.id)
  }
  const link = window.location.href
  return (
    <Dialog open={open} onOpenChange={onOpenChange} title="Delen" description="Collega's met toegang kunnen tegelijk met jou in dit ontwerp werken.">
      <div className="grid gap-5">
        <div className="grid gap-2"><Label>Wie heeft toegang</Label>
          <Segmented value={design.visibility} onChange={(v) => mine && setMeta({ visibility: v })} options={[{ value: 'private', label: 'Alleen ik en genodigden' }, { value: 'team', label: 'Iedereen bij daar-om.nl' }]} />
          {!mine && <p className="text-xs text-muted">Alleen de eigenaar kan dit wijzigen.</p>}
        </div>
        {design.visibility === 'private' && mine && (
          <div className="grid gap-2"><Label>Uitnodigen</Label>
            <div className="grid max-h-56 gap-1 overflow-auto">
              {profiles.filter((p) => p.id !== user!.id).map((p) => (
                <label key={p.id} className="flex cursor-pointer items-center gap-2.5 rounded-lg px-2 py-1.5 hover:bg-sunk">
                  <Avatar name={displayName(p)} color={p.color} src={p.avatar_url} size={28} />
                  <span className="min-w-0 flex-1"><span className="block truncate text-sm font-medium">{displayName(p)}</span><span className="block truncate text-xs text-muted">{p.email}</span></span>
                  <input type="checkbox" className="h-4 w-4 accent-[#FF5B2E]" checked={members.includes(p.id)} onChange={async (e) => { if (e.target.checked) { await addMember(design.id, p.id); setMembers((m) => [...m, p.id]) } else { await removeMember(design.id, p.id); setMembers((m) => m.filter((x) => x !== p.id)) } }} />
                </label>
              ))}
              {profiles.length <= 1 && <p className="text-sm text-muted">Collega's verschijnen hier zodra ze een keer zijn ingelogd.</p>}
            </div>
          </div>
        )}
        <div className="grid gap-2"><Label>Project</Label>
          <Select value={design.folder_id || ''} onChange={(v) => setMeta({ folder_id: v || null })} options={[{ value: '', label: 'Geen project' }, ...folders.map((f) => ({ value: f.id, label: f.name }))]} />
        </div>
        <div className="grid gap-2"><Label>Link</Label>
          <div className="flex gap-2"><input readOnly value={link} className="h-9 min-w-0 flex-1 rounded-lg bg-sunk px-3 text-sm" onFocus={(e) => e.target.select()} />
            <Button onClick={async () => { try { await navigator.clipboard.writeText(link); setCopied(true); setTimeout(() => setCopied(false), 1500) } catch { /* */ } }}>{copied ? <Check size={16} /> : <CopyIcon size={16} />} Kopieer</Button></div>
        </div>
      </div>
    </Dialog>
  )
}

export default function Editor({ id }: { id: string }) {
  const { user, profile } = useSession()
  const [error, setError] = useState<string | null>(null)
  const [loaded, setLoaded] = useState(false)
  const [exportOpen, setExportOpen] = useState(false)
  const [shareOpen, setShareOpen] = useState(false)
  const [toast, setToast] = useState<string | null>(null)
  const design = useEditor((s) => s.design)
  const saveState = useEditor((s) => s.saveState)
  const zoom = useEditor((s) => s.zoom)
  const fitZoom = useEditor((s) => s.fitZoom)
  const peers = useEditor((s) => s.peers)
  const past = useEditor((s) => s.past.length)
  const future = useEditor((s) => s.future.length)
  const saving = useRef(false)

  // laden + samenwerken
  useEffect(() => {
    let alive = true
    getDesign(id).then((row) => {
      if (!alive) return
      if (!row.data?.frames?.length) row.data = docFromFormats(['meta-sq'])
      useEditor.getState().load(row)
      setLoaded(true)
      startCollab(id, { id: user!.id, name: displayName(profile, user), color: profile?.color || '#5B3FD9', avatar: profile?.avatar_url })
    }).catch(() => setError('Dit ontwerp bestaat niet of je hebt er geen toegang toe.'))
    return () => { alive = false; stopCollab() }
  }, [id]) // eslint-disable-line react-hooks/exhaustive-deps

  // automatisch opslaan
  const save = useCallback(async () => {
    const st = useEditor.getState()
    if (!st.design || saving.current || st.saveState !== 'dirty') return
    saving.current = true
    const v = st.version
    useEditor.setState({ saveState: 'saving' })
    try {
      const f = st.doc.frames[0]
      const thumb = f ? await thumbnail(f, 360).catch(() => null) : null
      await saveDesign(st.design.id, { data: st.doc, title: st.design.title, ...(thumb ? { thumbnail: thumb } : {}) }, user!.id)
      useEditor.setState({ saveState: useEditor.getState().version === v && useEditor.getState().saveState === 'saving' ? 'saved' : 'dirty' })
    } catch {
      useEditor.setState({ saveState: 'error' })
    } finally { saving.current = false }
  }, [user])

  useEffect(() => {
    if (saveState !== 'dirty') return
    const t = setTimeout(save, 1500)
    return () => clearTimeout(t)
  }, [saveState, save, design?.title, useEditor.getState().version]) // eslint-disable-line react-hooks/exhaustive-deps

  useEffect(() => {
    const before = (e: BeforeUnloadEvent) => { if (useEditor.getState().saveState !== 'saved') { save(); e.preventDefault() } }
    window.addEventListener('beforeunload', before)
    return () => window.removeEventListener('beforeunload', before)
  }, [save])

  // sneltoetsen
  useEffect(() => {
    const onKey = (e: KeyboardEvent) => {
      const t = e.target as HTMLElement
      if (t.closest('input, textarea, select, [contenteditable="true"]')) return
      const st = useEditor.getState()
      const mod = e.metaKey || e.ctrlKey
      if (mod && e.key.toLowerCase() === 'z') { e.preventDefault(); e.shiftKey ? st.redo() : st.undo(); return }
      if (mod && e.key.toLowerCase() === 'y') { e.preventDefault(); st.redo(); return }
      if (mod && e.key.toLowerCase() === 'd') { e.preventDefault(); st.duplicateSelected(); return }
      if (mod && e.key.toLowerCase() === 'c') { st.copy(); return }
      if (mod && e.key.toLowerCase() === 'v') { if (st.clipboard.length) { e.preventDefault(); st.paste() } return }
      if (mod && e.key.toLowerCase() === 'a') { e.preventDefault(); st.select(st.frame().elements.filter((x) => !x.locked && x.visible).map((x) => x.id)); return }
      if (mod && (e.key === '=' || e.key === '+')) { e.preventDefault(); st.setZoom(st.zoom * 1.2); return }
      if (mod && e.key === '-') { e.preventDefault(); st.setZoom(st.zoom / 1.2); return }
      if (mod && e.key === '0') { e.preventDefault(); st.setZoom(st.fitZoom); return }
      if (e.key === 'Delete' || e.key === 'Backspace') { e.preventDefault(); st.removeSelected(); return }
      if (e.key === 'Escape') { st.select([]); useEditor.setState({ time: null, playing: false }); return }
      if (e.key === ' ') { e.preventDefault(); useEditor.setState({ playing: !st.playing, time: st.playing ? null : 0 }); return }
      if (e.key.startsWith('Arrow') && st.selectedIds.length) {
        e.preventDefault()
        const d = e.shiftKey ? 10 : 1
        const dx = e.key === 'ArrowLeft' ? -d : e.key === 'ArrowRight' ? d : 0
        const dy = e.key === 'ArrowUp' ? -d : e.key === 'ArrowDown' ? d : 0
        st.updateEls(st.selectedIds, (x) => (x.locked ? {} : { x: x.x + dx, y: x.y + dy }))
      }
    }
    // afbeelding plakken vanaf klembord
    const onPaste = async (e: ClipboardEvent) => {
      const t = e.target as HTMLElement
      if (t.closest('input, textarea')) return
      const file = Array.from(e.clipboardData?.files || []).find((f) => f.type.startsWith('image/'))
      if (!file) return
      e.preventDefault()
      setToast('Afbeelding uploaden…')
      const a = await uploadAsset(file, user!.id)
      await addImageFromUrl(a.url, a.width, a.height)
      setToast(null)
    }
    window.addEventListener('keydown', onKey)
    window.addEventListener('paste', onPaste)
    return () => { window.removeEventListener('keydown', onKey); window.removeEventListener('paste', onPaste) }
  }, [user])

  // bestanden op het canvas slepen
  const onDrop = async (e: React.DragEvent) => {
    e.preventDefault()
    const asset = e.dataTransfer.getData('text/adwerk-asset')
    if (asset) { const a = JSON.parse(asset); await addImageFromUrl(a.url, a.width, a.height); return }
    const files = Array.from(e.dataTransfer.files).filter((f) => f.type.startsWith('image/'))
    for (const f of files) {
      setToast(`${f.name} uploaden…`)
      try { const a = await uploadAsset(f, user!.id); await addImageFromUrl(a.url, a.width, a.height) } catch (err) { setToast((err as Error).message); setTimeout(() => setToast(null), 3000); return }
    }
    setToast(null)
  }

  if (error) return (
    <div className="grid h-full place-items-center p-6 text-center"><div><p className="font-display text-2xl font-bold">{error}</p><Button className="mt-4" onClick={() => navigate('/')}>Terug naar home</Button></div></div>
  )
  if (!loaded || !design) return <div className="grid h-full place-items-center"><Loader2 className="animate-spin text-accent" size={32} /></div>

  const peerList = Object.values(peers).filter((p, i, a) => a.findIndex((x) => x.id === p.id) === i)

  return (
    <div className="flex h-full flex-col" onDragOver={(e) => e.preventDefault()} onDrop={onDrop}>
      <header className="flex h-14 shrink-0 items-center gap-2 bg-ink px-3 text-white">
        <Tip label="Naar home"><button onClick={async () => { await save(); navigate('/') }} className="flex items-center gap-1 rounded-lg px-2 py-1.5 font-display text-lg font-extrabold hover:bg-white/10"><ChevronLeft size={18} />Adwerk<span className="text-accent">.</span></button></Tip>
        <span className="mx-1 h-6 w-px bg-white/15" />
        <input value={design.title} onChange={(e) => useEditor.getState().setTitle(e.target.value)} className="h-9 w-[clamp(120px,22vw,320px)] rounded-lg bg-transparent px-2 text-sm font-semibold outline-none hover:bg-white/10 focus:bg-white/10" aria-label="Naam van het ontwerp" />
        <span className="flex items-center gap-1.5 text-xs text-white/60" role="status">
          {saveState === 'saved' && <><Cloud size={15} /> Opgeslagen</>}
          {saveState === 'saving' && <><Loader2 size={15} className="animate-spin" /> Opslaan…</>}
          {saveState === 'dirty' && <><Cloud size={15} /> Wijzigingen…</>}
          {saveState === 'error' && <button onClick={() => { useEditor.setState({ saveState: 'dirty' }) }} className="flex items-center gap-1.5 text-accent"><CloudOff size={15} /> Niet opgeslagen, opnieuw proberen</button>}
        </span>
        <span className="flex-1" />
        <IconBtn dark label="Ongedaan maken (Ctrl+Z)" disabled={!past} onClick={() => useEditor.getState().undo()}><Undo2 size={18} /></IconBtn>
        <IconBtn dark label="Opnieuw (Ctrl+Y)" disabled={!future} onClick={() => useEditor.getState().redo()}><Redo2 size={18} /></IconBtn>
        <span className="mx-1 hidden h-6 w-px bg-white/15 md:block" />
        <div className="hidden items-center md:flex">
          <IconBtn dark label="Uitzoomen" onClick={() => useEditor.getState().setZoom(zoom / 1.2)}><Minus size={16} /></IconBtn>
          <button className="w-14 rounded-md py-1 text-center text-xs tabular-nums hover:bg-white/10" onClick={() => useEditor.getState().setZoom(1)} title="100%">{Math.round(zoom * 100)}%</button>
          <IconBtn dark label="Inzoomen" onClick={() => useEditor.getState().setZoom(zoom * 1.2)}><Plus size={16} /></IconBtn>
          <IconBtn dark label="Passend maken" onClick={() => useEditor.getState().setZoom(fitZoom)}><Maximize size={16} /></IconBtn>
        </div>
        <div className="ml-2 flex items-center pl-2">
          {peerList.slice(0, 5).map((p) => <span key={p.id} className="-ml-2"><Avatar name={p.name} color={p.color} src={p.avatar} size={30} ring="#1A1726" /></span>)}
          <span className="-ml-2"><Avatar name={displayName(profile, user)} color={profile?.color} src={profile?.avatar_url} size={30} ring="#1A1726" /></span>
        </div>
        <Button size="sm" className="ml-2 border-0 bg-white/10 text-white hover:bg-white/20" onClick={() => setShareOpen(true)}><Share2 size={15} /> Delen</Button>
        <Button size="sm" variant="primary" onClick={() => setExportOpen(true)}><Download size={15} /> Exporteren</Button>
      </header>
      <div className="flex min-h-0 flex-1">
        <LeftRail />
        <LeftPanel />
        <div className="flex min-w-0 flex-1 flex-col">
          <Canvas />
          <Timeline />
          <FormatStrip />
        </div>
        <Inspector />
      </div>
      <ExportDialog open={exportOpen} onOpenChange={setExportOpen} />
      <ShareDialog open={shareOpen} onOpenChange={setShareOpen} />
      <Toast text={toast} />
    </div>
  )
}

