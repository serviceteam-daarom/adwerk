import { useCallback, useEffect, useRef, useState } from 'react'
import { ChevronLeft, Undo2, Redo2, Minus, Plus, Maximize, Share2, Download, Cloud, CloudOff, Loader2, Copy as CopyIcon, Check, SlidersHorizontal, Eye, LifeBuoy, Sparkles, AtSign } from 'lucide-react'
import { useEditor } from '../store/editor'
import { useSession, displayName } from '../store/session'
import { addMember, getDesign, getMembers, listFolders, listProfiles, removeMember, saveDesign } from '../lib/api'
import { startCollab, stopCollab } from '../lib/collab'
import { startComments, stopComments, useComments, setCommentMode, openThread } from '../lib/comments'
import { CommentsButton, CommentsPanel } from './Comments'
import { StatusMenu, SendDialog, VersionsPanel, CompareDialog, PreviewDialog, useWorkflow } from './Workflow'
import { ShareLinks } from './ShareLinks'
import { useLive, useLiveReload } from '../lib/live'
import { thumbnail } from '../lib/export'
import type { DesignRow, Folder, Profile } from '../lib/types'
import { Avatar, Button, Dialog, IconBtn, Label, Segmented, Select, Tip, Toast, Popover, PopoverTrigger, PopoverContent } from '../ui/ui'
import { ThemeToggle } from '../ui/ThemeToggle'
import { ChatButton, HelpDialog, TagDialog } from '../ui/Chat'
import { setWhere } from '../lib/online'
import { useOnline } from '../lib/online'
import { navigate } from '../App'
import { Logo } from '../pages/Login'
import Canvas, { canvasApi } from './Canvas'
import { LeftPanel, LeftRail } from './LeftPanels'
import { readDragPayload, dropPayload, addImage } from './dnd'
import Inspector from './Inspector'
import { FormatStrip, Timeline } from './Bottom'
import ExportDialog from './ExportDialog'
import { uploadAsset } from '../lib/api'
import { docFromFormats } from '../lib/factory'

function ShareDialog({ open, onOpenChange }: { open: boolean; onOpenChange: (o: boolean) => void }) {
  const design = useEditor((s) => s.design)
  const { user } = useSession()
  const [profiles, setProfiles] = useState<Profile[]>([])
  const [members, setMembers] = useState<string[]>([])
  const [folders, setFolders] = useState<Folder[]>([])
  const [copied, setCopied] = useState(false)
  useEffect(() => {
    if (!open || !design) return
    listProfiles().then(setProfiles); getMembers(design.id).then(setMembers); listFolders().then(setFolders)
  }, [open, design])
  useLiveReload(['design_members', 'profiles', 'folders'], () => { if (open && design) { getMembers(design.id).then(setMembers); listProfiles().then(setProfiles); listFolders().then(setFolders) } })
  if (!design) return null
  const mine = design.owner_id === user!.id
  const setMeta = async (patch: Partial<typeof design>) => {
    useEditor.setState({ design: { ...design, ...patch } })
    await saveDesign(design.id, patch, user!.id)
  }
  const link = window.location.href
  return (
    <Dialog open={open} onOpenChange={onOpenChange} title="Delen" description="Collega's met toegang kunnen tegelijk met jou in dit ontwerp werken.">
      <div className="grid gap-5">
        <div className="grid gap-2"><Label>Wie heeft toegang</Label>
          <Segmented value={design.visibility} onChange={(v) => mine && setMeta({ visibility: v })} options={[{ value: 'private', label: 'Alleen ik en genodigden' }, { value: 'team', label: 'Iedereen bij daar-om.nl' }]} />
          {!mine && <p className="text-xs text-muted">Alleen de eigenaar kan dit wijzigen.</p>}
        </div>
        {design.visibility === 'private' && mine && (
          <div className="grid gap-2"><Label>Uitnodigen</Label>
            <div className="grid max-h-56 gap-1 overflow-auto">
              {profiles.filter((p) => p.id !== user!.id).map((p) => (
                <label key={p.id} className="flex cursor-pointer items-center gap-2.5 rounded-lg px-2 py-1.5 hover:bg-sunk">
                  <Avatar name={displayName(p)} color={p.color} src={p.avatar_url} size={28} />
                  <span className="min-w-0 flex-1"><span className="block truncate text-sm font-medium">{displayName(p)}</span><span className="block truncate text-xs text-muted">{p.email}</span></span>
                  <input type="checkbox" className="h-4 w-4 accent-[#EA5F39]" checked={members.includes(p.id)} onChange={async (e) => { if (e.target.checked) { await addMember(design.id, p.id); setMembers((m) => [...m, p.id]) } else { await removeMember(design.id, p.id); setMembers((m) => m.filter((x) => x !== p.id)) } }} />
                </label>
              ))}
              {profiles.length <= 1 && <p className="text-sm text-muted">Collega's verschijnen hier zodra ze een keer zijn ingelogd.</p>}
            </div>
          </div>
        )}
        <div className="grid gap-2"><Label>Project</Label>
          <Select value={design.folder_id || ''} onChange={(v) => setMeta({ folder_id: v || null })} options={[{ value: '', label: 'Geen project' }, ...folders.map((f) => ({ value: f.id, label: f.name }))]} />
        </div>
        <ShareLinks designId={design.id} />
        <div className="grid gap-2"><Label>Link voor collega's</Label>
          <div className="flex gap-2"><input readOnly value={link} className="h-9 min-w-0 flex-1 rounded-lg bg-sunk px-3 text-sm" onFocus={(e) => e.target.select()} />
            <Button onClick={async () => { try { await navigator.clipboard.writeText(link); setCopied(true); setTimeout(() => setCopied(false), 1500) } catch { /* */ } }}>{copied ? <Check size={16} /> : <CopyIcon size={16} />} Kopieer</Button></div>
        </div>
      </div>
    </Dialog>
  )
}

export default function Editor({ id }: { id: string }) {
  const { user, profile } = useSession()
  const [error, setError] = useState<string | null>(null)
  const [loaded, setLoaded] = useState(false)
  const [exportOpen, setExportOpen] = useState(false)
  const [dropHint, setDropHint] = useState(false)
  const [helpOpen, setHelpOpen] = useState(false)
  const [tagOpen, setTagOpen] = useState(false)
  const [shareOpen, setShareOpen] = useState(false)
  const [toast, setToast] = useState<string | null>(null)
  const design = useEditor((s) => s.design)
  const saveState = useEditor((s) => s.saveState)
  const zoom = useEditor((s) => s.zoom)
  const fitZoom = useEditor((s) => s.fitZoom)
  const peers = useEditor((s) => s.peers)
  const agents = useEditor((s) => s.agents)
  // naam, zichtbaarheid en template-status live overnemen als een collega (of Claude) ze wijzigt
  const lastDesign = useLive((s) => s.last.designs)
  useEffect(() => {
    const st = useEditor.getState(), d = st.design, n = lastDesign?.new as Partial<DesignRow> | undefined
    if (!d || !n || n.id !== d.id || n.updated_by === user?.id) return
    const patch: Partial<DesignRow> = {}
    for (const k of ['title', 'visibility', 'is_template', 'folder_id', 'status', 'status_at'] as const) if (n[k] !== undefined && n[k] !== d[k]) (patch as Record<string, unknown>)[k] = n[k]
    if (Object.keys(patch).length) useEditor.setState({ design: { ...d, ...patch } })
  }, [lastDesign]) // eslint-disable-line react-hooks/exhaustive-deps
  const past = useEditor((s) => s.past.length)
  const notice = useEditor((s) => s.notice)
  const rightOpen = useEditor((s) => s.rightOpen)
  const future = useEditor((s) => s.future.length)
  const saving = useRef(false)

  // laden + samenwerken
  useEffect(() => {
    let alive = true
    getDesign(id).then((row) => {
      if (!alive) return
      if (!row.data?.frames?.length) row.data = docFromFormats(['meta-sq'])
      useEditor.getState().load(row)
      setLoaded(true)
      startCollab(id, { id: user!.id, name: displayName(profile, user), color: profile?.color || '#1A5FC4', avatar: profile?.avatar_url })
      startComments(id, { id: user!.id, name: displayName(profile, user) })
      const open = new URLSearchParams(window.location.hash.split('?')[1] || '').get('c')
      if (open) setTimeout(() => openThread(open), 600)
      setWhere(id, row.title)
      if (window.innerWidth < 1024) useEditor.setState({ rightOpen: false })
      if (window.innerWidth < 768) useEditor.setState({ leftTab: null })
    }).catch(() => setError('Dit ontwerp bestaat niet of je hebt er geen toegang toe.'))
    return () => { alive = false; stopCollab(); stopComments(); setWhere(null, null) }
  }, [id]) // eslint-disable-line react-hooks/exhaustive-deps

  // automatisch opslaan
  const save = useCallback(async () => {
    const st = useEditor.getState()
    if (!st.design || saving.current || st.saveState !== 'dirty') return
    saving.current = true
    const v = st.version
    useEditor.setState({ saveState: 'saving' })
    try {
      const f = st.doc.frames[0]
      const thumb = f ? await thumbnail(f, 360).catch(() => null) : null
      await saveDesign(st.design.id, { data: st.doc, title: st.design.title, ...(thumb ? { thumbnail: thumb } : {}) }, user!.id)
      useEditor.setState({ saveState: useEditor.getState().version === v && useEditor.getState().saveState === 'saving' ? 'saved' : 'dirty' })
    } catch {
      useEditor.setState({ saveState: 'error' })
    } finally { saving.current = false }
  }, [user])

  useEffect(() => {
    if (saveState !== 'dirty') return
    const t = setTimeout(save, 1500)
    return () => clearTimeout(t)
  }, [saveState, save, design?.title, useEditor.getState().version]) // eslint-disable-line react-hooks/exhaustive-deps

  useEffect(() => {
    const before = (e: BeforeUnloadEvent) => { if (useEditor.getState().saveState !== 'saved') { save(); e.preventDefault() } }
    window.addEventListener('beforeunload', before)
    return () => window.removeEventListener('beforeunload', before)
  }, [save])

  // sneltoetsen
  useEffect(() => {
    const onKey = (e: KeyboardEvent) => {
      const t = e.target as HTMLElement
      if (t.closest('input, textarea, select, [contenteditable="true"]')) return
      const st = useEditor.getState()
      const mod = e.metaKey || e.ctrlKey
      if (mod && e.code === 'Backslash') { e.preventDefault(); if (e.shiftKey) st.toggleRight(); else st.toggleLeft(); return }
      if (mod && e.key.toLowerCase() === 'z') { e.preventDefault(); e.shiftKey ? st.redo() : st.undo(); return }
      if (mod && e.key.toLowerCase() === 'y') { e.preventDefault(); st.redo(); return }
      if (mod && e.code === 'KeyG') { e.preventDefault(); e.shiftKey ? st.ungroupSelected() : st.groupSelected(); return }
      if (mod && e.altKey && /^Key[LRTBHV]$/.test(e.code)) { e.preventDefault(); st.alignSelected(({ l: 'left', r: 'right', t: 'top', b: 'bottom', h: 'center', v: 'middle' } as const)[e.code.slice(3).toLowerCase() as 'l']); return }
      if (mod && e.key.toLowerCase() === 'd') { e.preventDefault(); st.duplicateSelected(); return }
      if (mod && e.key.toLowerCase() === 'c') { st.copy(); return }
      if (mod && e.key.toLowerCase() === 'v') { if (st.clipboard.length) { e.preventDefault(); st.paste() } return }
      if (mod && e.key.toLowerCase() === 'a') { e.preventDefault(); st.select(st.frame().elements.filter((x) => !x.locked && x.visible).map((x) => x.id)); return }
      if (mod && (e.key === '=' || e.key === '+')) { e.preventDefault(); st.setZoom(st.zoom * 1.2); return }
      if (mod && e.key === '-') { e.preventDefault(); st.setZoom(st.zoom / 1.2); return }
      if (mod && e.key === '0') { e.preventDefault(); st.setZoom(st.fitZoom); return }
      if (e.key === 'Delete' || e.key === 'Backspace') { e.preventDefault(); st.removeSelected(); return }
      if (e.key === 'Escape') { const cs = useComments.getState(); if (cs.draft || cs.active || cs.mode) { useComments.setState({ draft: null, active: null, mode: false }); return } st.select([]); useEditor.setState({ time: null, playing: false }); return }
      if (!mod && !e.altKey && e.key.toLowerCase() === 'c') { e.preventDefault(); setCommentMode(!useComments.getState().mode); return }
      if (e.key === ' ') { e.preventDefault(); useEditor.setState({ playing: !st.playing, time: st.playing ? null : 0 }); return }
      if (e.key.startsWith('Arrow') && st.selectedIds.length) {
        e.preventDefault()
        const d = e.shiftKey ? 10 : 1
        const dx = e.key === 'ArrowLeft' ? -d : e.key === 'ArrowRight' ? d : 0
        const dy = e.key === 'ArrowUp' ? -d : e.key === 'ArrowDown' ? d : 0
        st.updateEls(st.selectedIds, (x) => (x.locked ? {} : { x: x.x + dx, y: x.y + dy }))
      }
    }
    // afbeelding plakken vanaf klembord
    const onPaste = async (e: ClipboardEvent) => {
      const t = e.target as HTMLElement
      if (t.closest('input, textarea')) return
      const file = Array.from(e.clipboardData?.files || []).find((f) => f.type.startsWith('image/'))
      if (!file) return
      e.preventDefault()
      setToast('Afbeelding uploaden…')
      const a = await uploadAsset(file, user!.id)
      await addImage(a.url, { name: file.name, replaceSelected: false })
      setToast(null)
    }
    window.addEventListener('keydown', onKey)
    window.addEventListener('paste', onPaste)
    return () => { window.removeEventListener('keydown', onKey); window.removeEventListener('paste', onPaste) }
  }, [user])

  // bestanden op het canvas slepen
  const onDrop = async (e: React.DragEvent) => {
    e.preventDefault()
    setDropHint(false)
    const at = canvasApi.clientToFrame(e.clientX, e.clientY)
    const p = readDragPayload(e)
    if (p) { try { await dropPayload(p, at) } catch (err) { setToast((err as Error).message); setTimeout(() => setToast(null), 3000) } return }
    const files = Array.from(e.dataTransfer.files).filter((f) => f.type.startsWith('image/'))
    for (const [i, f] of files.entries()) {
      setToast(`${f.name} uploaden…`)
      try { const a = await uploadAsset(f, user!.id); await addImage(a.url, { name: f.name, at: at ? { x: at.x + i * 40, y: at.y + i * 40 } : null, replaceSelected: false }) } catch (err) { setToast((err as Error).message); setTimeout(() => setToast(null), 3000); return }
    }
    setToast(null)
  }

  if (error) return (
    <div className="grid h-full place-items-center p-6 text-center"><div><p className="font-display text-2xl font-bold">{error}</p><Button className="mt-4" onClick={() => navigate('/')}>Terug naar home</Button></div></div>
  )
  if (!loaded || !design) return <div className="grid h-full place-items-center"><Loader2 className="animate-spin text-accent-fg" size={32} /></div>

  const peerList = Object.values(peers).filter((p, i, a) => a.findIndex((x) => x.id === p.id) === i)
  const agentList = Object.values(agents)
  const frames = useEditor.getState().doc.frames

  return (
    <div className="flex h-full flex-col" onDragOver={(e) => { e.preventDefault(); if (!dropHint) setDropHint(true) }} onDragLeave={(e) => { if (!e.currentTarget.contains(e.relatedTarget as Node)) setDropHint(false) }} onDrop={onDrop}>
      <header className="flex h-14 shrink-0 items-center gap-1 bg-navy px-2 text-white sm:gap-2 sm:px-3">
        <Tip label="Naar overzicht"><button onClick={async () => { await save(); navigate('/') }} className="flex shrink-0 items-center gap-1 rounded-full py-1.5 pl-1 pr-2 hover:bg-white/10" aria-label="Naar overzicht">
          <ChevronLeft size={18} /><span className="hidden lg:block"><Logo light size={30} /></span><span className="hidden sm:block lg:hidden"><Logo light markOnly size={28} /></span></button></Tip>
        <span className="mx-1 hidden h-6 w-px bg-white/15 sm:block" />
        <input value={design.title} title={design.title} onChange={(e) => useEditor.getState().setTitle(e.target.value)} className="h-9 min-w-0 flex-1 rounded-lg bg-transparent px-2 text-sm font-semibold outline-none hover:bg-white/10 focus:bg-white/10 sm:max-w-[280px]" aria-label="Naam van het ontwerp" />
        <span className="hidden shrink-0 items-center gap-1.5 text-xs text-white/70 md:flex" role="status">
          {saveState === 'saved' && <><Cloud size={15} /> Opgeslagen</>}
          {saveState === 'saving' && <><Loader2 size={15} className="animate-spin" /> Opslaan…</>}
          {saveState === 'dirty' && <><Cloud size={15} /> Wijzigingen…</>}
          {saveState === 'error' && <button onClick={() => { useEditor.setState({ saveState: 'dirty' }) }} className="flex items-center gap-1.5 text-[#F08A6C]"><CloudOff size={15} /> Niet opgeslagen, opnieuw</button>}
        </span>
        <span className="hidden flex-1 sm:block" />
        <StatusMenu />
        <IconBtn dark label="Ongedaan maken (Ctrl+Z)" disabled={!past} onClick={() => useEditor.getState().undo()}><Undo2 size={18} /></IconBtn>
        <IconBtn dark className="max-sm:hidden" label="Opnieuw (Ctrl+Y)" disabled={!future} onClick={() => useEditor.getState().redo()}><Redo2 size={18} /></IconBtn>
        <span className="mx-1 hidden h-6 w-px bg-white/15 xl:block" />
        <div className="hidden items-center xl:flex">
          <IconBtn dark label="Uitzoomen (Ctrl -)" onClick={() => useEditor.getState().setZoom(zoom / 1.2)}><Minus size={16} /></IconBtn>
          <Tip label="Terug naar 100%"><button className="w-14 rounded-md py-1 text-center text-xs tabular-nums hover:bg-white/10" onClick={() => useEditor.getState().setZoom(1)}>{Math.round(zoom * 100)}%</button></Tip>
          <IconBtn dark label="Inzoomen (Ctrl +)" onClick={() => useEditor.getState().setZoom(zoom * 1.2)}><Plus size={16} /></IconBtn>
          <IconBtn dark label="Passend maken (Ctrl 0)" onClick={() => useEditor.getState().setZoom(fitZoom)}><Maximize size={16} /></IconBtn>
        </div>
        <Popover>
          <PopoverTrigger asChild>
            <button className="ml-1 flex shrink-0 items-center rounded-full py-1 pl-3 pr-1 max-sm:ml-0 max-sm:pl-2.5 hover:bg-white/10" aria-label={`${peerList.length + 1} mensen in dit ontwerp`}>
              {peerList.slice(0, 4).map((p) => <span key={p.id} className="-ml-2.5"><Avatar name={p.name} color={p.color} src={p.avatar} size={30} ring={p.color} /></span>)}
              {agentList.map((a) => <span key={a.key} className="-ml-2.5 grid h-[30px] w-[30px] place-items-center rounded-full text-white" style={{ background: a.color, boxShadow: `0 0 0 2px ${a.color}` }} title={`${a.name} (AI) werkt mee`}><Sparkles size={14} /></span>)}
              <span className="-ml-2.5"><Avatar name={displayName(profile, user)} color={profile?.color} src={profile?.avatar_url} size={30} ring="rgb(var(--navy))" /></span>
            </button>
          </PopoverTrigger>
          <PopoverContent align="end" className="w-72">
            <Label className="mb-2">In dit ontwerp</Label>
            <ul className="grid gap-1">
              <li className="flex items-center gap-2.5 rounded-lg px-1 py-1"><Avatar name={displayName(profile, user)} color={profile?.color} src={profile?.avatar_url} size={28} /><span className="flex-1 truncate text-sm font-medium">{displayName(profile, user)} (jij)</span></li>
              {peerList.map((p) => (
                <li key={p.id}><button className="flex w-full items-center gap-2.5 rounded-lg px-1 py-1 text-left hover:bg-sunk" onClick={() => p.frameId && useEditor.getState().setActiveFrame(p.frameId)}>
                  <Avatar name={p.name} color={p.color} src={p.avatar} size={28} />
                  <span className="min-w-0 flex-1"><span className="block truncate text-sm font-medium">{p.name}</span><span className="block truncate text-xs text-muted">{frames.find((f) => f.id === p.frameId)?.name || 'Kijkt mee'}</span></span>
                  <Eye size={15} className="text-muted" aria-label="Ga naar dit formaat" />
                </button></li>
              ))}
            </ul>
            {!peerList.length && <p className="mt-2 text-xs leading-relaxed text-muted">Nog niemand anders. Deel het ontwerp, dan zie je elkaars cursor en wijzigingen live.</p>}
            <OnlineElsewhere designId={design.id} />
          </PopoverContent>
        </Popover>
        <span className="hidden 2xl:block"><ThemeToggle dark /></span>
        <Tip label="Hulp vragen aan een collega"><button onClick={() => setHelpOpen(true)} className="press hidden h-9 min-w-9 items-center justify-center gap-1.5 rounded-lg px-2 text-sm font-semibold text-white/85 transition hover:bg-white/10 hover:text-white sm:inline-flex 2xl:px-3" aria-label="Hulp vragen"><LifeBuoy size={16} /><span className="hidden 2xl:inline">Hulp</span></button></Tip>
        <Tip label="Collega taggen in dit ontwerp"><button onClick={() => setTagOpen(true)} className="press hidden h-9 w-9 place-items-center rounded-lg text-white/85 transition hover:bg-white/10 hover:text-white sm:grid" aria-label="Collega taggen"><AtSign size={18} /></button></Tip>
        <Tip label="Advertentievoorbeeld"><button onClick={() => useWorkflow.setState({ preview: true })} className="press hidden h-9 w-9 place-items-center rounded-lg text-white/85 transition hover:bg-white/10 hover:text-white sm:grid" aria-label="Advertentievoorbeeld"><Eye size={18} /></button></Tip>
        <CommentsButton />
        <ChatButton dark />
        <Button size="sm" className="border-0 bg-white/10 px-3 text-white hover:bg-white/20" onClick={() => setShareOpen(true)} aria-label="Delen"><Share2 size={15} /><span className="hidden sm:inline">Delen</span></Button>
        <Button size="sm" variant="primary" className="px-3" onClick={() => setExportOpen(true)} aria-label="Exporteren"><Download size={15} /><span className="hidden sm:inline">Exporteren</span></Button>
        <span className="lg:hidden"><IconBtn dark label="Eigenschappen" active={rightOpen} onClick={() => useEditor.getState().toggleRight()}><SlidersHorizontal size={18} /></IconBtn></span>
      </header>
      <div className="relative flex min-h-0 flex-1 overflow-hidden [contain:paint]">
        <LeftRail />
        <LeftPanel />
        <div className="relative flex min-w-0 flex-1 flex-col">
          <Canvas />
          {dropHint && <div className="pointer-events-none absolute inset-3 z-20 grid place-items-center rounded-[20px] border-2 border-dashed border-accent bg-accent/5"><span className="rounded-blob bg-navy px-4 py-2 text-sm font-semibold text-white">Loslaten om toe te voegen<span className="text-lila">.</span></span></div>}
          <Timeline />
          <FormatStrip />
        </div>
        <Inspector />
        <CommentsPanel onShare={() => setShareOpen(true)} />
        <VersionsPanel />
      </div>
      <ExportDialog open={exportOpen} onOpenChange={setExportOpen} />
      <ShareDialog open={shareOpen} onOpenChange={setShareOpen} />
      <SendDialog />
      <CompareDialog />
      <PreviewDialog />
      <TagDialog open={tagOpen} onOpenChange={setTagOpen} designId={design.id} designTitle={design.title} />
      <HelpDialog open={helpOpen} onOpenChange={setHelpOpen} designId={design.id} designTitle={design.title} />
      <Toast text={toast || notice} />
    </div>
  )
}

function OnlineElsewhere({ designId }: { designId: string }) {
  const users = useOnline((s) => s.users.filter((u) => u.designId !== designId))
  if (!users.length) return null
  return (
    <div className="mt-4 border-t border-line pt-3">
      <Label className="mb-2">Ook online</Label>
      <ul className="grid gap-1">{users.map((u) => (
        <li key={u.id} className="flex items-center gap-2.5 px-1 py-0.5"><Avatar name={u.name} color={u.color} src={u.avatar} size={24} /><span className="min-w-0 flex-1 truncate text-[13px]">{u.name}<span className="text-muted"> · {u.designTitle || 'overzicht'}</span></span></li>
      ))}</ul>
    </div>
  )
}
