import { useEffect, useMemo, useRef, useState } from 'react'
import { LayoutTemplate, Shapes, Type, Upload, Palette, Sparkles, Ratio, Layers, Eye, EyeOff, Lock, Unlock, GripVertical, Trash2, Plus, Copy, Wand2, Check, X } from 'lucide-react'
import { useEditor, type LeftTab } from '../store/editor'
import { makeEl, resizeElements, cloneFrameTo, makeFrame, uid, defaultAnim } from '../lib/factory'
import { TEMPLATES } from '../lib/templates'
import { thumbnail } from '../lib/export'
import { ICONS, iconSvg } from '../lib/icons'
import { PLATFORMS, ALL_FORMATS } from '../lib/formats'
import { IN_ANIMS, EMPH_ANIMS } from '../lib/anim'
import { deleteAsset, listAssets, listKits, shareAsset, uploadAsset, getDesign, listDesigns } from '../lib/api'
import { useSession } from '../store/session'
import type { Asset, BrandKit, El, ElType, InAnim, EmphAnim, Frame } from '../lib/types'
import { Button, Input, Label, Segmented, Select, Slider, cn, Tip, Dialog } from '../ui/ui'
import { PlatformLogo, PlatformLogos } from '../ui/PlatformLogo'
import { loadFont } from '../lib/fonts'
import { KitEditor } from '../pages/BrandKits'
import { BRAND_ELEMENTS, DAAROM_KIT, brandUrl } from '../lib/brand'

const TABS: { key: LeftTab; label: string; icon: React.ReactNode }[] = [
  { key: 'templates', label: 'Templates', icon: <LayoutTemplate size={22} /> },
  { key: 'elements', label: 'Elementen', icon: <Shapes size={22} /> },
  { key: 'text', label: 'Tekst', icon: <Type size={22} /> },
  { key: 'uploads', label: 'Uploads', icon: <Upload size={22} /> },
  { key: 'brand', label: 'Merk', icon: <Palette size={22} /> },
  { key: 'animate', label: 'Animeren', icon: <Sparkles size={22} /> },
  { key: 'formats', label: 'Formaten', icon: <Ratio size={22} /> },
  { key: 'layers', label: 'Lagen', icon: <Layers size={22} /> },
]

export function LeftRail() {
  const tab = useEditor((s) => s.leftTab)
  const setTab = useEditor((s) => s.setLeftTab)
  return (
    <nav className="flex w-[76px] shrink-0 flex-col gap-1 overflow-y-auto border-r border-line bg-white px-1.5 py-2" aria-label="Panelen">
      {TABS.map((t) => (
        <button key={t.key} onClick={() => setTab(tab === t.key ? null : t.key)} aria-pressed={tab === t.key}
          className={cn('grid justify-items-center gap-1 rounded-xl px-1 py-2.5 text-[11px] font-semibold transition', tab === t.key ? 'bg-accent-soft text-accent' : 'text-muted hover:bg-sunk hover:text-ink')}>
          {t.icon}{t.label}
        </button>
      ))}
    </nav>
  )
}

export function LeftPanel() {
  const tab = useEditor((s) => s.leftTab)
  if (!tab) return null
  return (
    <aside className="flex w-[300px] shrink-0 flex-col overflow-hidden border-r border-line bg-white">
      <div className="min-h-0 flex-1 overflow-y-auto overflow-x-hidden p-4">
        {tab === 'templates' && <TemplatesPanel />}
        {tab === 'elements' && <ElementsPanel />}
        {tab === 'text' && <TextPanel />}
        {tab === 'uploads' && <UploadsPanel />}
        {tab === 'brand' && <BrandPanel />}
        {tab === 'animate' && <AnimatePanel />}
        {tab === 'formats' && <FormatsPanel />}
        {tab === 'layers' && <LayersPanel />}
      </div>
    </aside>
  )
}

const H = ({ children }: { children: React.ReactNode }) => <h3 className="mb-3 font-display text-lg font-bold">{children}</h3>

/* ---------- Templates ---------- */
const thumbCache = new Map<string, string>()

function applyTemplateFrame(src: Frame) {
  const st = useEditor.getState()
  st.mutate((d) => {
    d.frames = d.frames.map((f) => ({ ...f, background: { ...src.background }, duration: src.duration, elements: resizeElements(src, f) }))
  })
  st.select([])
}

function TemplatesPanel() {
  const [thumbs, setThumbs] = useState<Record<string, string>>(Object.fromEntries(thumbCache))
  const [team, setTeam] = useState<{ id: string; title: string; thumbnail: string | null }[]>([])
  const [confirm, setConfirm] = useState<null | (() => void)>(null)
  const { user } = useSession()
  useEffect(() => {
    let alive = true
    ;(async () => {
      for (const t of TEMPLATES) {
        if (thumbCache.has(t.key)) continue
        const url = await thumbnail(t.frame(), 240)
        thumbCache.set(t.key, url)
        if (alive) setThumbs(Object.fromEntries(thumbCache))
      }
    })()
    listDesigns({ scope: 'templates', userId: user!.id }).then((r) => alive && setTeam(r))
    return () => { alive = false }
  }, [user])
  const hasContent = useEditor((s) => s.doc.frames.some((f) => f.elements.length))
  const ask = (fn: () => void) => (hasContent ? setConfirm(() => fn) : fn())
  return (
    <div>
      <H>Templates</H>
      <p className="mb-4 text-sm text-muted">Een template wordt in één keer op alle formaten van je set gezet.</p>
      {team.length > 0 && (
        <>
          <Label className="mb-2">Van het team</Label>
          <div className="mb-5 grid grid-cols-2 gap-2.5">
            {team.map((t) => (
              <button key={t.id} onClick={() => ask(async () => { const d = await getDesign(t.id); if (d.data.frames[0]) applyTemplateFrame(d.data.frames[0]) })} className="grid gap-1 text-left">
                <span className="grid aspect-square place-items-center overflow-hidden rounded-lg bg-sunk">{t.thumbnail && <img src={t.thumbnail} alt="" className="max-h-full max-w-full" />}</span>
                <span className="truncate text-xs font-semibold">{t.title}</span>
              </button>
            ))}
          </div>
        </>
      )}
      <Label className="mb-2">Adwerk basis</Label>
      <div className="grid grid-cols-2 gap-2.5">
        {TEMPLATES.map((t) => (
          <button key={t.key} onClick={() => ask(() => applyTemplateFrame(t.frame()))} className="group grid gap-1 text-left">
            <span className="grid aspect-square place-items-center overflow-hidden rounded-lg bg-sunk ring-accent transition group-hover:ring-2">
              {thumbs[t.key] ? <img src={thumbs[t.key]} alt="" className="h-full w-full object-cover" /> : <span className="h-5 w-5 animate-spin rounded-full border-2 border-line border-t-accent" />}
            </span>
            <span className="text-xs font-semibold">{t.name}</span>
          </button>
        ))}
      </div>
      <Dialog open={!!confirm} onOpenChange={(o) => !o && setConfirm(null)} title="Template toepassen?" description="De huidige inhoud van alle formaten wordt vervangen. Met ongedaan maken (Ctrl+Z) haal je het terug.">
        <div className="flex justify-end gap-2"><Button onClick={() => setConfirm(null)}>Annuleren</Button><Button variant="primary" onClick={() => { confirm?.(); setConfirm(null) }}>Toepassen</Button></div>
      </Dialog>
    </div>
  )
}

/* ---------- Elementen ---------- */
function addShape(type: ElType, patch: Partial<El> = {}) {
  const st = useEditor.getState()
  st.addEl(makeEl(type, st.frame(), patch))
}

function ElementsPanel() {
  const [q, setQ] = useState('')
  const icons = Object.keys(ICONS).filter((k) => k.includes(q.toLowerCase()))
  const shapes: { label: string; type: ElType; patch?: Partial<El>; svg: React.ReactNode }[] = [
    { label: 'Rechthoek', type: 'rect', svg: <rect x="4" y="8" width="40" height="32" fill="currentColor" /> },
    { label: 'Afgerond', type: 'rect', patch: { cornerRadius: 40 }, svg: <rect x="4" y="8" width="40" height="32" rx="9" fill="currentColor" /> },
    { label: 'Cirkel', type: 'ellipse', svg: <circle cx="24" cy="24" r="18" fill="currentColor" /> },
    { label: 'Driehoek', type: 'triangle', svg: <path d="M24 6 44 42H4z" fill="currentColor" /> },
    { label: 'Ster', type: 'star', svg: <path d="m24 4 5.9 12.6L44 18.3l-10.2 9.6 2.5 13.7L24 34.8l-12.3 6.8 2.5-13.7L4 18.3l14.1-1.7z" fill="currentColor" /> },
    { label: 'Badge', type: 'star', patch: { points: 14, innerRatio: 0.82 }, svg: <path d="m24 4 3 4.6 5.3-1.3.9 5.4 5.2 1.6-1.6 5.2 3.8 4-3.8 4 1.6 5.2-5.2 1.6-.9 5.4-5.3-1.3L24 44l-3-4.6-5.3 1.3-.9-5.4-5.2-1.6 1.6-5.2L7.4 24l3.8-4-1.6-5.2 5.2-1.6.9-5.4 5.3 1.3z" fill="currentColor" /> },
    { label: 'Lijn', type: 'line', svg: <rect x="4" y="22" width="40" height="4" rx="2" fill="currentColor" /> },
    { label: 'Pil', type: 'rect', patch: { cornerRadius: 999, height: 120, width: 360 }, svg: <rect x="2" y="16" width="44" height="16" rx="8" fill="currentColor" /> },
    { label: 'Fotokader', type: 'image', svg: <g><rect x="4" y="8" width="40" height="32" rx="3" fill="#D9D6E3" /><path d="m8 36 10-12 8 9 6-6 8 9z" fill="#6B6880" /></g> },
  ]
  return (
    <div className="grid gap-5">
      <div><H>Vormen</H>
        <div className="grid grid-cols-3 gap-2">
          {shapes.map((s) => (
            <Tip key={s.label} label={s.label}>
              <button onClick={() => addShape(s.type, s.patch)} className="grid aspect-square place-items-center rounded-lg bg-sunk text-ink transition hover:bg-accent-soft hover:text-accent" aria-label={s.label}>
                <svg width="44" height="44" viewBox="0 0 48 48">{s.svg}</svg>
              </button>
            </Tip>
          ))}
        </div>
      </div>
      <div><H>daar-om.nl</H>
        <p className="-mt-2 mb-3 text-xs text-muted">Pijlen, Martinitoren en logo's van de website.</p>
        <div className="grid grid-cols-3 gap-2">
          {BRAND_ELEMENTS.map((b) => (
            <Tip key={b.file} label={b.name}>
              <button onClick={() => addImageFromUrl(brandUrl(b.file), b.w, b.h)} className={cn('grid aspect-square place-items-center rounded-lg p-2 transition hover:ring-2 hover:ring-accent', b.file.includes('wit') ? 'bg-ink' : 'bg-mist')} aria-label={b.name}>
                <img src={brandUrl(b.file)} alt="" className="max-h-full max-w-full object-contain" />
              </button>
            </Tip>
          ))}
        </div>
      </div>
      <div><H>Iconen</H>
        <Input placeholder="Zoek icoon (bijv. cart, phone)" value={q} onChange={(e) => setQ(e.target.value)} className="mb-3" />
        <div className="grid grid-cols-5 gap-1.5">
          {icons.map((k) => (
            <button key={k} title={k} onClick={() => addShape('icon', { icon: k })} className="grid aspect-square place-items-center rounded-lg text-ink hover:bg-sunk" dangerouslySetInnerHTML={{ __html: iconSvg(k, '#1B213B', 2, 24) }} />
          ))}
        </div>
      </div>
    </div>
  )
}

/* ---------- Tekst ---------- */
function TextPanel() {
  const add = (patch: Partial<El>) => {
    const st = useEditor.getState()
    const f = st.frame()
    const k = Math.min(f.w, f.h) / 1080
    if (patch.fontFamily) loadFont(patch.fontFamily)
    const el = makeEl('text', f, { ...patch, fontSize: Math.max(8, Math.round((patch.fontSize || 48) * k)) })
    el.x = (f.w - el.width) / 2
    st.addEl(el)
  }
  const combos: { label: string; p: Partial<El>; style: React.CSSProperties }[] = [
    { label: 'Mega sale', p: { text: 'MEGA SALE', fontFamily: 'Anton', fontWeight: 400, fontSize: 150, fill: '#EA5F39' }, style: { fontFamily: 'Anton', fontSize: 30, color: '#EA5F39' } },
    { label: 'Nieuw binnen', p: { text: 'Nieuw binnen', fontFamily: 'Playfair Display', fontWeight: 700, italic: true, fontSize: 110 }, style: { fontFamily: 'Playfair Display', fontStyle: 'italic', fontWeight: 700, fontSize: 26 } },
    { label: 'Gratis', p: { text: 'Gratis verzending', fontFamily: 'Unbounded', fontWeight: 800, fontSize: 80, fill: '#1A5FC4' }, style: { fontFamily: 'Unbounded', fontWeight: 800, fontSize: 18, color: '#1A5FC4' } },
    { label: 'Handgeschreven', p: { text: 'Met liefde gemaakt', fontFamily: 'Caveat', fontWeight: 700, fontSize: 110, fill: '#13B58C' }, style: { fontFamily: 'Caveat', fontWeight: 700, fontSize: 28, color: '#13B58C' } },
  ]
  useEffect(() => { combos.forEach((c) => loadFont(c.p.fontFamily!)) }, []) // eslint-disable-line react-hooks/exhaustive-deps
  return (
    <div className="grid gap-3">
      <H>Tekst</H>
      <Button variant="primary" onClick={() => add({ text: 'Typ je tekst', fontSize: 48, fontWeight: 500 })}><Plus size={17} /> Tekstvak toevoegen</Button>
      <button onClick={() => add({ text: 'Voeg een kop toe', fontSize: 110, fontWeight: 800, fontFamily: 'Poppins' })} className="rounded-lg border border-line p-3 text-left font-display text-[26px] font-extrabold hover:bg-sunk">Voeg een kop toe</button>
      <button onClick={() => add({ text: 'Voeg een subkop toe', fontSize: 64, fontWeight: 600 })} className="rounded-lg border border-line p-3 text-left text-lg font-semibold hover:bg-sunk">Voeg een subkop toe</button>
      <button onClick={() => add({ text: 'Voeg wat broodtekst toe', fontSize: 40, fontWeight: 400 })} className="rounded-lg border border-line p-3 text-left text-sm hover:bg-sunk">Voeg wat broodtekst toe</button>
      <Label className="mt-3">Combinaties</Label>
      <div className="grid grid-cols-2 gap-2">
        {combos.map((c) => (
          <button key={c.label} onClick={() => add(c.p)} className="grid h-24 place-items-center overflow-hidden rounded-lg bg-sunk px-2 text-center leading-none hover:ring-2 hover:ring-accent" style={c.style}>{c.p.text}</button>
        ))}
      </div>
    </div>
  )
}

/* ---------- Uploads ---------- */
export async function addImageFromUrl(url: string, w: number, h: number) {
  const st = useEditor.getState()
  const sel = st.frame().elements.find((e) => st.selectedIds.length === 1 && e.id === st.selectedIds[0] && e.type === 'image')
  if (sel) { st.updateEls([sel.id], { src: url, cropZoom: 1, cropX: 0.5, cropY: 0.5 }); return }
  const f = st.frame()
  const ratio = w && h ? w / h : 1
  let ew = f.w * 0.6, eh = ew / ratio
  if (eh > f.h * 0.6) { eh = f.h * 0.6; ew = eh * ratio }
  st.addEl(makeEl('image', f, { src: url, width: ew, height: eh, x: (f.w - ew) / 2, y: (f.h - eh) / 2, name: 'Afbeelding' }))
}

function UploadsPanel() {
  const { user } = useSession()
  const [scope, setScope] = useState<'mine' | 'shared'>('mine')
  const [assets, setAssets] = useState<Asset[]>([])
  const [busy, setBusy] = useState(0)
  const [err, setErr] = useState<string | null>(null)
  const inputRef = useRef<HTMLInputElement>(null)
  const load = () => listAssets(user!.id, scope).then(setAssets)
  useEffect(() => { load() }, [scope]) // eslint-disable-line react-hooks/exhaustive-deps
  const upload = async (files: FileList | File[] | null) => {
    if (!files) return
    setErr(null)
    const list = Array.from(files).filter((f) => f.type.startsWith('image/'))
    setBusy(list.length)
    for (const f of list) {
      try {
        if (f.size > 20 * 1024 * 1024) throw new Error(`${f.name} is groter dan 20 MB`)
        const a = await uploadAsset(f, user!.id, scope === 'shared')
        setAssets((x) => [a, ...x])
      } catch (e) { setErr((e as Error).message) }
      setBusy((b) => b - 1)
    }
  }
  return (
    <div className="grid gap-4" onDragOver={(e) => e.preventDefault()} onDrop={(e) => { e.preventDefault(); upload(e.dataTransfer.files) }}>
      <H>Uploads</H>
      <Button variant="primary" onClick={() => inputRef.current?.click()}><Upload size={17} /> Bestanden uploaden</Button>
      <input ref={inputRef} type="file" accept="image/*" multiple className="hidden" onChange={(e) => upload(e.target.files)} />
      <p className="-mt-2 text-xs text-muted">Of sleep afbeeldingen hierheen. PNG, JPG, SVG of WebP tot 20 MB.</p>
      {err && <p role="alert" className="rounded-lg bg-accent-soft px-3 py-2 text-sm text-accent-dark">{err}</p>}
      <Segmented value={scope} onChange={setScope} options={[{ value: 'mine', label: 'Mijn uploads' }, { value: 'shared', label: 'Team' }]} />
      {busy > 0 && <p className="text-sm text-muted">Bezig met uploaden ({busy})…</p>}
      <div className="grid grid-cols-2 gap-2">
        {assets.map((a) => (
          <div key={a.id} className="checker group relative aspect-square overflow-hidden rounded-lg">
            <button className="h-full w-full" onClick={() => addImageFromUrl(a.url, a.width, a.height)} draggable onDragStart={(e) => e.dataTransfer.setData('text/adwerk-asset', JSON.stringify(a))} title={a.name}>
              <img src={a.url} alt={a.name} loading="lazy" className="h-full w-full object-contain" />
            </button>
            {a.owner_id === user!.id && (
              <div className="absolute right-1 top-1 hidden gap-1 group-hover:flex">
                <button className="rounded-md bg-white/95 p-1 text-ink shadow" title={a.shared ? 'Niet meer delen' : 'Delen met team'} onClick={async () => { await shareAsset(a.id, !a.shared); load() }}>{a.shared ? <X size={14} /> : <Copy size={14} />}</button>
                <button className="rounded-md bg-white/95 p-1 text-red-600 shadow" title="Verwijderen" onClick={async () => { await deleteAsset(a); load() }}><Trash2 size={14} /></button>
              </div>
            )}
          </div>
        ))}
      </div>
      {!assets.length && !busy && <p className="text-center text-sm text-muted">{scope === 'mine' ? 'Nog geen uploads.' : 'Nog niets gedeeld door het team.'}</p>}
    </div>
  )
}

/* ---------- Merk ---------- */
function BrandPanel() {
  const [kits, setKits] = useState<BrandKit[]>([])
  const [kitId, setKitId] = useState<string>(() => { try { return localStorage.getItem('adwerk.kit') || '' } catch { return '' } })
  const [edit, setEdit] = useState<Partial<BrandKit> | null>(null)
  const load = () => listKits().then((k) => { const all = [DAAROM_KIT(), ...k]; setKits(all); if (!kitId) setKitId(all[0].id) })
  useEffect(() => { load() }, []) // eslint-disable-line react-hooks/exhaustive-deps
  useEffect(() => { try { localStorage.setItem('adwerk.kit', kitId) } catch { /* */ } ; useEditor.setState({}) }, [kitId])
  const kit = kits.find((k) => k.id === kitId)
  useEffect(() => { kit?.fonts.forEach(loadFont) }, [kit])
  const sel = useEditor((s) => s.selectedIds)
  const applyColor = (c: string) => {
    const st = useEditor.getState()
    if (st.selectedIds.length) st.updateEls(st.selectedIds, { fill: c })
    else st.mutate((d) => { const f = d.frames.find((x) => x.id === st.activeFrameId); if (f) f.background = { ...f.background, type: 'solid', color: c } })
  }
  const applyFont = (font: string, heading: boolean) => {
    const st = useEditor.getState()
    const ids = st.selectedIds.length ? st.selectedIds : st.frame().elements.filter((e) => e.type === 'text' && (heading ? (e.fontSize || 0) >= 60 : (e.fontSize || 0) < 60)).map((e) => e.id)
    st.updateEls(ids, (e) => (e.type === 'text' ? { fontFamily: font } : {}))
  }
  const applyKitToAll = () => {
    if (!kit) return
    const st = useEditor.getState()
    const [c1, c2, c3] = kit.colors
    st.mutate((d) => {
      for (const f of d.frames) {
        for (const e of f.elements) {
          if (e.type === 'text' && kit.fonts.length) e.fontFamily = (e.fontSize || 0) >= 60 ? kit.fonts[0] : kit.fonts[1] || kit.fonts[0]
          if ((e.type === 'rect' || e.type === 'ellipse' || e.type === 'star') && c1) e.fill = e.name === 'Knop' ? c2 || c1 : c1
        }
        if (c3 && f.background.type === 'solid') f.background.color = c3
      }
    })
  }
  return (
    <div className="grid gap-4">
      <H>Merk</H>
      <Select value={kitId} onChange={setKitId} options={[{ value: '', label: kits.length ? 'Kies een merkset' : 'Nog geen merksets' }, ...kits.map((k) => ({ value: k.id, label: k.name }))]} />
      <div className="flex gap-2">
        <Button size="sm" className="flex-1" onClick={() => setEdit({ name: '', colors: [], fonts: [], logos: [] })}><Plus size={15} /> Nieuwe merkset</Button>
        {kit && kit.id !== 'daar-om-builtin' && <Button size="sm" onClick={() => setEdit(kit)}>Bewerken</Button>}
      </div>
      {kit && (
        <>
          <div><Label className="mb-2">Kleuren</Label>
            <p className="mb-2 text-xs text-muted">{sel.length ? 'Klik om de selectie te kleuren.' : 'Klik om de achtergrond te kleuren.'}</p>
            <div className="flex flex-wrap gap-2">{kit.colors.map((c, i) => <button key={c + i} onClick={() => applyColor(c)} title={c} className="h-10 w-10 rounded-lg border border-line" style={{ background: c }} />)}</div>
          </div>
          <div><Label className="mb-2">Lettertypes</Label>
            <div className="grid gap-1.5">{kit.fonts.map((f, i) => (
              <button key={f} onClick={() => applyFont(f, i === 0)} className="rounded-lg border border-line px-3 py-2 text-left hover:bg-sunk" style={{ fontFamily: `"${f}"`, fontSize: i === 0 ? 22 : 16, fontWeight: i === 0 ? 700 : 400 }}>{f}</button>
            ))}</div>
          </div>
          <div><Label className="mb-2">Logo's</Label>
            <div className="grid grid-cols-2 gap-2">{kit.logos.map((l) => (
              <button key={l.url} title={l.name} onClick={() => addImageFromUrl(l.url, 0, 0)} className="checker grid aspect-video place-items-center rounded-lg p-2"><img src={l.url} alt={l.name} className="max-h-full max-w-full object-contain" /></button>
            ))}</div>
          </div>
          <Button variant="dark" onClick={applyKitToAll}><Wand2 size={16} /> Huisstijl op alle formaten</Button>
        </>
      )}
      <KitEditor kit={edit} open={!!edit} onOpenChange={(o) => !o && setEdit(null)} onSaved={load} />
    </div>
  )
}

/* ---------- Animeren ---------- */
function AnimatePanel() {
  const selectedIds = useEditor((s) => s.selectedIds)
  const frame = useEditor((s) => s.frame())
  const els = frame.elements.filter((e) => selectedIds.includes(e.id))
  const el = els[0]
  const a = el?.anim || defaultAnim()
  const set = (patch: (an: NonNullable<El['anim']>) => void) => {
    useEditor.getState().updateEls(selectedIds, (e) => { const an = JSON.parse(JSON.stringify(e.anim || defaultAnim())); patch(an); return { anim: an } })
  }
  const magic = (style: 'rustig' | 'speels' | 'krachtig') => {
    const st = useEditor.getState()
    st.mutate((d) => {
      for (const f of d.frames) {
        const order = [...f.elements].sort((x, y) => x.y - y.y)
        order.forEach((e, i) => {
          const big = e.width >= f.w * 0.9 && e.height >= f.h * 0.9
          const type: InAnim = big ? (style === 'krachtig' ? 'zoomOut' : 'fade') : style === 'rustig' ? (e.type === 'text' ? 'slideUp' : 'fade') : style === 'speels' ? (e.type === 'text' ? 'slideUp' : 'pop') : (e.type === 'text' ? 'slideLeft' : 'zoomIn')
          const emph: EmphAnim = e.name === 'Knop' || e.name === 'Knoptekst' ? 'pulse' : 'none'
          const ee = f.elements.find((x) => x.id === e.id)!
          ee.anim = { in: { type, delay: big ? 0 : Math.round(i * (style === 'krachtig' ? 0.15 : 0.25) * 100) / 100, duration: style === 'rustig' ? 0.8 : 0.55 }, out: { type: 'none', delay: 0, duration: 0.5 }, emph: { type: emph, speed: 1 } }
        })
      }
    })
    st.setPlaying(true)
  }
  return (
    <div className="grid gap-5">
      <H>Animeren</H>
      <div className="grid gap-2 rounded-xl bg-mist p-3">
        <div className="flex items-center gap-2 font-semibold"><Wand2 size={16} className="text-accent" /> Alles in één klik animeren</div>
        <p className="text-xs text-muted">Zet een animatie op alle elementen van alle formaten, in leesvolgorde.</p>
        <div className="grid grid-cols-3 gap-1.5">
          {(['rustig', 'speels', 'krachtig'] as const).map((s) => <Button key={s} size="sm" onClick={() => magic(s)} className="capitalize">{s}</Button>)}
        </div>
      </div>
      {!el ? (
        <p className="rounded-xl border-2 border-dashed border-line p-5 text-center text-sm text-muted">Selecteer een element op het canvas om de animatie in te stellen.</p>
      ) : (
        <>
          <div className="grid gap-2"><Label>Binnenkomen</Label>
            <div className="grid grid-cols-2 gap-1.5">{IN_ANIMS.map((x) => (
              <button key={x.key} onClick={() => set((an) => { an.in.type = x.key })} className={cn('rounded-lg border px-2 py-2 text-left text-[13px] font-medium', a.in.type === x.key ? 'border-accent bg-accent-soft text-accent' : 'border-line hover:bg-sunk')}>{x.name}</button>
            ))}</div>
            {a.in.type !== 'none' && (<>
              <Slider label="Start na" value={a.in.delay} min={0} max={frame.duration} step={0.05} format={(v) => `${v.toFixed(2)} s`} onChange={(v) => set((an) => { an.in.delay = v })} />
              <Slider label="Duur" value={a.in.duration} min={0.1} max={3} step={0.05} format={(v) => `${v.toFixed(2)} s`} onChange={(v) => set((an) => { an.in.duration = v })} />
            </>)}
          </div>
          <div className="grid gap-2"><Label>Nadruk (herhalend)</Label>
            <div className="grid grid-cols-2 gap-1.5">{EMPH_ANIMS.map((x) => (
              <button key={x.key} onClick={() => set((an) => { an.emph.type = x.key })} className={cn('rounded-lg border px-2 py-2 text-left text-[13px] font-medium', a.emph.type === x.key ? 'border-accent bg-accent-soft text-accent' : 'border-line hover:bg-sunk')}>{x.name}</button>
            ))}</div>
            {a.emph.type !== 'none' && <Slider label="Snelheid" value={a.emph.speed} min={0.25} max={3} step={0.05} format={(v) => `${v.toFixed(2)}×`} onChange={(v) => set((an) => { an.emph.speed = v })} />}
          </div>
          <div className="grid gap-2"><Label>Verdwijnen aan het eind</Label>
            <Select value={a.out.type} onChange={(v) => set((an) => { an.out.type = v as InAnim })} options={IN_ANIMS.map((x) => ({ value: x.key, label: x.name }))} />
            {a.out.type !== 'none' && <Slider label="Duur" value={a.out.duration} min={0.1} max={2} step={0.05} format={(v) => `${v.toFixed(2)} s`} onChange={(v) => set((an) => { an.out.duration = v })} />}
          </div>
          <Button variant="dark" onClick={() => useEditor.getState().setPlaying(true)}>Bekijk animatie</Button>
        </>
      )}
    </div>
  )
}

/* ---------- Formaten ---------- */
function FormatsPanel() {
  const frames = useEditor((s) => s.doc.frames)
  const active = useEditor((s) => s.activeFrameId)
  const [adding, setAdding] = useState(false)
  const [sel, setSel] = useState<string[]>([])
  const [cw, setCw] = useState(1080), [ch, setCh] = useState(1080)
  const [confirmSync, setConfirmSync] = useState(false)
  const existing = useMemo(() => new Set(frames.map((f) => `${f.w}x${f.h}`)), [frames])
  const add = () => {
    const st = useEditor.getState()
    const src = st.frame()
    st.mutate((d) => {
      for (const k of sel) { const p = ALL_FORMATS.find((x) => x.key === k)!; d.frames.push(src ? cloneFrameTo(src, p) : makeFrame(p)) }
    })
    setSel([]); setAdding(false)
  }
  const addCustom = () => {
    const st = useEditor.getState()
    const src = st.frame()
    const p = { key: 'custom', name: 'Eigen formaat', w: cw, h: ch, platform: 'Eigen' }
    st.mutate((d) => { d.frames.push(src ? cloneFrameTo(src, p) : makeFrame(p)) })
  }
  return (
    <div className="grid gap-4">
      <H>Formaten</H>
      <div className="grid gap-1.5">
        {frames.map((f) => (
          <div key={f.id} className={cn('group flex items-center gap-2 rounded-lg border px-2.5 py-2', f.id === active ? 'border-accent bg-accent-soft' : 'border-line')}>
            <button className="flex min-w-0 flex-1 items-center gap-2.5 text-left" onClick={() => useEditor.getState().setActiveFrame(f.id)}>
              <span className="grid h-8 w-8 shrink-0 place-items-center"><span className="block rounded-[2px] bg-ink/80" style={{ width: Math.max(4, 28 * f.w / Math.max(f.w, f.h)), height: Math.max(4, 28 * f.h / Math.max(f.w, f.h)) }} /></span>
              <span className="min-w-0"><span className="block truncate text-sm font-semibold">{f.name}</span><span className="flex items-center gap-1.5 text-xs text-muted"><PlatformLogo platform={f.platform} size={13} />{f.w}×{f.h}</span></span>
            </button>
            <Tip label="Dupliceren"><button className="rounded p-1 text-muted hover:bg-white" onClick={() => useEditor.getState().mutate((d) => { const i = d.frames.findIndex((x) => x.id === f.id); const c = JSON.parse(JSON.stringify(f)); c.id = uid(); c.name = f.name + ' kopie'; c.elements.forEach((e: El) => (e.id = uid())); d.frames.splice(i + 1, 0, c) })}><Copy size={14} /></button></Tip>
            {frames.length > 1 && <Tip label="Verwijderen"><button className="rounded p-1 text-muted hover:bg-white hover:text-red-600" onClick={() => useEditor.getState().mutate((d) => { d.frames = d.frames.filter((x) => x.id !== f.id) })}><Trash2 size={14} /></button></Tip>}
          </div>
        ))}
      </div>
      {frames.length > 1 && (
        <div className="grid gap-2 rounded-xl bg-mist p-3">
          <div className="flex items-center gap-2 font-semibold"><Wand2 size={16} className="text-accent" /> Slim meeschalen</div>
          <p className="text-xs text-muted">Neem het ontwerp van het actieve formaat over in alle andere formaten. Daarna kun je per formaat bijsturen.</p>
          <Button size="sm" variant="dark" onClick={() => setConfirmSync(true)}>Actief formaat naar alle formaten</Button>
        </div>
      )}
      {!adding ? <Button variant="primary" onClick={() => setAdding(true)}><Plus size={17} /> Formaten toevoegen</Button> : (
        <div className="grid gap-3 rounded-xl border border-line p-3">
          {PLATFORMS.map((p) => (
            <div key={p.name} className="grid gap-0.5">
              <div className="flex items-center gap-1.5 text-xs font-bold text-muted"><PlatformLogos platforms={p.logos} size={14} />{p.name}</div>
              {p.formats.map((f) => (
                <label key={f.key} className="flex cursor-pointer items-center gap-2 rounded px-1 py-1 text-sm hover:bg-sunk">
                  <input type="checkbox" className="h-4 w-4 accent-[#EA5F39]" checked={sel.includes(f.key)} onChange={() => setSel((s) => (s.includes(f.key) ? s.filter((x) => x !== f.key) : [...s, f.key]))} />
                  <span className="flex-1">{f.name}</span>
                  {existing.has(`${f.w}x${f.h}`) && <Check size={14} className="text-mint" aria-label="Al aanwezig" />}
                  <span className="text-xs tabular-nums text-muted">{f.w}×{f.h}</span>
                </label>
              ))}
            </div>
          ))}
          <div className="flex gap-2"><Button size="sm" onClick={() => setAdding(false)}>Annuleren</Button><Button size="sm" variant="primary" className="flex-1" disabled={!sel.length} onClick={add}>Voeg {sel.length || ''} toe</Button></div>
          <div className="flex items-center gap-1.5 border-t border-line pt-3">
            <Input type="number" value={cw} onChange={(e) => setCw(+e.target.value)} aria-label="Breedte" className="w-20" /><span className="text-muted">×</span>
            <Input type="number" value={ch} onChange={(e) => setCh(+e.target.value)} aria-label="Hoogte" className="w-20" />
            <Button size="sm" onClick={addCustom} disabled={cw < 10 || ch < 10}>Eigen</Button>
          </div>
        </div>
      )}
      <Dialog open={confirmSync} onOpenChange={setConfirmSync} title="Alle formaten overschrijven?" description="De inhoud van de andere formaten wordt vervangen door een meegeschaalde versie van het actieve formaat. Ongedaan maken kan met Ctrl+Z.">
        <div className="flex justify-end gap-2"><Button onClick={() => setConfirmSync(false)}>Annuleren</Button><Button variant="primary" onClick={() => { useEditor.getState().resizeAllFrom(active); setConfirmSync(false) }}>Overschrijven</Button></div>
      </Dialog>
    </div>
  )
}

/* ---------- Lagen ---------- */
function LayersPanel() {
  const frame = useEditor((s) => s.frame())
  const selectedIds = useEditor((s) => s.selectedIds)
  const [dragId, setDragId] = useState<string | null>(null)
  const [renaming, setRenaming] = useState<string | null>(null)
  const list = [...frame.elements].reverse()
  const st = useEditor.getState
  return (
    <div>
      <H>Lagen</H>
      {!list.length && <p className="text-sm text-muted">Nog geen lagen. Voeg tekst, vormen of afbeeldingen toe.</p>}
      <div className="grid gap-1">
        {list.map((e) => (
          <div key={e.id} draggable onDragStart={() => setDragId(e.id)} onDragOver={(ev) => ev.preventDefault()}
            onDrop={() => { if (dragId && dragId !== e.id) st().moveTo(dragId, frame.elements.findIndex((x) => x.id === e.id)); setDragId(null) }}
            onClick={(ev) => { const s = st(); if (ev.shiftKey) s.select(s.selectedIds.includes(e.id) ? s.selectedIds.filter((x) => x !== e.id) : [...s.selectedIds, e.id]); else s.select([e.id]) }}
            className={cn('group flex min-w-0 cursor-pointer items-center gap-2 rounded-lg border px-2 py-1.5', selectedIds.includes(e.id) ? 'border-accent bg-accent-soft' : 'border-transparent hover:bg-sunk', !e.visible && 'opacity-50')}>
            <GripVertical size={14} className="shrink-0 cursor-grab text-muted" />
            <LayerThumb el={e} />
            {renaming === e.id ? (
              <Input autoFocus defaultValue={e.name} className="h-7" onBlur={(ev) => { st().updateEls([e.id], { name: ev.target.value || e.name }); setRenaming(null) }} onKeyDown={(ev) => ev.key === 'Enter' && (ev.target as HTMLInputElement).blur()} />
            ) : (
              <span className="min-w-0 flex-1 truncate text-sm" onDoubleClick={() => setRenaming(e.id)} title="Dubbelklik om te hernoemen">{e.type === 'text' ? e.text : e.name}</span>
            )}
            <button className="rounded p-1 text-muted hover:bg-white hover:text-ink" aria-label={e.locked ? 'Ontgrendelen' : 'Vergrendelen'} onClick={(ev) => { ev.stopPropagation(); st().updateEls([e.id], { locked: !e.locked }) }}>{e.locked ? <Lock size={14} /> : <Unlock size={14} className="opacity-0 group-hover:opacity-100" />}</button>
            <button className="rounded p-1 text-muted hover:bg-white hover:text-ink" aria-label={e.visible ? 'Verbergen' : 'Tonen'} onClick={(ev) => { ev.stopPropagation(); st().updateEls([e.id], { visible: !e.visible }) }}>{e.visible ? <Eye size={14} className="opacity-0 group-hover:opacity-100" /> : <EyeOff size={14} />}</button>
          </div>
        ))}
      </div>
    </div>
  )
}

function LayerThumb({ el }: { el: El }) {
  const base = 'grid h-7 w-7 shrink-0 place-items-center overflow-hidden rounded-md bg-sunk'
  if (el.type === 'text') return <span className={cn(base, 'text-xs font-bold')} style={{ color: el.fill }}>T</span>
  if (el.type === 'image') return <span className={base}>{el.src ? <img src={el.src} alt="" className="h-full w-full object-cover" /> : null}</span>
  if (el.type === 'icon') return <span className={base} dangerouslySetInnerHTML={{ __html: iconSvg(el.icon || 'star', el.fill, 2, 16) }} />
  return <span className={base}><span className={cn('block h-4 w-4', el.type === 'ellipse' && 'rounded-full')} style={{ background: el.fill }} /></span>
}
