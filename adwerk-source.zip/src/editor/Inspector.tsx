import { useMemo } from 'react'
import { AlignLeft, AlignCenter, AlignRight, Bold, Italic, Underline, CaseUpper, Trash2, Copy, Lock, Unlock, ArrowUpToLine, ArrowDownToLine, ChevronUp, ChevronDown, FlipHorizontal, FlipVertical, AlignStartVertical, AlignCenterVertical, AlignEndVertical, AlignStartHorizontal, AlignCenterHorizontal, AlignEndHorizontal, ImageUp, AlertTriangle, CheckCircle2 } from 'lucide-react'
import { useEditor } from '../store/editor'
import type { El, Frame } from '../lib/types'
import { FONTS, loadFont, nearestWeight, fontDef } from '../lib/fonts'
import { ICONS } from '../lib/icons'
import { Button, ColorPicker, IconBtn, Label, NumberField, Segmented, Select, Slider, cn } from '../ui/ui'
import { useSession } from '../store/session'
import { uploadAsset } from '../lib/api'

const BLENDS = [
  ['source-over', 'Normaal'], ['multiply', 'Vermenigvuldigen'], ['screen', 'Bleken'], ['overlay', 'Bedekken'], ['darken', 'Donkerder'],
  ['lighten', 'Lichter'], ['color-dodge', 'Kleur tegenhouden'], ['color-burn', 'Kleur doordrukken'], ['hard-light', 'Fel licht'], ['soft-light', 'Zacht licht'],
  ['difference', 'Verschil'], ['exclusion', 'Uitsluiting'], ['hue', 'Kleurtoon'], ['saturation', 'Verzadiging'], ['color', 'Kleur'], ['luminosity', 'Helderheid'],
]

function Section({ title, children }: { title: string; children: React.ReactNode }) {
  return <section className="grid gap-2.5 border-b border-line px-4 py-4 last:border-0"><Label>{title}</Label>{children}</section>
}

function useDocColors() {
  const doc = useEditor((s) => s.doc)
  return useMemo(() => {
    const set = new Set<string>()
    for (const f of doc.frames) { set.add(f.background.color); for (const e of f.elements) set.add(e.fill) }
    return [...set].filter((c) => /^#/.test(c))
  }, [doc])
}

function useBrandColors() {
  // merkkleuren uit de laatst gekozen merkset worden in het Merk-paneel gekozen; hier tonen we kleuren uit het document
  return [] as string[]
}

export default function Inspector() {
  const selectedIds = useEditor((s) => s.selectedIds)
  const frame = useEditor((s) => s.frame())
  const playing = useEditor((s) => s.playing)
  const els = frame?.elements.filter((e) => selectedIds.includes(e.id)) || []
  if (!frame) return null
  return (
    <aside className="flex w-[290px] shrink-0 flex-col overflow-y-auto border-l border-line bg-white" aria-label="Eigenschappen">
      {playing ? <p className="p-4 text-sm text-muted">Animatie speelt af…</p> : els.length === 0 ? <FrameProps frame={frame} /> : <ElProps els={els} frame={frame} />}
    </aside>
  )
}

function FrameProps({ frame }: { frame: Frame }) {
  const docColors = useDocColors()
  const brand = useBrandColors()
  const { user } = useSession()
  const set = (patch: Partial<Frame>) => {
    const st = useEditor.getState()
    st.mutate((d) => { const f = d.frames.find((x) => x.id === frame.id); if (f) Object.assign(f, patch) })
  }
  const bg = frame.background
  const checks = useAdChecks(frame)
  return (
    <>
      <Section title="Formaat">
        <input className="h-9 rounded-lg bg-sunk px-3 text-sm font-semibold outline-none focus:ring-2 focus:ring-violet" value={frame.name} onChange={(e) => set({ name: e.target.value })} aria-label="Naam formaat" />
        <div className="grid grid-cols-2 gap-2">
          <NumberField label="B" value={frame.w} min={10} max={8000} onChange={(v) => set({ w: Math.round(v) })} suffix="px" />
          <NumberField label="H" value={frame.h} min={10} max={8000} onChange={(v) => set({ h: Math.round(v) })} suffix="px" />
        </div>
        <label className="flex items-center gap-2 text-sm"><input type="checkbox" className="h-4 w-4 accent-[#FF5B2E]" checked={!!frame.safeZone} onChange={(e) => set({ safeZone: e.target.checked })} /> Veilige zones voor stories tonen</label>
      </Section>
      <Section title="Achtergrond">
        <Segmented value={bg.type} onChange={(v) => set({ background: { ...bg, type: v } })} options={[{ value: 'solid', label: 'Kleur' }, { value: 'gradient', label: 'Verloop' }, { value: 'image', label: 'Foto' }]} />
        <ColorPicker value={bg.color} onChange={(c) => set({ background: { ...bg, color: c } })} docColors={docColors} brandColors={brand} />
        {bg.type === 'gradient' && (<>
          <ColorPicker value={bg.color2} onChange={(c) => set({ background: { ...bg, color2: c } })} docColors={docColors} />
          <Slider label="Hoek" value={bg.angle} min={0} max={360} onChange={(v) => set({ background: { ...bg, angle: v } })} format={(v) => `${v}°`} />
        </>)}
        {bg.type === 'image' && (
          <label className="flex h-9 cursor-pointer items-center justify-center gap-2 rounded-lg border border-line text-sm font-semibold hover:bg-sunk">
            <ImageUp size={16} /> {bg.src ? 'Andere foto' : 'Foto kiezen'}
            <input type="file" accept="image/*" className="hidden" onChange={async (e) => { const f = e.target.files?.[0]; if (!f) return; const a = await uploadAsset(f, user!.id); set({ background: { ...bg, type: 'image', src: a.url } }) }} />
          </label>
        )}
      </Section>
      <Section title="Animatie">
        <Slider label="Lengte" value={frame.duration} min={1} max={30} step={0.5} onChange={(v) => set({ duration: v })} format={(v) => `${v} s`} />
        <p className="text-xs text-muted">Google Ads staat maximaal 30 seconden animatie toe, inclusief herhalingen.</p>
      </Section>
      <Section title="Advertentiecontrole">
        <ul className="grid gap-2 text-sm">
          {checks.map((c, i) => (
            <li key={i} className="flex gap-2">{c.ok ? <CheckCircle2 size={16} className="mt-0.5 shrink-0 text-mint" /> : <AlertTriangle size={16} className="mt-0.5 shrink-0 text-sun" />}<span>{c.text}</span></li>
          ))}
        </ul>
      </Section>
      <p className="px-4 py-4 text-xs leading-relaxed text-muted">Tip: klik op een element om het aan te passen. Dubbelklik op tekst om te typen. Houd Shift ingedrukt om meerdere dingen te selecteren.</p>
    </>
  )
}

function useAdChecks(frame: Frame) {
  return useMemo(() => {
    const out: { ok: boolean; text: string }[] = []
    const texts = frame.elements.filter((e) => e.type === 'text' && e.visible)
    const small = frame.w <= 1000 && frame.h <= 1000 && frame.w * frame.h < 400000
    const minFont = Math.min(...texts.map((t) => t.fontSize || 99), 99)
    const minOk = small ? 10 : 24
    out.push(texts.length && minFont < minOk ? { ok: false, text: `Kleinste tekst is ${Math.round(minFont)} px. Houd minimaal ${minOk} px aan voor leesbaarheid.` } : { ok: true, text: 'Tekstgrootte is goed leesbaar.' })
    const area = texts.reduce((s, t) => s + t.width * t.height, 0) / (frame.w * frame.h)
    out.push(area > 0.25 ? { ok: false, text: `Tekst bedekt ongeveer ${Math.round(area * 100)}% van het beeld. Minder tekst presteert meestal beter.` } : { ok: true, text: 'Verhouding tekst en beeld is in orde.' })
    if (frame.safeZone) {
      const top = frame.h * 0.14, bottom = frame.h * 0.8
      const bad = texts.filter((t) => t.y < top || t.y + t.height > bottom)
      out.push(bad.length ? { ok: false, text: `${bad.length} tekst${bad.length > 1 ? 'en vallen' : ' valt'} in een veilige zone van de story.` } : { ok: true, text: 'Tekst staat buiten de veilige zones.' })
    }
    const outside = frame.elements.filter((e) => e.visible && e.type === 'text' && (e.x < 0 || e.y < 0 || e.x + e.width > frame.w || e.y + e.height > frame.h))
    if (outside.length) out.push({ ok: false, text: 'Er valt tekst buiten het canvas.' })
    if (frame.duration > 30) out.push({ ok: false, text: 'Animatie is langer dan 30 seconden.' })
    return out
  }, [frame])
}

function ElProps({ els, frame }: { els: El[]; frame: Frame }) {
  const el = els[0]
  const ids = els.map((e) => e.id)
  const multi = els.length > 1
  const st = useEditor.getState
  const up = (patch: Partial<El> | ((e: El) => Partial<El>), history = true) => st().updateEls(ids, patch, { history })
  const docColors = useDocColors()
  const { user } = useSession()
  const align = (how: string) => up((e) => {
    const h = e.height
    if (how === 'left') return { x: 0 }
    if (how === 'hcenter') return { x: (frame.w - e.width) / 2 }
    if (how === 'right') return { x: frame.w - e.width }
    if (how === 'top') return { y: 0 }
    if (how === 'vcenter') return { y: (frame.h - h) / 2 }
    return { y: frame.h - h }
  })
  const f = el.filters || { brightness: 0, contrast: 0, saturation: 0, hue: 0, blur: 0, grayscale: false }
  const setF = (p: Partial<typeof f>) => up({ filters: { ...f, ...p } })
  return (
    <>
      <div className="flex flex-wrap items-center gap-0.5 border-b border-line px-3 py-2">
        <IconBtn label="Dupliceren (Ctrl+D)" onClick={() => st().duplicateSelected()}><Copy size={16} /></IconBtn>
        <IconBtn label={el.locked ? 'Ontgrendelen' : 'Vergrendelen'} onClick={() => up({ locked: !el.locked })}>{el.locked ? <Lock size={16} /> : <Unlock size={16} />}</IconBtn>
        {!multi && <>
          <IconBtn label="Naar voren" onClick={() => st().reorder(el.id, 'up')}><ChevronUp size={16} /></IconBtn>
          <IconBtn label="Naar achteren" onClick={() => st().reorder(el.id, 'down')}><ChevronDown size={16} /></IconBtn>
          <IconBtn label="Helemaal naar voren" onClick={() => st().reorder(el.id, 'top')}><ArrowUpToLine size={16} /></IconBtn>
          <IconBtn label="Helemaal naar achteren" onClick={() => st().reorder(el.id, 'bottom')}><ArrowDownToLine size={16} /></IconBtn>
        </>}
        <span className="flex-1" />
        <IconBtn label="Verwijderen (Delete)" onClick={() => st().removeSelected()} className="text-red-600"><Trash2 size={16} /></IconBtn>
      </div>

      {el.type === 'text' && !multi && <TextProps el={el} up={up} docColors={docColors} />}

      {el.type !== 'text' && el.type !== 'image' && (
        <Section title={el.type === 'icon' ? 'Icoon' : 'Vorm'}>
          <ColorPicker value={el.fill} onChange={(c) => up({ fill: c })} docColors={docColors} label="Vulkleur" />
          {el.type === 'icon' && !multi && (
            <>
              <Select value={el.icon || 'star'} onChange={(v) => up({ icon: v })} options={Object.keys(ICONS).map((k) => ({ value: k, label: k }))} />
              <Slider label="Lijndikte" value={el.strokeWidth || 2} min={0.5} max={4} step={0.25} onChange={(v) => up({ strokeWidth: v })} />
            </>
          )}
          {el.type !== 'icon' && (<>
            <div className="grid grid-cols-[1fr_96px] gap-2">
              <ColorPicker value={el.stroke} onChange={(c) => up({ stroke: c, strokeWidth: el.strokeWidth || 4 })} docColors={docColors} label="Randkleur" />
              <NumberField label="Rand" value={el.strokeWidth} min={0} max={200} onChange={(v) => up({ strokeWidth: v })} />
            </div>
            {(el.type === 'rect' || el.type === 'line') && <Slider label="Afronding" value={Math.min(el.cornerRadius, Math.min(el.width, el.height) / 2)} min={0} max={Math.round(Math.min(el.width, el.height) / 2)} onChange={(v) => up({ cornerRadius: v })} />}
            {el.type === 'star' && (<>
              <Slider label="Punten" value={el.points || 5} min={3} max={24} onChange={(v) => up({ points: v })} />
              <Slider label="Binnenstraal" value={Math.round((el.innerRatio || 0.45) * 100)} min={10} max={95} onChange={(v) => up({ innerRatio: v / 100 })} format={(v) => `${v}%`} />
            </>)}
          </>)}
        </Section>
      )}

      {el.type === 'image' && !multi && (
        <Section title="Afbeelding">
          <label className="flex h-9 cursor-pointer items-center justify-center gap-2 rounded-lg border border-line text-sm font-semibold hover:bg-sunk">
            <ImageUp size={16} /> {el.src ? 'Afbeelding vervangen' : 'Afbeelding kiezen'}
            <input type="file" accept="image/*" className="hidden" onChange={async (e) => { const file = e.target.files?.[0]; if (!file) return; const a = await uploadAsset(file, user!.id); up({ src: a.url, cropZoom: 1, cropX: 0.5, cropY: 0.5 }) }} />
          </label>
          {el.src && (<>
            <Slider label="Inzoomen" value={el.cropZoom || 1} min={1} max={4} step={0.05} onChange={(v) => up({ cropZoom: v })} format={(v) => `${Math.round(v * 100)}%`} />
            <Slider label="Uitsnede horizontaal" value={Math.round((el.cropX ?? 0.5) * 100)} min={0} max={100} onChange={(v) => up({ cropX: v / 100 })} format={(v) => `${v}%`} />
            <Slider label="Uitsnede verticaal" value={Math.round((el.cropY ?? 0.5) * 100)} min={0} max={100} onChange={(v) => up({ cropY: v / 100 })} format={(v) => `${v}%`} />
          </>)}
          <div className="flex gap-1">
            <IconBtn label="Horizontaal spiegelen" active={el.flipX} onClick={() => up({ flipX: !el.flipX })}><FlipHorizontal size={16} /></IconBtn>
            <IconBtn label="Verticaal spiegelen" active={el.flipY} onClick={() => up({ flipY: !el.flipY })}><FlipVertical size={16} /></IconBtn>
          </div>
          <Slider label="Afronding" value={el.cornerRadius} min={0} max={Math.round(Math.min(el.width, el.height) / 2)} onChange={(v) => up({ cornerRadius: v })} />
        </Section>
      )}

      {(el.type === 'image' || el.type === 'icon') && !multi && (
        <Section title="Filters">
          <Slider label="Helderheid" value={Math.round(f.brightness * 100)} min={-60} max={60} onChange={(v) => setF({ brightness: v / 100 })} />
          <Slider label="Contrast" value={f.contrast} min={-60} max={60} onChange={(v) => setF({ contrast: v })} />
          <Slider label="Verzadiging" value={Math.round(f.saturation * 50)} min={-50} max={100} onChange={(v) => setF({ saturation: v / 50 })} />
          <Slider label="Kleurtoon" value={f.hue} min={0} max={359} onChange={(v) => setF({ hue: v })} format={(v) => `${v}°`} />
          <Slider label="Vervagen" value={f.blur} min={0} max={40} onChange={(v) => setF({ blur: v })} />
          <label className="flex items-center gap-2 text-sm"><input type="checkbox" className="h-4 w-4 accent-[#FF5B2E]" checked={f.grayscale} onChange={(e) => setF({ grayscale: e.target.checked })} /> Zwart-wit</label>
          <div className="grid grid-cols-4 gap-1.5">
            {[
              { n: 'Origineel', v: { brightness: 0, contrast: 0, saturation: 0, hue: 0, blur: 0, grayscale: false } },
              { n: 'Warm', v: { brightness: 0.05, contrast: 10, saturation: 0.3, hue: 10, blur: 0, grayscale: false } },
              { n: 'Fel', v: { brightness: 0.05, contrast: 25, saturation: 0.6, hue: 0, blur: 0, grayscale: false } },
              { n: 'Mat', v: { brightness: 0.08, contrast: -20, saturation: -0.3, hue: 0, blur: 0, grayscale: false } },
            ].map((p) => <Button key={p.n} size="sm" className="px-1 text-[11px]" onClick={() => up({ filters: p.v })}>{p.n}</Button>)}
          </div>
        </Section>
      )}

      <Section title="Uitlijnen op canvas">
        <div className="grid grid-cols-6 gap-0.5">
          <IconBtn label="Links" onClick={() => align('left')}><AlignStartVertical size={16} /></IconBtn>
          <IconBtn label="Midden" onClick={() => align('hcenter')}><AlignCenterVertical size={16} /></IconBtn>
          <IconBtn label="Rechts" onClick={() => align('right')}><AlignEndVertical size={16} /></IconBtn>
          <IconBtn label="Boven" onClick={() => align('top')}><AlignStartHorizontal size={16} /></IconBtn>
          <IconBtn label="Midden" onClick={() => align('vcenter')}><AlignCenterHorizontal size={16} /></IconBtn>
          <IconBtn label="Onder" onClick={() => align('bottom')}><AlignEndHorizontal size={16} /></IconBtn>
        </div>
      </Section>

      {!multi && (
        <Section title="Positie en grootte">
          <div className="grid grid-cols-2 gap-2">
            <NumberField label="X" value={el.x} onChange={(v) => up({ x: v })} />
            <NumberField label="Y" value={el.y} onChange={(v) => up({ y: v })} />
            <NumberField label="B" value={el.width} min={1} onChange={(v) => up({ width: v })} />
            {el.type !== 'text' ? <NumberField label="H" value={el.height} min={1} onChange={(v) => up({ height: v })} /> : <div />}
            <NumberField label="Draai" value={el.rotation} suffix="°" onChange={(v) => up({ rotation: v })} />
          </div>
        </Section>
      )}

      <Section title="Effecten">
        <Slider label="Dekking" value={Math.round(el.opacity * 100)} min={0} max={100} onChange={(v) => up({ opacity: v / 100 })} format={(v) => `${v}%`} />
        <div className="grid gap-1"><span className="text-[13px] font-medium">Overvloeimodus</span>
          <Select value={el.blend || 'source-over'} onChange={(v) => up({ blend: v })} options={BLENDS.map(([value, label]) => ({ value, label }))} />
        </div>
        <label className="flex items-center gap-2 text-sm font-medium"><input type="checkbox" className="h-4 w-4 accent-[#FF5B2E]" checked={el.shadow.enabled} onChange={(e) => up((x) => ({ shadow: { ...x.shadow, enabled: e.target.checked } }))} /> Schaduw</label>
        {el.shadow.enabled && (
          <div className="grid gap-2.5 rounded-lg bg-mist p-2.5">
            <ColorPicker value={el.shadow.color} onChange={(c) => up((x) => ({ shadow: { ...x.shadow, color: c } }))} label="Schaduwkleur" />
            <Slider label="Vervaging" value={el.shadow.blur} min={0} max={120} onChange={(v) => up((x) => ({ shadow: { ...x.shadow, blur: v } }))} />
            <Slider label="Afstand" value={el.shadow.y} min={-60} max={60} onChange={(v) => up((x) => ({ shadow: { ...x.shadow, y: v } }))} />
            <Slider label="Dekking" value={Math.round(el.shadow.opacity * 100)} min={0} max={100} onChange={(v) => up((x) => ({ shadow: { ...x.shadow, opacity: v / 100 } }))} format={(v) => `${v}%`} />
          </div>
        )}
      </Section>
    </>
  )
}

function TextProps({ el, up, docColors }: { el: El; up: (p: Partial<El>) => void; docColors: string[] }) {
  const def = fontDef(el.fontFamily || 'Figtree')
  const weights = def?.weights || [400, 700]
  const wNames: Record<number, string> = { 300: 'Licht', 400: 'Normaal', 500: 'Medium', 600: 'Halfvet', 700: 'Vet', 800: 'Extra vet', 900: 'Zwart' }
  return (
    <Section title="Tekst">
      <textarea value={el.text} onChange={(e) => up({ text: e.target.value })} rows={2} className="w-full resize-y rounded-lg bg-sunk px-3 py-2 text-sm outline-none focus:ring-2 focus:ring-violet" aria-label="Tekstinhoud" />
      <select value={el.fontFamily} onChange={(e) => { const fam = e.target.value; loadFont(fam).then(() => up({ fontFamily: fam, fontWeight: nearestWeight(fam, el.fontWeight || 400) })) }} className="h-9 rounded-lg bg-sunk px-2.5 text-sm outline-none focus:ring-2 focus:ring-violet" style={{ fontFamily: `"${el.fontFamily}"` }} aria-label="Lettertype">
        {(['sans', 'display', 'serif', 'script'] as const).map((cat) => (
          <optgroup key={cat} label={{ sans: 'Schreefloos', display: 'Opvallend', serif: 'Schreef', script: 'Handschrift' }[cat]}>
            {FONTS.filter((x) => x.category === cat).map((x) => <option key={x.name} value={x.name}>{x.name}</option>)}
          </optgroup>
        ))}
      </select>
      <div className="grid grid-cols-[1fr_110px] gap-2">
        <Select value={String(nearestWeight(el.fontFamily || 'Figtree', el.fontWeight || 400))} onChange={(v) => up({ fontWeight: +v })} options={weights.map((w) => ({ value: String(w), label: wNames[w] || String(w) }))} />
        <NumberField label="Aa" value={el.fontSize || 24} min={4} max={1000} onChange={(v) => up({ fontSize: v })} />
      </div>
      <div className="flex flex-wrap gap-0.5">
        <IconBtn label="Vet" active={(el.fontWeight || 400) >= 700} onClick={() => up({ fontWeight: (el.fontWeight || 400) >= 700 ? 400 : nearestWeight(el.fontFamily || 'Figtree', 700) })}><Bold size={16} /></IconBtn>
        <IconBtn label="Cursief" active={el.italic} onClick={() => up({ italic: !el.italic })}><Italic size={16} /></IconBtn>
        <IconBtn label="Onderstrepen" active={el.underline} onClick={() => up({ underline: !el.underline })}><Underline size={16} /></IconBtn>
        <IconBtn label="Hoofdletters" active={el.uppercase} onClick={() => up({ uppercase: !el.uppercase })}><CaseUpper size={16} /></IconBtn>
        <span className="mx-1 w-px bg-line" />
        <IconBtn label="Links uitlijnen" active={el.align === 'left'} onClick={() => up({ align: 'left' })}><AlignLeft size={16} /></IconBtn>
        <IconBtn label="Centreren" active={el.align === 'center'} onClick={() => up({ align: 'center' })}><AlignCenter size={16} /></IconBtn>
        <IconBtn label="Rechts uitlijnen" active={el.align === 'right'} onClick={() => up({ align: 'right' })}><AlignRight size={16} /></IconBtn>
      </div>
      <ColorPicker value={el.fill} onChange={(c) => up({ fill: c })} docColors={docColors} label="Tekstkleur" />
      <Slider label="Regelafstand" value={el.lineHeight || 1.2} min={0.7} max={2.5} step={0.05} onChange={(v) => up({ lineHeight: v })} format={(v) => v.toFixed(2)} />
      <Slider label="Letterafstand" value={el.letterSpacing || 0} min={-10} max={40} step={0.5} onChange={(v) => up({ letterSpacing: v })} />
      <div className="grid grid-cols-[1fr_96px] gap-2">
        <ColorPicker value={el.stroke} onChange={(c) => up({ stroke: c, strokeWidth: el.strokeWidth || 2 })} docColors={docColors} label="Contourkleur" />
        <NumberField label="Contour" value={el.strokeWidth} min={0} max={40} onChange={(v) => up({ strokeWidth: v })} />
      </div>
      <p className={cn('text-xs text-muted')}>Dubbelklik op de tekst in het canvas om direct te typen.</p>
    </Section>
  )
}
