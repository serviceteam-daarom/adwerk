import { useMemo } from 'react'
import { AlignLeft, AlignCenter, AlignRight, Bold, Italic, Underline, CaseUpper, Trash2, Copy, Lock, Unlock, ArrowUpToLine, ArrowDownToLine, ChevronUp, ChevronDown, FlipHorizontal, FlipVertical, ImageUp, AlertTriangle, CheckCircle2 } from 'lucide-react'
import { adChecks } from '../lib/adchecks'
import { useEditor } from '../store/editor'
import type { El, Frame } from '../lib/types'
import { nearestWeight, fontWeights } from '../lib/fonts'
import { FontPicker } from './FontPicker'
import { ICONS } from '../lib/icons'
import { Button, ColorPicker, IconBtn, Label, NumberField, Segmented, Select, Slider, cn, EdgeToggle } from '../ui/ui'
import { useSession } from '../store/session'
import { uploadAsset } from '../lib/api'
import { selectedGroup, groupBox } from '../lib/groups'
import { AlignTools } from './AlignTools'
import { Group as GroupIcon, Sparkles } from 'lucide-react'

const BLENDS = [
  ['source-over', 'Normaal'], ['multiply', 'Vermenigvuldigen'], ['screen', 'Bleken'], ['overlay', 'Bedekken'], ['darken', 'Donkerder'],
  ['lighten', 'Lichter'], ['color-dodge', 'Kleur tegenhouden'], ['color-burn', 'Kleur doordrukken'], ['hard-light', 'Fel licht'], ['soft-light', 'Zacht licht'],
  ['difference', 'Verschil'], ['exclusion', 'Uitsluiting'], ['hue', 'Kleurtoon'], ['saturation', 'Verzadiging'], ['color', 'Kleur'], ['luminosity', 'Helderheid'],
]

function Section({ title, children }: { title: string; children: React.ReactNode }) {
  return <section className="grid grid-cols-[minmax(0,1fr)] gap-2.5 border-b border-line px-4 py-4 last:border-0"><Label>{title}</Label>{children}</section>
}

function useDocColors() {
  const doc = useEditor((s) => s.doc)
  return useMemo(() => {
    const set = new Set<string>()
    for (const f of doc.frames) { set.add(f.background.color); for (const e of f.elements) set.add(e.fill) }
    return [...set].filter((c) => /^#/.test(c))
  }, [doc])
}

function useBrandColors() {
  // merkkleuren uit de laatst gekozen merkset worden in het Merk-paneel gekozen; hier tonen we kleuren uit het document
  return [] as string[]
}

export default function Inspector() {
  const selectedIds = useEditor((s) => s.selectedIds)
  const frame = useEditor((s) => s.frame())
  const playing = useEditor((s) => s.playing)
  const rightOpen = useEditor((s) => s.rightOpen)
  const els = frame?.elements.filter((e) => selectedIds.includes(e.id)) || []
  if (!frame) return null
  return (
    <div className={cn('group/edge relative flex shrink-0 max-lg:absolute max-lg:inset-y-0 max-lg:right-0 max-lg:z-30', !rightOpen && 'max-lg:pointer-events-none')}>
      {rightOpen && (
        <aside className="flex w-[300px] shrink-0 flex-col overflow-y-auto overflow-x-hidden border-l border-line bg-surface [animation:panelIn_.26s_var(--ease-out)] max-lg:w-[min(320px,92vw)] max-lg:shadow-pop" aria-label="Eigenschappen">
          <div key={playing ? 'play' : els.length === 0 ? 'frame' : els.length > 1 ? 'multi' : els[0].type} className="anim-tabswap">
            {playing ? <p className="p-4 text-sm text-muted">Animatie speelt af…</p> : els.length === 0 ? <FrameProps frame={frame} /> : <ElProps els={els} frame={frame} />}
          </div>
        </aside>
      )}
      <EdgeToggle edge="left" collapsed={!rightOpen} onToggle={() => useEditor.getState().toggleRight()} label={rightOpen ? 'Eigenschappen inklappen' : 'Eigenschappen uitklappen'} kbd={'Ctrl ⇧ \\'} always={!rightOpen} className="max-lg:hidden" handleClassName={rightOpen ? undefined : '-left-10'} />
    </div>
  )
}

function FrameProps({ frame }: { frame: Frame }) {
  const docColors = useDocColors()
  const brand = useBrandColors()
  const { user } = useSession()
  const set = (patch: Partial<Frame>) => {
    const st = useEditor.getState()
    st.mutate((d) => { const f = d.frames.find((x) => x.id === frame.id); if (f) Object.assign(f, patch) })
  }
  const bg = frame.background
  const checks = useAdChecks(frame)
  return (
    <>
      <Section title="Formaat">
        <input className="h-9 w-full min-w-0 rounded-lg bg-sunk px-3 text-sm font-semibold outline-none focus:ring-2 focus:ring-violet" value={frame.name} onChange={(e) => set({ name: e.target.value })} aria-label="Naam formaat" />
        <div className="grid grid-cols-2 gap-2">
          <NumberField label="B" value={frame.w} min={10} max={8000} onChange={(v) => set({ w: Math.round(v) })} suffix="px" />
          <NumberField label="H" value={frame.h} min={10} max={8000} onChange={(v) => set({ h: Math.round(v) })} suffix="px" />
        </div>
        <label className="flex items-center gap-2 text-sm"><input type="checkbox" className="h-4 w-4 accent-[#EA5F39]" checked={!!frame.safeZone} onChange={(e) => set({ safeZone: e.target.checked })} /> Veilige zones voor stories tonen</label>
      </Section>
      <Section title="Achtergrond">
        <Segmented value={bg.type} onChange={(v) => set({ background: { ...bg, type: v } })} options={[{ value: 'solid', label: 'Kleur' }, { value: 'gradient', label: 'Verloop' }, { value: 'image', label: 'Foto' }]} />
        <ColorPicker value={bg.color} onChange={(c) => set({ background: { ...bg, color: c } })} docColors={docColors} brandColors={brand} />
        {bg.type === 'gradient' && (<>
          <ColorPicker value={bg.color2} onChange={(c) => set({ background: { ...bg, color2: c } })} docColors={docColors} />
          <Slider label="Hoek" value={bg.angle} min={0} max={360} onChange={(v) => set({ background: { ...bg, angle: v } })} format={(v) => `${v}°`} />
        </>)}
        {bg.type === 'image' && (
          <label className="flex h-9 cursor-pointer items-center justify-center gap-2 rounded-lg border border-line text-sm font-semibold hover:bg-sunk">
            <ImageUp size={16} /> {bg.src ? 'Andere foto' : 'Foto kiezen'}
            <input type="file" accept="image/*" className="hidden" onChange={async (e) => { const f = e.target.files?.[0]; if (!f) return; const a = await uploadAsset(f, user!.id); set({ background: { ...bg, type: 'image', src: a.url } }) }} />
          </label>
        )}
      </Section>
      <Section title="Animatie">
        <Slider label="Lengte" value={frame.duration} min={1} max={30} step={0.5} onChange={(v) => set({ duration: v })} format={(v) => `${v} s`} />
        <p className="text-xs text-muted">Google Ads staat maximaal 30 seconden animatie toe, inclusief herhalingen.</p>
      </Section>
      <Section title="Advertentiecontrole">
        <ul className="grid gap-2 text-sm">
          {checks.map((c, i) => (
            <li key={c.text + i} className="anim-rise">
              <button disabled={!c.ids?.length} onClick={() => c.ids && useEditor.getState().select(c.ids.slice(0, 1))} className="flex w-full gap-2 rounded-lg px-1 py-0.5 text-left enabled:hover:bg-sunk" title={c.ids?.length ? 'Klik om dit element te selecteren' : undefined}>
                {c.ok ? <CheckCircle2 size={16} className="mt-0.5 shrink-0 text-mint" /> : <AlertTriangle size={16} className="mt-0.5 shrink-0 text-warn" />}<span>{c.text}</span>
              </button>
            </li>
          ))}
        </ul>
      </Section>
      <p className="px-4 py-4 text-xs leading-relaxed text-muted">Tip: klik op een element om het aan te passen. Dubbelklik op tekst om te typen. Houd Shift ingedrukt om meerdere dingen te selecteren.</p>
    </>
  )
}

function useAdChecks(frame: Frame) {
  return useMemo(() => adChecks(frame), [frame])
}

function ElProps({ els, frame }: { els: El[]; frame: Frame }) {
  const el = els[0]
  const ids = els.map((e) => e.id)
  const multi = els.length > 1
  const st = useEditor.getState
  const up = (patch: Partial<El> | ((e: El) => Partial<El>), history = true) => st().updateEls(ids, patch, { history })
  const docColors = useDocColors()
  const { user } = useSession()
  const grp = selectedGroup(frame, ids)
  const f = el.filters || { brightness: 0, contrast: 0, saturation: 0, hue: 0, blur: 0, grayscale: false }
  const setF = (p: Partial<typeof f>) => up({ filters: { ...f, ...p } })
  return (
    <>
      <div className="flex flex-wrap items-center gap-0.5 border-b border-line px-3 py-2">
        <IconBtn label="Dupliceren (Ctrl+D)" onClick={() => st().duplicateSelected()}><Copy size={16} /></IconBtn>
        <IconBtn label={el.locked ? 'Ontgrendelen' : 'Vergrendelen'} onClick={() => up({ locked: !el.locked })}>{el.locked ? <Lock size={16} /> : <Unlock size={16} />}</IconBtn>
        {!multi && <>
          <IconBtn label="Naar voren" onClick={() => st().reorder(el.id, 'up')}><ChevronUp size={16} /></IconBtn>
          <IconBtn label="Naar achteren" onClick={() => st().reorder(el.id, 'down')}><ChevronDown size={16} /></IconBtn>
          <IconBtn label="Helemaal naar voren" onClick={() => st().reorder(el.id, 'top')}><ArrowUpToLine size={16} /></IconBtn>
          <IconBtn label="Helemaal naar achteren" onClick={() => st().reorder(el.id, 'bottom')}><ArrowDownToLine size={16} /></IconBtn>
        </>}
        <span className="flex-1" />
        <IconBtn label="Verwijderen (Delete)" onClick={() => st().removeSelected()} className="text-red-600"><Trash2 size={16} /></IconBtn>
      </div>

      {el.type === 'text' && !multi && <TextProps el={el} up={up} docColors={docColors} />}

      {el.type !== 'text' && el.type !== 'image' && (
        <Section title={el.type === 'icon' ? 'Icoon' : 'Vorm'}>
          {!(el.type === 'icon' && el.iconMulti) && <ColorPicker value={el.fill} onChange={(c) => up({ fill: c })} docColors={docColors} label="Vulkleur" />}
          {el.type === 'icon' && el.iconMulti && <p className="text-xs text-muted">Dit is een kleurenicoon; de kleuren liggen vast.</p>}
          {el.type === 'icon' && !multi && !el.iconSvg && (
            <>
              <Select value={el.icon || 'star'} onChange={(v) => up({ icon: v })} options={Object.keys(ICONS).map((k) => ({ value: k, label: k }))} />
              <Slider label="Lijndikte" value={el.strokeWidth || 2} min={0.5} max={4} step={0.25} onChange={(v) => up({ strokeWidth: v })} />
            </>
          )}
          {el.type !== 'icon' && (<>
            <div className="grid grid-cols-[1fr_96px] gap-2">
              <ColorPicker value={el.stroke} onChange={(c) => up({ stroke: c, strokeWidth: el.strokeWidth || 4 })} docColors={docColors} label="Randkleur" />
              <NumberField label="Rand" value={el.strokeWidth} min={0} max={200} onChange={(v) => up({ strokeWidth: v })} />
            </div>
            {(el.type === 'rect' || el.type === 'line') && <Slider label="Afronding" value={Math.min(el.cornerRadius, Math.min(el.width, el.height) / 2)} min={0} max={Math.round(Math.min(el.width, el.height) / 2)} onChange={(v) => up({ cornerRadius: v })} />}
            {el.type === 'star' && (<>
              <Slider label="Punten" value={el.points || 5} min={3} max={24} onChange={(v) => up({ points: v })} />
              <Slider label="Binnenstraal" value={Math.round((el.innerRatio || 0.45) * 100)} min={10} max={95} onChange={(v) => up({ innerRatio: v / 100 })} format={(v) => `${v}%`} />
            </>)}
          </>)}
        </Section>
      )}

      {el.type === 'image' && !multi && (
        <Section title="Afbeelding">
          <label className="flex h-9 cursor-pointer items-center justify-center gap-2 rounded-lg border border-line text-sm font-semibold hover:bg-sunk">
            <ImageUp size={16} /> {el.src ? 'Afbeelding vervangen' : 'Afbeelding kiezen'}
            <input type="file" accept="image/*" className="hidden" onChange={async (e) => { const file = e.target.files?.[0]; if (!file) return; const a = await uploadAsset(file, user!.id); up({ src: a.url, cropZoom: 1, cropX: 0.5, cropY: 0.5 }) }} />
          </label>
          {el.src && (<>
            <Slider label="Inzoomen" value={el.cropZoom || 1} min={1} max={4} step={0.05} onChange={(v) => up({ cropZoom: v })} format={(v) => `${Math.round(v * 100)}%`} />
            <Slider label="Uitsnede horizontaal" value={Math.round((el.cropX ?? 0.5) * 100)} min={0} max={100} onChange={(v) => up({ cropX: v / 100 })} format={(v) => `${v}%`} />
            <Slider label="Uitsnede verticaal" value={Math.round((el.cropY ?? 0.5) * 100)} min={0} max={100} onChange={(v) => up({ cropY: v / 100 })} format={(v) => `${v}%`} />
          </>)}
          <div className="grid gap-1"><span className="text-[13px] font-medium">Vorm</span>
            <Segmented value={el.mask || 'none'} onChange={(v) => up({ mask: v })} options={[
              { value: 'none', label: '▭', title: 'Rechthoek' }, { value: 'circle', label: '●', title: 'Cirkel' }, { value: 'oval', label: '⬭', title: 'Ovaal' },
              { value: 'arch', label: '⌓', title: 'Boog' }, { value: 'leaf', label: '◆', title: 'Blad' }, { value: 'blob', label: '◔', title: 'Organisch' },
            ]} />
          </div>
          <div className="flex gap-1">
            <IconBtn label="Horizontaal spiegelen" active={el.flipX} onClick={() => up({ flipX: !el.flipX })}><FlipHorizontal size={16} /></IconBtn>
            <IconBtn label="Verticaal spiegelen" active={el.flipY} onClick={() => up({ flipY: !el.flipY })}><FlipVertical size={16} /></IconBtn>
          </div>
          <Slider label="Afronding" value={el.cornerRadius} min={0} max={Math.round(Math.min(el.width, el.height) / 2)} onChange={(v) => up({ cornerRadius: v })} />
        </Section>
      )}

      {(el.type === 'image' || el.type === 'icon') && !multi && (
        <Section title="Filters">
          <Slider label="Helderheid" value={Math.round(f.brightness * 100)} min={-60} max={60} onChange={(v) => setF({ brightness: v / 100 })} />
          <Slider label="Contrast" value={f.contrast} min={-60} max={60} onChange={(v) => setF({ contrast: v })} />
          <Slider label="Verzadiging" value={Math.round(f.saturation * 50)} min={-50} max={100} onChange={(v) => setF({ saturation: v / 50 })} />
          <Slider label="Kleurtoon" value={f.hue} min={0} max={359} onChange={(v) => setF({ hue: v })} format={(v) => `${v}°`} />
          <Slider label="Vervagen" value={f.blur} min={0} max={40} onChange={(v) => setF({ blur: v })} />
          <label className="flex items-center gap-2 text-sm"><input type="checkbox" className="h-4 w-4 accent-[#EA5F39]" checked={f.grayscale} onChange={(e) => setF({ grayscale: e.target.checked })} /> Zwart-wit</label>
          <div className="grid grid-cols-4 gap-1.5">
            {[
              { n: 'Origineel', v: { brightness: 0, contrast: 0, saturation: 0, hue: 0, blur: 0, grayscale: false } },
              { n: 'Warm', v: { brightness: 0.05, contrast: 10, saturation: 0.3, hue: 10, blur: 0, grayscale: false } },
              { n: 'Fel', v: { brightness: 0.05, contrast: 25, saturation: 0.6, hue: 0, blur: 0, grayscale: false } },
              { n: 'Mat', v: { brightness: 0.08, contrast: -20, saturation: -0.3, hue: 0, blur: 0, grayscale: false } },
            ].map((p) => <Button key={p.n} size="sm" className="px-1 text-[11px]" onClick={() => up({ filters: p.v })}>{p.n}</Button>)}
          </div>
        </Section>
      )}

      {grp && <GroupProps frame={frame} gid={grp.id} />}
      <Section title={multi ? 'Uitlijnen en groeperen' : 'Uitlijnen op het formaat'}>
        <AlignTools />
      </Section>

      {!multi && (
        <Section title="Positie en grootte">
          <div className="grid grid-cols-2 gap-2">
            <NumberField label="X" value={el.x} onChange={(v) => up({ x: v })} />
            <NumberField label="Y" value={el.y} onChange={(v) => up({ y: v })} />
            <NumberField label="B" value={el.width} min={1} onChange={(v) => up({ width: v })} />
            {el.type !== 'text' ? <NumberField label="H" value={el.height} min={1} onChange={(v) => up({ height: v })} /> : <div />}
            <NumberField label="Draai" value={el.rotation} suffix="°" onChange={(v) => up({ rotation: v })} />
          </div>
        </Section>
      )}

      <Section title="Effecten">
        <Slider label="Dekking" value={Math.round(el.opacity * 100)} min={0} max={100} onChange={(v) => up({ opacity: v / 100 })} format={(v) => `${v}%`} />
        <div className="grid gap-1"><span className="text-[13px] font-medium">Overvloeimodus</span>
          <Select value={el.blend || 'source-over'} onChange={(v) => up({ blend: v })} options={BLENDS.map(([value, label]) => ({ value, label }))} />
        </div>
        <label className="flex items-center gap-2 text-sm font-medium"><input type="checkbox" className="h-4 w-4 accent-[#EA5F39]" checked={el.shadow.enabled} onChange={(e) => up((x) => ({ shadow: { ...x.shadow, enabled: e.target.checked } }))} /> Schaduw</label>
        {el.shadow.enabled && (
          <div className="grid gap-2.5 rounded-lg bg-mist p-2.5">
            <ColorPicker value={el.shadow.color} onChange={(c) => up((x) => ({ shadow: { ...x.shadow, color: c } }))} label="Schaduwkleur" />
            <Slider label="Vervaging" value={el.shadow.blur} min={0} max={120} onChange={(v) => up((x) => ({ shadow: { ...x.shadow, blur: v } }))} />
            <Slider label="Afstand" value={el.shadow.y} min={-60} max={60} onChange={(v) => up((x) => ({ shadow: { ...x.shadow, y: v } }))} />
            <Slider label="Dekking" value={Math.round(el.shadow.opacity * 100)} min={0} max={100} onChange={(v) => up((x) => ({ shadow: { ...x.shadow, opacity: v / 100 } }))} format={(v) => `${v}%`} />
          </div>
        )}
      </Section>
    </>
  )
}

function TextProps({ el, up, docColors }: { el: El; up: (p: Partial<El>) => void; docColors: string[] }) {
  const weights = fontWeights(el.fontFamily || 'Poppins')
  const wNames: Record<number, string> = { 300: 'Licht', 400: 'Normaal', 500: 'Medium', 600: 'Halfvet', 700: 'Vet', 800: 'Extra vet', 900: 'Zwart' }
  return (
    <Section title="Tekst">
      <textarea value={el.text} onChange={(e) => up({ text: e.target.value })} rows={2} className="w-full resize-y rounded-lg bg-sunk px-3 py-2 text-sm outline-none focus:ring-2 focus:ring-violet" aria-label="Tekstinhoud" />
      <FontPicker value={el.fontFamily || 'Poppins'} onChange={(fam) => up({ fontFamily: fam, fontWeight: nearestWeight(fam, el.fontWeight || 400) })} />
      <div className="grid grid-cols-[1fr_110px] gap-2">
        <Select value={String(nearestWeight(el.fontFamily || 'Poppins', el.fontWeight || 400))} onChange={(v) => up({ fontWeight: +v })} options={weights.map((w) => ({ value: String(w), label: wNames[w] || String(w) }))} />
        <NumberField label="Aa" value={el.fontSize || 24} min={4} max={1000} onChange={(v) => up({ fontSize: v })} />
      </div>
      <div className="flex flex-wrap gap-0.5">
        <IconBtn label="Vet" active={(el.fontWeight || 400) >= 700} onClick={() => up({ fontWeight: (el.fontWeight || 400) >= 700 ? 400 : nearestWeight(el.fontFamily || 'Poppins', 700) })}><Bold size={16} /></IconBtn>
        <IconBtn label="Cursief" active={el.italic} onClick={() => up({ italic: !el.italic })}><Italic size={16} /></IconBtn>
        <IconBtn label="Onderstrepen" active={el.underline} onClick={() => up({ underline: !el.underline })}><Underline size={16} /></IconBtn>
        <IconBtn label="Hoofdletters" active={el.uppercase} onClick={() => up({ uppercase: !el.uppercase })}><CaseUpper size={16} /></IconBtn>
        <span className="mx-1 w-px bg-line" />
        <IconBtn label="Links uitlijnen" active={el.align === 'left'} onClick={() => up({ align: 'left' })}><AlignLeft size={16} /></IconBtn>
        <IconBtn label="Centreren" active={el.align === 'center'} onClick={() => up({ align: 'center' })}><AlignCenter size={16} /></IconBtn>
        <IconBtn label="Rechts uitlijnen" active={el.align === 'right'} onClick={() => up({ align: 'right' })}><AlignRight size={16} /></IconBtn>
      </div>
      <ColorPicker value={el.fill} onChange={(c) => up({ fill: c })} docColors={docColors} label="Tekstkleur" />
      <Slider label="Regelafstand" value={el.lineHeight || 1.2} min={0.7} max={2.5} step={0.05} onChange={(v) => up({ lineHeight: v })} format={(v) => v.toFixed(2)} />
      <Slider label="Letterafstand" value={el.letterSpacing || 0} min={-10} max={40} step={0.5} onChange={(v) => up({ letterSpacing: v })} />
      <div className="grid grid-cols-[1fr_96px] gap-2">
        <ColorPicker value={el.stroke} onChange={(c) => up({ stroke: c, strokeWidth: el.strokeWidth || 2 })} docColors={docColors} label="Contourkleur" />
        <NumberField label="Contour" value={el.strokeWidth} min={0} max={40} onChange={(v) => up({ strokeWidth: v })} />
      </div>
      <p className={cn('text-xs text-muted')}>Dubbelklik op de tekst in het canvas om direct te typen.</p>
    </Section>
  )
}

/** Groep: naam, positie van de hele groep en animatie als één geheel. */
function GroupProps({ frame, gid }: { frame: Frame; gid: string }) {
  const g = (frame.groups || []).find((x) => x.id === gid)
  const box = groupBox(frame, gid)
  if (!g || !box) return null
  const st = useEditor.getState
  const move = (dx: number, dy: number) => st().updateEls(frame.elements.filter((e) => e.groupId === gid).map((e) => e.id), (e) => ({ x: Math.round((e.x + dx) * 10) / 10, y: Math.round((e.y + dy) * 10) / 10 }))
  return (
    <Section title="Groep">
      <div className="flex items-center gap-2">
        <span className="grid h-8 w-8 shrink-0 place-items-center rounded-lg bg-violet-soft text-violet"><GroupIcon size={16} /></span>
        <input defaultValue={g.name} key={g.id + g.name} onBlur={(e) => e.target.value.trim() && e.target.value !== g.name && st().renameGroup(gid, e.target.value.trim())} onKeyDown={(e) => { if (e.key === 'Enter') (e.target as HTMLInputElement).blur() }} className="h-9 min-w-0 flex-1 rounded-lg bg-sunk px-3 text-sm font-semibold outline-none focus:ring-2 focus:ring-violet/30" aria-label="Naam van de groep" />
      </div>
      <div className="grid grid-cols-2 gap-2">
        <NumberField label="X" value={Math.round(box.x)} onChange={(v) => move(v - box.x, 0)} />
        <NumberField label="Y" value={Math.round(box.y)} onChange={(v) => move(0, v - box.y)} />
      </div>
      <button onClick={() => st().setLeftTab('animate')} className="flex items-center gap-2 rounded-lg px-1 py-1 text-left text-xs font-semibold text-violet hover:underline"><Sparkles size={14} /> {g.anim && (g.anim.in.type !== 'none' || g.anim.emph.type !== 'none' || g.anim.out.type !== 'none') ? 'Groepsanimatie aanpassen' : 'Groep als één geheel animeren'}</button>
      <p className="text-[11px] leading-snug text-muted">Dubbelklik op een onderdeel om het los aan te passen. Ctrl G groepeert, Ctrl Shift G heft op.</p>
    </Section>
  )
}
