import { useEffect, useLayoutEffect, useRef, useState } from 'react'
import Konva from 'konva'
import { useEditor } from '../store/editor'
import { FrameRenderer, fontStyle } from '../lib/render'
import { loadFontsForDoc } from '../lib/fonts'
import { sendCursor, sendLive } from '../lib/collab'
import type { El, Frame } from '../lib/types'

const PAD = 48

export default function Canvas() {
  const wrapRef = useRef<HTMLDivElement>(null)
  const hostRef = useRef<HTMLDivElement>(null)
  const stageRef = useRef<Konva.Stage | null>(null)
  const rendererRef = useRef<FrameRenderer | null>(null)
  const uiRef = useRef<{ layer: Konva.Layer; tr: Konva.Transformer; guides: Konva.Group; marquee: Konva.Rect; peers: Konva.Group; safe: Konva.Group; shadow: Konva.Rect } | null>(null)
  const [size, setSize] = useState({ w: 800, h: 600 })
  const [editing, setEditing] = useState<El | null>(null)
  const offsetRef = useRef({ x: PAD, y: PAD })

  const frame = useEditor((s) => s.doc.frames.find((f) => f.id === s.activeFrameId) || s.doc.frames[0])
  const zoom = useEditor((s) => s.zoom)
  const selectedIds = useEditor((s) => s.selectedIds)
  const playing = useEditor((s) => s.playing)
  const time = useEditor((s) => s.time)
  const peers = useEditor((s) => s.peers)

  // container meten
  useLayoutEffect(() => {
    const el = wrapRef.current!
    const ro = new ResizeObserver(() => setSize({ w: el.clientWidth, h: el.clientHeight }))
    ro.observe(el)
    setSize({ w: el.clientWidth, h: el.clientHeight })
    return () => ro.disconnect()
  }, [])

  // passende zoom bij wisselen van formaat
  const fid = frame?.id
  useEffect(() => {
    if (!frame) return
    const fit = Math.min((size.w - PAD * 2) / frame.w, (size.h - PAD * 2) / frame.h)
    useEditor.setState({ fitZoom: fit, zoom: Math.max(0.05, Math.min(fit, 4)) })
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [fid, frame?.w, frame?.h, size.w, size.h])

  // stage opbouwen (eenmalig)
  useEffect(() => {
    const stage = new Konva.Stage({ container: hostRef.current!, width: 800, height: 600 })
    const main = new Konva.Layer()
    const ui = new Konva.Layer()
    stage.add(main, ui)
    const shadow = new Konva.Rect({ fill: '#fff', shadowColor: '#1B213B', shadowBlur: 24, shadowOpacity: 0.12, shadowOffsetY: 6, listening: false })
    main.add(shadow)
    const renderer = new FrameRenderer(main, {
      interactive: true,
      onMeasure: (id, h) => useEditor.getState().updateEls([id], { height: h }, { history: false }),
    })
    const tr = new Konva.Transformer({
      rotationSnaps: [0, 45, 90, 135, 180, 225, 270, 315], rotationSnapTolerance: 4,
      anchorSize: 10, anchorCornerRadius: 5, anchorStroke: '#1A5FC4', anchorFill: '#fff', borderStroke: '#1A5FC4', borderStrokeWidth: 1.5,
      rotateAnchorOffset: 28, padding: 0, ignoreStroke: true, flipEnabled: false,
    })
    const guides = new Konva.Group({ listening: false })
    const peersG = new Konva.Group({ listening: false })
    const safe = new Konva.Group({ listening: false })
    const marquee = new Konva.Rect({ fill: 'rgba(91,63,217,0.08)', stroke: '#1A5FC4', strokeWidth: 1, visible: false, listening: false })
    ui.add(safe, peersG, tr, guides, marquee)
    stageRef.current = stage
    rendererRef.current = renderer
    uiRef.current = { layer: ui, tr, guides, marquee, peers: peersG, safe, shadow }

    const findGroup = (n: Konva.Node | null): Konva.Group | null => {
      while (n && n !== stage) { if (n.name() === 'el') return n as Konva.Group; n = n.getParent() }
      return null
    }
    const elOf = (g: Konva.Group) => g.getAttr('el') as El
    const toFrame = (p: { x: number; y: number }) => {
      const z = useEditor.getState().zoom
      return { x: (p.x - offsetRef.current.x) / z, y: (p.y - offsetRef.current.y) / z }
    }

    // selectie
    let marqueeStart: { x: number; y: number } | null = null
    stage.on('mousedown touchstart', (e) => {
      if (useEditor.getState().playing) return
      if (e.target.getParent()?.className === 'Transformer') return
      const g = findGroup(e.target)
      const st = useEditor.getState()
      if (g) {
        const id = g.id()
        const shift = (e.evt as MouseEvent).shiftKey || (e.evt as MouseEvent).metaKey
        if (shift) st.select(st.selectedIds.includes(id) ? st.selectedIds.filter((x) => x !== id) : [...st.selectedIds, id])
        else if (!st.selectedIds.includes(id)) st.select([id])
        return
      }
      if (!(e.evt as MouseEvent).shiftKey) st.select([])
      const p = stage.getPointerPosition()!
      marqueeStart = p
      marquee.setAttrs({ x: p.x, y: p.y, width: 0, height: 0, visible: true })
    })
    stage.on('mousemove touchmove', () => {
      const p = stage.getPointerPosition()
      if (p) sendCursor(toFrame(p))
      if (!marqueeStart || !p) return
      marquee.setAttrs({ x: Math.min(p.x, marqueeStart.x), y: Math.min(p.y, marqueeStart.y), width: Math.abs(p.x - marqueeStart.x), height: Math.abs(p.y - marqueeStart.y) })
      ui.batchDraw()
    })
    stage.on('mouseleave', () => sendCursor(null))
    stage.on('mouseup touchend', () => {
      if (!marqueeStart) return
      const box = marquee.getClientRect()
      marquee.visible(false)
      marqueeStart = null
      if (box.width > 4 && box.height > 4) {
        const ids: string[] = []
        renderer.nodes.forEach((g, id) => {
          const el = elOf(g)
          if (el.locked || !el.visible) return
          if (Konva.Util.haveIntersection(box, g.getClientRect())) ids.push(id)
        })
        useEditor.getState().select(ids)
      }
      ui.batchDraw()
    })

    // slepen met hulplijnen
    let dragStart: Record<string, { x: number; y: number }> = {}
    stage.on('dragstart', (e) => {
      const g = findGroup(e.target)
      if (!g) return
      dragStart = {}
      const st = useEditor.getState()
      for (const id of st.selectedIds) { const n = renderer.nodes.get(id); if (n) dragStart[id] = { x: n.x(), y: n.y() } }
      dragStart[g.id()] = { x: g.x(), y: g.y() }
    })
    stage.on('dragmove', (e) => {
      const g = findGroup(e.target)
      if (!g || e.target !== g) return
      const el = elOf(g)
      const f = renderer.frame!
      const z = useEditor.getState().zoom
      const thr = 6 / z
      const h = g.getAttr('h') ?? el.height
      const w = el.width
      const xs = [0, f.w / 2, f.w], ys = [0, f.h / 2, f.h]
      const sel = useEditor.getState().selectedIds
      for (const o of f.elements) {
        if (o.id === el.id || sel.includes(o.id) || !o.visible) continue
        const on = renderer.nodes.get(o.id)
        const oh = on?.getAttr('h') ?? o.height
        xs.push(o.x, o.x + o.width / 2, o.x + o.width)
        ys.push(o.y, o.y + oh / 2, o.y + oh)
      }
      const lines: { v: boolean; p: number }[] = []
      let cx = g.x(), cy = g.y()
      const snap = (vals: number[], edges: number[]) => {
        let best: { d: number; delta: number; p: number } | null = null
        for (const v of vals) for (const ed of edges) { const d = Math.abs(v - ed); if (d < thr && (!best || d < best.d)) best = { d, delta: v - ed, p: v } }
        return best
      }
      const sx = snap(xs, [cx - w / 2, cx, cx + w / 2])
      if (sx) { cx += sx.delta; lines.push({ v: true, p: sx.p }) }
      const sy = snap(ys, [cy - h / 2, cy, cy + h / 2])
      if (sy) { cy += sy.delta; lines.push({ v: false, p: sy.p }) }
      g.position({ x: cx, y: cy })
      // andere geselecteerde elementen meeschuiven
      const start = dragStart[g.id()]
      const dx = cx - (start?.x ?? cx), dy = cy - (start?.y ?? cy)
      const live: { id: string; x: number; y: number; rotation: number }[] = []
      for (const id of sel) {
        const n = renderer.nodes.get(id)
        if (!n) continue
        if (n !== g && dragStart[id]) n.position({ x: dragStart[id].x + dx, y: dragStart[id].y + dy })
        const ee = elOf(n)
        live.push({ id, x: n.x() - ee.width / 2, y: n.y() - (n.getAttr('h') ?? ee.height) / 2, rotation: n.rotation() })
      }
      if (!sel.includes(g.id())) live.push({ id: g.id(), x: cx - w / 2, y: cy - h / 2, rotation: g.rotation() })
      sendLive(live)
      guides.destroyChildren()
      const o = offsetRef.current
      for (const l of lines) {
        guides.add(new Konva.Line({
          points: l.v ? [o.x + l.p * z, 0, o.x + l.p * z, stage.height()] : [0, o.y + l.p * z, stage.width(), o.y + l.p * z],
          stroke: '#E0337A', strokeWidth: 1, dash: [4, 4],
        }))
      }
      ui.batchDraw()
    })
    stage.on('dragend', (e) => {
      const g = findGroup(e.target)
      guides.destroyChildren(); ui.batchDraw()
      if (!g) return
      const st = useEditor.getState()
      const ids = st.selectedIds.includes(g.id()) ? st.selectedIds : [g.id()]
      const pos: Record<string, { x: number; y: number }> = {}
      for (const id of ids) {
        const n = renderer.nodes.get(id)
        if (!n) continue
        const el = elOf(n)
        pos[id] = { x: Math.round((n.x() - el.width / 2) * 10) / 10, y: Math.round((n.y() - (n.getAttr('h') ?? el.height) / 2) * 10) / 10 }
      }
      st.updateEls(ids, (el) => pos[el.id] || {})
    })

    // transformeren
    tr.on('transform', () => {
      for (const n of tr.nodes()) {
        const el = elOf(n as Konva.Group)
        if (el.type !== 'text') continue
        const anchor = tr.getActiveAnchor()
        if (anchor === 'middle-left' || anchor === 'middle-right') {
          const t = (n as Konva.Group).findOne('.shape') as Konva.Text
          const nw = Math.max(20, el.width * n.scaleX())
          t.width(nw)
          n.scaleX(1); n.scaleY(1)
          n.offsetX(nw / 2)
          n.setAttr('liveW', nw)
        }
      }
    })
    tr.on('transformend', () => {
      const st = useEditor.getState()
      const anchor = tr.getActiveAnchor() || ''
      const patches: Record<string, Partial<El>> = {}
      for (const n of tr.nodes()) {
        const el = elOf(n as Konva.Group)
        const sx = n.scaleX(), sy = n.scaleY()
        const p: Partial<El> = { rotation: Math.round(n.rotation() * 10) / 10 }
        if (el.type === 'text') {
          const liveW = n.getAttr('liveW')
          if (liveW) { p.width = liveW; n.setAttr('liveW', null) }
          else if (Math.abs(sx - 1) > 0.001 || Math.abs(sy - 1) > 0.001) {
            p.width = el.width * sx
            if (!anchor.startsWith('middle')) p.fontSize = Math.max(4, Math.round((el.fontSize || 24) * sy * 10) / 10)
          }
          const w = p.width ?? el.width
          const h = (n.getAttr('h') ?? el.height) * (p.fontSize ? sy : 1)
          p.x = n.x() - w / 2; p.y = n.y() - h / 2
          if (p.fontSize) p.height = h
        } else {
          p.width = Math.max(1, el.width * sx)
          p.height = Math.max(1, el.height * sy)
          p.x = n.x() - p.width / 2
          p.y = n.y() - p.height / 2
        }
        n.scaleX(1); n.scaleY(1)
        patches[el.id] = p
      }
      st.updateEls(Object.keys(patches), (e) => patches[e.id])
    })

    // dubbelklik op tekst = bewerken
    stage.on('dblclick dbltap', (e) => {
      const g = findGroup(e.target)
      if (!g) return
      const el = elOf(g)
      if (el.type === 'text' && !el.locked) setEditing(el)
    })

    // ctrl + scroll = zoomen
    stage.on('wheel', (e) => {
      if (!e.evt.ctrlKey && !e.evt.metaKey) return
      e.evt.preventDefault()
      const st = useEditor.getState()
      st.setZoom(st.zoom * (e.evt.deltaY > 0 ? 0.9 : 1.1))
    })

    return () => { stage.destroy(); stageRef.current = null; rendererRef.current = null }
  }, [])

  // afmetingen en positie
  const fw = frame ? frame.w * zoom : 0, fh = frame ? frame.h * zoom : 0
  const stageW = Math.max(size.w, fw + PAD * 2), stageH = Math.max(size.h, fh + PAD * 2)
  const ox = Math.round((stageW - fw) / 2), oy = Math.round((stageH - fh) / 2)
  offsetRef.current = { x: ox, y: oy }

  useEffect(() => {
    const stage = stageRef.current, r = rendererRef.current, ui = uiRef.current
    if (!stage || !r || !ui || !frame) return
    stage.size({ width: stageW, height: stageH })
    r.root.position({ x: ox, y: oy })
    r.root.scale({ x: zoom, y: zoom })
    ui.shadow.setAttrs({ x: ox, y: oy, width: fw, height: fh })
    drawOverlays()
    stage.batchDraw()
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [stageW, stageH, ox, oy, zoom, frame?.w, frame?.h])

  // inhoud synchroniseren
  useEffect(() => {
    const r = rendererRef.current
    if (!r || !frame) return
    r.sync(frame)
    const t = useEditor.getState().time
    r.applyTime(t)
    updateTransformer()
    drawOverlays()
    r.root.getLayer()?.batchDraw()
    const fams = frame.elements.filter((e) => e.type === 'text').map((e) => e.fontFamily || 'Poppins')
    loadFontsForDoc(fams).then(() => {
      if (rendererRef.current !== r || !r.frame) return
      let need = false
      r.nodes.forEach((g) => { const el = g.getAttr('el') as El; if (el?.type === 'text' && !g.getAttr('fontOk')) { g.setAttr('json', ''); g.setAttr('fontOk', true); need = true } })
      if (need) { r.sync(r.frame); r.applyTime(useEditor.getState().time); updateTransformer() }
    })
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [frame])

  useEffect(() => { updateTransformer(); drawOverlays() }, [selectedIds, playing, time, peers]) // eslint-disable-line react-hooks/exhaustive-deps

  // afspelen
  useEffect(() => {
    if (!playing || !frame) return
    let raf = 0
    const start = performance.now() - (useEditor.getState().time || 0) * 1000
    const tick = () => {
      let t = (performance.now() - start) / 1000
      if (t > frame.duration) { useEditor.setState({ playing: false, time: null }); rendererRef.current?.applyTime(null); return }
      rendererRef.current?.applyTime(t)
      if (Math.floor(t * 10) !== Math.floor((useEditor.getState().time || 0) * 10)) useEditor.setState({ time: t })
      t = 0
      raf = requestAnimationFrame(tick)
    }
    raf = requestAnimationFrame(tick)
    return () => cancelAnimationFrame(raf)
  }, [playing, frame?.id]) // eslint-disable-line react-hooks/exhaustive-deps

  useEffect(() => { if (!playing) rendererRef.current?.applyTime(time) }, [time, playing])

  function updateTransformer() {
    const r = rendererRef.current, ui = uiRef.current
    if (!r || !ui) return
    const st = useEditor.getState()
    const nodes = st.playing || st.time !== null || editing ? [] : st.selectedIds.map((id) => r.nodes.get(id)).filter((n): n is Konva.Group => !!n && !(n.getAttr('el') as El).locked && (n.getAttr('el') as El).visible)
    ui.tr.nodes(nodes)
    const textOnly = nodes.length === 1 && (nodes[0].getAttr('el') as El).type === 'text'
    ui.tr.enabledAnchors(textOnly ? ['top-left', 'top-right', 'bottom-left', 'bottom-right', 'middle-left', 'middle-right'] : ['top-left', 'top-center', 'top-right', 'middle-left', 'middle-right', 'bottom-left', 'bottom-center', 'bottom-right'])
    ui.tr.keepRatio(textOnly || (nodes.length === 1 && ['image', 'icon'].includes((nodes[0].getAttr('el') as El).type)))
    // vergrendelde selectie tonen met stippellijn
    ui.layer.batchDraw()
  }

  function drawOverlays() {
    const r = rendererRef.current, ui = uiRef.current, f = r?.frame
    if (!r || !ui || !f) return
    const z = useEditor.getState().zoom
    const o = offsetRef.current
    ui.safe.destroyChildren()
    if (f.safeZone) {
      const top = f.h * 0.14, bottom = f.h * 0.2
      for (const [y, h, label] of [[0, top, 'Veilige zone: profiel en balk'], [f.h - bottom, bottom, 'Veilige zone: knoppen en tekst']] as const) {
        ui.safe.add(new Konva.Rect({ x: o.x, y: o.y + y * z, width: f.w * z, height: h * z, fill: 'rgba(224,51,122,0.08)', stroke: 'rgba(224,51,122,0.5)', dash: [6, 4], strokeWidth: 1 }))
        ui.safe.add(new Konva.Text({ x: o.x + 8, y: o.y + y * z + 6, text: label, fontSize: 11, fontFamily: 'Poppins', fill: '#E0337A', fontStyle: '600' }))
      }
    }
    ui.peers.destroyChildren()
    const st = useEditor.getState()
    for (const p of Object.values(st.peers)) {
      if (p.frameId !== f.id || !p.selection?.length) continue
      for (const id of p.selection) {
        const n = r.nodes.get(id)
        if (!n) continue
        const box = n.getClientRect()
        ui.peers.add(new Konva.Rect({ ...box, stroke: p.color, strokeWidth: 2, dash: [6, 3] }))
        ui.peers.add(new Konva.Label({ x: box.x, y: box.y - 18 }).add(new Konva.Tag({ fill: p.color, cornerRadius: 3 })).add(new Konva.Text({ text: p.name.split(' ')[0], fontSize: 11, padding: 3, fill: '#fff', fontFamily: 'Poppins', fontStyle: '700' })))
      }
    }
    // vergrendelde selectie
    for (const id of st.selectedIds) {
      const n = r.nodes.get(id)
      const el = n?.getAttr('el') as El | undefined
      if (n && el?.locked) ui.peers.add(new Konva.Rect({ ...n.getClientRect(), stroke: '#6B6880', strokeWidth: 1.5, dash: [4, 3] }))
    }
    ui.layer.batchDraw()
  }

  // tekstbewerking
  const commitText = (val: string) => {
    if (!editing) return
    const g = rendererRef.current?.nodes.get(editing.id)
    g?.visible(true)
    if (val !== editing.text) useEditor.getState().updateEls([editing.id], { text: val })
    setEditing(null)
  }
  useEffect(() => {
    if (!editing) return
    rendererRef.current?.nodes.get(editing.id)?.visible(false)
    rendererRef.current?.root.getLayer()?.batchDraw()
    updateTransformer()
  }, [editing]) // eslint-disable-line react-hooks/exhaustive-deps

  const peerCursors = Object.entries(peers).filter(([, p]) => p.cursor && p.frameId === frame?.id)

  return (
    <div ref={wrapRef} className="relative min-h-0 flex-1 overflow-auto bg-sunk" onDragOver={(e) => e.preventDefault()}>
      <div ref={hostRef} style={{ width: stageW, height: stageH }} />
      {editing && frame && <TextEditor el={editing} frame={frame} zoom={zoom} ox={ox} oy={oy} onDone={commitText} />}
      {peerCursors.map(([key, p]) => (
        <div key={key} className="pointer-events-none absolute left-0 top-0 z-10 transition-transform duration-75" style={{ transform: `translate(${ox + p.cursor!.x * zoom}px, ${oy + p.cursor!.y * zoom}px)` }}>
          <svg width="18" height="18" viewBox="0 0 24 24"><path d="M3 2l18 8-8 2-2 8z" fill={p.color} stroke="#fff" strokeWidth="1.5" /></svg>
          <span className="ml-3 rounded px-1.5 py-0.5 text-[11px] font-bold text-white" style={{ background: p.color }}>{p.name.split(' ')[0]}</span>
        </div>
      ))}
    </div>
  )
}

function TextEditor({ el, frame, zoom, ox, oy, onDone }: { el: El; frame: Frame; zoom: number; ox: number; oy: number; onDone: (v: string) => void }) {
  const ref = useRef<HTMLTextAreaElement>(null)
  const [val, setVal] = useState(el.text || '')
  void frame
  useEffect(() => {
    const t = ref.current!
    t.focus(); t.select()
  }, [])
  useEffect(() => {
    const t = ref.current!
    t.style.height = 'auto'
    t.style.height = t.scrollHeight + 'px'
  }, [val])
  const [weight, ital] = (() => { const s = fontStyle(el); return [s.replace('italic ', ''), s.includes('italic')] })()
  return (
    <textarea
      ref={ref}
      value={val}
      onChange={(e) => setVal(e.target.value)}
      onBlur={() => onDone(val)}
      onKeyDown={(e) => { if (e.key === 'Escape' || (e.key === 'Enter' && (e.metaKey || e.ctrlKey))) { e.preventDefault(); onDone(val) } e.stopPropagation() }}
      className="absolute z-20 resize-none overflow-hidden border-0 bg-transparent p-0 outline outline-2 outline-violet"
      style={{
        left: ox + el.x * zoom, top: oy + el.y * zoom, width: el.width * zoom, minHeight: el.height * zoom,
        transform: `rotate(${el.rotation}deg)`, transformOrigin: 'center center',
        fontFamily: `"${el.fontFamily}", sans-serif`, fontSize: (el.fontSize || 24) * zoom, fontWeight: Number(weight), fontStyle: ital ? 'italic' : 'normal',
        lineHeight: el.lineHeight || 1.2, letterSpacing: (el.letterSpacing || 0) * zoom, textAlign: el.align || 'left', color: el.fill,
        textTransform: el.uppercase ? 'uppercase' : 'none', textDecoration: el.underline ? 'underline' : 'none',
      }}
    />
  )
}
