import { useEffect, useLayoutEffect, useRef, useState } from 'react'
import Konva from 'konva'
import { useEditor } from '../store/editor'
import { FrameRenderer } from '../lib/render'
import { loadFontsForDoc } from '../lib/fonts'
import { sendCursor, sendLive, onLive, type LiveItem } from '../lib/collab'
import type { El } from '../lib/types'
import Cursors from './Cursors'
import { RichTextEditor } from './RichTextEditor'
import SelectionToolbar from './SelectionToolbar'
import { CommentLayer } from './Comments'
import { expandToGroups } from '../lib/groups'
import { useComments } from '../lib/comments'

const PAD = 48

/** Coördinaten omrekenen tussen scherm en formaat (voor slepen vanuit de panelen en de agent-cursor). */
export const canvasApi: { clientToFrame: (cx: number, cy: number) => { x: number; y: number } | null; frameToClient: (x: number, y: number) => { x: number; y: number } } = {
  clientToFrame: () => null,
  frameToClient: (x, y) => ({ x, y }),
}

export default function Canvas() {
  const wrapRef = useRef<HTMLDivElement>(null)
  const hostRef = useRef<HTMLDivElement>(null)
  const flipRef = useRef(0)
  const hoverRef = useRef<Konva.Rect | null>(null)
  const lastZoomRef = useRef(0)
  const sizeRef = useRef({ w: 0, h: 0 })
  const stageRef = useRef<Konva.Stage | null>(null)
  const rendererRef = useRef<FrameRenderer | null>(null)
  const uiRef = useRef<{ layer: Konva.Layer; tr: Konva.Transformer; guides: Konva.Group; marquee: Konva.Rect; peers: Konva.Group; safe: Konva.Group; shadow: Konva.Rect } | null>(null)
  const [size, setSize] = useState({ w: 800, h: 600 })
  sizeRef.current = size
  const [editing, setEditing] = useState<El | null>(null)
  const editingRef = useRef(false); editingRef.current = !!editing
  const [selBox, setSelBox] = useState<{ x: number; y: number; width: number; height: number } | null>(null)
  const [moving, setMoving] = useState(false)
  const [badge, setBadge] = useState<{ x: number; y: number; text: string } | null>(null)
  const offsetRef = useRef({ x: PAD, y: PAD })

  const frame = useEditor((s) => s.doc.frames.find((f) => f.id === s.activeFrameId) || s.doc.frames[0])
  const zoom = useEditor((s) => s.zoom)
  const selectedIds = useEditor((s) => s.selectedIds)
  const playing = useEditor((s) => s.playing)
  const time = useEditor((s) => s.time)
  const peers = useEditor((s) => s.peers)
  const agents = useEditor((s) => s.agents)
  const commentMode = useComments((s) => s.mode)

  // container meten
  useLayoutEffect(() => {
    const el = wrapRef.current!
    // Klapt een zijpaneel in of uit, dan springt de layout één keer; het ontwerp glijdt met een transform naar het nieuwe midden
    // en het canvas tekent pas opnieuw als de beweging klaar is. Daarna zoomt het vloeiend naar de nieuwe passende maat (FLIP).
    let raf = 0, settle = 0
    const commit = () => {
      const host = hostRef.current
      if (host) { host.style.transition = 'none'; host.style.translate = ''; host.style.willChange = '' }
      el.style.overflow = ''
      flipRef.current = performance.now() + 400
      setSize((s) => (s.w === el.clientWidth && s.h === el.clientHeight ? s : { w: el.clientWidth, h: el.clientHeight }))
    }
    const onResize = () => {
      cancelAnimationFrame(raf)
      raf = requestAnimationFrame(() => {
        const until = useEditor.getState().motionUntil
        const host = hostRef.current
        if (host && performance.now() < until) {
          const dx = (el.clientWidth - sizeRef.current.w) / 2
          el.style.overflow = 'hidden'
          host.style.willChange = 'translate'
          host.style.transition = `translate ${Math.max(120, until - performance.now() - 40)}ms var(--ease-drawer)`
          host.style.translate = `${dx}px 0`
          clearTimeout(settle)
          settle = window.setTimeout(commit, Math.max(0, until - performance.now()) + 16)
          return
        }
        setSize((s) => (s.w === el.clientWidth && s.h === el.clientHeight ? s : { w: el.clientWidth, h: el.clientHeight }))
      })
    }
    const ro = new ResizeObserver(onResize)
    ro.observe(el)
    setSize({ w: el.clientWidth, h: el.clientHeight })
    return () => { ro.disconnect(); cancelAnimationFrame(raf); clearTimeout(settle) }
  }, [])

  // passende zoom bij wisselen van formaat
  const fid = frame?.id
  useEffect(() => {
    if (!frame) return
    const fit = Math.min((size.w - PAD * 2) / frame.w, (size.h - PAD * 2) / frame.h)
    useEditor.setState({ fitZoom: fit, zoom: Math.max(0.05, Math.min(fit, 4)) })
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [fid, frame?.w, frame?.h, size.w, size.h])

  // stage opbouwen (eenmalig)
  useEffect(() => {
    const stage = new Konva.Stage({ container: hostRef.current!, width: 800, height: 600 })
    const main = new Konva.Layer()
    const ui = new Konva.Layer()
    stage.add(main, ui)
    const shadow = new Konva.Rect({ fill: '#fff', shadowColor: '#1B213B', shadowBlur: 24, shadowOpacity: 0.12, shadowOffsetY: 6, listening: false })
    main.add(shadow)
    const renderer = new FrameRenderer(main, {
      interactive: true,
      onMeasure: (id, h) => useEditor.getState().updateEls([id], { height: h }, { history: false }),
    })
    const tr = new Konva.Transformer({
      rotationSnaps: [0, 45, 90, 135, 180, 225, 270, 315], rotationSnapTolerance: 4,
      anchorSize: 10, anchorCornerRadius: 5, anchorStroke: '#1A5FC4', anchorFill: '#fff', borderStroke: '#1A5FC4', borderStrokeWidth: 1.5,
      rotateAnchorOffset: 30, padding: 0, ignoreStroke: true, flipEnabled: false,
      anchorStyleFunc: (a: Konva.Rect) => {
        const coarse = window.matchMedia?.('(pointer: coarse)').matches ? 1.45 : 1
        const n = a.name()
        a.shadowColor('#1B213B'); a.shadowBlur(4); a.shadowOpacity(0.25); a.shadowOffsetY(1)
        a.stroke('#1A5FC4'); a.strokeWidth(1.5); a.fill('#FFFFFF')
        if (n.includes('rotater')) { const s = 16 * coarse; a.size({ width: s, height: s }); a.offset({ x: s / 2, y: s / 2 }); a.cornerRadius(s / 2); a.fill('#1A5FC4'); a.stroke('#FFFFFF'); a.strokeWidth(2) }
        else if (n.includes('middle-left') || n.includes('middle-right')) { const w = 7 * coarse, h = 20 * coarse; a.size({ width: w, height: h }); a.offset({ x: w / 2, y: h / 2 }); a.cornerRadius(w / 2) }
        else if (n.includes('top-center') || n.includes('bottom-center')) { const w = 20 * coarse, h = 7 * coarse; a.size({ width: w, height: h }); a.offset({ x: w / 2, y: h / 2 }); a.cornerRadius(h / 2) }
        else { const s = 12 * coarse; a.size({ width: s, height: s }); a.offset({ x: s / 2, y: s / 2 }); a.cornerRadius(s / 2) }
      },
    })
    const hover = new Konva.Rect({ stroke: '#1A5FC4', strokeWidth: 1.5, listening: false, visible: false })
    hoverRef.current = hover
    const guides = new Konva.Group({ listening: false })
    const peersG = new Konva.Group({ listening: false })
    const safe = new Konva.Group({ listening: false })
    const marquee = new Konva.Rect({ fill: 'rgba(91,63,217,0.08)', stroke: '#1A5FC4', strokeWidth: 1, visible: false, listening: false })
    ui.add(safe, peersG, hover, tr, guides, marquee)
    stageRef.current = stage
    rendererRef.current = renderer
    uiRef.current = { layer: ui, tr, guides, marquee, peers: peersG, safe, shadow }

    const findGroup = (n: Konva.Node | null): Konva.Group | null => {
      while (n && n !== stage) { if (n.name() === 'el') return n as Konva.Group; n = n.getParent() }
      return null
    }
    const elOf = (g: Konva.Group) => g.getAttr('el') as El
    // omlijning bij aanwijzen, zoals in Canva
    stage.on('mouseover', (e) => {
      const g = findGroup(e.target)
      if (!g || useEditor.getState().selectedIds.includes(g.id()) || useEditor.getState().playing || editingRef.current) { hover.visible(false); ui.batchDraw(); return }
      let r = g.getClientRect({ skipShadow: true, skipStroke: true })
      // bij een groep: omlijning om de hele groep (tenzij je al in de groep zit)
      const gid = elOf(g).groupId, sel = useEditor.getState().selectedIds
      if (gid && !sel.some((x) => renderer.nodes.get(x) && elOf(renderer.nodes.get(x)!).groupId === gid)) {
        const rs = [...renderer.nodes.values()].filter((n) => elOf(n).groupId === gid).map((n) => n.getClientRect({ skipShadow: true, skipStroke: true }))
        const x0 = Math.min(...rs.map((q) => q.x)), y0 = Math.min(...rs.map((q) => q.y))
        r = { x: x0, y: y0, width: Math.max(...rs.map((q) => q.x + q.width)) - x0, height: Math.max(...rs.map((q) => q.y + q.height)) - y0 }
        hover.dash([5, 4])
      } else hover.dash([])
      hover.setAttrs({ ...r, visible: true }); ui.batchDraw()
      stage.container().style.cursor = (elOf(g).locked ? 'default' : 'move')
    })
    stage.on('mouseout', (e) => { if (findGroup(e.target)) { hover.visible(false); ui.batchDraw(); stage.container().style.cursor = '' } })
    const toFrame = (p: { x: number; y: number }) => {
      const z = useEditor.getState().zoom
      return { x: (p.x - offsetRef.current.x) / z, y: (p.y - offsetRef.current.y) / z }
    }
    canvasApi.clientToFrame = (cx, cy) => {
      const r = stage.container().getBoundingClientRect()
      if (cx < r.left || cy < r.top || cx > r.right || cy > r.bottom) return null
      return toFrame({ x: cx - r.left, y: cy - r.top })
    }
    canvasApi.frameToClient = (x, y) => {
      const r = stage.container().getBoundingClientRect(), z = useEditor.getState().zoom
      return { x: r.left + offsetRef.current.x + x * z, y: r.top + offsetRef.current.y + y * z }
    }

    // selectie
    let marqueeStart: { x: number; y: number } | null = null
    stage.on('mousedown touchstart', (e) => {
      if (useEditor.getState().playing) return
      { const cs = useComments.getState(); if (cs.active || cs.draft) useComments.setState({ active: null, draft: null }) }
      if (e.target.getParent()?.className === 'Transformer') return
      const g = findGroup(e.target)
      const st = useEditor.getState()
      if (g) {
        const id = g.id()
        const ev = e.evt as MouseEvent
        const f = st.frame(), el = f.elements.find((x) => x.id === id)
        const unit = el?.groupId ? f.elements.filter((x) => x.groupId === el.groupId).map((x) => x.id) : [id]
        // in een groep "gestapt" (één lid geselecteerd): andere leden los aanklikken
        const inside = !!el?.groupId && st.selectedIds.length > 0 && st.selectedIds.length < unit.length && st.selectedIds.every((x) => unit.includes(x))
        if (ev.ctrlKey || ev.metaKey || inside) { if (!(ev.shiftKey)) { if (!st.selectedIds.includes(id) || st.selectedIds.length !== 1) st.select([id]) } else st.select(st.selectedIds.includes(id) ? st.selectedIds.filter((x) => x !== id) : [...st.selectedIds, id]); return }
        if (ev.shiftKey) st.select(unit.every((x) => st.selectedIds.includes(x)) ? st.selectedIds.filter((x) => !unit.includes(x)) : [...new Set([...st.selectedIds, ...unit])])
        else if (!st.selectedIds.includes(id)) st.select(unit)
        return
      }
      if (!(e.evt as MouseEvent).shiftKey) st.select([])
      const p = stage.getPointerPosition()!
      marqueeStart = p
      marquee.setAttrs({ x: p.x, y: p.y, width: 0, height: 0, visible: true })
    })
    stage.on('mousemove touchmove', () => {
      const p = stage.getPointerPosition()
      if (p) sendCursor(toFrame(p))
      if (!marqueeStart || !p) return
      marquee.setAttrs({ x: Math.min(p.x, marqueeStart.x), y: Math.min(p.y, marqueeStart.y), width: Math.abs(p.x - marqueeStart.x), height: Math.abs(p.y - marqueeStart.y) })
      ui.batchDraw()
    })
    stage.on('mouseleave', () => sendCursor(null))
    stage.on('mouseup touchend', () => {
      if (!marqueeStart) return
      const box = marquee.getClientRect()
      marquee.visible(false)
      marqueeStart = null
      if (box.width > 4 && box.height > 4) {
        const ids: string[] = []
        renderer.nodes.forEach((g, id) => {
          const el = elOf(g)
          if (el.locked || !el.visible) return
          if (Konva.Util.haveIntersection(box, g.getClientRect())) ids.push(id)
        })
        useEditor.getState().select(expandToGroups(useEditor.getState().frame(), ids))
      }
      ui.batchDraw()
    })

    // slepen met hulplijnen
    let dragStart: Record<string, { x: number; y: number }> = {}
    stage.on('dragstart', (e) => {
      const g = findGroup(e.target)
      if (!g) return
      hover.visible(false); setMoving(true)
      dragStart = {}
      const st = useEditor.getState()
      for (const id of st.selectedIds) { const n = renderer.nodes.get(id); if (n) dragStart[id] = { x: n.x(), y: n.y() } }
      dragStart[g.id()] = { x: g.x(), y: g.y() }
    })
    stage.on('dragmove', (e) => {
      const g = findGroup(e.target)
      if (!g || e.target !== g) return
      const el = elOf(g)
      const f = renderer.frame!
      const z = useEditor.getState().zoom
      const thr = 6 / z
      const h = g.getAttr('h') ?? el.height
      const w = el.width
      const xs = [0, f.w / 2, f.w], ys = [0, f.h / 2, f.h]
      const sel = useEditor.getState().selectedIds
      for (const o of f.elements) {
        if (o.id === el.id || sel.includes(o.id) || !o.visible) continue
        const on = renderer.nodes.get(o.id)
        const oh = on?.getAttr('h') ?? o.height
        xs.push(o.x, o.x + o.width / 2, o.x + o.width)
        ys.push(o.y, o.y + oh / 2, o.y + oh)
      }
      const lines: { v: boolean; p: number }[] = []
      let cx = g.x(), cy = g.y()
      const snap = (vals: number[], edges: number[]) => {
        let best: { d: number; delta: number; p: number } | null = null
        for (const v of vals) for (const ed of edges) { const d = Math.abs(v - ed); if (d < thr && (!best || d < best.d)) best = { d, delta: v - ed, p: v } }
        return best
      }
      const sx = snap(xs, [cx - w / 2, cx, cx + w / 2])
      if (sx) { cx += sx.delta; lines.push({ v: true, p: sx.p }) }
      const sy = snap(ys, [cy - h / 2, cy, cy + h / 2])
      if (sy) { cy += sy.delta; lines.push({ v: false, p: sy.p }) }
      g.position({ x: cx, y: cy })
      // andere geselecteerde elementen meeschuiven
      const start = dragStart[g.id()]
      const dx = cx - (start?.x ?? cx), dy = cy - (start?.y ?? cy)
      const live: { id: string; x: number; y: number; rotation: number }[] = []
      for (const id of sel) {
        const n = renderer.nodes.get(id)
        if (!n) continue
        if (n !== g && dragStart[id]) n.position({ x: dragStart[id].x + dx, y: dragStart[id].y + dy })
        const ee = elOf(n)
        live.push({ id, x: n.x() - ee.width / 2, y: n.y() - (n.getAttr('h') ?? ee.height) / 2, rotation: n.rotation() })
      }
      if (!sel.includes(g.id())) live.push({ id: g.id(), x: cx - w / 2, y: cy - h / 2, rotation: g.rotation() })
      sendLive(live)
      guides.destroyChildren()
      const o = offsetRef.current
      for (const l of lines) {
        guides.add(new Konva.Line({
          points: l.v ? [o.x + l.p * z, 0, o.x + l.p * z, stage.height()] : [0, o.y + l.p * z, stage.width(), o.y + l.p * z],
          stroke: '#E0337A', strokeWidth: 1, dash: [4, 4],
        }))
      }
      ui.batchDraw()
    })
    stage.on('dragend', (e) => {
      const g = findGroup(e.target)
      setMoving(false)
      guides.destroyChildren(); ui.batchDraw()
      if (!g) return
      const st = useEditor.getState()
      const ids = st.selectedIds.includes(g.id()) ? st.selectedIds : [g.id()]
      const pos: Record<string, { x: number; y: number }> = {}
      for (const id of ids) {
        const n = renderer.nodes.get(id)
        if (!n) continue
        const el = elOf(n)
        pos[id] = { x: Math.round((n.x() - el.width / 2) * 10) / 10, y: Math.round((n.y() - (n.getAttr('h') ?? el.height) / 2) * 10) / 10 }
      }
      st.updateEls(ids, (el) => pos[el.id] || {})
    })

    // transformeren
    tr.on('transformstart', () => { setMoving(true); hover.visible(false) })
    tr.on('transform', () => {
      // maat of hoek live tonen bij de cursor
      const p = stage.getPointerPosition(), n0 = tr.nodes()[0]
      if (p && n0) {
        const e0 = elOf(n0 as Konva.Group), rot = tr.getActiveAnchor() === 'rotater'
        const w = (n0.getAttr('liveW') ?? e0.width) * n0.scaleX(), h = (n0.getAttr('h') ?? e0.height) * n0.scaleY()
        setBadge({ x: p.x + 18, y: p.y + 18, text: rot ? `${Math.round(((n0.rotation() % 360) + 360) % 360)}°` : `${Math.round(w)} × ${Math.round(h)}` })
      }
      for (const n of tr.nodes()) {
        const el = elOf(n as Konva.Group)
        if (el.type !== 'text') continue
        const anchor = tr.getActiveAnchor()
        if (anchor === 'middle-left' || anchor === 'middle-right') {
          const t = (n as Konva.Group).findOne('.shape')
          const cur = n.getAttr('liveW') ?? el.width
          const nw = Math.max(20, cur * n.scaleX())
          if (t instanceof Konva.Text) t.width(nw)
          else rendererRef.current?.previewText(n as Konva.Group, { ...el, width: nw })
          n.scaleX(1); n.scaleY(1)
          n.offsetX(nw / 2)
          n.setAttr('liveW', nw)
        }
      }
      // collega's zien het schalen en draaien live mee
      const items: LiveItem[] = tr.nodes().map((n) => {
        const el = elOf(n as Konva.Group)
        const h = (n.getAttr('h') ?? el.height)
        const w = (n.getAttr('liveW') ?? el.width) * n.scaleX(), hh = h * n.scaleY()
        return { id: el.id, x: n.x() - w / 2, y: n.y() - hh / 2, width: w, height: hh, rotation: n.rotation() }
      })
      sendLive(items)
    })
    tr.on('transformend', () => {
      setMoving(false); setBadge(null)
      const st = useEditor.getState()
      const anchor = tr.getActiveAnchor() || ''
      const patches: Record<string, Partial<El>> = {}
      for (const n of tr.nodes()) {
        const el = elOf(n as Konva.Group)
        const sx = n.scaleX(), sy = n.scaleY()
        const p: Partial<El> = { rotation: Math.round(n.rotation() * 10) / 10 }
        if (el.type === 'text') {
          const liveW = n.getAttr('liveW')
          if (liveW) { p.width = Math.round(liveW * 10) / 10; n.setAttr('liveW', null) }
          else if (Math.abs(sx - 1) > 0.001 || Math.abs(sy - 1) > 0.001) {
            p.width = el.width * sx
            if (!anchor.startsWith('middle')) p.fontSize = Math.max(4, Math.round((el.fontSize || 24) * sy * 10) / 10)
          }
          const w = p.width ?? el.width
          const h = (n.getAttr('h') ?? el.height) * (p.fontSize ? sy : 1)
          p.x = n.x() - w / 2; p.y = n.y() - h / 2
          if (liveW) p.y = el.y // alleen breder of smaller: bovenkant blijft staan
          if (p.fontSize) p.height = h
        } else {
          p.width = Math.max(1, el.width * sx)
          p.height = Math.max(1, el.height * sy)
          p.x = n.x() - p.width / 2
          p.y = n.y() - p.height / 2
        }
        n.scaleX(1); n.scaleY(1)
        patches[el.id] = p
      }
      st.updateEls(Object.keys(patches), (e) => patches[e.id])
    })

    // dubbelklik op tekst = bewerken
    stage.on('dblclick dbltap', (e) => {
      const g = findGroup(e.target)
      if (!g) return
      const el = elOf(g)
      const st = useEditor.getState()
      // dubbelklik op een groep: één element eruit selecteren
      if (el.groupId && st.selectedIds.length > 1 && st.selectedIds.includes(el.id)) { st.select([el.id]); return }
      if (el.type === 'text' && !el.locked) setEditing(el)
    })

    // ctrl + scroll = zoomen
    stage.on('wheel', (e) => {
      if (!e.evt.ctrlKey && !e.evt.metaKey) return
      e.evt.preventDefault()
      const st = useEditor.getState()
      st.setZoom(st.zoom * (e.evt.deltaY > 0 ? 0.9 : 1.1))
    })

    // live bewegingen van collega's (slepen, schalen, draaien) vloeiend tonen
    onLive((frameId, items, duration) => {
      if (frameId !== useEditor.getState().activeFrameId) return
      for (const it of items) {
        const g = renderer.nodes.get(it.id)
        if (!g) continue
        const el = elOf(g)
        const h = g.getAttr('h') ?? el.height
        const w = it.width ?? el.width, hh = it.height ?? h
        g.to({ x: it.x + w / 2, y: it.y + hh / 2, rotation: it.rotation, scaleX: w / el.width, scaleY: hh / h, duration: duration ?? 0.06, easing: duration ? Konva.Easings.EaseInOut : Konva.Easings.Linear, onFinish: drawOverlays })
      }
    })

    return () => { onLive(null); stage.destroy(); stageRef.current = null; rendererRef.current = null }
  }, [])

  // afmetingen en positie
  const fw = frame ? frame.w * zoom : 0, fh = frame ? frame.h * zoom : 0
  const stageW = Math.max(size.w, fw + PAD * 2), stageH = Math.max(size.h, fh + PAD * 2)
  const ox = Math.round((stageW - fw) / 2), oy = Math.round((stageH - fh) / 2)
  offsetRef.current = { x: ox, y: oy }

  useEffect(() => {
    const stage = stageRef.current, r = rendererRef.current, ui = uiRef.current
    if (!stage || !r || !ui || !frame) return
    stage.size({ width: stageW, height: stageH })
    // vloeiende zoom na het in- of uitklappen van een paneel (FLIP: start op de oude schaal, glijd naar de nieuwe)
    const host = hostRef.current
    if (host && performance.now() < flipRef.current && lastZoomRef.current && lastZoomRef.current !== zoom) {
      const k = lastZoomRef.current / zoom
      host.style.transition = 'none'
      host.style.transformOrigin = `${ox + fw / 2}px ${oy + fh / 2}px`
      host.style.transform = `scale(${k})`
      void host.offsetWidth
      host.style.transition = 'transform 300ms var(--ease-drawer)'
      host.style.transform = ''
      flipRef.current = 0
    }
    lastZoomRef.current = zoom
    r.root.position({ x: ox, y: oy })
    r.root.scale({ x: zoom, y: zoom })
    ui.shadow.setAttrs({ x: ox, y: oy, width: fw, height: fh })
    drawOverlays()
    stage.batchDraw()
    updateTransformer()
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [stageW, stageH, ox, oy, zoom, frame?.w, frame?.h])

  // inhoud synchroniseren
  useEffect(() => {
    const r = rendererRef.current
    if (!r || !frame) return
    r.sync(frame)
    const t = useEditor.getState().time
    r.applyTime(t)
    updateTransformer()
    drawOverlays()
    r.root.getLayer()?.batchDraw()
    const fams = frame.elements.filter((e) => e.type === 'text').map((e) => e.fontFamily || 'Poppins')
    loadFontsForDoc(fams).then(() => {
      if (rendererRef.current !== r || !r.frame) return
      let need = false
      r.nodes.forEach((g) => { const el = g.getAttr('el') as El; if (el?.type === 'text' && !g.getAttr('fontOk')) { g.setAttr('json', ''); g.setAttr('fontOk', true); need = true } })
      if (need) { r.sync(r.frame); r.applyTime(useEditor.getState().time); updateTransformer() }
    })
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [frame])

  useEffect(() => {
    rendererRef.current?.setPeerLocked(new Set(Object.keys(useEditor.getState().lockedBy())))
    updateTransformer(); drawOverlays()
  }, [selectedIds, playing, time, peers, agents]) // eslint-disable-line react-hooks/exhaustive-deps

  // afspelen
  useEffect(() => {
    if (!playing || !frame) return
    let raf = 0
    const start = performance.now() - (useEditor.getState().time || 0) * 1000
    const tick = () => {
      let t = (performance.now() - start) / 1000
      if (t > frame.duration) { useEditor.setState({ playing: false, time: null }); rendererRef.current?.applyTime(null); return }
      rendererRef.current?.applyTime(t)
      if (Math.floor(t * 10) !== Math.floor((useEditor.getState().time || 0) * 10)) useEditor.setState({ time: t })
      t = 0
      raf = requestAnimationFrame(tick)
    }
    raf = requestAnimationFrame(tick)
    return () => cancelAnimationFrame(raf)
  }, [playing, frame?.id]) // eslint-disable-line react-hooks/exhaustive-deps

  useEffect(() => { if (!playing) rendererRef.current?.applyTime(time) }, [time, playing])

  function updateTransformer() {
    const r = rendererRef.current, ui = uiRef.current
    if (!r || !ui) return
    const st = useEditor.getState()
    const nodes = st.playing || st.time !== null || editing ? [] : st.selectedIds.map((id) => r.nodes.get(id)).filter((n): n is Konva.Group => !!n && !(n.getAttr('el') as El).locked && (n.getAttr('el') as El).visible)
    ui.tr.nodes(nodes)
    const textOnly = nodes.length === 1 && (nodes[0].getAttr('el') as El).type === 'text'
    ui.tr.enabledAnchors(textOnly ? ['top-left', 'top-right', 'bottom-left', 'bottom-right', 'middle-left', 'middle-right'] : ['top-left', 'top-center', 'top-right', 'middle-left', 'middle-right', 'bottom-left', 'bottom-center', 'bottom-right'])
    ui.tr.keepRatio(textOnly || (nodes.length === 1 && ['image', 'icon'].includes((nodes[0].getAttr('el') as El).type)))
    // vergrendelde selectie tonen met stippellijn
    ui.layer.batchDraw()
    if (nodes.length) { const r = ui.tr.getClientRect(); setSelBox({ x: r.x, y: r.y, width: r.width, height: r.height }) }
    else if (st.selectedIds.length && !st.playing && st.time === null) {
      // vergrendeld element: werkbalk wel tonen om te ontgrendelen
      const n = r.nodes.get(st.selectedIds[0]); setSelBox(n ? n.getClientRect() : null)
    } else setSelBox(null)
  }

  function drawOverlays() {
    const r = rendererRef.current, ui = uiRef.current, f = r?.frame
    if (!r || !ui || !f) return
    const z = useEditor.getState().zoom
    const o = offsetRef.current
    ui.safe.destroyChildren()
    if (f.safeZone) {
      const top = f.h * 0.14, bottom = f.h * 0.2
      for (const [y, h, label] of [[0, top, 'Veilige zone: profiel en balk'], [f.h - bottom, bottom, 'Veilige zone: knoppen en tekst']] as const) {
        ui.safe.add(new Konva.Rect({ x: o.x, y: o.y + y * z, width: f.w * z, height: h * z, fill: 'rgba(224,51,122,0.08)', stroke: 'rgba(224,51,122,0.5)', dash: [6, 4], strokeWidth: 1 }))
        ui.safe.add(new Konva.Text({ x: o.x + 8, y: o.y + y * z + 6, text: label, fontSize: 11, fontFamily: 'Poppins', fill: '#E0337A', fontStyle: '600' }))
      }
    }
    ui.peers.destroyChildren()
    const st = useEditor.getState()
    for (const p of [...Object.values(st.peers), ...Object.values(st.agents)]) {
      if (p.frameId !== f.id || !p.selection?.length) continue
      for (const id of p.selection) {
        const n = r.nodes.get(id)
        if (!n) continue
        const box = n.getClientRect({ relativeTo: ui.layer as unknown as Konva.Container })
        ui.peers.add(new Konva.Rect({ ...box, stroke: p.color, strokeWidth: 2, cornerRadius: 2 }))
        const label = new Konva.Label({ x: box.x - 1, y: box.y - 22 })
        label.add(new Konva.Tag({ fill: p.color, cornerRadius: [4, 4, 4, 0] }))
        label.add(new Konva.Text({ text: p.name.split(' ')[0] + ' bewerkt', fontSize: 11, padding: 5, fill: '#fff', fontFamily: 'Poppins', fontStyle: '600' }))
        ui.peers.add(label)
      }
    }
    // vergrendelde selectie
    for (const id of st.selectedIds) {
      const n = r.nodes.get(id)
      const el = n?.getAttr('el') as El | undefined
      if (n && el?.locked) ui.peers.add(new Konva.Rect({ ...n.getClientRect(), stroke: '#6B6880', strokeWidth: 1.5, dash: [4, 3] }))
    }
    ui.layer.batchDraw()
  }

  // tekstbewerking
  // De echte canvastekst blijft zichtbaar en wordt tijdens het typen live bijgewerkt (zonder geschiedenis),
  // zodat je precies ziet hoe het eruitziet. Bij afronden komt er één stap in ongedaan maken bij.
  const liveText = (v: { text: string; runs?: El['runs'] }) => { if (editing) useEditor.getState().updateEls([editing.id], { text: v.text, runs: v.runs }, { history: false }) }
  const commitText = (v: { text: string; runs?: El['runs'] }) => {
    if (!editing) return
    const st = useEditor.getState()
    const changed = v.text !== (editing.text || '') || JSON.stringify(v.runs || null) !== JSON.stringify(editing.runs || null)
    if (changed) {
      // één stap in ongedaan maken, gerekend vanaf de tekst vóór het bewerken; collega's zien geen terugspringer
      const base = structuredClone(st.doc)
      for (const f of base.frames) f.elements = f.elements.map((e) => (e.id === editing.id ? { ...e, text: editing.text, runs: editing.runs } : e))
      for (const f of base.frames) for (const e of f.elements) if (e.id === editing.id && !e.runs) delete e.runs
      st.updateEls([editing.id], { text: v.text, runs: v.runs }, { historyFrom: base })
    }
    setEditing(null)
  }
  useEffect(() => { if (editing) { hoverRef.current?.visible(false); hoverRef.current?.getLayer()?.batchDraw(); updateTransformer() } }, [editing]) // eslint-disable-line react-hooks/exhaustive-deps
  /** Werkelijke grootte en lettergrootte van de tekst op het canvas (na automatisch verkleinen). */
  const textBox = (id: string) => {
    const g = rendererRef.current?.nodes.get(id)
    return { h: (g?.getAttr('h') as number) || 0, fontSize: (g?.getAttr('fs') as number) || 0 }
  }

  const peerCursors = [...Object.entries(peers), ...Object.entries(agents)].filter(([, p]) => p.cursor && p.frameId === frame?.id)

  return (
    <div ref={wrapRef} className="relative min-h-0 flex-1 overflow-auto bg-sunk" onDragOver={(e) => e.preventDefault()}>
      <div ref={hostRef} style={{ width: stageW, height: stageH }} />
      {editing && frame && <RichTextEditor el={editing} zoom={zoom} ox={ox} oy={oy} onDone={commitText} onLive={liveText} measure={() => textBox(editing.id)} />}
      <Cursors peers={peerCursors} ox={ox} oy={oy} zoom={zoom} />
      {frame && !playing && <CommentLayer frame={frame} ox={ox} oy={oy} zoom={zoom} stageW={stageW} stageH={stageH} />}
      {selBox && !moving && !editing && !playing && !commentMode && <SelectionToolbar box={selBox} onEdit={() => { const st = useEditor.getState(); const el = st.frame().elements.find((e) => e.id === st.selectedIds[0]); if (el?.type === 'text' && !el.locked) setEditing(el) }} />}
      {badge && <div className="pointer-events-none absolute z-40 rounded-md bg-navy px-2 py-1 text-[11px] font-semibold tabular-nums text-white shadow-pop" style={{ left: badge.x, top: badge.y }}>{badge.text}</div>}
    </div>
  )
}

