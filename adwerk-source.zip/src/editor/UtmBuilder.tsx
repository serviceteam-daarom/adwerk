import { useEffect, useState } from 'react'
import { Check, ChevronDown, Copy, Link2, Wand2 } from 'lucide-react'
import { useEditor } from '../store/editor'
import { UTM_PRESETS, SOURCES, MEDIUMS, buildUtmUrl, slugify, type Utm } from '../lib/utm'
import type { Brief } from '../lib/types'
import { Combobox } from '../ui/Combobox'
import { Input, Tip, cn } from '../ui/ui'
import { editBrief } from './BriefPanel'

const ID = 'p-utm'
const FIELDS: { key: keyof Utm; label: string; help: string }[] = [
  { key: 'utm_source', label: 'Bron', help: 'Waar komt de bezoeker vandaan (facebook, linkedin)' },
  { key: 'utm_medium', label: 'Medium', help: 'Soort verkeer (paid_social, social, cpc)' },
  { key: 'utm_campaign', label: 'Campagne', help: 'Naam van de campagne' },
  { key: 'utm_content', label: 'Inhoud', help: 'Welke advertentie of variant' },
  { key: 'utm_term', label: 'Term', help: 'Optioneel, bijv. de doelgroep' },
]

/** UTM-link bouwen bij de landingspagina; het resultaat staat als intern veld "Tracking-link" in de brief. */
export function UtmBuilder({ brief, landing }: { brief: Brief; landing: string }) {
  const title = useEditor((s) => s.design?.title || '')
  const field = brief.fields.find((f) => f.id === ID || f.preset === 'utm')
  const utm: Utm = field?.utm || {}
  const [open, setOpen] = useState(false)
  const [copied, setCopied] = useState(false)
  const url = buildUtmUrl(landing, utm)
  const write = (next: Utm) => editBrief((b) => {
    let f = b.fields.find((x) => x.id === ID || x.preset === 'utm')
    if (!f) {
      f = { id: ID, label: 'Tracking-link', kind: 'url', value: '', preset: 'utm', hidden: true }
      const i = b.fields.findIndex((x) => x.preset === 'landing')
      b.fields.splice(i >= 0 ? i + 1 : b.fields.length, 0, f)
    }
    f.utm = next
    f.value = buildUtmUrl(landing, next)
  })
  // landingspagina gewijzigd: tracking-link meenemen
  useEffect(() => {
    if (!field?.utm) return
    const t = setTimeout(() => { if (field.value !== url && url) editBrief((b) => { const f = b.fields.find((x) => x.id === field.id); if (f) f.value = url }) }, 400)
    return () => clearTimeout(t)
  }, [url]) // eslint-disable-line react-hooks/exhaustive-deps
  const set = (k: keyof Utm, v: string) => write({ ...utm, [k]: v })
  const preset = (p: (typeof UTM_PRESETS)[number]) => write({ utm_campaign: utm.utm_campaign || slugify(title), ...utm, ...p.utm, ...(p.key === 'meta-dyn' ? {} : { utm_campaign: utm.utm_campaign && !utm.utm_campaign.startsWith('{{') ? utm.utm_campaign : slugify(title) }) })
  const copy = async () => { try { await navigator.clipboard.writeText(url); setCopied(true); setTimeout(() => setCopied(false), 1400) } catch { /* */ } }
  if (!landing.trim()) return null
  return (
    <div className="grid min-w-0 grid-cols-[minmax(0,1fr)] gap-2">
      <button onClick={() => { setOpen(!open); if (!field) preset(UTM_PRESETS[0]) }} className="flex w-fit items-center gap-1.5 rounded-md px-1.5 py-1 text-xs font-semibold text-violet hover:bg-violet-soft/50">
        <Link2 size={13} /> {field ? 'UTM-link aanpassen' : 'UTM-link maken'} <ChevronDown size={13} className={cn('transition-transform duration-200', open && 'rotate-180')} />
      </button>
      {field && url && !open && (
        <div className="flex items-center gap-1.5 rounded-lg bg-sunk px-2.5 py-1.5"><code className="min-w-0 flex-1 truncate text-[11px] text-muted">{url}</code><Tip label="Kopiëren"><button onClick={copy} className="grid h-6 w-6 place-items-center rounded text-muted hover:text-ink" aria-label="UTM-link kopiëren">{copied ? <Check size={13} className="text-mint" /> : <Copy size={13} />}</button></Tip></div>
      )}
      {open && (
        <div className="anim-rise grid min-w-0 grid-cols-[minmax(0,1fr)] gap-3 rounded-xl border border-line p-3">
          <div className="grid min-w-0 grid-cols-[minmax(0,1fr)] gap-1.5">
            <span className="flex items-center gap-1.5 text-[11px] font-bold uppercase tracking-[0.08em] text-muted"><Wand2 size={12} /> Snel invullen</span>
            <div className="grid min-w-0 grid-cols-2 gap-1">
              {UTM_PRESETS.map((p) => <Tip key={p.key} label={p.hint}><button onClick={() => preset(p)} className="truncate rounded-lg border border-line px-2 py-1.5 text-left text-xs font-medium transition hover:border-ink/30 hover:bg-sunk">{p.label}</button></Tip>)}
            </div>
          </div>
          {FIELDS.map((f) => (
            <label key={f.key} className="grid min-w-0 grid-cols-[minmax(0,1fr)] gap-1">
              <span className="flex items-baseline justify-between gap-2"><span className="text-xs font-semibold">{f.label}</span><code className="text-[10px] text-muted">{f.key}</code></span>
              {f.key === 'utm_source' || f.key === 'utm_medium'
                ? <Combobox value={utm[f.key] || ''} onChange={(v) => set(f.key, v)} suggestions={f.key === 'utm_source' ? SOURCES : MEDIUMS} placeholder={f.help} ariaLabel={f.label} />
                : <Input value={utm[f.key] || ''} onChange={(e) => set(f.key, e.target.value)} placeholder={f.key === 'utm_campaign' ? slugify(title) || f.help : f.help} onKeyDown={(e) => e.stopPropagation()} aria-label={f.label} />}
            </label>
          ))}
          <div className="grid min-w-0 grid-cols-[minmax(0,1fr)] gap-1.5">
            <span className="text-[11px] font-bold uppercase tracking-[0.08em] text-muted">Resultaat</span>
            <div className="break-all rounded-lg bg-sunk p-2.5 font-mono text-[11px] leading-relaxed">{url || <span className="text-muted">Vul een geldige landingspagina in</span>}</div>
            <div className="flex items-center gap-2">
              <button onClick={copy} disabled={!url} className="press flex h-8 items-center gap-1.5 rounded-lg bg-navy px-3 text-xs font-semibold text-white disabled:opacity-40">{copied ? <Check size={14} /> : <Copy size={14} />} {copied ? 'Gekopieerd' : 'Kopiëren'}</button>
              <span className="text-[11px] leading-snug text-muted">Opgeslagen als intern veld "Tracking-link". Kleine letters en zonder spaties.</span>
            </div>
          </div>
        </div>
      )}
    </div>
  )
}
