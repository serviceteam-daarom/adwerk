import { Sortable } from '../ui/Sortable'
import { useRef, useState } from 'react'
import { Play, Pause, ChevronUp, ChevronDown, Plus, Group } from 'lucide-react'
import { useEditor } from '../store/editor'
import { cn, IconBtn } from '../ui/ui'
import { PlatformLogo } from '../ui/PlatformLogo'
import type { El } from '../lib/types'
import { defaultAnim } from '../lib/factory'

export function Timeline() {
  const frame = useEditor((s) => s.frame())
  const playing = useEditor((s) => s.playing)
  const time = useEditor((s) => s.time)
  const selectedIds = useEditor((s) => s.selectedIds)
  const [open, setOpen] = useState(false)
  const trackRef = useRef<HTMLDivElement>(null)
  if (!frame) return null
  const D = frame.duration
  const els = [...frame.elements].reverse()
  const pct = (t: number) => `${(t / D) * 100}%`

  const scrub = (clientX: number) => {
    const r = trackRef.current!.getBoundingClientRect()
    const t = Math.max(0, Math.min(D, ((clientX - r.left) / r.width) * D))
    useEditor.setState({ playing: false, time: t })
  }
  const dragBar = (key: { el?: El; gid?: string }, e: React.PointerEvent) => {
    e.stopPropagation()
    const r = trackRef.current!.getBoundingClientRect()
    const startX = e.clientX
    const st = useEditor.getState()
    const a = (key.gid ? frame.groups?.find((g) => g.id === key.gid)?.anim : key.el!.anim) || defaultAnim()
    const startDelay = a.in.delay
    const mv = (ev: PointerEvent) => {
      const dt = ((ev.clientX - startX) / r.width) * D
      const nd = Math.max(0, Math.min(D - 0.1, Math.round((startDelay + dt) * 20) / 20))
      if (key.gid) st.setGroupAnim(key.gid, (cur) => ({ ...(cur || defaultAnim()), in: { ...(cur || defaultAnim()).in, delay: nd } }))
      else useEditor.getState().updateEls([key.el!.id], (x) => ({ anim: { ...(x.anim || defaultAnim()), in: { ...(x.anim || defaultAnim()).in, delay: nd } } }), { history: false })
    }
    const upH = () => { window.removeEventListener('pointermove', mv); window.removeEventListener('pointerup', upH) }
    window.addEventListener('pointermove', mv)
    window.addEventListener('pointerup', upH)
    st.select(key.gid ? frame.elements.filter((x) => x.groupId === key.gid).map((x) => x.id) : [key.el!.id])
  }
  // rijen: een groep krijgt een eigen rij boven zijn onderdelen
  const rows: { key: string; label: string; anim?: El['anim']; el?: El; gid?: string; indent?: boolean }[] = []
  const seenG = new Set<string>()
  for (const el of els) {
    if (el.groupId && !seenG.has(el.groupId)) {
      seenG.add(el.groupId)
      const g = frame.groups?.find((x) => x.id === el.groupId)
      if (g) rows.push({ key: 'g' + g.id, label: g.name, anim: g.anim, gid: g.id })
    }
    rows.push({ key: el.id, label: el.type === 'text' ? el.text || el.name : el.name, anim: el.anim, el, indent: !!el.groupId })
  }

  return (
    <div className="shrink-0 border-t border-line bg-surface">
      <div className="flex items-center gap-2 px-3 py-1.5">
        <IconBtn label={playing ? 'Pauze' : 'Afspelen (spatie)'} onClick={() => (playing ? useEditor.setState({ playing: false }) : useEditor.setState({ playing: true, time: time ?? 0 }))}>
          {playing ? <Pause size={18} /> : <Play size={18} />}
        </IconBtn>
        <span className="w-24 text-xs tabular-nums text-muted">{(time ?? 0).toFixed(1)} / {D.toFixed(1)} s</span>
        {time !== null && !playing && <button className="text-xs font-semibold text-violet hover:underline" onClick={() => useEditor.setState({ time: null })}>Terug naar bewerken</button>}
        <span className="flex-1" />
        <button className="flex items-center gap-1 rounded-md px-2 py-1 text-xs font-semibold text-muted hover:bg-sunk" onClick={() => setOpen(!open)}>{open ? <ChevronDown size={14} /> : <ChevronUp size={14} />} Tijdlijn</button>
      </div>
      {open && (
        <div className="max-h-40 overflow-y-auto px-3 pb-2">
          <div className="grid grid-cols-[130px_1fr] gap-x-3 gap-y-1">
            <div />
            <div ref={trackRef} className="relative h-5 cursor-pointer select-none" onPointerDown={(e) => { scrub(e.clientX); const mv = (ev: PointerEvent) => scrub(ev.clientX); const upH = () => { window.removeEventListener('pointermove', mv); window.removeEventListener('pointerup', upH) }; window.addEventListener('pointermove', mv); window.addEventListener('pointerup', upH) }}>
              {Array.from({ length: Math.floor(D) + 1 }).map((_, i) => (
                <span key={i} className="absolute top-0 text-[10px] tabular-nums text-muted" style={{ left: pct(i), transform: 'translateX(-50%)' }}>{i}s</span>
              ))}
              {time !== null && <span className="absolute bottom-[-200px] top-0 z-10 w-0.5 bg-accent" style={{ left: pct(time) }} />}
            </div>
            {rows.map((row) => {
              const a = row.anim || defaultAnim()
              const ids = row.gid ? frame.elements.filter((x) => x.groupId === row.gid).map((x) => x.id) : [row.el!.id]
              const sel = ids.every((i) => selectedIds.includes(i)) && (row.gid ? true : !(row.el?.groupId && selectedIds.length > 1))
              return (
                <div key={row.key} className="contents">
                  <button onClick={() => useEditor.getState().select(ids)} className={cn('flex min-w-0 items-center gap-1 truncate rounded px-1.5 text-left text-xs', row.indent && 'pl-4', row.gid && 'font-semibold', sel ? 'font-semibold text-accent-fg' : 'text-ink')}>{row.gid && <Group size={12} className="shrink-0 text-violet" />}<span className="truncate">{row.label}</span></button>
                  <div className={cn('relative h-5 rounded bg-sunk', row.gid && 'bg-violet-soft/60')}>
                    {a.in.type !== 'none' && (
                      <span onPointerDown={(e) => dragBar(row.gid ? { gid: row.gid } : { el: row.el }, e)} title="Sleep om de starttijd te wijzigen" className={cn('absolute bottom-0.5 top-0.5 cursor-ew-resize rounded', sel ? 'bg-accent' : row.gid ? 'bg-violet' : 'bg-violet/80')} style={{ left: pct(a.in.delay), width: pct(Math.max(0.05, a.in.duration)) }} />
                    )}
                    {a.emph.type !== 'none' && <span className="absolute bottom-1.5 top-1.5 rounded bg-sun/70" style={{ left: pct(a.in.type !== 'none' ? a.in.delay + a.in.duration : 0), right: 0 }} />}
                    {a.out.type !== 'none' && <span className="absolute bottom-0.5 top-0.5 rounded bg-ink/60" style={{ left: pct(D - a.out.duration - a.out.delay), width: pct(a.out.duration) }} />}
                    {a.in.type === 'none' && a.emph.type === 'none' && a.out.type === 'none' && (
                      <button className="absolute inset-0 flex items-center gap-1 px-2 text-[11px] text-muted opacity-0 hover:opacity-100" onClick={() => { useEditor.getState().select(ids); useEditor.getState().setLeftTab('animate') }}><Plus size={11} /> {row.gid ? 'groepsanimatie' : 'animatie'}</button>
                    )}
                  </div>
                </div>
              )
            })}
          </div>
        </div>
      )}
    </div>
  )
}

/** Volgorde van formaten aanpassen (slepen in de strook onderaan of in het Formaten-paneel). */
export function reorderFrames(ids: string[]) {
  useEditor.getState().mutate((d) => { const m = new Map(d.frames.map((f) => [f.id, f])); d.frames = ids.map((id) => m.get(id)!).filter(Boolean) })
}

export function FormatStrip() {
  const frames = useEditor((s) => s.doc.frames)
  const active = useEditor((s) => s.activeFrameId)
  const peers = useEditor((s) => s.peers)
  return (
    <div className="flex shrink-0 items-end gap-3 overflow-x-auto border-t border-line bg-surface px-3 py-2" role="tablist" aria-label="Formaten">
      <Sortable items={frames} getId={(f) => f.id} axis="x" label="Volgorde van formaten" className="flex items-end gap-3" liftClassName="!rounded-lg"
        onReorder={(ids) => reorderFrames(ids)}
        render={(f) => {
        const s = 36 / Math.max(f.w, f.h)
        const here = Object.values(peers).filter((p) => p.frameId === f.id)
        return (
          <button role="tab" aria-selected={f.id === active} onClick={() => useEditor.getState().setActiveFrame(f.id)} className={cn('relative grid shrink-0 justify-items-center gap-1 rounded-lg px-2 py-1 text-[11px] font-medium', f.id === active ? 'bg-accent-soft text-accent-fg' : 'text-muted hover:bg-sunk')}>
            <span className="grid h-10 place-items-center"><span className={cn('block rounded-[2px] border-[1.5px]', f.id === active ? 'border-accent bg-surface' : 'border-line bg-sunk')} style={{ width: Math.max(6, f.w * s), height: Math.max(6, f.h * s) }} /></span>
            <span className="flex items-center gap-1 tabular-nums"><PlatformLogo platform={f.platform} size={12} />{f.w}×{f.h}</span>
            {here.length > 0 && <span className="absolute right-0.5 top-0.5 flex">{here.slice(0, 3).map((p) => <span key={p.id + p.name} className="-ml-1 h-2.5 w-2.5 rounded-full border border-white" style={{ background: p.color }} />)}</span>}
          </button>
        )
      }} />
      <button className="mb-1 grid h-10 w-10 shrink-0 place-items-center rounded-lg border-2 border-dashed border-line text-muted hover:border-ink hover:text-ink" aria-label="Formaat toevoegen" onClick={() => useEditor.getState().setLeftTab('formats')}><Plus size={16} /></button>
    </div>
  )
}
