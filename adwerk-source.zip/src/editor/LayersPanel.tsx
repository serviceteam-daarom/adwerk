import { useRef, useState } from 'react'
import { Eye, EyeOff, Lock, Unlock, GripVertical, ChevronUp, ChevronDown, ChevronsUp, ChevronsDown, Image as ImageIcon, Group as GroupIcon, Ungroup, Sparkles } from 'lucide-react'
import { useEditor, type Peer } from '../store/editor'
import { iconSvg } from '../lib/icons'
import { colorSvg } from '../lib/iconify'
import type { El } from '../lib/types'
import { Input, cn, Tip } from '../ui/ui'

/** Lagenpaneel: slepen om te ordenen (muis en touch), knoppen voor voor/achter en zien wie welke laag bewerkt. */
export default function LayersPanel() {
  const frame = useEditor((s) => s.frame())
  const selectedIds = useEditor((s) => s.selectedIds)
  const peers = useEditor((s) => s.peers)
  const agents = useEditor((s) => s.agents)
  const [renaming, setRenaming] = useState<string | null>(null)
  const [drag, setDrag] = useState<{ id: string; dy: number; target: number } | null>(null)
  const listRef = useRef<HTMLDivElement>(null)
  const rowsRef = useRef<Map<string, HTMLDivElement>>(new Map())
  const list = [...frame.elements].reverse()
  const st = useEditor.getState

  // wie heeft welke laag geselecteerd
  const byEl = new Map<string, Peer[]>()
  for (const p of [...Object.values(peers), ...Object.values(agents)]) {
    if (p.frameId !== frame.id) continue
    for (const id of p.selection || []) byEl.set(id, [...(byEl.get(id) || []).filter((x) => x.id !== p.id || x.key !== p.key), p])
  }

  const onPointerDown = (ev: React.PointerEvent, el: El, index: number) => {
    if ((ev.target as HTMLElement).closest('button, input')) return
    if (ev.button !== 0) return
    const startY = ev.clientY
    const row = rowsRef.current.get(el.id)
    const rects = list.map((e) => rowsRef.current.get(e.id)!.getBoundingClientRect())
    const rowH = row ? row.getBoundingClientRect().height + 4 : 40
    let moved = false
    const move = (e: PointerEvent) => {
      const dy = e.clientY - startY
      if (!moved && Math.abs(dy) < 5) return
      if (!moved) { moved = true; (ev.target as HTMLElement).setPointerCapture?.(ev.pointerId) }
      const y = e.clientY
      let target = rects.findIndex((r) => y < r.top + r.height / 2)
      if (target < 0) target = rects.length
      // positie in de lijst zonder de gesleepte laag
      const t = target > index ? target - 1 : target
      setDrag({ id: el.id, dy, target: Math.max(0, Math.min(list.length - 1, t)) })
      // automatisch scrollen bij de rand
      const box = listRef.current?.closest('.overflow-y-auto') as HTMLElement | null
      if (box) { const b = box.getBoundingClientRect(); if (y < b.top + 30) box.scrollTop -= 8; else if (y > b.bottom - 30) box.scrollTop += 8 }
      void rowH
    }
    const up = () => {
      window.removeEventListener('pointermove', move)
      window.removeEventListener('pointerup', up)
      setDrag((d) => {
        if (moved && d) {
          const n = list.length
          if (d.target !== index) st().moveTo(d.id, n - 1 - d.target)
        }
        return null
      })
      if (!moved) {
        const s = st()
        if (ev.shiftKey || ev.metaKey) s.select(s.selectedIds.includes(el.id) ? s.selectedIds.filter((x) => x !== el.id) : [...s.selectedIds, el.id])
        else s.select([el.id])
      }
    }
    window.addEventListener('pointermove', move)
    window.addEventListener('pointerup', up)
  }

  const sel = selectedIds.length === 1 ? selectedIds[0] : null
  const selIndex = sel ? frame.elements.findIndex((e) => e.id === sel) : -1
  const arrange = (dir: 'up' | 'down' | 'top' | 'bottom') => { if (sel) st().reorder(sel, dir) }

  return (
    <div>
      <div className="mb-3 flex items-center justify-between">
        <h3 className="font-display text-lg font-semibold">Lagen</h3>
        <span className="text-xs text-muted">{list.length} {list.length === 1 ? 'laag' : 'lagen'}</span>
      </div>
      <div className={cn('mb-3 grid grid-cols-4 gap-1 rounded-xl bg-sunk p-1 transition', !sel && 'opacity-50')} role="toolbar" aria-label="Volgorde van de geselecteerde laag">
        {([
          ['top', 'Helemaal naar voren', <ChevronsUp size={16} key="a" />, selIndex === frame.elements.length - 1],
          ['up', 'Eén naar voren', <ChevronUp size={16} key="b" />, selIndex === frame.elements.length - 1],
          ['down', 'Eén naar achteren', <ChevronDown size={16} key="c" />, selIndex === 0],
          ['bottom', 'Helemaal naar achteren', <ChevronsDown size={16} key="d" />, selIndex === 0],
        ] as const).map(([dir, label, icon, disabled]) => (
          <Tip key={dir} label={label}>
            <button disabled={!sel || disabled} onClick={() => arrange(dir)} aria-label={label} className="grid h-8 place-items-center rounded-lg text-ink transition hover:bg-surface disabled:pointer-events-none disabled:opacity-40">{icon}</button>
          </Tip>
        ))}
      </div>
      {!list.length && <p className="text-sm text-muted">Nog geen lagen. Voeg tekst, vormen of afbeeldingen toe, of sleep ze op het canvas.</p>}
      <p className="mb-2 text-[11px] text-muted">Bovenaan ligt voorop. Sleep een laag om de volgorde te veranderen.</p>
      <div ref={listRef} className="relative grid gap-1" role="list">
        {list.map((e, i) => {
          const isDrag = drag?.id === e.id
          // andere rijen schuiven opzij tijdens het slepen
          let shift = 0
          if (drag && !isDrag) {
            const from = list.findIndex((x) => x.id === drag.id)
            if (from < i && i <= drag.target) shift = -1
            if (from > i && i >= drag.target) shift = 1
          }
          const who = byEl.get(e.id) || []
          const selected = selectedIds.includes(e.id)
          const g = e.groupId ? frame.groups?.find((x) => x.id === e.groupId) : undefined
          const firstOfGroup = !!g && list.findIndex((x) => x.groupId === e.groupId) === i
          const gIds = g ? frame.elements.filter((x) => x.groupId === g.id).map((x) => x.id) : []
          const gSel = g && gIds.every((x) => selectedIds.includes(x))
          const gHidden = g && frame.elements.filter((x) => x.groupId === g.id).every((x) => !x.visible)
          return (
            <div key={e.id} className="contents">
            {firstOfGroup && g && (
              <div className={cn('group/g anim-rise flex items-center gap-2 rounded-xl border px-2 py-1.5 text-sm font-semibold transition', gSel ? 'border-violet/40 bg-violet-soft/60' : 'border-transparent hover:bg-sunk')} onClick={() => st().select(gIds)} role="button" tabIndex={0}>
                <span className="grid h-7 w-7 shrink-0 place-items-center rounded-md bg-violet-soft text-violet"><GroupIcon size={15} /></span>
                {renaming === 'g' + g.id ? (
                  <Input autoFocus defaultValue={g.name} className="h-7" onClick={(ev) => ev.stopPropagation()} onBlur={(ev) => { if (ev.target.value.trim()) st().renameGroup(g.id, ev.target.value.trim()); setRenaming(null) }} onKeyDown={(ev) => ev.key === 'Enter' && (ev.target as HTMLInputElement).blur()} />
                ) : <span className="min-w-0 flex-1 truncate" onDoubleClick={() => setRenaming('g' + g.id)} title="Dubbelklik om te hernoemen">{g.name}{g.anim && g.anim.in.type !== 'none' && <Sparkles size={12} className="ml-1.5 inline text-violet" aria-label="Geanimeerd als groep" />}</span>}
                <span className="text-[11px] font-normal text-muted">{gIds.length}</span>
                <Tip label="Groep opheffen"><button className="rounded-md p-1 text-muted opacity-0 hover:bg-surface hover:text-ink group-hover/g:opacity-100 max-md:opacity-60" aria-label="Groep opheffen" onClick={(ev) => { ev.stopPropagation(); st().select(gIds); st().ungroupSelected() }}><Ungroup size={14} /></button></Tip>
                <button className="rounded-md p-1 text-muted hover:bg-surface hover:text-ink" aria-label={gHidden ? 'Groep tonen' : 'Groep verbergen'} onClick={(ev) => { ev.stopPropagation(); st().updateEls(gIds, { visible: !!gHidden }) }}>{gHidden ? <EyeOff size={14} /> : <Eye size={14} className="opacity-0 group-hover/g:opacity-100 max-md:opacity-60" />}</button>
              </div>
            )}
            <div role="listitem" ref={(n) => { if (n) rowsRef.current.set(e.id, n); else rowsRef.current.delete(e.id) }}
              onPointerDown={(ev) => onPointerDown(ev, e, i)}
              style={{ transform: isDrag ? `translateY(${drag!.dy}px) scale(1.02)` : shift ? `translateY(${shift * 100}%)` : undefined, transition: isDrag ? 'none' : 'transform 160ms ease', zIndex: isDrag ? 10 : undefined, touchAction: 'none' }}
              className={cn('group relative flex min-w-0 cursor-grab select-none items-center gap-2 rounded-xl border bg-surface px-2 py-1.5 active:cursor-grabbing', g && 'ml-4 before:absolute before:-left-2.5 before:inset-y-0 before:w-0.5 before:rounded-full before:bg-violet/30',
                selected ? 'border-accent bg-accent-soft' : 'border-transparent hover:bg-sunk', isDrag && 'shadow-pop', !e.visible && 'opacity-50')}>
              {who.length > 0 && <span className="absolute inset-y-1 left-0 w-1 rounded-full" style={{ background: who[0].color }} aria-hidden />}
              <GripVertical size={14} className="shrink-0 text-muted opacity-60 group-hover:opacity-100" />
              <LayerThumb el={e} />
              {renaming === e.id ? (
                <Input autoFocus defaultValue={e.name} className="h-7" onBlur={(ev) => { st().updateEls([e.id], { name: ev.target.value || e.name }); setRenaming(null) }} onKeyDown={(ev) => ev.key === 'Enter' && (ev.target as HTMLInputElement).blur()} />
              ) : (
                <span className="min-w-0 flex-1 truncate text-sm" onDoubleClick={() => setRenaming(e.id)} title="Dubbelklik om te hernoemen">{e.type === 'text' ? (e.text || '').replace(/\n/g, ' ') : e.name}</span>
              )}
              {who.length > 0 && (
                <span className="flex -space-x-1.5" title={`${who.map((p) => p.name).join(', ')} bewerkt deze laag`}>
                  {who.slice(0, 2).map((p) => (
                    <span key={p.key || p.id} className="grid h-5 w-5 place-items-center rounded-full text-[9px] font-bold text-white ring-2 ring-surface" style={{ background: p.color }}>{initials(p.name)}</span>
                  ))}
                </span>
              )}
              <button className="rounded-md p-1 text-muted hover:bg-surface hover:text-ink" aria-label={e.locked ? 'Ontgrendelen' : 'Vergrendelen'} onClick={(ev) => { ev.stopPropagation(); st().updateEls([e.id], { locked: !e.locked }) }}>{e.locked ? <Lock size={14} /> : <Unlock size={14} className="opacity-0 group-hover:opacity-100 max-md:opacity-60" />}</button>
              <button className="rounded-md p-1 text-muted hover:bg-surface hover:text-ink" aria-label={e.visible ? 'Verbergen' : 'Tonen'} onClick={(ev) => { ev.stopPropagation(); st().updateEls([e.id], { visible: !e.visible }) }}>{e.visible ? <Eye size={14} className="opacity-0 group-hover:opacity-100 max-md:opacity-60" /> : <EyeOff size={14} />}</button>
            </div>
            </div>
          )
        })}
        {list.length > 0 && (
          <div className="flex items-center gap-2 rounded-xl border border-dashed border-line px-2 py-1.5 text-sm text-muted">
            <span className="w-[14px]" />
            <span className="grid h-7 w-7 shrink-0 place-items-center overflow-hidden rounded-md border border-line" style={{ background: frame.background.type === 'gradient' ? `linear-gradient(${frame.background.angle}deg, ${frame.background.color}, ${frame.background.color2})` : frame.background.color }}>
              {frame.background.type === 'image' && <ImageIcon size={13} className="text-white" />}
            </span>
            Achtergrond
          </div>
        )}
      </div>
    </div>
  )
}

const initials = (n: string) => n.split(/\s+/).filter(Boolean).slice(0, 2).map((x) => x[0]?.toUpperCase()).join('')

function LayerThumb({ el }: { el: El }) {
  const base = 'grid h-7 w-7 shrink-0 place-items-center overflow-hidden rounded-md bg-sunk'
  if (el.type === 'text') return <span className={cn(base, 'text-xs font-bold')} style={{ color: el.fill }}>T</span>
  if (el.type === 'image') return <span className={cn(base, 'checker')}>{el.src ? <img src={el.src} alt="" className="h-full w-full object-cover" draggable={false} /> : <ImageIcon size={14} className="text-muted" />}</span>
  if (el.type === 'icon') return <span className={cn(base, '[&>svg]:h-4 [&>svg]:w-4')} dangerouslySetInnerHTML={{ __html: el.iconSvg ? colorSvg(el.iconSvg, el.iconMulti ? 'currentColor' : el.fill) : iconSvg(el.icon || 'star', el.fill, 2, 16) }} />
  return <span className={base}><span className={cn('block h-4 w-4', el.type === 'ellipse' && 'rounded-full')} style={{ background: el.fill }} /></span>
}
