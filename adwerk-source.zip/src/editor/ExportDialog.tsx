import { useEffect, useState } from 'react'
import JSZip from 'jszip'
import { Download, AlertTriangle, CheckCircle2 } from 'lucide-react'
import { useEditor } from '../store/editor'
import { Button, Dialog, Input, Label, Segmented, Slider, cn } from '../ui/ui'
import { PlatformLogo } from '../ui/PlatformLogo'
import { downloadBlob, exportGif, exportHtml5, exportImage, exportVideo, slug } from '../lib/export'

type Kind = 'png' | 'jpg' | 'gif' | 'video' | 'html5'

const KINDS: { key: Kind; name: string; hint: string }[] = [
  { key: 'png', name: 'PNG', hint: 'Scherp, ook met transparantie' },
  { key: 'jpg', name: 'JPG', hint: 'Klein bestand voor foto\'s' },
  { key: 'gif', name: 'GIF', hint: 'Geanimeerd, werkt overal' },
  { key: 'video', name: 'Video', hint: 'MP4 of WebM voor social' },
  { key: 'html5', name: 'HTML5', hint: 'Bannerset voor Google Ads' },
]

const kb = (b: number) => (b < 1024 * 1024 ? `${Math.round(b / 1024)} kB` : `${(b / 1024 / 1024).toFixed(1)} MB`)

export default function ExportDialog({ open, onOpenChange }: { open: boolean; onOpenChange: (o: boolean) => void }) {
  const frames = useEditor((s) => s.doc.frames)
  const title = useEditor((s) => s.design?.title || 'ontwerp')
  const active = useEditor((s) => s.activeFrameId)
  const [kind, setKind] = useState<Kind>('png')
  const [sel, setSel] = useState<string[]>([])
  const [scale, setScale] = useState(1)
  const [quality, setQuality] = useState(85)
  const [fps, setFps] = useState(15)
  const [loops, setLoops] = useState(0)
  const [clickTag, setClickTag] = useState('https://www.daar-om.nl')
  const [hLoops, setHLoops] = useState(1)
  const [busy, setBusy] = useState(false)
  const [progress, setProgress] = useState('')
  const [results, setResults] = useState<{ name: string; size: number; warn?: string }[]>([])

  useEffect(() => { if (open) { setSel([active]); setResults([]); setProgress('') } }, [open, active])
  useEffect(() => {
    // HTML5 en GIF zijn vooral voor display-formaten
    if (kind === 'html5') setSel(frames.filter((f) => f.platform === 'Google Display').map((f) => f.id).concat(frames.length && !frames.some((f) => f.platform === 'Google Display') ? [active] : []))
  }, [kind]) // eslint-disable-line react-hooks/exhaustive-deps

  const run = async () => {
    setBusy(true); setResults([])
    const chosen = frames.filter((f) => sel.includes(f.id))
    const files: { name: string; blob: Blob }[] = []
    const res: { name: string; size: number; warn?: string }[] = []
    try {
      for (const [i, f] of chosen.entries()) {
        const base = `${slug(title)}-${f.w}x${f.h}`
        setProgress(`${f.name} (${i + 1}/${chosen.length})`)
        if (kind === 'png' || kind === 'jpg') {
          const b = await exportImage(f, kind, scale, quality / 100)
          files.push({ name: `${base}.${kind}`, blob: b }); res.push({ name: `${base}.${kind}`, size: b.size })
        } else if (kind === 'gif') {
          const b = await exportGif(f, { fps, scale, loops, onProgress: (p) => setProgress(`${f.name}: ${Math.round(p * 100)}%`) })
          const warn = f.platform === 'Google Display' && b.size > 150 * 1024 ? 'Groter dan 150 kB: Google Ads weigert dit. Verlaag fps of maak de animatie korter.' : undefined
          files.push({ name: `${base}.gif`, blob: b }); res.push({ name: `${base}.gif`, size: b.size, warn })
        } else if (kind === 'video') {
          const { blob, ext } = await exportVideo(f, { scale, fps: 30, onProgress: (p) => setProgress(`${f.name}: opnemen ${Math.round(p * 100)}%`) })
          files.push({ name: `${base}.${ext}`, blob }); res.push({ name: `${base}.${ext}`, size: blob.size })
        } else {
          const { blob, backup } = await exportHtml5(f, { clickTag, loops: hLoops, density: scale })
          const warn = blob.size > 150 * 1024 ? 'Zip is groter dan 150 kB: Google Ads weigert dit. Kies 1x of gebruik minder foto\'s.' : f.duration * hLoops > 30 ? 'Animatie duurt met herhalingen langer dan 30 seconden.' : undefined
          files.push({ name: `${base}.zip`, blob }, { name: `${base}-backup.jpg`, blob: backup })
          res.push({ name: `${base}.zip`, size: blob.size, warn })
        }
      }
      if (files.length === 1) downloadBlob(files[0].blob, files[0].name)
      else {
        const zip = new JSZip()
        for (const f of files) zip.file(f.name, f.blob)
        const all = await zip.generateAsync({ type: 'blob' })
        downloadBlob(all, `${slug(title)}-${kind}.zip`)
      }
      setResults(res)
      setProgress('Klaar. De download is gestart.')
    } catch (e) {
      setProgress(`Er ging iets mis: ${(e as Error).message}`)
    } finally { setBusy(false) }
  }

  return (
    <Dialog open={open} onOpenChange={onOpenChange} title="Exporteren" description="Kies het bestandstype en de formaten. Meerdere formaten komen samen in één zip." wide>
      <div className="grid gap-5">
        <div className="grid grid-cols-2 gap-2 sm:grid-cols-5">
          {KINDS.map((k) => (
            <button key={k.key} onClick={() => setKind(k.key)} className={cn('grid gap-0.5 rounded-xl border p-3 text-left', kind === k.key ? 'border-accent bg-accent-soft' : 'border-line hover:bg-sunk')}>
              <span className={cn('font-display text-lg font-bold', kind === k.key && 'text-accent')}>{k.name}</span>
              <span className="text-xs text-muted">{k.hint}</span>
            </button>
          ))}
        </div>
        <div className="grid gap-5 md:grid-cols-[1fr_1fr]">
          <div className="grid content-start gap-2">
            <div className="flex items-center justify-between"><Label>Formaten</Label>
              <button className="text-xs font-semibold text-violet" onClick={() => setSel(sel.length === frames.length ? [] : frames.map((f) => f.id))}>{sel.length === frames.length ? 'Niets' : 'Alles'} selecteren</button></div>
            <div className="grid max-h-60 gap-1 overflow-auto">
              {frames.map((f) => (
                <label key={f.id} className="flex cursor-pointer items-center gap-2 rounded-lg px-2 py-1.5 text-sm hover:bg-sunk">
                  <input type="checkbox" className="h-4 w-4 accent-[#EA5F39]" checked={sel.includes(f.id)} onChange={() => setSel((s) => (s.includes(f.id) ? s.filter((x) => x !== f.id) : [...s, f.id]))} />
                  <PlatformLogo platform={f.platform} size={15} /><span className="flex-1 truncate">{f.name}</span><span className="text-xs tabular-nums text-muted">{f.w}×{f.h}</span>
                </label>
              ))}
            </div>
          </div>
          <div className="grid content-start gap-4">
            <div className="grid gap-1.5"><Label>{kind === 'html5' ? 'Pixeldichtheid' : 'Formaat'}</Label>
              <Segmented value={String(scale)} onChange={(v) => setScale(+v)} options={(kind === 'gif' || kind === 'video' ? [['0.5', '0,5x'], ['1', '1x']] : [['1', '1x'], ['1.5', '1,5x'], ['2', '2x']]).map(([v, l]) => ({ value: v, label: l }))} />
            </div>
            {kind === 'jpg' && <Slider label="Kwaliteit" value={quality} min={40} max={100} onChange={setQuality} format={(v) => `${v}%`} />}
            {kind === 'gif' && (<>
              <Slider label="Beelden per seconde" value={fps} min={5} max={30} onChange={setFps} />
              <div className="grid gap-1.5"><Label>Herhalen</Label><Segmented value={String(loops)} onChange={(v) => setLoops(+v)} options={[{ value: '0', label: 'Altijd' }, { value: '1', label: '1x' }, { value: '3', label: '3x' }]} /></div>
            </>)}
            {kind === 'html5' && (<>
              <div className="grid gap-1.5"><Label>Klik-URL (clickTag)</Label><Input value={clickTag} onChange={(e) => setClickTag(e.target.value)} /></div>
              <div className="grid gap-1.5"><Label>Afspelen</Label><Segmented value={String(hLoops)} onChange={(v) => setHLoops(+v)} options={[{ value: '1', label: '1x' }, { value: '2', label: '2x' }, { value: '3', label: '3x' }]} /></div>
              <p className="text-xs text-muted">Per formaat krijg je een zip met index.html, de clickTag en een backup-afbeelding. Google Ads accepteert maximaal 150 kB per zip en 30 seconden animatie.</p>
            </>)}
            {kind === 'video' && <p className="text-xs text-muted">De video wordt in realtime opgenomen. Een animatie van 6 seconden duurt dus 6 seconden per formaat.</p>}
          </div>
        </div>
        {results.length > 0 && (
          <ul className="grid gap-1.5 rounded-xl bg-mist p-3 text-sm">
            {results.map((r) => (
              <li key={r.name} className="flex items-start gap-2">{r.warn ? <AlertTriangle size={16} className="mt-0.5 shrink-0 text-sun" /> : <CheckCircle2 size={16} className="mt-0.5 shrink-0 text-mint" />}
                <span className="min-w-0 flex-1"><span className="font-medium">{r.name}</span> <span className="text-muted">· {kb(r.size)}</span>{r.warn && <span className="block text-xs text-accent-dark">{r.warn}</span>}</span></li>
            ))}
          </ul>
        )}
        <div className="flex items-center gap-3">
          <span className="flex-1 text-sm text-muted" role="status">{progress}</span>
          <Button variant="primary" size="lg" disabled={busy || !sel.length} onClick={run}><Download size={18} /> {busy ? 'Bezig…' : `Download ${sel.length > 1 ? `${sel.length} formaten` : ''}`}</Button>
        </div>
      </div>
    </Dialog>
  )
}
