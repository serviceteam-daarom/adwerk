import { useMemo } from 'react'
import { MessageSquarePlus, MessageSquareText, X, Link2 } from 'lucide-react'
import { useEditor } from '../store/editor'
import { useSession } from '../store/session'
import { useComments, addComment, setResolved, deleteComment, openThread, setCommentMode, type Comment } from '../lib/comments'
import { Pin, Thread, CommentComposer, CommentItem, timeAgo, pinColor } from '../ui/CommentUI'
import { cn, Tip } from '../ui/ui'
import type { Frame } from '../lib/types'

/** Draden (hoofdopmerking + reacties), genummerd op volgorde van plaatsen. */
export function useThreads() {
  const list = useComments((s) => s.list)
  return useMemo(() => {
    const roots = list.filter((c) => !c.parent_id)
    return roots.map((r, i) => ({ root: r, n: i + 1, replies: list.filter((c) => c.parent_id === r.id) }))
  }, [list])
}

const canDeleteFn = (meId?: string, ownerId?: string) => (c: Comment) => !!meId && (c.author_id === meId || ownerId === meId)

/** Punten op het canvas en (in reageer-modus) klikken om een nieuw punt te plaatsen. */
export function CommentLayer({ frame, ox, oy, zoom, stageW, stageH }: { frame: Frame; ox: number; oy: number; zoom: number; stageW: number; stageH: number }) {
  const { mode, active, draft, showResolved, panel } = useComments()
  const threads = useThreads()
  const { user } = useSession()
  const owner = useEditor((s) => s.design?.owner_id)
  const here = threads.filter((t) => t.root.frame_id === frame.id && t.root.x != null && t.root.y != null && (showResolved || !t.root.resolved || t.root.id === active))
  const visible = mode || panel || !!active || !!draft
  const at = (x: number, y: number) => ({ left: ox + x * zoom, top: oy + y * zoom })
  const narrow = typeof window !== 'undefined' && window.innerWidth < 640
  const cardPos = (x: number, y: number): React.CSSProperties => {
    if (narrow) return { position: 'fixed', left: 8, right: 8, bottom: 8, zIndex: 60 }
    const p = at(x, y)
    const left = p.left + 26 + 320 > stageW ? Math.max(8, p.left - 330) : p.left + 26
    return { left, top: Math.max(8, Math.min(p.top - 36, stageH - 300)) }
  }
  const act = here.find((t) => t.root.id === active)

  if (!visible) return null
  return (
    <>
      {mode && (
        <div
          className="absolute left-0 top-0 z-[25] cursor-comment"
          style={{ width: stageW, height: stageH }}
          onMouseDown={(e) => {
            e.preventDefault()
            const r = e.currentTarget.getBoundingClientRect()
            const x = (e.clientX - r.left - ox) / zoom, y = (e.clientY - r.top - oy) / zoom
            if (x < 0 || y < 0 || x > frame.w || y > frame.h) { useComments.setState({ draft: null, active: null }); return }
            useComments.setState({ draft: { frame_id: frame.id, x: Math.round(x), y: Math.round(y) }, active: null })
          }}
        />
      )}
      {here.map((t) => <Pin key={t.root.id} c={t.root} n={t.n} active={t.root.id === active} style={at(t.root.x!, t.root.y!)} onClick={() => useComments.setState({ active: active === t.root.id ? null : t.root.id, draft: null })} />)}
      {draft && draft.frame_id === frame.id && (
        <>
          <div className="comment-pin z-30" style={at(draft.x, draft.y)}><span className="grid h-8 w-8 place-items-center rounded-[16px_16px_16px_3px] border-2 border-white bg-accent text-white shadow-pop"><MessageSquarePlus size={14} /></span></div>
          <div className="anim-card absolute z-40 w-[300px] rounded-2xl max-sm:w-auto border border-line bg-surface p-2.5 shadow-pop" style={cardPos(draft.x, draft.y)} onMouseDown={(e) => e.stopPropagation()}>
            <CommentComposer autoFocus placeholder="Wat valt je op? Enter om te plaatsen" onCancel={() => useComments.setState({ draft: null })}
              onSend={async (body) => { const c = await addComment({ frame_id: draft.frame_id, x: draft.x, y: draft.y, body }); useComments.setState({ draft: null, active: c?.id || null }) }} />
          </div>
        </>
      )}
      {act && (
        <div className="anim-card absolute z-40" style={cardPos(act.root.x!, act.root.y!)} key={act.root.id}>
          <Thread className={narrow ? 'w-full max-w-none' : undefined} root={act.root} replies={act.replies} n={act.n}
            onClose={() => useComments.setState({ active: null })}
            onReply={(body) => addComment({ frame_id: act.root.frame_id, body, parent_id: act.root.id })}
            onResolve={(r) => setResolved(act.root.id, r)}
            onDelete={(id) => deleteComment(id)} canDelete={canDeleteFn(user?.id, owner)} />
        </div>
      )}
    </>
  )
}

/** Paneel rechts met alle feedback in dit ontwerp. */
export function CommentsPanel({ onShare }: { onShare: () => void }) {
  const { panel, mode, active, showResolved } = useComments()
  const threads = useThreads()
  const frames = useEditor((s) => s.doc.frames)
  const activeFrameId = useEditor((s) => s.activeFrameId)
  const owner = useEditor((s) => s.design?.owner_id)
  const { user } = useSession()
  if (!panel) return null
  const open = threads.filter((t) => !t.root.resolved)
  const shown = showResolved ? threads : open
  const resolvedCount = threads.length - open.length
  return (
    <aside className="anim-panel absolute inset-y-0 right-0 z-30 flex w-[340px] max-w-full flex-col border-l border-line bg-surface shadow-pop" aria-label="Feedback">
      <div className="flex h-12 shrink-0 items-center gap-2 border-b border-line pl-4 pr-2">
        <MessageSquareText size={17} className="text-muted" />
        <span className="flex-1 text-sm font-semibold">Feedback <span className="font-normal text-muted">{open.length ? `${open.length} open` : ''}</span></span>
        <Tip label="Deellink voor de klant"><button onClick={onShare} className="grid h-8 w-8 place-items-center rounded-lg text-muted hover:bg-sunk hover:text-ink" aria-label="Deellink voor de klant"><Link2 size={17} /></button></Tip>
        <button onClick={() => { setCommentMode(false); useComments.setState({ panel: false, active: null, draft: null }) }} className="grid h-8 w-8 place-items-center rounded-lg text-muted hover:bg-sunk hover:text-ink" aria-label="Sluiten"><X size={17} /></button>
      </div>
      <div className="grid gap-2 border-b border-line p-3">
        <button onClick={() => setCommentMode(!mode)} className={cn('press flex h-10 items-center justify-center gap-2 rounded-xl text-sm font-semibold transition', mode ? 'bg-navy text-white' : 'bg-accent text-white hover:bg-accent-dark')}>
          <MessageSquarePlus size={17} /> {mode ? 'Klik op het ontwerp… (Esc stopt)' : 'Punt plaatsen op het ontwerp'}
        </button>
        {resolvedCount > 0 && (
          <label className="flex cursor-pointer items-center justify-between px-1 text-xs text-muted">
            <span>Afgehandeld tonen ({resolvedCount})</span>
            <input type="checkbox" className="h-4 w-4 accent-[#EA5F39]" checked={showResolved} onChange={(e) => useComments.setState({ showResolved: e.target.checked })} />
          </label>
        )}
      </div>
      <div className="min-h-0 flex-1 overflow-auto p-2">
        {!shown.length && (
          <div className="grid place-items-center px-6 py-12 text-center">
            <span className="mb-3 grid h-12 w-12 place-items-center rounded-full bg-sunk text-muted"><MessageSquareText size={22} /></span>
            <p className="text-sm font-semibold">{threads.length ? 'Alles afgehandeld' : 'Nog geen feedback'}</p>
            <p className="mt-1 text-xs leading-relaxed text-muted">Plaats een punt op het ontwerp, of deel een link zodat de klant zonder account kan reageren.</p>
          </div>
        )}
        <ul className="grid gap-1">
          {shown.map((t) => {
            const f = frames.find((x) => x.id === t.root.frame_id)
            const isActive = active === t.root.id
            const pinned = t.root.x != null && !!f
            return (
              <li key={t.root.id} className="anim-rise">
                <div
                  role="button" tabIndex={0}
                  onClick={() => { if (f && f.id !== activeFrameId) useEditor.getState().setActiveFrame(f.id); isActive && !pinned ? useComments.setState({ active: null }) : openThread(t.root.id) }}
                  onKeyDown={(e) => { if (e.key === 'Enter') openThread(t.root.id) }}
                  className={cn('cursor-pointer rounded-xl border p-3 text-left transition', isActive ? 'border-violet/50 bg-violet-soft/40' : 'border-transparent hover:bg-sunk', t.root.resolved && 'opacity-60')}
                >
                  <div className="mb-1.5 flex items-center gap-2 text-[11px] font-semibold text-muted">
                    <span className="grid h-5 min-w-5 place-items-center rounded-[10px_10px_10px_2px] px-1 text-[10px] text-white" style={{ background: pinColor(t.root) }}>{t.n}</span>
                    <span className="truncate">{f ? f.name : 'Algemeen'}</span>
                    {t.replies.length > 0 && <span className="ml-auto shrink-0">{t.replies.length} {t.replies.length === 1 ? 'reactie' : 'reacties'}</span>}
                  </div>
                  <CommentItem c={t.root} />
                  {t.replies.length > 0 && !(isActive && !pinned) && <p className="mt-2 pl-[38px] text-xs text-muted">Laatste: {t.replies[t.replies.length - 1].author?.name} · {timeAgo(t.replies[t.replies.length - 1].created_at)}</p>}
                </div>
                {isActive && !pinned && (
                  <Thread className="anim-card mx-1 mb-2 mt-1 w-auto max-w-none shadow-none" root={t.root} replies={t.replies} n={t.n}
                    onReply={(body) => addComment({ frame_id: null, body, parent_id: t.root.id })}
                    onResolve={(r) => setResolved(t.root.id, r)} onDelete={(id) => deleteComment(id)} canDelete={canDeleteFn(user?.id, owner)} />
                )}
              </li>
            )
          })}
        </ul>
      </div>
      <div className="border-t border-line p-3">
        <CommentComposer placeholder="Algemene opmerking over het hele ontwerp…" onSend={(body) => addComment({ frame_id: null, body })} />
      </div>
    </aside>
  )
}

/** Knop in de kopbalk met het aantal open punten. */
export function CommentsButton() {
  const panel = useComments((s) => s.panel)
  const openCount = useComments((s) => s.list.filter((c) => !c.parent_id && !c.resolved).length)
  return (
    <Tip label="Feedback (C)">
      <button onClick={() => useComments.setState({ panel: !panel, ...(panel ? { mode: false, active: null, draft: null } : {}) })} className={cn('relative grid h-9 w-9 place-items-center rounded-lg text-white/85 transition hover:bg-white/10', panel && 'bg-white/15 text-white')} aria-label="Feedback" aria-pressed={panel}>
        <MessageSquareText size={18} />
        {openCount > 0 && <span key={openCount} className="anim-badge absolute -right-0.5 -top-0.5 grid h-[18px] min-w-[18px] place-items-center rounded-full bg-accent px-1 text-[10px] font-bold text-white ring-2 ring-navy">{openCount}</span>}
      </button>
    </Tip>
  )
}
