import { useEffect, useState } from 'react'
import { Check, Copy, Link2, Plus, Trash2, MessageSquareText, Eye } from 'lucide-react'
import { listLinks, createLink, updateLink, reviewUrl, type ShareLink } from '../lib/comments'
import { Button, Label, cn, Tip } from '../ui/ui'
import { timeAgo } from '../ui/CommentUI'

/** Deellinks voor klanten: meekijken en feedback geven zonder account. */
export function ShareLinks({ designId }: { designId: string }) {
  const [links, setLinks] = useState<ShareLink[] | null>(null)
  const [label, setLabel] = useState('')
  const [busy, setBusy] = useState(false)
  const [copied, setCopied] = useState<string | null>(null)
  useEffect(() => { listLinks(designId).then(setLinks) }, [designId])
  const copy = async (l: ShareLink) => { try { await navigator.clipboard.writeText(reviewUrl(l.token)); setCopied(l.id); setTimeout(() => setCopied(null), 1600) } catch { /* */ } }
  const make = async () => {
    setBusy(true)
    try { const l = await createLink(designId, label.trim()); setLinks((x) => [l, ...(x || [])]); setLabel(''); copy(l) } catch (e) { alert((e as Error).message) } finally { setBusy(false) }
  }
  return (
    <div className="grid gap-2 rounded-xl border border-line p-3">
      <div className="flex items-start gap-2.5">
        <span className="grid h-8 w-8 shrink-0 place-items-center rounded-full bg-[#CC4A25]/12 text-[#CC4A25]"><Link2 size={16} /></span>
        <div className="min-w-0"><Label>Feedbacklink voor de klant</Label><p className="text-xs leading-relaxed text-muted">Iedereen met de link kan het ontwerp bekijken en punten plaatsen, zonder account. Je ziet hun feedback live binnenkomen.</p></div>
      </div>
      <div className="flex gap-2">
        <input value={label} onChange={(e) => setLabel(e.target.value)} onKeyDown={(e) => { if (e.key === 'Enter') make() }} placeholder="Voor wie? Bijv. Marketing Bleyenberg" className="h-9 min-w-0 flex-1 rounded-lg bg-sunk px-3 text-sm outline-none focus:ring-2 focus:ring-violet/30" />
        <Button onClick={make} disabled={busy}><Plus size={16} /> Link maken</Button>
      </div>
      {links && links.length > 0 && (
        <ul className="grid gap-1">
          {links.map((l) => (
            <li key={l.id} className="anim-rise flex items-center gap-2 rounded-lg bg-sunk/60 py-1.5 pl-3 pr-1.5">
              <span className="min-w-0 flex-1">
                <span className="block truncate text-sm font-medium">{l.label || 'Feedbacklink'}</span>
                <span className="block truncate text-xs text-muted">{l.last_used_at ? `Laatst geopend ${timeAgo(l.last_used_at)}` : 'Nog niet geopend'}</span>
              </span>
              <Tip label={l.can_comment ? 'Klant mag reageren (klik: alleen bekijken)' : 'Alleen bekijken (klik: reageren toestaan)'}>
                <button onClick={async () => { await updateLink(l.id, { can_comment: !l.can_comment }); setLinks((x) => x!.map((y) => (y.id === l.id ? { ...y, can_comment: !l.can_comment } : y))) }} className={cn('grid h-8 w-8 place-items-center rounded-md hover:bg-surface', l.can_comment ? 'text-ink' : 'text-muted')} aria-label="Reageren aan of uit">{l.can_comment ? <MessageSquareText size={16} /> : <Eye size={16} />}</button>
              </Tip>
              <Tip label="Link kopiëren"><button onClick={() => copy(l)} className="grid h-8 w-8 place-items-center rounded-md hover:bg-surface" aria-label="Link kopiëren">{copied === l.id ? <Check size={16} className="text-mint" /> : <Copy size={16} />}</button></Tip>
              <Tip label="Link intrekken"><button onClick={async () => { if (!confirm('Deze link intrekken? De klant kan het ontwerp dan niet meer openen.')) return; await updateLink(l.id, { revoked: true }); setLinks((x) => x!.filter((y) => y.id !== l.id)) }} className="grid h-8 w-8 place-items-center rounded-md text-muted hover:bg-surface hover:text-accent-fg" aria-label="Link intrekken"><Trash2 size={16} /></button></Tip>
            </li>
          ))}
        </ul>
      )}
      {copied && <p className="anim-rise text-xs font-medium text-[#137A52]">Link gekopieerd. Plak hem in je mail naar de klant.</p>}
    </div>
  )
}
