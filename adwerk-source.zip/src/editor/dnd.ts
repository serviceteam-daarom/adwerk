import type React from 'react'
import { useEditor } from '../store/editor'
import { makeEl } from '../lib/factory'
import { fetchIconSvg, type IconHit } from '../lib/iconify'
import type { El, ElType } from '../lib/types'

/** Wat je vanuit een paneel naar het canvas kunt slepen. */
export type DragPayload =
  | { kind: 'image'; url: string; w?: number; h?: number; name?: string }
  | { kind: 'icon'; hit: IconHit }
  | { kind: 'shape'; type: ElType; patch?: Partial<El> }
  | { kind: 'text'; patch: Partial<El> }

const MIME = 'application/x-adwerk'

export function setDragPayload(e: React.DragEvent, p: DragPayload) {
  e.dataTransfer.setData(MIME, JSON.stringify(p))
  e.dataTransfer.effectAllowed = 'copy'
}
export function readDragPayload(e: React.DragEvent | DragEvent): DragPayload | null {
  try { const s = e.dataTransfer?.getData(MIME); return s ? JSON.parse(s) as DragPayload : null } catch { return null }
}
export const hasDragPayload = (e: React.DragEvent | DragEvent) => !!e.dataTransfer?.types.includes(MIME)

/** Echte afmetingen van een beeld bepalen (ook voor svg's zonder breedte/hoogte). */
import { normalizeSvg, isSvgSrc } from '../lib/svg'

export function measureImage(url: string): Promise<{ w: number; h: number }> {
  return new Promise((resolve) => {
    const img = new Image()
    img.crossOrigin = 'anonymous'
    img.onload = async () => {
      let w = img.naturalWidth, h = img.naturalHeight
      if (isSvgSrc(url) || /image\/svg/i.test(url)) {
        try { const n = normalizeSvg(url.startsWith('data:') ? decodeURIComponent(url.slice(url.indexOf(',') + 1)) : await (await fetch(url)).text()); if (n) { w = n.w; h = n.h } } catch { /* laten zoals het is */ }
      }
      resolve({ w: w || 1, h: h || 1 })
    }
    img.onerror = () => resolve({ w: 1, h: 1 })
    img.src = url
  })
}

/** Plaatst een nieuw element: op het sleeppunt als dat er is, anders in het midden. */
export function placeEl(el: El, at?: { x: number; y: number } | null) {
  const st = useEditor.getState()
  const f = st.frame()
  if (at) {
    el.x = Math.round(Math.min(Math.max(at.x - el.width / 2, -el.width / 2), f.w - el.width / 2))
    el.y = Math.round(Math.min(Math.max(at.y - el.height / 2, -el.height / 2), f.h - el.height / 2))
  }
  st.addEl(el)
}

/** Beeld toevoegen in de juiste verhouding, passend binnen het formaat. */
export async function addImage(url: string, opts: { w?: number; h?: number; name?: string; at?: { x: number; y: number } | null; replaceSelected?: boolean } = {}) {
  const st = useEditor.getState()
  if (opts.replaceSelected !== false && !opts.at) {
    const sel = st.frame().elements.find((e) => st.selectedIds.length === 1 && e.id === st.selectedIds[0] && e.type === 'image')
    if (sel) { st.updateEls([sel.id], { src: url, cropZoom: 1, cropX: 0.5, cropY: 0.5 }); return }
  }
  let { w, h } = opts
  if (!w || !h) ({ w, h } = await measureImage(url))
  const f = useEditor.getState().frame()
  const ratio = w! / h!
  const max = opts.at ? 0.5 : 0.6
  let ew = f.w * max, eh = ew / ratio
  if (eh > f.h * max) { eh = f.h * max; ew = eh * ratio }
  const el = makeEl('image', f, { src: url, width: Math.round(ew), height: Math.round(eh), x: Math.round((f.w - ew) / 2), y: Math.round((f.h - eh) / 2), name: opts.name || 'Afbeelding' })
  placeEl(el, opts.at)
}

export async function addIcon(hit: IconHit, at?: { x: number; y: number } | null) {
  const svg = await fetchIconSvg(hit)
  const st = useEditor.getState()
  const el = makeEl('icon', st.frame(), { name: hit.name, iconSvg: svg, iconId: hit.id, iconMulti: !svg.includes('currentColor'), fill: '#1B213B' })
  placeEl(el, at)
}

export async function dropPayload(p: DragPayload, at: { x: number; y: number } | null) {
  const st = useEditor.getState()
  if (p.kind === 'image') return addImage(p.url, { w: p.w, h: p.h, name: p.name, at, replaceSelected: false })
  if (p.kind === 'icon') return addIcon(p.hit, at)
  if (p.kind === 'shape') return placeEl(makeEl(p.type, st.frame(), p.patch || {}), at)
  if (p.kind === 'text') {
    const f = st.frame(), k = Math.min(f.w, f.h) / 1080
    return placeEl(makeEl('text', f, { ...p.patch, fontSize: Math.max(8, Math.round((p.patch.fontSize || 48) * k)) }), at)
  }
}
