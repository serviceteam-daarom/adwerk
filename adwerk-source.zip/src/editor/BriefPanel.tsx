import { useEffect, useRef, useState } from 'react'
import { ClipboardList, Eye, EyeOff, ExternalLink, MoreHorizontal, Plus, Trash2, X, PenLine, GripVertical } from 'lucide-react'
import { useEditor } from '../store/editor'
import type { Brief, BriefField, BriefKind } from '../lib/types'
import { PRESETS, EXTRA_SUGGESTIONS, SUGGESTIONS_BY_LABEL, defaultBrief, presetOf, filled } from '../lib/brief'
import { uid } from '../lib/factory'
import { Combobox } from '../ui/Combobox'
import { UtmBuilder } from './UtmBuilder'
import { Button, Input, Label, Switch, Tip, cn, Popover, PopoverTrigger, PopoverContent, Menu, MenuTrigger, MenuContent, MenuItem, MenuSep, Select } from '../ui/ui'

/** Brief aanpassen; maakt hem eerst aan met de standaardvelden als het ontwerp er nog geen heeft. */
export function editBrief(fn: (b: Brief) => void) {
  useEditor.getState().mutate((d) => { if (!d.brief) d.brief = defaultBrief(); fn(d.brief) })
}
const setField = (id: string, patch: Partial<BriefField>) => editBrief((b) => { const f = b.fields.find((x) => x.id === id); if (f) Object.assign(f, patch) })

function AutoText({ value, onChange, placeholder, className, rows = 2, autoFocus, ariaLabel }: { value: string; onChange: (v: string) => void; placeholder?: string; className?: string; rows?: number; autoFocus?: boolean; ariaLabel?: string }) {
  const ref = useRef<HTMLTextAreaElement>(null)
  useEffect(() => { const t = ref.current; if (!t) return; t.style.height = 'auto'; t.style.height = t.scrollHeight + 2 + 'px' }, [value])
  useEffect(() => { if (autoFocus) ref.current?.focus() }, [autoFocus])
  return <textarea ref={ref} rows={rows} value={value} placeholder={placeholder} aria-label={ariaLabel} onChange={(e) => onChange(e.target.value)} onKeyDown={(e) => e.stopPropagation()}
    className={cn('w-full resize-none rounded-lg bg-sunk px-3 py-2 text-sm leading-relaxed outline-none ring-violet placeholder:text-muted focus:ring-2', className)} />
}

function ListField({ f }: { f: BriefField }) {
  const p = presetOf(f)
  const items = f.items?.length ? f.items : ['']
  const [focusNew, setFocusNew] = useState(-1)
  const set = (next: string[]) => setField(f.id, { items: next })
  const single = (p?.limit || 0) <= 40
  return (
    <div className="grid grid-cols-[minmax(0,1fr)] gap-1.5">
      {items.map((it, i) => {
        const over = p?.limit && it.length > p.limit
        return (
          <div key={i} className="group/it anim-rise relative flex items-start gap-2">
            <span className="mt-2 w-4 shrink-0 text-right text-xs font-semibold tabular-nums text-muted">{i + 1}</span>
            <div className="relative min-w-0 flex-1">
              <AutoText rows={single ? 1 : 2} value={it} autoFocus={focusNew === i} placeholder={`${p?.placeholder || f.label} ${i + 1}`} ariaLabel={`${f.label} ${i + 1}`} onChange={(v) => set(items.map((x, j) => (j === i ? v : x)))} className={cn(p?.limit && 'pb-5')} />
              {p?.limit && it.length > 0 && <span className={cn('pointer-events-none absolute bottom-1 right-2 text-[10px] font-semibold tabular-nums', over ? 'text-[#CC4A25]' : 'text-muted')}>{it.length}/{p.limit}</span>}
            </div>
            {items.length > 1 && <button onClick={() => set(items.filter((_, j) => j !== i))} className="mt-1.5 grid h-6 w-6 place-items-center rounded-md text-muted opacity-0 transition hover:bg-sunk hover:text-ink focus:opacity-100 group-hover/it:opacity-100 max-md:opacity-60" aria-label={`${f.label} ${i + 1} verwijderen`}><X size={14} /></button>}
          </div>
        )
      })}
      <button onClick={() => { set([...items, '']); setFocusNew(items.length) }} className="ml-6 flex w-fit items-center gap-1.5 rounded-md px-1.5 py-1 text-xs font-semibold text-violet hover:bg-violet-soft/50"><Plus size={13} /> {f.label === 'Koppen' ? 'Kop' : f.label === 'Teksten' ? 'Tekst' : 'Regel'} toevoegen</button>
      {p?.hint && <p className="ml-6 text-[11px] text-muted">{p.hint}</p>}
    </div>
  )
}

function FieldInput({ f }: { f: BriefField }) {
  const p = presetOf(f)
  const sugg = p?.suggestions || SUGGESTIONS_BY_LABEL[f.label.trim().toLowerCase()]
  if (f.kind === 'list') return <ListField f={f} />
  if (f.kind === 'longtext') return <AutoText value={f.value} placeholder={p?.placeholder || 'Vrij invullen'} ariaLabel={f.label} onChange={(v) => setField(f.id, { value: v })} />
  if (f.kind === 'url') {
    const bad = f.value.trim() && !/^https?:\/\/\S+\.\S+/.test(f.value.trim())
    return (
      <div className="grid min-w-0 gap-1">
        <div className="flex min-w-0 gap-1.5">
          <Input value={f.value} placeholder="https://" aria-label={f.label} onKeyDown={(e) => e.stopPropagation()} onChange={(e) => setField(f.id, { value: e.target.value })} onBlur={(e) => { const v = e.target.value.trim(); if (v && !/^https?:\/\//.test(v) && /\./.test(v)) setField(f.id, { value: 'https://' + v }) }} />
          {f.value.trim() && !bad && <Tip label="Openen"><a href={f.value.trim()} target="_blank" rel="noreferrer" className="grid h-9 w-9 shrink-0 place-items-center rounded-lg bg-sunk text-muted hover:text-ink" aria-label="Landingspagina openen"><ExternalLink size={15} /></a></Tip>}
        </div>
        {bad && <p className="text-[11px] text-[#CC4A25]">Dit lijkt geen volledige url.</p>}
        {f.preset === 'landing' && !bad && <UtmBuilder brief={useEditor.getState().doc.brief || defaultBrief()} landing={f.value} />}
      </div>
    )
  }
  if (sugg) return <Combobox value={f.value} onChange={(v) => setField(f.id, { value: v })} suggestions={sugg} placeholder={p?.placeholder || 'Kies of typ zelf'} ariaLabel={f.label} />
  return <Input value={f.value} placeholder={p?.placeholder || 'Vrij invullen'} aria-label={f.label} onKeyDown={(e) => e.stopPropagation()} onChange={(e) => setField(f.id, { value: e.target.value })} />
}

function FieldRow({ f, index, count }: { f: BriefField; index: number; count: number }) {
  const [renaming, setRenaming] = useState(false)
  return (
    <div className={cn('group/f anim-rise relative grid grid-cols-[minmax(0,1fr)] gap-1.5 rounded-xl px-2 py-2 transition-colors focus-within:z-20 hover:bg-sunk/40', f.hidden && 'opacity-70')}>
      <div className="flex min-h-[24px] items-center gap-1.5">
        {renaming ? (
          <input autoFocus defaultValue={f.label} onKeyDown={(e) => { e.stopPropagation(); if (e.key === 'Enter') (e.target as HTMLInputElement).blur(); if (e.key === 'Escape') setRenaming(false) }} onBlur={(e) => { const v = e.target.value.trim(); if (v && v !== f.label) setField(f.id, { label: v }); setRenaming(false) }} className="h-6 min-w-0 flex-1 rounded-md bg-sunk px-2 text-[11px] font-bold uppercase tracking-[0.08em] outline-none ring-2 ring-violet/40" aria-label="Naam van het veld" />
        ) : (
          <button onDoubleClick={() => setRenaming(true)} className="min-w-0 flex-1 truncate text-left" title="Dubbelklik om de naam te wijzigen"><Label className="inline">{f.label}</Label></button>
        )}
        {f.hidden && <span className="text-[10px] font-semibold uppercase tracking-wide text-muted">Intern</span>}
        <Tip label={f.hidden ? 'Alleen intern: klant ziet dit niet (klik om te tonen)' : 'Zichtbaar voor de klant (klik om intern te houden)'}>
          <button onClick={() => setField(f.id, { hidden: !f.hidden })} className={cn('grid h-6 w-6 place-items-center rounded-md transition hover:bg-surface', f.hidden ? 'text-[#CC4A25]' : 'text-muted opacity-0 focus:opacity-100 group-hover/f:opacity-100 max-md:opacity-60')} aria-label={f.hidden ? 'Tonen aan klant' : 'Verbergen voor klant'}>{f.hidden ? <EyeOff size={14} /> : <Eye size={14} />}</button>
        </Tip>
        <Menu>
          <MenuTrigger className="grid h-6 w-6 place-items-center rounded-md text-muted opacity-0 transition hover:bg-surface hover:text-ink focus:opacity-100 group-hover/f:opacity-100 data-[state=open]:opacity-100 max-md:opacity-60" aria-label={`Opties voor ${f.label}`}><MoreHorizontal size={15} /></MenuTrigger>
          <MenuContent>
            <MenuItem onSelect={() => setRenaming(true)}><PenLine size={15} /> Naam wijzigen</MenuItem>
            {index > 0 && <MenuItem onSelect={() => editBrief((b) => { const [x] = b.fields.splice(index, 1); b.fields.splice(index - 1, 0, x) })}><GripVertical size={15} /> Omhoog</MenuItem>}
            {index < count - 1 && <MenuItem onSelect={() => editBrief((b) => { const [x] = b.fields.splice(index, 1); b.fields.splice(index + 1, 0, x) })}><GripVertical size={15} /> Omlaag</MenuItem>}
            <MenuSep />
            <MenuItem danger onSelect={() => editBrief((b) => { b.fields = b.fields.filter((x) => x.id !== f.id) })}><Trash2 size={15} /> Veld verwijderen</MenuItem>
          </MenuContent>
        </Menu>
      </div>
      <FieldInput f={f} />
    </div>
  )
}

function AddField({ brief }: { brief: Brief }) {
  const [open, setOpen] = useState(false)
  const [name, setName] = useState('')
  const [kind, setKind] = useState<BriefKind>('text')
  const add = (label: string, k: BriefKind, preset?: string) => {
    const id = uid()
    editBrief((b) => { b.fields.push({ id, label, kind: k, value: '', ...(k === 'list' ? { items: [''] } : {}), ...(preset ? { preset } : {}) }) })
    setOpen(false); setName('')
  }
  const have = new Set(brief.fields.map((f) => f.label.toLowerCase()))
  const missing = [...PRESETS.filter((p) => !brief.fields.some((f) => f.preset === p.key)).map((p) => ({ label: p.label, kind: p.kind, preset: p.key })), ...EXTRA_SUGGESTIONS.filter((x) => !have.has(x.label.toLowerCase())).map((x) => ({ label: x.label, kind: x.kind, preset: undefined }))]
  return (
    <Popover open={open} onOpenChange={setOpen}>
      <PopoverTrigger asChild><button className="flex h-10 w-full items-center justify-center gap-2 rounded-xl border-2 border-dashed border-line text-sm font-semibold text-muted transition hover:border-ink/30 hover:text-ink"><Plus size={16} /> Veld toevoegen</button></PopoverTrigger>
      <PopoverContent side="top" className="w-[268px] p-2">
        {missing.length > 0 && <>
          <Label className="px-1.5 pb-1">Snel toevoegen</Label>
          <div className="mb-2 grid grid-cols-2 gap-1">{missing.map((m) => <button key={m.label} onClick={() => add(m.label, m.kind, m.preset)} className="truncate rounded-lg px-2 py-1.5 text-left text-[13px] hover:bg-sunk">{m.label}</button>)}</div>
          <div className="mb-2 h-px bg-line" />
        </>}
        <Label className="px-1.5 pb-1.5">Eigen veld</Label>
        <div className="grid gap-1.5">
          <Input autoFocus value={name} onChange={(e) => setName(e.target.value)} placeholder="Naam, bijv. Seizoen" onKeyDown={(e) => { e.stopPropagation(); if (e.key === 'Enter' && name.trim()) add(name.trim(), kind) }} />
          <Select value={kind} onChange={(v) => setKind(v as BriefKind)} options={[{ value: 'text', label: 'Korte tekst' }, { value: 'longtext', label: 'Lange tekst' }, { value: 'url', label: 'Link' }, { value: 'list', label: 'Lijst (meerdere regels)' }]} />
          <Button variant="primary" size="sm" disabled={!name.trim()} onClick={() => add(name.trim(), kind)}><Plus size={15} /> Toevoegen</Button>
        </div>
      </PopoverContent>
    </Popover>
  )
}

/** Paneel "Brief": de instellingen van deze advertentie of campagne. */
export default function BriefPanel() {
  const stored = useEditor((s) => s.doc.brief)
  const brief = stored || defaultBrief()
  const done = brief.fields.filter(filled).length
  const show = brief.showClient !== false
  return (
    <div className="grid grid-cols-[minmax(0,1fr)] gap-4">
      <div className="min-w-0">
        <div className="flex items-center gap-2"><ClipboardList size={20} className="text-accent-fg" /><h3 className="font-display text-lg font-bold">Brief</h3><span className="ml-auto text-xs tabular-nums text-muted">{done}/{brief.fields.length} ingevuld</span></div>
        <p className="mt-1 text-xs leading-relaxed text-muted">De instellingen van dit ontwerp. Alles is vrij in te vullen; de pijltjes geven suggesties.</p>
        <div className="mt-2 h-1 overflow-hidden rounded-full bg-sunk"><div className="h-full rounded-full bg-accent transition-[width] duration-500 [transition-timing-function:var(--ease-out)]" style={{ width: `${brief.fields.length ? (done / brief.fields.length) * 100 : 0}%` }} /></div>
      </div>
      <label className="flex cursor-pointer items-start gap-3 rounded-xl bg-mist p-3">
        <span className="min-w-0 flex-1"><span className="block text-sm font-semibold">Tonen in de feedbacklink</span><span className="block text-xs leading-relaxed text-muted">{show ? 'De klant ziet de brief naast het ontwerp. Velden met het oog-icoon doorgestreept blijven intern.' : 'De klant ziet alleen het ontwerp.'}</span></span>
        <Switch checked={show} onChange={(v) => editBrief((b) => { b.showClient = v })} label="Brief tonen in de feedbacklink" />
      </label>
      <div className="-mx-2 grid grid-cols-[minmax(0,1fr)] gap-0.5">
        {brief.fields.map((f, i) => <FieldRow key={f.id} f={f} index={i} count={brief.fields.length} />)}
      </div>
      <AddField brief={brief} />
    </div>
  )
}
