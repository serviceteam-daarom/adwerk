import { create } from 'zustand'
import type { User } from '@supabase/supabase-js'
import type { Profile } from '../lib/types'

interface SessionState { user: User | null; profile: Profile | null; ready: boolean; set: (p: Partial<SessionState>) => void }
export const useSession = create<SessionState>((set) => ({ user: null, profile: null, ready: false, set: (p) => set(p) }))

export function displayName(p: Profile | null, u?: User | null) {
  return p?.full_name || (u?.user_metadata?.full_name as string) || p?.email || u?.email || 'Onbekend'
}
