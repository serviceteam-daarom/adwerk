import { create } from 'zustand'
import type { DesignDoc, DesignRow, El, ElAnim, Frame, Group } from '../lib/types'
import { makeGroup, ungroup, normalizeGroups, remapGroups, alignDeltas, distributeDeltas, type AlignMode } from '../lib/groups'
import { clone, uid, resizeElements } from '../lib/factory'
import { diffDocs, applyPatch, type DocPatch } from '../lib/patch'

export type LeftTab = 'brief' | 'templates' | 'elements' | 'text' | 'uploads' | 'brand' | 'animate' | 'formats' | 'layers'

export interface Peer { agent?: boolean; action?: string; seen?: number; key?: string; id: string; name: string; color: string; avatar?: string | null; frameId?: string; cursor?: { x: number; y: number } | null; selection?: string[] }

interface HistEntry { undo: DocPatch; redo: DocPatch; key: string; t: number }

interface EditorState {
  design: Omit<DesignRow, 'data'> | null
  doc: DesignDoc
  activeFrameId: string
  selectedIds: string[]
  zoom: number
  fitZoom: number
  playing: boolean
  time: number | null
  past: HistEntry[]
  future: HistEntry[]
  saveState: 'saved' | 'dirty' | 'saving' | 'error'
  leftTab: LeftTab | null
  lastLeftTab: LeftTab
  toggleLeft: () => void
  toggleRight: () => void
  rightOpen: boolean
  peers: Record<string, Peer>
  agents: Record<string, Peer>
  editingTextId: string | null
  clipboard: El[]
  version: number
  notice: string | null

  load: (row: DesignRow) => void
  setDoc: (doc: DesignDoc, opts?: { history?: boolean; remote?: boolean }) => void
  mutate: (fn: (d: DesignDoc) => void, opts?: { history?: boolean }) => void
  frame: () => Frame
  setActiveFrame: (id: string) => void
  select: (ids: string[]) => void
  lockedBy: () => Record<string, Peer>
  updateEls: (ids: string[], patch: Partial<El> | ((e: El) => Partial<El>), opts?: { history?: boolean }) => void
  addEl: (el: El) => void
  removeSelected: () => void
  duplicateSelected: () => void
  copy: () => void
  paste: () => void
  reorder: (id: string, dir: 'up' | 'down' | 'top' | 'bottom') => void
  moveTo: (id: string, index: number) => void
  undo: () => void
  redo: () => void
  setZoom: (z: number) => void
  setTitle: (t: string) => void
  setLeftTab: (t: LeftTab | null) => void
  setPlaying: (p: boolean) => void
  setTime: (t: number | null) => void
  resizeAllFrom: (srcId: string) => void
  notify: (t: string) => void
  clipboardGroups: Group[]
  groupSelected: () => void
  ungroupSelected: () => void
  alignSelected: (mode: AlignMode, to?: 'frame' | 'selection') => void
  distributeSelected: (axis: 'horizontal' | 'vertical') => void
  setGroupAnim: (gid: string, fn: (a: ElAnim | undefined) => ElAnim | undefined) => void
  renameGroup: (gid: string, name: string) => void
}

let broadcaster: ((prev: DesignDoc, next: DesignDoc) => void) | null = null
export const setBroadcaster = (fn: typeof broadcaster) => { broadcaster = fn }

const emptyDoc: DesignDoc = { version: 1, frames: [] }
let noticeTimer: ReturnType<typeof setTimeout> | undefined

export const useEditor = create<EditorState>((set, get) => ({
  design: null,
  doc: emptyDoc,
  activeFrameId: '',
  selectedIds: [],
  zoom: 1,
  fitZoom: 1,
  playing: false,
  time: null,
  past: [],
  future: [],
  saveState: 'saved',
  leftTab: 'templates',
  lastLeftTab: 'templates',
  rightOpen: (() => { try { return localStorage.getItem('adwerk-right-open') !== '0' } catch { return true } })(),
  peers: {},
  agents: {},
  editingTextId: null,
  clipboard: [],
  clipboardGroups: [],
  version: 0,
  notice: null,

  load: (row) => {
    const { data, ...meta } = row
    const doc = data && data.frames ? data : emptyDoc
    set({ design: meta, doc, activeFrameId: doc.frames[0]?.id || '', selectedIds: [], past: [], future: [], saveState: 'saved', time: null, playing: false, version: 0 })
  },

  setDoc: (doc, opts = {}) => {
    const prev = get().doc
    const s: Partial<EditorState> = { doc, version: get().version + 1 }
    if (!opts.remote) s.saveState = 'dirty'
    if (opts.history !== false && !opts.remote) {
      // ongedaan maken per wijziging: alleen wat jij aanpaste, wijzigingen van collega's blijven staan
      const redo = diffDocs(prev, doc), undo = diffDocs(doc, prev)
      if (redo && undo) {
        const key = JSON.stringify([redo.frames.map((f) => [f.id, (f.upserts || []).map((e) => e.id), Object.keys(f.meta || {})]), redo.frameOrder, redo.removed])
        const past = get().past
        const last = past[past.length - 1]
        const now = performance.now()
        const structural = redo.frames.some((f) => f.deletes || f.full) || redo.removed || redo.frameOrder
        if (last && last.key === key && now - last.t < 700 && !structural) s.past = [...past.slice(0, -1), { ...last, redo, t: now }]
        else s.past = [...past, { undo, redo, key, t: now }].slice(-150)
        s.future = []
      }
    }
    if (!doc.frames.find((f) => f.id === get().activeFrameId)) s.activeFrameId = doc.frames[0]?.id || ''
    const frame = doc.frames.find((f) => f.id === (s.activeFrameId || get().activeFrameId))
    if (frame) {
      const ids = new Set(frame.elements.map((e) => e.id))
      const sel = get().selectedIds.filter((i) => ids.has(i))
      if (sel.length !== get().selectedIds.length) s.selectedIds = sel
    }
    set(s)
    if (!opts.remote && broadcaster) broadcaster(prev, doc)
  },

  mutate: (fn, opts) => {
    const d = clone(get().doc)
    fn(d)
    get().setDoc(d, opts)
  },

  frame: () => {
    const { doc, activeFrameId } = get()
    return doc.frames.find((f) => f.id === activeFrameId) || doc.frames[0]
  },

  setActiveFrame: (id) => set({ activeFrameId: id, selectedIds: [], editingTextId: null }),

  select: (ids) => {
    const locked = get().lockedBy()
    const blocked = ids.find((i) => locked[i])
    if (blocked) get().notify(`${locked[blocked].name.split(' ')[0]} is dit element aan het bewerken`)
    set({ selectedIds: ids.filter((i) => !locked[i]) })
  },

  lockedBy: () => {
    const out: Record<string, Peer> = {}
    const fid = get().activeFrameId
    for (const p of Object.values(get().peers)) if (p.frameId === fid) for (const id of p.selection || []) out[id] = p
    return out
  },

  updateEls: (ids, patch, opts) => {
    const fid = get().activeFrameId
    const locked = get().lockedBy()
    const allowed = ids.filter((i) => !locked[i])
    if (!allowed.length) return
    get().mutate((d) => {
      const f = d.frames.find((x) => x.id === fid)
      if (!f) return
      f.elements = f.elements.map((e) => (allowed.includes(e.id) ? { ...e, ...(typeof patch === 'function' ? patch(e) : patch) } : e))
    }, opts)
  },

  addEl: (el) => {
    const fid = get().activeFrameId
    get().mutate((d) => {
      d.frames.find((x) => x.id === fid)?.elements.push(el)
    })
    set({ selectedIds: [el.id] })
  },

  removeSelected: () => {
    const { activeFrameId } = get()
    const locked = get().lockedBy()
    const selectedIds = get().selectedIds.filter((i) => !locked[i])
    if (!selectedIds.length) return
    get().mutate((d) => {
      const f = d.frames.find((x) => x.id === activeFrameId)
      if (f) { f.elements = f.elements.filter((e) => !selectedIds.includes(e.id) || e.locked); normalizeGroups(f) }
    })
    set({ selectedIds: [] })
  },

  duplicateSelected: () => {
    const { selectedIds, activeFrameId } = get()
    const newIds: string[] = []
    get().mutate((d) => {
      const f = d.frames.find((x) => x.id === activeFrameId)
      if (!f) return
      const copies = f.elements.filter((e) => selectedIds.includes(e.id)).map((e) => {
        const n = { ...clone(e), id: uid(), x: e.x + 20, y: e.y + 20, locked: false }
        newIds.push(n.id)
        return n
      })
      // een volledige groep wordt een nieuwe groep; een los lid uit een groep wordt een los element
      const whole = new Set(copies.filter((c) => c.groupId && f.elements.filter((e) => e.groupId === c.groupId).every((e) => selectedIds.includes(e.id))).map((c) => c.groupId!))
      for (const c of copies) if (c.groupId && !whole.has(c.groupId)) delete c.groupId
      remapGroups(copies, f.groups, f)
      f.elements.push(...copies)
      normalizeGroups(f)
    })
    set({ selectedIds: newIds })
  },

  copy: () => {
    const f = get().frame()
    set({ clipboard: clone(f.elements.filter((e) => get().selectedIds.includes(e.id))), clipboardGroups: clone(f.groups || []) })
  },

  paste: () => {
    const items = get().clipboard
    if (!items.length) return
    const fid = get().activeFrameId
    const newIds: string[] = []
    get().mutate((d) => {
      const f = d.frames.find((x) => x.id === fid)
      if (!f) return
      const copies = items.map((e) => ({ ...clone(e), id: uid(), x: e.x + 20, y: e.y + 20 }))
      remapGroups(copies, get().clipboardGroups, f)
      for (const n of copies) { newIds.push(n.id); f.elements.push(n) }
      normalizeGroups(f)
    })
    set({ selectedIds: newIds })
  },

  reorder: (id, dir) => {
    const fid = get().activeFrameId
    get().mutate((d) => {
      const f = d.frames.find((x) => x.id === fid)
      if (!f) return
      const i = f.elements.findIndex((e) => e.id === id)
      if (i < 0) return
      const [el] = f.elements.splice(i, 1)
      const j = dir === 'up' ? Math.min(f.elements.length, i + 1) : dir === 'down' ? Math.max(0, i - 1) : dir === 'top' ? f.elements.length : 0
      f.elements.splice(j, 0, el)
    })
  },

  moveTo: (id, index) => {
    const fid = get().activeFrameId
    get().mutate((d) => {
      const f = d.frames.find((x) => x.id === fid)
      if (!f) return
      const i = f.elements.findIndex((e) => e.id === id)
      if (i < 0) return
      const [el] = f.elements.splice(i, 1)
      f.elements.splice(Math.max(0, Math.min(f.elements.length, index)), 0, el)
    })
  },

  undo: () => {
    const { past, future } = get()
    const e = past[past.length - 1]
    if (!e) return
    set({ past: past.slice(0, -1), future: [e, ...future].slice(0, 150) })
    get().setDoc(applyPatch(get().doc, e.undo), { history: false })
  },

  redo: () => {
    const { future, past } = get()
    const e = future[0]
    if (!e) return
    set({ future: future.slice(1), past: [...past, e] })
    get().setDoc(applyPatch(get().doc, e.redo), { history: false })
  },

  setZoom: (z) => set({ zoom: Math.max(0.05, Math.min(8, z)) }),
  setTitle: (t) => set((s) => ({ design: s.design ? { ...s.design, title: t } : s.design, saveState: 'dirty' })),
  setLeftTab: (t) => set(t ? { leftTab: t, lastLeftTab: t } : { leftTab: null }),
  toggleLeft: () => set((s) => (s.leftTab ? { leftTab: null } : { leftTab: s.lastLeftTab || 'templates' })),
  toggleRight: () => set((s) => { const v = !s.rightOpen; try { if (window.innerWidth >= 1024) localStorage.setItem('adwerk-right-open', v ? '1' : '0') } catch { /* */ } return { rightOpen: v } }),
  setPlaying: (p) => set({ playing: p, time: p ? 0 : null }),
  setTime: (t) => set({ time: t }),

  resizeAllFrom: (srcId) => {
    get().mutate((d) => {
      const src = d.frames.find((f) => f.id === srcId)
      if (!src) return
      d.frames = d.frames.map((f) => (f.id === srcId ? f : { ...f, background: { ...src.background }, duration: src.duration, elements: resizeElements(src, f), ...(src.groups ? { groups: clone(src.groups) } : { groups: undefined }) }))
    })
  },

  groupSelected: () => {
    const fid = get().activeFrameId, ids = get().selectedIds
    if (ids.length < 2) return
    get().mutate((d) => { const f = d.frames.find((x) => x.id === fid); if (f) makeGroup(f, ids) })
    get().notify('Gegroepeerd: de elementen bewegen en animeren nu samen')
  },

  ungroupSelected: () => {
    const fid = get().activeFrameId, ids = get().selectedIds
    get().mutate((d) => {
      const f = d.frames.find((x) => x.id === fid)
      if (!f) return
      const gids = new Set(f.elements.filter((e) => ids.includes(e.id) && e.groupId).map((e) => e.groupId!))
      gids.forEach((g) => ungroup(f, g))
    })
  },

  alignSelected: (mode, to) => {
    const f = get().frame()
    const deltas = alignDeltas(f, get().selectedIds, mode, to)
    get().updateEls(Object.keys(deltas), (e) => ({ x: e.x + deltas[e.id].dx, y: e.y + deltas[e.id].dy }))
  },

  distributeSelected: (axis) => {
    const f = get().frame()
    const deltas = distributeDeltas(f, get().selectedIds, axis)
    if (!Object.keys(deltas).length) { get().notify('Selecteer minstens drie elementen of groepen om te verdelen'); return }
    get().updateEls(Object.keys(deltas), (e) => ({ x: e.x + deltas[e.id].dx, y: e.y + deltas[e.id].dy }))
  },

  setGroupAnim: (gid, fn) => {
    const fid = get().activeFrameId
    get().mutate((d) => {
      const f = d.frames.find((x) => x.id === fid)
      const g = f?.groups?.find((x) => x.id === gid)
      if (!g) return
      const a = fn(g.anim ? clone(g.anim) : undefined)
      if (a) g.anim = a; else delete g.anim
    })
  },

  renameGroup: (gid, name) => {
    const fid = get().activeFrameId
    get().mutate((d) => { const g = d.frames.find((x) => x.id === fid)?.groups?.find((x) => x.id === gid); if (g) g.name = name })
  },

  notify: (t) => {
    clearTimeout(noticeTimer)
    set({ notice: t })
    noticeTimer = setTimeout(() => set({ notice: null }), 2600)
  },
}))

export const activeFrame = () => useEditor.getState().frame()
