import { create } from 'zustand'
import type { DesignDoc, DesignRow, El, Frame } from '../lib/types'
import { clone, uid, resizeElements } from '../lib/factory'
import { diffDocs, applyPatch, type DocPatch } from '../lib/patch'

export type LeftTab = 'templates' | 'elements' | 'text' | 'uploads' | 'brand' | 'animate' | 'formats' | 'layers'

export interface Peer { agent?: boolean; action?: string; seen?: number; key?: string; id: string; name: string; color: string; avatar?: string | null; frameId?: string; cursor?: { x: number; y: number } | null; selection?: string[] }

interface HistEntry { undo: DocPatch; redo: DocPatch; key: string; t: number }

interface EditorState {
  design: Omit<DesignRow, 'data'> | null
  doc: DesignDoc
  activeFrameId: string
  selectedIds: string[]
  zoom: number
  fitZoom: number
  playing: boolean
  time: number | null
  past: HistEntry[]
  future: HistEntry[]
  saveState: 'saved' | 'dirty' | 'saving' | 'error'
  leftTab: LeftTab | null
  rightOpen: boolean
  peers: Record<string, Peer>
  agents: Record<string, Peer>
  editingTextId: string | null
  clipboard: El[]
  version: number
  notice: string | null

  load: (row: DesignRow) => void
  setDoc: (doc: DesignDoc, opts?: { history?: boolean; remote?: boolean }) => void
  mutate: (fn: (d: DesignDoc) => void, opts?: { history?: boolean }) => void
  frame: () => Frame
  setActiveFrame: (id: string) => void
  select: (ids: string[]) => void
  lockedBy: () => Record<string, Peer>
  updateEls: (ids: string[], patch: Partial<El> | ((e: El) => Partial<El>), opts?: { history?: boolean }) => void
  addEl: (el: El) => void
  removeSelected: () => void
  duplicateSelected: () => void
  copy: () => void
  paste: () => void
  reorder: (id: string, dir: 'up' | 'down' | 'top' | 'bottom') => void
  moveTo: (id: string, index: number) => void
  undo: () => void
  redo: () => void
  setZoom: (z: number) => void
  setTitle: (t: string) => void
  setLeftTab: (t: LeftTab | null) => void
  setPlaying: (p: boolean) => void
  setTime: (t: number | null) => void
  resizeAllFrom: (srcId: string) => void
  notify: (t: string) => void
}

let broadcaster: ((prev: DesignDoc, next: DesignDoc) => void) | null = null
export const setBroadcaster = (fn: typeof broadcaster) => { broadcaster = fn }

const emptyDoc: DesignDoc = { version: 1, frames: [] }
let noticeTimer: ReturnType<typeof setTimeout> | undefined

export const useEditor = create<EditorState>((set, get) => ({
  design: null,
  doc: emptyDoc,
  activeFrameId: '',
  selectedIds: [],
  zoom: 1,
  fitZoom: 1,
  playing: false,
  time: null,
  past: [],
  future: [],
  saveState: 'saved',
  leftTab: 'templates',
  rightOpen: true,
  peers: {},
  agents: {},
  editingTextId: null,
  clipboard: [],
  version: 0,
  notice: null,

  load: (row) => {
    const { data, ...meta } = row
    const doc = data && data.frames ? data : emptyDoc
    set({ design: meta, doc, activeFrameId: doc.frames[0]?.id || '', selectedIds: [], past: [], future: [], saveState: 'saved', time: null, playing: false, version: 0 })
  },

  setDoc: (doc, opts = {}) => {
    const prev = get().doc
    const s: Partial<EditorState> = { doc, version: get().version + 1 }
    if (!opts.remote) s.saveState = 'dirty'
    if (opts.history !== false && !opts.remote) {
      // ongedaan maken per wijziging: alleen wat jij aanpaste, wijzigingen van collega's blijven staan
      const redo = diffDocs(prev, doc), undo = diffDocs(doc, prev)
      if (redo && undo) {
        const key = JSON.stringify([redo.frames.map((f) => [f.id, (f.upserts || []).map((e) => e.id), Object.keys(f.meta || {})]), redo.frameOrder, redo.removed])
        const past = get().past
        const last = past[past.length - 1]
        const now = performance.now()
        const structural = redo.frames.some((f) => f.deletes || f.full) || redo.removed || redo.frameOrder
        if (last && last.key === key && now - last.t < 700 && !structural) s.past = [...past.slice(0, -1), { ...last, redo, t: now }]
        else s.past = [...past, { undo, redo, key, t: now }].slice(-150)
        s.future = []
      }
    }
    if (!doc.frames.find((f) => f.id === get().activeFrameId)) s.activeFrameId = doc.frames[0]?.id || ''
    const frame = doc.frames.find((f) => f.id === (s.activeFrameId || get().activeFrameId))
    if (frame) {
      const ids = new Set(frame.elements.map((e) => e.id))
      const sel = get().selectedIds.filter((i) => ids.has(i))
      if (sel.length !== get().selectedIds.length) s.selectedIds = sel
    }
    set(s)
    if (!opts.remote && broadcaster) broadcaster(prev, doc)
  },

  mutate: (fn, opts) => {
    const d = clone(get().doc)
    fn(d)
    get().setDoc(d, opts)
  },

  frame: () => {
    const { doc, activeFrameId } = get()
    return doc.frames.find((f) => f.id === activeFrameId) || doc.frames[0]
  },

  setActiveFrame: (id) => set({ activeFrameId: id, selectedIds: [], editingTextId: null }),

  select: (ids) => {
    const locked = get().lockedBy()
    const blocked = ids.find((i) => locked[i])
    if (blocked) get().notify(`${locked[blocked].name.split(' ')[0]} is dit element aan het bewerken`)
    set({ selectedIds: ids.filter((i) => !locked[i]) })
  },

  lockedBy: () => {
    const out: Record<string, Peer> = {}
    const fid = get().activeFrameId
    for (const p of Object.values(get().peers)) if (p.frameId === fid) for (const id of p.selection || []) out[id] = p
    return out
  },

  updateEls: (ids, patch, opts) => {
    const fid = get().activeFrameId
    const locked = get().lockedBy()
    const allowed = ids.filter((i) => !locked[i])
    if (!allowed.length) return
    get().mutate((d) => {
      const f = d.frames.find((x) => x.id === fid)
      if (!f) return
      f.elements = f.elements.map((e) => (allowed.includes(e.id) ? { ...e, ...(typeof patch === 'function' ? patch(e) : patch) } : e))
    }, opts)
  },

  addEl: (el) => {
    const fid = get().activeFrameId
    get().mutate((d) => {
      d.frames.find((x) => x.id === fid)?.elements.push(el)
    })
    set({ selectedIds: [el.id] })
  },

  removeSelected: () => {
    const { activeFrameId } = get()
    const locked = get().lockedBy()
    const selectedIds = get().selectedIds.filter((i) => !locked[i])
    if (!selectedIds.length) return
    get().mutate((d) => {
      const f = d.frames.find((x) => x.id === activeFrameId)
      if (f) f.elements = f.elements.filter((e) => !selectedIds.includes(e.id) || e.locked)
    })
    set({ selectedIds: [] })
  },

  duplicateSelected: () => {
    const { selectedIds, activeFrameId } = get()
    const newIds: string[] = []
    get().mutate((d) => {
      const f = d.frames.find((x) => x.id === activeFrameId)
      if (!f) return
      const copies = f.elements.filter((e) => selectedIds.includes(e.id)).map((e) => {
        const n = { ...clone(e), id: uid(), x: e.x + 20, y: e.y + 20, locked: false }
        newIds.push(n.id)
        return n
      })
      f.elements.push(...copies)
    })
    set({ selectedIds: newIds })
  },

  copy: () => {
    const f = get().frame()
    set({ clipboard: clone(f.elements.filter((e) => get().selectedIds.includes(e.id))) })
  },

  paste: () => {
    const items = get().clipboard
    if (!items.length) return
    const fid = get().activeFrameId
    const newIds: string[] = []
    get().mutate((d) => {
      const f = d.frames.find((x) => x.id === fid)
      if (!f) return
      for (const e of items) {
        const n = { ...clone(e), id: uid(), x: e.x + 20, y: e.y + 20 }
        newIds.push(n.id)
        f.elements.push(n)
      }
    })
    set({ selectedIds: newIds })
  },

  reorder: (id, dir) => {
    const fid = get().activeFrameId
    get().mutate((d) => {
      const f = d.frames.find((x) => x.id === fid)
      if (!f) return
      const i = f.elements.findIndex((e) => e.id === id)
      if (i < 0) return
      const [el] = f.elements.splice(i, 1)
      const j = dir === 'up' ? Math.min(f.elements.length, i + 1) : dir === 'down' ? Math.max(0, i - 1) : dir === 'top' ? f.elements.length : 0
      f.elements.splice(j, 0, el)
    })
  },

  moveTo: (id, index) => {
    const fid = get().activeFrameId
    get().mutate((d) => {
      const f = d.frames.find((x) => x.id === fid)
      if (!f) return
      const i = f.elements.findIndex((e) => e.id === id)
      if (i < 0) return
      const [el] = f.elements.splice(i, 1)
      f.elements.splice(Math.max(0, Math.min(f.elements.length, index)), 0, el)
    })
  },

  undo: () => {
    const { past, future } = get()
    const e = past[past.length - 1]
    if (!e) return
    set({ past: past.slice(0, -1), future: [e, ...future].slice(0, 150) })
    get().setDoc(applyPatch(get().doc, e.undo), { history: false })
  },

  redo: () => {
    const { future, past } = get()
    const e = future[0]
    if (!e) return
    set({ future: future.slice(1), past: [...past, e] })
    get().setDoc(applyPatch(get().doc, e.redo), { history: false })
  },

  setZoom: (z) => set({ zoom: Math.max(0.05, Math.min(8, z)) }),
  setTitle: (t) => set((s) => ({ design: s.design ? { ...s.design, title: t } : s.design, saveState: 'dirty' })),
  setLeftTab: (t) => set({ leftTab: t }),
  setPlaying: (p) => set({ playing: p, time: p ? 0 : null }),
  setTime: (t) => set({ time: t }),

  resizeAllFrom: (srcId) => {
    get().mutate((d) => {
      const src = d.frames.find((f) => f.id === srcId)
      if (!src) return
      d.frames = d.frames.map((f) => (f.id === srcId ? f : { ...f, background: { ...src.background }, duration: src.duration, elements: resizeElements(src, f) }))
    })
  },

  notify: (t) => {
    clearTimeout(noticeTimer)
    set({ notice: t })
    noticeTimer = setTimeout(() => set({ notice: null }), 2600)
  },
}))

export const activeFrame = () => useEditor.getState().frame()
