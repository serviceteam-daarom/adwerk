import { create } from 'zustand'
import type { DesignDoc, DesignRow, El, Frame } from '../lib/types'
import { clone, uid, resizeElements } from '../lib/factory'

export type LeftTab = 'templates' | 'elements' | 'text' | 'uploads' | 'brand' | 'animate' | 'formats' | 'layers'

export interface Peer { id: string; name: string; color: string; avatar?: string | null; frameId?: string; cursor?: { x: number; y: number } | null; selection?: string[] }

interface EditorState {
  design: Omit<DesignRow, 'data'> | null
  doc: DesignDoc
  activeFrameId: string
  selectedIds: string[]
  zoom: number
  fitZoom: number
  playing: boolean
  time: number | null
  past: string[]
  future: string[]
  saveState: 'saved' | 'dirty' | 'saving' | 'error'
  leftTab: LeftTab | null
  peers: Record<string, Peer>
  editingTextId: string | null
  clipboard: El[]
  version: number

  load: (row: DesignRow) => void
  setDoc: (doc: DesignDoc, opts?: { history?: boolean; remote?: boolean }) => void
  mutate: (fn: (d: DesignDoc) => void, opts?: { history?: boolean }) => void
  frame: () => Frame
  setActiveFrame: (id: string) => void
  select: (ids: string[]) => void
  updateEls: (ids: string[], patch: Partial<El> | ((e: El) => Partial<El>), opts?: { history?: boolean }) => void
  addEl: (el: El) => void
  removeSelected: () => void
  duplicateSelected: () => void
  copy: () => void
  paste: () => void
  reorder: (id: string, dir: 'up' | 'down' | 'top' | 'bottom') => void
  moveTo: (id: string, index: number) => void
  undo: () => void
  redo: () => void
  setZoom: (z: number) => void
  setTitle: (t: string) => void
  setLeftTab: (t: LeftTab | null) => void
  setPlaying: (p: boolean) => void
  setTime: (t: number | null) => void
  resizeAllFrom: (srcId: string) => void
}

let broadcaster: ((prev: DesignDoc, next: DesignDoc) => void) | null = null
export const setBroadcaster = (fn: typeof broadcaster) => { broadcaster = fn }

const emptyDoc: DesignDoc = { version: 1, frames: [] }

export const useEditor = create<EditorState>((set, get) => ({
  design: null,
  doc: emptyDoc,
  activeFrameId: '',
  selectedIds: [],
  zoom: 1,
  fitZoom: 1,
  playing: false,
  time: null,
  past: [],
  future: [],
  saveState: 'saved',
  leftTab: 'templates',
  peers: {},
  editingTextId: null,
  clipboard: [],
  version: 0,

  load: (row) => {
    const { data, ...meta } = row
    const doc = data && data.frames ? data : emptyDoc
    set({ design: meta, doc, activeFrameId: doc.frames[0]?.id || '', selectedIds: [], past: [], future: [], saveState: 'saved', time: null, playing: false, version: 0 })
  },

  setDoc: (doc, opts = {}) => {
    const prev = get().doc
    const s: Partial<EditorState> = { doc, version: get().version + 1 }
    if (!opts.remote) s.saveState = 'dirty'
    if (opts.history !== false && !opts.remote) {
      s.past = [...get().past, JSON.stringify(prev)].slice(-100)
      s.future = []
    }
    if (!doc.frames.find((f) => f.id === get().activeFrameId)) s.activeFrameId = doc.frames[0]?.id || ''
    const frame = doc.frames.find((f) => f.id === (s.activeFrameId || get().activeFrameId))
    if (frame) {
      const ids = new Set(frame.elements.map((e) => e.id))
      const sel = get().selectedIds.filter((i) => ids.has(i))
      if (sel.length !== get().selectedIds.length) s.selectedIds = sel
    }
    set(s)
    if (!opts.remote && broadcaster) broadcaster(prev, doc)
  },

  mutate: (fn, opts) => {
    const d = clone(get().doc)
    fn(d)
    get().setDoc(d, opts)
  },

  frame: () => {
    const { doc, activeFrameId } = get()
    return doc.frames.find((f) => f.id === activeFrameId) || doc.frames[0]
  },

  setActiveFrame: (id) => set({ activeFrameId: id, selectedIds: [], editingTextId: null }),
  select: (ids) => set({ selectedIds: ids }),

  updateEls: (ids, patch, opts) => {
    const fid = get().activeFrameId
    get().mutate((d) => {
      const f = d.frames.find((x) => x.id === fid)
      if (!f) return
      f.elements = f.elements.map((e) => (ids.includes(e.id) ? { ...e, ...(typeof patch === 'function' ? patch(e) : patch) } : e))
    }, opts)
  },

  addEl: (el) => {
    const fid = get().activeFrameId
    get().mutate((d) => {
      d.frames.find((x) => x.id === fid)?.elements.push(el)
    })
    set({ selectedIds: [el.id] })
  },

  removeSelected: () => {
    const { selectedIds, activeFrameId } = get()
    if (!selectedIds.length) return
    get().mutate((d) => {
      const f = d.frames.find((x) => x.id === activeFrameId)
      if (f) f.elements = f.elements.filter((e) => !selectedIds.includes(e.id) || e.locked)
    })
    set({ selectedIds: [] })
  },

  duplicateSelected: () => {
    const { selectedIds, activeFrameId } = get()
    const newIds: string[] = []
    get().mutate((d) => {
      const f = d.frames.find((x) => x.id === activeFrameId)
      if (!f) return
      const copies = f.elements.filter((e) => selectedIds.includes(e.id)).map((e) => {
        const n = { ...clone(e), id: uid(), x: e.x + 20, y: e.y + 20, locked: false }
        newIds.push(n.id)
        return n
      })
      f.elements.push(...copies)
    })
    set({ selectedIds: newIds })
  },

  copy: () => {
    const f = get().frame()
    set({ clipboard: clone(f.elements.filter((e) => get().selectedIds.includes(e.id))) })
  },

  paste: () => {
    const items = get().clipboard
    if (!items.length) return
    const fid = get().activeFrameId
    const newIds: string[] = []
    get().mutate((d) => {
      const f = d.frames.find((x) => x.id === fid)
      if (!f) return
      for (const e of items) {
        const n = { ...clone(e), id: uid(), x: e.x + 20, y: e.y + 20 }
        newIds.push(n.id)
        f.elements.push(n)
      }
    })
    set({ selectedIds: newIds })
  },

  reorder: (id, dir) => {
    const fid = get().activeFrameId
    get().mutate((d) => {
      const f = d.frames.find((x) => x.id === fid)
      if (!f) return
      const i = f.elements.findIndex((e) => e.id === id)
      if (i < 0) return
      const [el] = f.elements.splice(i, 1)
      const j = dir === 'up' ? Math.min(f.elements.length, i + 1) : dir === 'down' ? Math.max(0, i - 1) : dir === 'top' ? f.elements.length : 0
      f.elements.splice(j, 0, el)
    })
  },

  moveTo: (id, index) => {
    const fid = get().activeFrameId
    get().mutate((d) => {
      const f = d.frames.find((x) => x.id === fid)
      if (!f) return
      const i = f.elements.findIndex((e) => e.id === id)
      if (i < 0) return
      const [el] = f.elements.splice(i, 1)
      f.elements.splice(Math.max(0, Math.min(f.elements.length, index)), 0, el)
    })
  },

  undo: () => {
    const { past, doc, future } = get()
    if (!past.length) return
    const prev = JSON.parse(past[past.length - 1])
    set({ past: past.slice(0, -1), future: [JSON.stringify(doc), ...future].slice(0, 100) })
    get().setDoc(prev, { history: false })
  },

  redo: () => {
    const { future, doc, past } = get()
    if (!future.length) return
    const next = JSON.parse(future[0])
    set({ future: future.slice(1), past: [...past, JSON.stringify(doc)] })
    get().setDoc(next, { history: false })
  },

  setZoom: (z) => set({ zoom: Math.max(0.05, Math.min(8, z)) }),
  setTitle: (t) => set((s) => ({ design: s.design ? { ...s.design, title: t } : s.design, saveState: 'dirty' })),
  setLeftTab: (t) => set({ leftTab: t }),
  setPlaying: (p) => set({ playing: p, time: p ? 0 : null }),
  setTime: (t) => set({ time: t }),

  resizeAllFrom: (srcId) => {
    get().mutate((d) => {
      const src = d.frames.find((f) => f.id === srcId)
      if (!src) return
      d.frames = d.frames.map((f) => (f.id === srcId ? f : { ...f, background: { ...src.background }, duration: src.duration, elements: resizeElements(src, f) }))
    })
  },
}))

export const activeFrame = () => useEditor.getState().frame()
