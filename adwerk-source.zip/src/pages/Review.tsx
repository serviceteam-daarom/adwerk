import { useEffect, useMemo, useRef, useState } from 'react'
import { Loader2, MessageSquarePlus, MessageSquareText, X, ChevronLeft, ChevronRight, ClipboardList, LayoutGrid, Smartphone, History, CheckCircle2, AlertCircle } from 'lucide-react'
import { supabase } from '../lib/supabase'
import { createOffscreen } from '../lib/render'
import type { Comment } from '../lib/comments'
import type { Brief, Frame } from '../lib/types'
import { BriefView } from '../ui/BriefView'
import { AdPreviewer } from '../ui/AdPreview'
import { Dialog } from '../ui/ui'
import { filled } from '../lib/brief'
import { Pin, Thread, CommentComposer, CommentItem, pinColor } from '../ui/CommentUI'
import { cn } from '../ui/ui'
import { Logo } from './Login'

interface ReviewApproval { version: number | null; decision: 'approved' | 'changes'; name: string; note: string | null; created_at: string }
interface ReviewData { design: { id: string; title: string; frames: Frame[]; updated_at: string; brief?: Brief | null }; version: number | null; latest: number | null; versions: { number: number; note: string | null; created_at: string }[]; status: string; approvals: ReviewApproval[]; can_comment: boolean; comments: Comment[] }

async function call(body: Record<string, unknown>) {
  const { data, error } = await supabase.functions.invoke('review', { body })
  if (error) {
    const status = (error as { context?: Response }).context?.status
    throw new Error(status === 404 ? 'not_found' : status === 429 ? 'Even rustig aan: probeer het over een paar minuten opnieuw.' : status === 403 ? 'Op deze link kun je alleen meekijken.' : 'Er ging iets mis. Probeer het opnieuw.')
  }
  return data
}

const NAME_KEY = 'adwerk-review-name'
const getName = () => { try { return localStorage.getItem(NAME_KEY) || '' } catch { return '' } }
const putName = (n: string) => { try { localStorage.setItem(NAME_KEY, n) } catch { /* */ } }

/** Publieke feedbackpagina voor klanten: bekijken en punten plaatsen zonder account. */
export default function Review({ token }: { token: string }) {
  const [data, setData] = useState<ReviewData | null>(null)
  const [err, setErr] = useState<string | null>(null)
  const [fi, setFi] = useState(0)
  const [img, setImg] = useState<Record<string, string>>({})
  const [mode, setMode] = useState(false)
  const [draft, setDraft] = useState<{ x: number; y: number } | null>(null)
  const [active, setActive] = useState<string | null>(null)
  const [name, setName] = useState(getName)
  const [list, setList] = useState(false)
  const [briefOpen, setBriefOpen] = useState(() => window.innerWidth >= 1024)
  const [ver, setVer] = useState<number | null>(null)
  const [view, setView] = useState<'design' | 'ad'>('design')
  const [decide, setDecide] = useState<'approved' | 'changes' | null>(null)
  const boxRef = useRef<HTMLDivElement>(null)
  const [box, setBox] = useState({ w: 800, h: 600 })

  useEffect(() => { document.title = 'Feedback geven · Adwerk' }, [])
  // laden, en af en toe kijken of het ontwerp is bijgewerkt
  useEffect(() => {
    let alive = true, stamp = ''
    const load = () => call({ token, action: 'get', ...(ver !== null ? { version: ver } : {}) }).then((d: ReviewData) => {
      if (!alive) return
      if (d.design.updated_at !== stamp) { if (stamp) setImg({}); stamp = d.design.updated_at }
      setData(d)
    }).catch((e) => alive && setErr((e as Error).message))
    load()
    const t = setInterval(load, 45000)
    return () => { alive = false; clearInterval(t) }
  }, [token, ver])

  // live: nieuwe feedback van het team of andere klanten
  const did = data?.design.id
  useEffect(() => {
    if (!did) return
    const ch = supabase.channel(`comments:${did}`)
      .on('broadcast', { event: 'comment' }, ({ payload }) => addLocal(payload as Comment))
      .on('broadcast', { event: 'update' }, ({ payload }) => addLocal(payload as Comment))
      .on('broadcast', { event: 'approval' }, ({ payload }) => setData((d) => d && { ...d, approvals: [payload as ReviewApproval, ...d.approvals], status: (payload as ReviewApproval).decision === 'approved' ? 'goedgekeurd' : 'aanpassen' }))
      .on('broadcast', { event: 'delete' }, ({ payload }) => setData((d) => d && { ...d, comments: d.comments.filter((c) => c.id !== (payload as { id: string }).id && c.parent_id !== (payload as { id: string }).id) }))
      .subscribe()
    return () => { supabase.removeChannel(ch) }
  }, [did])
  const addLocal = (c: Comment) => setData((d) => {
    if (!d) return d
    const clean: Comment = { id: c.id, frame_id: c.frame_id, x: c.x, y: c.y, parent_id: c.parent_id, body: c.body, resolved: c.resolved, created_at: c.created_at, author: c.author || (c.guest_name ? { name: c.guest_name, team: false } : { name: 'daar-om.nl', team: true }) }
    const i = d.comments.findIndex((x) => x.id === c.id)
    const old = i >= 0 ? d.comments[i] : null
    if (old?.author) clean.author = old.author
    return { ...d, comments: i >= 0 ? d.comments.map((x) => (x.id === c.id ? clean : x)) : [...d.comments, clean] }
  })

  const frames = data?.design.frames || []
  const frame = frames[fi]
  // formaat renderen
  useEffect(() => {
    if (!frame || img[frame.id]) return
    let alive = true
    createOffscreen(frame).then((off) => {
      try {
        const c = off.canvasAt(null, Math.min(2, 1600 / Math.max(frame.w, frame.h)))
        if (alive) setImg((m) => ({ ...m, [frame.id]: c.toDataURL('image/png') }))
      } finally { off.destroy() }
    }).catch(() => { /* */ })
    return () => { alive = false }
  }, [frame, img])

  useEffect(() => {
    const el = boxRef.current
    if (!el) return
    const ro = new ResizeObserver(() => setBox({ w: el.clientWidth, h: el.clientHeight }))
    ro.observe(el)
    return () => ro.disconnect()
  }, [data, view])

  const threads = useMemo(() => {
    const cs = data?.comments || []
    return cs.filter((c) => !c.parent_id).map((r, i) => ({ root: r, n: i + 1, replies: cs.filter((c) => c.parent_id === r.id) }))
  }, [data])

  if (err) return (
    <div className="grid h-full place-items-center bg-sunk p-6 text-center">
      <div className="max-w-sm"><Logo size={34} />
        <p className="mt-8 font-display text-2xl font-bold">{err === 'not_found' ? 'Deze link werkt niet (meer)' : 'Er ging iets mis'}</p>
        <p className="mt-2 text-sm text-muted">{err === 'not_found' ? 'Misschien is de link ingetrokken. Vraag je contactpersoon bij daar-om.nl om een nieuwe.' : err}</p></div>
    </div>
  )
  if (!data || !frame) return <div className="grid h-full place-items-center"><Loader2 className="animate-spin text-accent-fg" size={32} /></div>

  const curVersion = data.versions.find((v) => v.number === data.version)
  const myDecision = data.approvals.find((a) => a.version === data.version)
  const hasBrief = !!data.design.brief && data.design.brief.fields.some((f) => !f.hidden && filled(f))
  const pad = 40
  const scale = Math.min((box.w - pad * 2) / frame.w, (box.h - pad * 2) / frame.h, 1.5)
  const W = Math.max(50, frame.w * scale), H = Math.max(50, frame.h * scale)
  const here = threads.filter((t) => t.root.frame_id === frame.id && t.root.x != null)
  const act = threads.find((t) => t.root.id === active)
  const openCount = threads.filter((t) => !t.root.resolved).length

  const send = async (body: string, extra: Record<string, unknown>) => {
    const n = name.trim()
    if (!n) throw new Error('Vul eerst je naam in')
    putName(n)
    const r = await call({ token, action: 'comment', name: n, body, ...extra })
    addLocal({ ...r.comment, author: { name: n, team: false } })
    return r.comment as Comment
  }
  const nameField = !getName() ? (
    <input value={name} onChange={(e) => setName(e.target.value)} placeholder="Je naam" className="h-9 rounded-lg border border-line bg-surface px-3 text-sm outline-none focus:border-violet" onKeyDown={(e) => e.stopPropagation()} />
  ) : null
  const narrow = box.w < 640
  const cardPos = (x: number, y: number): React.CSSProperties => {
    if (narrow) return { position: 'fixed', left: 8, right: 8, bottom: 8, top: 'auto' }
    const left = x * scale + 26 + 320 > W + (box.w - W) / 2 ? x * scale - 330 : x * scale + 26
    return { left, top: Math.max(-((box.h - H) / 2) + 8, y * scale - 36) }
  }

  return (
    <div className="flex h-full flex-col bg-sunk">
      <header className="flex h-14 shrink-0 items-center gap-3 border-b border-line bg-surface px-3 sm:px-4">
        <Logo size={28} />
        <span className="hidden h-6 w-px bg-line sm:block" />
        <div className="min-w-0 flex-1"><p className="truncate text-sm font-semibold">{data.design.title}</p><p className="hidden truncate text-xs text-muted sm:block">Feedback geven op dit ontwerp van daar-om.nl</p></div>
        {data.can_comment && (
          <button onClick={() => { setMode(!mode); setDraft(null); setActive(null) }} className={cn('press flex h-9 items-center gap-2 rounded-full px-4 text-sm font-semibold text-white transition', mode ? 'bg-navy' : 'bg-accent hover:bg-accent-dark')}>
            <MessageSquarePlus size={16} /><span className="hidden sm:inline">{mode ? 'Klik op het ontwerp' : 'Punt plaatsen'}</span>
          </button>
        )}
        {hasBrief && <button onClick={() => setBriefOpen(!briefOpen)} className={cn('flex h-9 items-center gap-1.5 rounded-full px-2.5 text-sm font-semibold transition hover:bg-sunk sm:px-3', briefOpen && 'bg-sunk')} aria-label="Brief van deze campagne" aria-pressed={briefOpen}><ClipboardList size={17} /><span className="hidden sm:inline">Brief</span></button>}
        <button onClick={() => setList(!list)} className={cn('relative grid h-9 w-9 place-items-center rounded-full transition hover:bg-sunk', list && 'bg-sunk')} aria-label="Alle feedback">
          <MessageSquareText size={18} />
          {openCount > 0 && <span className="absolute -right-0.5 -top-0.5 grid h-[18px] min-w-[18px] place-items-center rounded-full bg-accent px-1 text-[10px] font-bold text-white ring-2 ring-surface">{openCount}</span>}
        </button>
      </header>

      <DecideDialog kind={decide} onClose={() => setDecide(null)} version={data.latest} name={name} setName={setName}
        onSubmit={async (k, n, note) => { putName(n); const r = await call({ token, action: 'decide', decision: k, name: n, note, version: data.latest }); setData((d) => d && { ...d, approvals: [r.approval, ...d.approvals.filter((a) => !(a.created_at === r.approval.created_at))], status: k === 'approved' ? 'goedgekeurd' : 'aanpassen' }); setDecide(null) }} />
      <div className="relative flex min-h-0 flex-1">
        {hasBrief && briefOpen && (
          <aside className="anim-leftpanel flex w-[340px] shrink-0 flex-col border-r border-line bg-surface max-lg:absolute max-lg:inset-y-0 max-lg:left-0 max-lg:z-50 max-lg:w-full max-lg:max-w-[420px] max-lg:shadow-pop" aria-label="Brief">
            <div className="flex h-12 shrink-0 items-center gap-2 border-b border-line pl-4 pr-2"><ClipboardList size={17} className="text-accent-fg" /><span className="flex-1 text-sm font-semibold">Over deze campagne</span><button onClick={() => setBriefOpen(false)} className="grid h-8 w-8 place-items-center rounded-lg text-muted hover:bg-sunk" aria-label="Brief sluiten"><X size={17} /></button></div>
            <div className="min-h-0 flex-1 overflow-auto p-4"><BriefView brief={data.design.brief!} /></div>
            {data.can_comment && <div className="border-t border-line p-3"><CommentComposer placeholder="Opmerking over de brief of teksten…" nameField={nameField} onSend={(body) => send(`Over de brief: ${body}`, {})} /></div>}
          </aside>
        )}
        <div className="flex min-w-0 flex-1 flex-col">
          <div className="flex shrink-0 items-center gap-2 overflow-x-auto border-b border-line bg-surface px-3 py-2">
            <div className="flex shrink-0 rounded-lg bg-sunk p-0.5 text-xs font-semibold" role="tablist" aria-label="Weergave">
              <button role="tab" aria-selected={view === 'design'} onClick={() => setView('design')} className={cn('flex items-center gap-1.5 rounded-md px-2.5 py-1.5 transition', view === 'design' ? 'bg-surface text-ink shadow-card' : 'text-muted hover:text-ink')}><LayoutGrid size={14} /> Ontwerp</button>
              <button role="tab" aria-selected={view === 'ad'} onClick={() => { setView('ad'); setMode(false); setDraft(null); setActive(null) }} className={cn('flex items-center gap-1.5 rounded-md px-2.5 py-1.5 transition', view === 'ad' ? 'bg-surface text-ink shadow-card' : 'text-muted hover:text-ink')}><Smartphone size={14} /> Advertentie</button>
            </div>
            {view === 'design' && frames.length > 1 && <span className="h-5 w-px shrink-0 bg-line" />}
            {view === 'design' && frames.length > 1 && <div className="flex items-center gap-1">
              {frames.map((f, i) => {
                const n = threads.filter((t) => t.root.frame_id === f.id && !t.root.resolved).length
                return <button key={f.id} onClick={() => { setFi(i); setDraft(null); setActive(null) }} className={cn('flex shrink-0 items-center gap-1.5 rounded-full px-3 py-1.5 text-xs font-semibold transition', i === fi ? 'bg-navy text-white' : 'text-muted hover:bg-sunk hover:text-ink')}>{f.name} <span className="font-normal opacity-70">{f.w}×{f.h}</span>{n > 0 && <span className="rounded-full bg-accent px-1.5 text-[10px] text-white">{n}</span>}</button>
              })}
            </div>}
            {data.versions.length > 0 && (
              <label className="ml-auto flex shrink-0 items-center gap-1.5 text-xs text-muted">
                <History size={14} />
                <select value={data.version ?? ''} onChange={(e) => { setVer(e.target.value === String(data.latest) ? null : Number(e.target.value)); setDraft(null); setActive(null) }} className="h-8 rounded-lg bg-sunk px-2 text-xs font-semibold text-ink outline-none" aria-label="Versie">
                  {data.versions.map((v) => <option key={v.number} value={v.number}>Versie {v.number}{v.number === data.latest ? ' (nieuwste)' : ''}</option>)}
                </select>
              </label>
            )}
          </div>
          {data.version !== null && data.version !== data.latest && <p className="flex shrink-0 items-center gap-2 bg-[#fff4e5] px-4 py-2 text-xs font-medium text-[#8a4b00]"><History size={14} /> Je bekijkt een oudere versie. <button onClick={() => setVer(null)} className="font-semibold underline">Naar de nieuwste</button></p>}
          {curVersion?.note && data.version === data.latest && <p className="shrink-0 border-b border-line bg-surface/60 px-4 py-2 text-xs text-muted"><strong className="text-ink">Versie {curVersion.number}:</strong> {curVersion.note}</p>}
          {view === 'ad' ? (
            <div className="min-h-0 flex-1 overflow-auto px-3 pb-28 pt-5 sm:px-8"><div className="mx-auto max-w-3xl"><AdPreviewer frames={frames} brief={data.design.brief} pageName={data.design.title} compact /></div></div>
          ) : (
          <div ref={boxRef} className="relative grid min-h-0 flex-1 place-items-center overflow-hidden" onMouseDown={() => { setActive(null); if (!mode) setDraft(null) }}>
            {frames.length > 1 && <>
              <button onClick={() => setFi((fi - 1 + frames.length) % frames.length)} className="absolute left-3 top-1/2 z-10 grid h-10 w-10 -translate-y-1/2 place-items-center rounded-full bg-surface shadow-pop sm:hidden" aria-label="Vorig formaat"><ChevronLeft size={18} /></button>
              <button onClick={() => setFi((fi + 1) % frames.length)} className="absolute right-3 top-1/2 z-10 grid h-10 w-10 -translate-y-1/2 place-items-center rounded-full bg-surface shadow-pop sm:hidden" aria-label="Volgend formaat"><ChevronRight size={18} /></button>
            </>}
            <div className={cn('relative bg-surface shadow-pop', mode && 'cursor-comment')} style={{ width: W, height: H }}
              onMouseDown={(e) => {
                e.stopPropagation()
                if (!mode) { setActive(null); return }
                const r = e.currentTarget.getBoundingClientRect()
                setDraft({ x: Math.round((e.clientX - r.left) / scale), y: Math.round((e.clientY - r.top) / scale) }); setActive(null)
              }}>
              {img[frame.id] ? <img src={img[frame.id]} alt={frame.name} className="anim-overlay h-full w-full select-none" draggable={false} data-state="open" /> : <div className="grid h-full w-full place-items-center"><Loader2 className="animate-spin text-muted" /></div>}
              {here.map((t) => <Pin key={t.root.id} c={t.root} n={t.n} active={t.root.id === active} style={{ left: t.root.x! * scale, top: t.root.y! * scale }} onClick={() => { setActive(active === t.root.id ? null : t.root.id); setDraft(null) }} />)}
              {draft && <>
                <div className="comment-pin z-30" style={{ left: draft.x * scale, top: draft.y * scale }}><span className="grid h-8 w-8 place-items-center rounded-[16px_16px_16px_3px] border-2 border-white bg-accent text-white shadow-pop"><MessageSquarePlus size={14} /></span></div>
                <div className="anim-card absolute z-40 w-[300px] max-w-[calc(100vw-16px)] rounded-2xl max-sm:w-auto border border-line bg-surface p-2.5 shadow-pop" style={cardPos(draft.x, draft.y)} onMouseDown={(e) => e.stopPropagation()}>
                  <CommentComposer autoFocus placeholder="Wat wil je aangepast zien?" nameField={nameField} onCancel={() => setDraft(null)}
                    onSend={async (body) => { const c = await send(body, { frame_id: frame.id, x: draft.x, y: draft.y }); setDraft(null); setMode(false); setActive(c.id) }} />
                </div>
              </>}
              {act && act.root.frame_id === frame.id && act.root.x != null && (
                <div className="anim-card absolute z-40" style={cardPos(act.root.x, act.root.y!)} key={act.root.id} onMouseDown={(e) => e.stopPropagation()}>
                  <Thread className={narrow ? 'w-full max-w-none' : undefined} root={act.root} replies={act.replies} n={act.n} onClose={() => setActive(null)} nameField={nameField}
                    onReply={data.can_comment ? (body) => send(body, { parent_id: act.root.id, frame_id: frame.id }) : undefined} />
                </div>
              )}
            </div>
            {mode && !draft && <div className="pointer-events-none absolute left-1/2 top-4 -translate-x-1/2 rounded-full bg-navy px-4 py-2 text-sm font-semibold text-white shadow-pop anim-rise">Klik op de plek waar je iets over wilt zeggen</div>}
          </div>
          )}
          {data.can_comment && (data.version === data.latest) && (
            <div className="pointer-events-none absolute inset-x-0 bottom-4 z-30 flex justify-center px-3">
              <div className="anim-rise pointer-events-auto flex max-w-full items-center gap-2 rounded-2xl border border-line bg-surface p-1.5 pl-4 shadow-pop">
                {myDecision ? (
                  <>
                    {myDecision.decision === 'approved' ? <CheckCircle2 size={18} className="shrink-0 text-[#13A06B]" /> : <AlertCircle size={18} className="shrink-0 text-[#CC4A25]" />}
                    <span className="min-w-0 truncate text-sm"><strong>{myDecision.name}</strong> {myDecision.decision === 'approved' ? 'keurde dit goed' : 'vraagt aanpassingen'}</span>
                    <button onClick={() => setDecide(myDecision.decision === 'approved' ? 'changes' : 'approved')} className="shrink-0 rounded-xl px-3 py-2 text-xs font-semibold text-muted hover:bg-sunk hover:text-ink">Wijzigen</button>
                  </>
                ) : (
                  <>
                    <span className="hidden text-sm font-medium sm:inline">{data.latest ? `Versie ${data.latest}:` : ''} akkoord?</span>
                    <button onClick={() => setDecide('changes')} className="press flex h-10 shrink-0 items-center gap-1.5 rounded-xl px-3.5 text-sm font-semibold hover:bg-sunk"><AlertCircle size={16} className="text-[#CC4A25]" /> Aanpassingen</button>
                    <button onClick={() => setDecide('approved')} className="press flex h-10 shrink-0 items-center gap-1.5 rounded-xl bg-[#13A06B] px-4 text-sm font-semibold text-white hover:bg-[#0E8A5B]"><CheckCircle2 size={16} /> Goedkeuren</button>
                  </>
                )}
              </div>
            </div>
          )}
        </div>

        {list && (
          <aside className="anim-panel absolute inset-y-0 right-0 z-50 flex w-[340px] max-w-full flex-col border-l border-line bg-surface shadow-pop">
            <div className="flex h-12 shrink-0 items-center border-b border-line pl-4 pr-2"><span className="flex-1 text-sm font-semibold">Alle feedback</span><button onClick={() => setList(false)} className="grid h-8 w-8 place-items-center rounded-lg text-muted hover:bg-sunk" aria-label="Sluiten"><X size={17} /></button></div>
            <div className="min-h-0 flex-1 overflow-auto p-2">
              {!threads.length && <p className="px-4 py-10 text-center text-sm text-muted">Nog geen feedback. Klik op Punt plaatsen en daarna op het ontwerp.</p>}
              <ul className="grid gap-1">{threads.map((t) => {
                const fIdx = frames.findIndex((f) => f.id === t.root.frame_id)
                return (
                  <li key={t.root.id}><button onClick={() => { if (fIdx >= 0) setFi(fIdx); setActive(t.root.id); if (window.innerWidth < 768) setList(false) }} className={cn('w-full rounded-xl p-3 text-left transition hover:bg-sunk', active === t.root.id && 'bg-violet-soft/40', t.root.resolved && 'opacity-60')}>
                    <div className="mb-1.5 flex items-center gap-2 text-[11px] font-semibold text-muted"><span className="grid h-5 min-w-5 place-items-center rounded-[10px_10px_10px_2px] px-1 text-[10px] text-white" style={{ background: pinColor(t.root) }}>{t.n}</span>{fIdx >= 0 ? frames[fIdx].name : 'Algemeen'}{t.root.resolved && <span className="text-mint">afgehandeld</span>}{t.replies.length > 0 && <span className="ml-auto">{t.replies.length} {t.replies.length === 1 ? 'reactie' : 'reacties'}</span>}</div>
                    <CommentItem c={t.root} />
                  </button></li>
                )
              })}</ul>
            </div>
            {data.can_comment && <div className="border-t border-line p-3"><CommentComposer placeholder="Algemene opmerking…" nameField={nameField} onSend={(body) => send(body, {})} /></div>}
          </aside>
        )}
      </div>
    </div>
  )
}

function DecideDialog({ kind, onClose, onSubmit, version, name, setName }: { kind: 'approved' | 'changes' | null; onClose: () => void; onSubmit: (k: 'approved' | 'changes', name: string, note: string) => Promise<void>; version: number | null; name: string; setName: (v: string) => void }) {
  const [note, setNote] = useState('')
  const [busy, setBusy] = useState(false)
  const [err, setErr] = useState<string | null>(null)
  useEffect(() => { setNote(''); setErr(null) }, [kind])
  if (!kind) return null
  const ok = kind === 'approved'
  return (
    <Dialog open={!!kind} onOpenChange={(o) => !o && onClose()} title={ok ? 'Goedkeuren' : 'Aanpassingen vragen'} description={ok ? `Je geeft akkoord op ${version ? `versie ${version}` : 'dit ontwerp'}. Het team krijgt direct een melding.` : 'Laat weten wat er anders moet. Losse punten op het ontwerp kun je ook met "Punt plaatsen" toevoegen.'}>
      <div className="grid gap-3">
        <label className="grid gap-1.5"><span className="text-sm font-semibold">Je naam</span><input value={name} onChange={(e) => setName(e.target.value)} className="h-10 rounded-lg bg-sunk px-3 text-sm outline-none ring-violet focus:ring-2" placeholder="Voor- en achternaam" /></label>
        <label className="grid gap-1.5"><span className="text-sm font-semibold">{ok ? 'Opmerking (optioneel)' : 'Wat moet er anders?'}</span><textarea value={note} onChange={(e) => setNote(e.target.value)} rows={4} className="resize-none rounded-lg bg-sunk px-3 py-2 text-sm outline-none ring-violet focus:ring-2" placeholder={ok ? 'Bijv. akkoord, mag live vanaf maandag' : 'Bijv. liever een andere foto en de kop korter'} /></label>
        {err && <p className="text-sm text-[#CC4A25]">{err}</p>}
        <div className="flex justify-end gap-2">
          <button onClick={onClose} className="h-10 rounded-full px-4 text-sm font-semibold hover:bg-sunk">Annuleren</button>
          <button disabled={busy || !name.trim() || (!ok && !note.trim())} onClick={async () => { setBusy(true); setErr(null); try { await onSubmit(kind, name.trim(), note.trim()) } catch (e) { setErr((e as Error).message) } finally { setBusy(false) } }}
            className={cn('press flex h-10 items-center gap-2 rounded-full px-5 text-sm font-semibold text-white disabled:opacity-40', ok ? 'bg-[#13A06B]' : 'bg-[#CC4A25]')}>{busy ? <Loader2 size={16} className="animate-spin" /> : ok ? <CheckCircle2 size={16} /> : <AlertCircle size={16} />} {ok ? 'Akkoord geven' : 'Versturen'}</button>
        </div>
      </div>
    </Dialog>
  )
}
