import { useEffect, useState } from 'react'
import { Plus, Trash2, Upload, X, Globe, Loader2 } from 'lucide-react'
import { useLiveReload } from '../lib/live'
import { deleteKit, listKits, saveKit, uploadAsset, scanBrand, importRemoteImage, importSvg } from '../lib/api'
import type { BrandKit } from '../lib/types'
import { FONTS, loadFont, localFonts } from '../lib/fonts'
import { useSession } from '../store/session'
import { DAAROM_KIT } from '../lib/brand'
import { Button, Dialog, Input, Label, Select } from '../ui/ui'
import { cn as cx } from '../ui/ui'

export function KitEditor({ kit, open, onOpenChange, onSaved }: { kit: Partial<BrandKit> | null; open: boolean; onOpenChange: (o: boolean) => void; onSaved: () => void }) {
  const { user } = useSession()
  const [k, setK] = useState<Partial<BrandKit>>({ name: '', colors: [], fonts: [], logos: [] })
  const [color, setColor] = useState('#EA5F39')
  const [busy, setBusy] = useState(false)
  const [site, setSite] = useState('')
  const [scanning, setScanning] = useState<string | null>(null)
  const [scanErr, setScanErr] = useState<string | null>(null)
  useEffect(() => { if (kit) { setK({ colors: [], fonts: [], logos: [], ...kit }); setSite(''); setScanErr(null) } }, [kit])
  const scan = async () => {
    if (!site.trim()) return
    setScanErr(null); setScanning('Website uitlezen…')
    try {
      const r = await scanBrand(site.trim())
      const colors = [...r.brandColors.slice(0, 6).map((c) => c.hex), ...r.neutralColors.filter((c) => c.hex !== '#FFFFFF' && c.hex !== '#000000').slice(0, 1).map((c) => c.hex), '#FFFFFF']
      const fonts = r.fonts.filter((f) => !/icon|awesome|symbol|dashicons|glyph|fontello|eicons|ionicons|feather/i.test(f)).slice(0, 3)
      setScanning("Logo's en beelden ophalen…")
      const logos: BrandKit['logos'] = []
      const top = Math.max(0, ...r.logos.map((x) => x.score))
      for (const [i, l] of r.logos.filter((x) => x.source !== 'icon' && x.score >= top * 0.6).slice(0, 3).entries()) {
        try {
          const a = l.svg ? await importSvg(l.svg, user!.id, `${r.name}-logo-${i + 1}`) : await importRemoteImage(l.url!, user!.id, `${r.name}-logo-${i + 1}`)
          logos.push({ url: a.url, name: `Logo ${i + 1}` })
        } catch { /* overslaan */ }
      }
      for (const [i, u] of r.images.slice(0, 4).entries()) {
        try { const a = await importRemoteImage(u, user!.id, `${r.name}-beeld-${i + 1}`); logos.push({ url: a.url, name: `Beeld ${i + 1}` }) } catch { /* overslaan */ }
      }
      setK((cur) => ({ ...cur, name: cur.name || r.name, colors: [...new Set([...(cur.colors || []), ...colors])], fonts: [...new Set([...(cur.fonts || []), ...fonts])], logos: [...(cur.logos || []), ...logos] }))
      fonts.forEach(loadFont)
    } catch (e) { setScanErr((e as Error).message) } finally { setScanning(null) }
  }
  const upload = async (files: FileList | null) => {
    if (!files) return
    setBusy(true)
    try {
      const logos = [...(k.logos || [])]
      for (const f of Array.from(files)) { const a = await uploadAsset(f, user!.id, true); logos.push({ url: a.url, name: f.name }) }
      setK({ ...k, logos })
    } finally { setBusy(false) }
  }
  return (
    <Dialog open={open} onOpenChange={onOpenChange} title={k.id ? 'Merkset bewerken' : 'Nieuwe merkset'} description="Kleuren, lettertypes en logo's van een klant. Iedereen in het team kan ze gebruiken.">
      <div className="grid gap-5">
        <div className="grid gap-2 rounded-[20px] bg-mist p-4 dark:bg-sunk">
          <Label>Automatisch invullen vanaf de website</Label>
          <div className="flex gap-2">
            <div className="relative flex-1"><Globe size={16} className="absolute left-3 top-1/2 -translate-y-1/2 text-muted" />
              <Input value={site} onChange={(e) => setSite(e.target.value)} onKeyDown={(e) => e.key === 'Enter' && scan()} placeholder="www.klant.nl" className="bg-surface pl-9" aria-label="Website van de klant" /></div>
            <Button variant="primary" onClick={scan} disabled={!!scanning || !site.trim()}>{scanning ? <Loader2 size={16} className="animate-spin" /> : null} Scan</Button>
          </div>
          <p className="text-xs leading-relaxed text-muted">{scanning || 'We halen kleuren, lettertypes, logo\'s en beelden van de site. Controleer daarna wat klopt en verwijder wat niet past.'}</p>
          {scanErr && <p role="alert" className="text-sm text-accent-fg">{scanErr}</p>}
        </div>
        <div className="grid gap-1.5"><Label>Naam</Label><Input value={k.name || ''} onChange={(e) => setK({ ...k, name: e.target.value })} placeholder="Bijvoorbeeld: Bleyenberg" /></div>
        <div className="grid gap-2"><Label>Kleuren</Label>
          <div className="flex flex-wrap items-center gap-2">
            {(k.colors || []).map((c, i) => (
              <button key={c + i} title="Verwijderen" aria-label={`Kleur ${c} verwijderen`} onClick={() => setK({ ...k, colors: k.colors!.filter((_, j) => j !== i) })} className="group relative h-10 w-10 rounded-lg border border-line" style={{ background: c }}>
                <X size={14} className="absolute -right-1.5 -top-1.5 rounded-full bg-navy p-0.5 text-white opacity-70 ring-2 ring-surface group-hover:opacity-100" />
              </button>
            ))}
            <input type="color" value={color} onChange={(e) => setColor(e.target.value)} className="h-10 w-12 cursor-pointer rounded-lg border border-line p-0.5" aria-label="Kleur kiezen" />
            <Input value={color} onChange={(e) => setColor(e.target.value)} className="!w-28 font-mono uppercase" aria-label="Hexcode" />
            <Button size="sm" onClick={() => /^#[0-9a-f]{6}$/i.test(color) && setK({ ...k, colors: [...(k.colors || []), color] })}><Plus size={15} /> Toevoegen</Button>
          </div>
        </div>
        <div className="grid gap-2"><Label>Lettertypes</Label>
          <div className="flex flex-wrap gap-2">{(k.fonts || []).map((f, i) => (
            <span key={f} className="inline-flex items-center gap-1.5 rounded-lg bg-sunk px-2.5 py-1.5 text-sm"><span className="text-xs text-muted">{i === 0 ? 'Koppen' : 'Tekst'}</span> {f}
              <button aria-label={`${f} verwijderen`} onClick={() => setK({ ...k, fonts: k.fonts!.filter((x) => x !== f) })}><X size={13} /></button></span>
          ))}</div>
          <Select value="" onChange={(v) => v && setK({ ...k, fonts: [...new Set([...(k.fonts || []), v])] })} options={[{ value: '', label: 'Lettertype toevoegen…' }, ...localFonts().map((f) => ({ value: f.name, label: `${f.name} (lokaal)` })), ...FONTS.map((f) => ({ value: f.name, label: f.name }))]} />
          {(k.fonts || []).some((f) => !FONTS.find((x) => x.name === f) && !localFonts().some((x) => x.name === f)) && <p className="text-xs text-muted">Lettertypes die niet bij Google Fonts staan (zoals betaalde fonts) worden vervangen door een standaardletter in het canvas. Kies dan een Google-alternatief.</p>}
        </div>
        <div className="grid gap-2"><Label>Logo's</Label>
          <div className="flex flex-wrap gap-2">
            {(k.logos || []).map((l, i) => (
              <div key={l.url} className="checker group relative grid h-20 w-20 place-items-center rounded-lg border border-line p-1.5 [&>img]:min-h-0">
                <img src={l.url} alt={l.name} className="h-full w-full object-contain" />
                <button aria-label="Logo verwijderen" onClick={() => setK({ ...k, logos: k.logos!.filter((_, j) => j !== i) })} className="absolute -right-1.5 -top-1.5 rounded-full bg-navy p-0.5 text-white opacity-70 ring-2 ring-surface group-hover:opacity-100"><X size={12} /></button>
              </div>
            ))}
            <label className="grid h-20 w-20 cursor-pointer place-items-center rounded-lg border-2 border-dashed border-line text-muted hover:border-ink hover:text-ink">
              <Upload size={18} /><input type="file" accept="image/*" multiple className="hidden" onChange={(e) => upload(e.target.files)} />
            </label>
          </div>
        </div>
        <Button variant="primary" disabled={!k.name?.trim() || busy} onClick={async () => { setBusy(true); try { await saveKit(k); onSaved(); onOpenChange(false) } finally { setBusy(false) } }}>Opslaan</Button>
      </div>
    </Dialog>
  )
}

export default function BrandKits() {
  const [kits, setKits] = useState<BrandKit[]>([])
  const [edit, setEdit] = useState<Partial<BrandKit> | null>(null)
  const load = () => listKits().then((k) => setKits([DAAROM_KIT(), ...k]))
  useEffect(() => { load() }, [])
  useLiveReload(['brand_kits'], load)
  return (
    <div className="grid gap-5">
      <div className="flex items-center justify-between"><h2 className="font-display text-2xl font-bold">Merksets</h2><Button variant="primary" onClick={() => setEdit({ name: '', colors: [], fonts: [], logos: [] })}><Plus size={17} /> Nieuwe merkset</Button></div>
      {kits.length === 0 && <p className="rounded-xl border-2 border-dashed border-line p-10 text-center text-muted">Nog geen merksets. Maak er een per klant, dan staan kleuren, lettertypes en logo's direct klaar in de editor.</p>}
      <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
        {kits.map((k) => (
          <div key={k.id} className="grid gap-3 rounded-2xl border border-line bg-surface p-4">
            <div className="flex items-center justify-between"><div className="font-display text-lg font-bold">{k.name}</div>
              {k.id !== 'daar-om-builtin' && <button className="rounded-md p-1.5 text-muted hover:bg-sunk" aria-label="Verwijderen" onClick={async () => { await deleteKit(k.id); load() }}><Trash2 size={16} /></button>}</div>
            <div className="flex h-10 overflow-hidden rounded-lg">{k.colors.length ? k.colors.map((c, i) => <span key={i} className="flex-1" style={{ background: c }} />) : <span className="flex-1 bg-sunk" />}</div>
            {k.logos.length > 0 && <div className="grid grid-cols-3 gap-2">{k.logos.slice(0, 3).map((l) => (
              <span key={l.url} className={cx('grid h-14 min-w-0 place-items-center overflow-hidden rounded-lg p-2', /wit|white/i.test(l.url + l.name) ? 'bg-[#1B213B]' : 'bg-[#EEF4FA]')}>
                <img src={l.url} alt={l.name} className="max-h-full max-w-full object-contain" />
              </span>
            ))}</div>}
            <div className="text-sm text-muted">{k.fonts.join(', ') || 'Geen lettertypes'} · {k.logos.length} logo's</div>
            {k.id === 'daar-om-builtin' ? <p className="text-xs text-muted">Vaste huisstijl van daar-om.nl, overgenomen van de website.</p> : <Button size="sm" onClick={() => setEdit(k)}>Bewerken</Button>}
          </div>
        ))}
      </div>
      <KitEditor kit={edit} open={!!edit} onOpenChange={(o) => !o && setEdit(null)} onSaved={load} />
    </div>
  )
}
