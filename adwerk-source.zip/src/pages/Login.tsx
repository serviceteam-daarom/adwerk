import { useState } from 'react'
import { signInWithGoogle } from '../lib/supabase'
import { Button } from '../ui/ui'
import { brandUrl } from '../lib/brand'
import { PlatformLogos } from '../ui/PlatformLogo'

const asset = (f: string) => new URL(`./${f}`, window.location.href.split('#')[0]).href

/** Adwerk-logo: woordmerk in de letter van daar-om.nl met eigen beeldmerk (spraakwolk-frame). */
export function Logo({ light, size = 34, markOnly }: { light?: boolean; size?: number; markOnly?: boolean }) {
  if (markOnly) return <img src={asset(light ? 'adwerk-mark-wit.svg' : 'adwerk-mark.svg')} alt="Adwerk" style={{ height: size, width: size }} />
  if (light) return <img src={asset('adwerk-logo-wit.svg')} alt="Adwerk by daar-om.nl" style={{ height: size, width: 'auto', maxWidth: 'none' }} />
  return (
    <>
      <img src={asset('adwerk-logo.svg')} alt="Adwerk by daar-om.nl" className="dark:hidden" style={{ height: size, width: 'auto', maxWidth: 'none' }} />
      <img src={asset('adwerk-logo-wit.svg')} alt="Adwerk by daar-om.nl" className="hidden dark:block" style={{ height: size, width: 'auto', maxWidth: 'none' }} />
    </>
  )
}

export function GoogleG({ size = 18 }: { size?: number }) {
  return (
    <span className="grid shrink-0 place-items-center rounded-full bg-white" style={{ width: size + 10, height: size + 10 }}>
      <svg width={size} height={size} viewBox="0 0 48 48" aria-hidden><path fill="#FFC107" d="M43.6 20.5H42V20H24v8h11.3C33.7 32.7 29.2 36 24 36c-6.6 0-12-5.4-12-12s5.4-12 12-12c3.1 0 5.8 1.2 7.9 3.1l5.7-5.7C34 6.1 29.3 4 24 4 12.9 4 4 12.9 4 24s8.9 20 20 20 20-8.9 20-20c0-1.3-.1-2.4-.4-3.5z"/><path fill="#FF3D00" d="m6.3 14.7 6.6 4.8C14.7 15.1 19 12 24 12c3.1 0 5.8 1.2 7.9 3.1l5.7-5.7C34 6.1 29.3 4 24 4 16.3 4 9.7 8.3 6.3 14.7z"/><path fill="#4CAF50" d="M24 44c5.2 0 9.9-2 13.4-5.2l-6.2-5.2C29.2 35.1 26.7 36 24 36c-5.2 0-9.6-3.3-11.3-7.9l-6.5 5C9.5 39.6 16.2 44 24 44z"/><path fill="#1976D2" d="M43.6 20.5H42V20H24v8h11.3c-.8 2.2-2.2 4.2-4.1 5.6l6.2 5.2C37 39.2 44 34 44 24c0-1.3-.1-2.4-.4-3.5z"/></svg>
    </span>
  )
}

export default function Login({ error }: { error: string | null }) {
  const [busy, setBusy] = useState(false)
  const [err, setErr] = useState<string | null>(error)
  const go = async () => {
    setBusy(true)
    const { error } = await signInWithGoogle()
    if (error) { setErr(error.message); setBusy(false) }
  }
  return (
    <div className="grid min-h-full bg-mist lg:grid-cols-[1.1fr_1fr]">
      <div className="relative hidden overflow-hidden rounded-br-[180px] bg-navy p-12 text-white lg:flex lg:flex-col lg:justify-between">
        <div className="self-start"><Logo light size={48} /></div>
        <div className="relative z-10 max-w-lg xl:max-w-[440px]">
          <h1 className="font-display text-[56px] font-medium leading-[1.08] tracking-tight">Eén ontwerp.<br /><strong className="font-bold">Elk formaat<span className="text-lila">.</span></strong></h1>
          <p className="mt-5 max-w-md text-lg text-white/75">Social ads, geanimeerde HTML5 banners en GIF's maken met het hele team, in één bestand tegelijk.</p>
          <div className="mt-10 flex items-start gap-2">
            <span className="font-hand text-2xl text-white/90">Ontworpen in Groningen!</span>
            <img src={brandUrl('pijl-oranje-3.svg')} alt="" className="h-12 w-12 -translate-y-3" />
          </div>
        </div>
        <div className="relative z-10 flex items-center gap-4" aria-label="Meta, Instagram, LinkedIn, Google Ads, YouTube en TikTok">
          <PlatformLogos platforms={['Facebook', 'Instagram', 'LinkedIn', 'Google Ads', 'YouTube', 'TikTok']} size={22} mono="rgba(255,255,255,.75)" />
        </div>
        <img aria-hidden src={brandUrl('martinitoren.svg')} alt="" className="pointer-events-none absolute -bottom-6 right-4 h-[62%] opacity-25 xl:right-16 xl:h-[78%] xl:opacity-95" />
      </div>
      <div className="flex items-center justify-center p-8">
        <div className="w-full max-w-sm">
          <div className="mb-10 flex lg:hidden"><Logo size={44} /></div>
          <h2 className="font-display text-3xl font-medium">Welkom <strong className="font-bold">terug</strong><span className="text-accent-fg">.</span></h2>
          <p className="mt-2 text-muted">Log in met je Google-account van <span className="whitespace-nowrap">daar-om.nl</span>.</p>
          <Button variant="primary" size="lg" className="mt-8 w-full pl-2" onClick={go} disabled={busy}>
            <GoogleG />
            {busy ? 'Doorsturen naar Google…' : 'Inloggen met Google'}
          </Button>
          {err && <p role="alert" className="mt-4 rounded-lg bg-accent-soft px-3 py-2.5 text-sm text-accent-fg">{err}</p>}
          <p className="mt-8 text-xs leading-relaxed text-muted">Alleen medewerkers met een @daar-om.nl account hebben toegang. Je ontwerpen worden veilig opgeslagen en zijn alleen zichtbaar voor jou, tenzij je ze deelt met het team.</p>
        </div>
      </div>
    </div>
  )
}
