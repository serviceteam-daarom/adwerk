import { useState } from 'react'
import { signInWithGoogle } from '../lib/supabase'
import { Button } from '../ui/ui'

export function Logo({ light, size = 26 }: { light?: boolean; size?: number }) {
  return (
    <span className="font-display font-extrabold tracking-tight" style={{ fontSize: size, color: light ? '#fff' : '#1A1726' }}>
      Adwerk<span className="text-accent">.</span>
    </span>
  )
}

export default function Login({ error }: { error: string | null }) {
  const [busy, setBusy] = useState(false)
  const [err, setErr] = useState<string | null>(error)
  const go = async () => {
    setBusy(true)
    const { error } = await signInWithGoogle()
    if (error) { setErr(error.message); setBusy(false) }
  }
  return (
    <div className="grid min-h-full lg:grid-cols-[1.1fr_1fr]">
      <div className="relative hidden overflow-hidden bg-ink p-12 text-white lg:flex lg:flex-col lg:justify-between">
        <Logo light size={30} />
        <div className="relative z-10 max-w-lg">
          <h1 className="font-display text-6xl font-extrabold leading-[1.02] tracking-tight">Eén ontwerp.<br />Elk formaat.</h1>
          <p className="mt-5 text-lg text-white/70">Social ads, geanimeerde HTML5 banners en GIF's maken met het hele team, in één bestand tegelijk.</p>
        </div>
        <div className="relative z-10 flex gap-3 text-sm text-white/60">
          <span>Meta</span><span aria-hidden>·</span><span>LinkedIn</span><span aria-hidden>·</span><span>Google Display</span><span aria-hidden>·</span><span>Demand Gen</span>
        </div>
        {/* formaatblokken als decor */}
        <div aria-hidden className="pointer-events-none absolute right-[-60px] top-24 grid grid-cols-3 gap-4 opacity-90">
          <div className="h-40 w-40 rounded-2xl bg-accent" />
          <div className="h-52 w-32 rounded-2xl bg-violet" />
          <div className="h-64 w-28 rounded-2xl bg-sun" />
          <div className="col-span-2 h-24 rounded-2xl bg-mint" />
          <div className="h-24 w-28 rounded-2xl border-2 border-white/20" />
        </div>
      </div>
      <div className="flex items-center justify-center p-8">
        <div className="w-full max-w-sm">
          <div className="mb-10 lg:hidden"><Logo size={32} /></div>
          <h2 className="font-display text-3xl font-bold">Welkom terug</h2>
          <p className="mt-2 text-muted">Log in met je Google-account van daar-om.nl.</p>
          <Button variant="dark" size="lg" className="mt-8 w-full" onClick={go} disabled={busy}>
            <svg width="20" height="20" viewBox="0 0 48 48" aria-hidden><path fill="#FFC107" d="M43.6 20.5H42V20H24v8h11.3C33.7 32.7 29.2 36 24 36c-6.6 0-12-5.4-12-12s5.4-12 12-12c3.1 0 5.8 1.2 7.9 3.1l5.7-5.7C34 6.1 29.3 4 24 4 12.9 4 4 12.9 4 24s8.9 20 20 20 20-8.9 20-20c0-1.3-.1-2.4-.4-3.5z"/><path fill="#FF3D00" d="m6.3 14.7 6.6 4.8C14.7 15.1 19 12 24 12c3.1 0 5.8 1.2 7.9 3.1l5.7-5.7C34 6.1 29.3 4 24 4 16.3 4 9.7 8.3 6.3 14.7z"/><path fill="#4CAF50" d="M24 44c5.2 0 9.9-2 13.4-5.2l-6.2-5.2C29.2 35.1 26.7 36 24 36c-5.2 0-9.6-3.3-11.3-7.9l-6.5 5C9.5 39.6 16.2 44 24 44z"/><path fill="#1976D2" d="M43.6 20.5H42V20H24v8h11.3c-.8 2.2-2.2 4.2-4.1 5.6l6.2 5.2C37 39.2 44 34 44 24c0-1.3-.1-2.4-.4-3.5z"/></svg>
            {busy ? 'Doorsturen naar Google…' : 'Inloggen met Google'}
          </Button>
          {err && <p role="alert" className="mt-4 rounded-lg bg-accent-soft px-3 py-2.5 text-sm text-accent-dark">{err}</p>}
          <p className="mt-8 text-xs leading-relaxed text-muted">Alleen medewerkers met een @daar-om.nl account hebben toegang. Je ontwerpen worden veilig opgeslagen en zijn alleen zichtbaar voor jou, tenzij je ze deelt met het team.</p>
        </div>
      </div>
    </div>
  )
}
