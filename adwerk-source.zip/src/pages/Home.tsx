import { useCallback, useEffect, useMemo, useState } from 'react'
import { Plus, Home as HomeIcon, User, Users, LayoutTemplate, Folder as FolderIcon, Palette, MoreHorizontal, Copy, Trash2, Share2, FolderInput, Pencil, Search, Lock, Globe2, Menu as MenuIcon, X } from 'lucide-react'
import { useSession, displayName } from '../store/session'
import { createDesign, createFolder, deleteDesign, deleteFolder, duplicateDesign, listDesigns, listFolders, listProfiles, saveDesign } from '../lib/api'
import type { DesignRow, Folder, Profile } from '../lib/types'
import { SETS, PLATFORMS } from '../lib/formats'
import { docFromFormats, makeFrame } from '../lib/factory'
import { Button, Dialog, Input, Label, Menu, MenuContent, MenuItem, MenuSep, MenuTrigger, Segmented, cn, Toast, Tip, Sheet } from '../ui/ui'
import { PlatformLogos } from '../ui/PlatformLogo'
import { SetCard } from '../ui/SetCard'
import { useLiveReload } from '../lib/live'
import { ChatButton } from '../ui/Chat'
import { AccountMenu } from '../ui/AccountMenu'
import { OnlineList, OnlineAvatars, OnlineStack } from '../ui/OnlineList'
import { brandUrl } from '../lib/brand'
import { Logo } from './Login'
import { navigate } from '../App'
import BrandKits from './BrandKits'

type Row = Omit<DesignRow, 'data'>

function timeAgo(iso: string) {
  const s = (Date.now() - new Date(iso).getTime()) / 1000
  if (s < 60) return 'zojuist'
  if (s < 3600) return `${Math.floor(s / 60)} min geleden`
  if (s < 86400) return `${Math.floor(s / 3600)} uur geleden`
  if (s < 86400 * 7) return `${Math.floor(s / 86400)} dagen geleden`
  return new Date(iso).toLocaleDateString('nl-NL', { day: 'numeric', month: 'short', year: 'numeric' })
}

export function NewDesignDialog({ open, onOpenChange, folderId }: { open: boolean; onOpenChange: (o: boolean) => void; folderId?: string | null }) {
  const [sel, setSel] = useState<string[]>(['meta-sq', 'meta-45', 'meta-story'])
  const [title, setTitle] = useState('')
  const [cw, setCw] = useState(1080)
  const [ch, setCh] = useState(1080)
  const [busy, setBusy] = useState(false)
  const toggle = (k: string) => setSel((s) => (s.includes(k) ? s.filter((x) => x !== k) : [...s, k]))
  const create = async (keys: string[], name?: string, custom?: { w: number; h: number }) => {
    setBusy(true)
    try {
      const doc = docFromFormats(keys)
      if (custom) doc.frames.push(makeFrame({ key: 'custom', name: 'Eigen formaat', w: custom.w, h: custom.h, platform: 'Eigen' }))
      const id = await createDesign(name || title || 'Naamloos ontwerp', doc, { folder_id: folderId || null, visibility: folderId ? 'team' : 'private' })
      onOpenChange(false)
      navigate(`/d/${id}`)
    } finally { setBusy(false) }
  }
  return (
    <Dialog open={open} onOpenChange={onOpenChange} title="Nieuw ontwerp" description="Kies een set of stel zelf je formaten samen. Je kunt later altijd formaten toevoegen." wide>
      <div className="grid gap-6">
        <div className="grid grid-cols-1 gap-3 sm:grid-cols-2 md:grid-cols-3">
          {SETS.map((s) => <SetCard key={s.key} set={s} disabled={busy} onClick={() => create(s.formats, s.name)} />)}
        </div>
        <div className="grid gap-3 rounded-[20px] border border-line p-4">
          <Label>Zelf samenstellen</Label>
          <div className="grid max-h-64 gap-4 overflow-auto pr-1 sm:grid-cols-2">
            {PLATFORMS.map((p) => (
              <div key={p.name} className="grid content-start gap-1">
                <div className="flex items-center gap-2 text-sm font-semibold"><PlatformLogos platforms={p.logos} size={16} />{p.name}</div>
                {p.formats.map((f) => (
                  <label key={f.key} className="flex cursor-pointer items-center gap-2 rounded-lg px-1.5 py-1 text-sm hover:bg-sunk">
                    <input type="checkbox" checked={sel.includes(f.key)} onChange={() => toggle(f.key)} className="h-4 w-4 accent-[#EA5F39]" />
                    <span className="flex-1">{f.name}</span>
                    <span className="tabular-nums text-xs text-muted">{f.w}×{f.h}</span>
                  </label>
                ))}
              </div>
            ))}
          </div>
          <div className="flex flex-wrap items-center gap-2">
            <Input placeholder="Naam van het ontwerp" value={title} onChange={(e) => setTitle(e.target.value)} className="min-w-[200px] flex-1" />
            <Button variant="primary" disabled={!sel.length || busy} onClick={() => create(sel)}>Maak {sel.length} formaten</Button>
          </div>
        </div>
        <div className="flex flex-wrap items-end gap-2">
          <div className="grid gap-1"><Label>Eigen formaat</Label>
            <div className="flex items-center gap-2"><Input type="number" value={cw} onChange={(e) => setCw(+e.target.value)} className="w-24" aria-label="Breedte" /><span className="text-muted">×</span><Input type="number" value={ch} onChange={(e) => setCh(+e.target.value)} className="w-24" aria-label="Hoogte" /><span className="text-sm text-muted">px</span></div>
          </div>
          <Button disabled={busy || cw < 10 || ch < 10} onClick={() => create([], title || `Eigen formaat ${cw}×${ch}`, { w: cw, h: ch })}>Maak eigen formaat</Button>
        </div>
      </div>
    </Dialog>
  )
}

function DesignCard({ d, me, owner, folders, onChanged, toast }: { d: Row; me: string; owner?: Profile; folders: Folder[]; onChanged: () => void; toast: (t: string) => void }) {
  const [rename, setRename] = useState(false)
  const [name, setName] = useState(d.title)
  const mine = d.owner_id === me
  const doRename = async () => { setRename(false); if (name.trim() && name !== d.title) { await saveDesign(d.id, { title: name.trim() }, me); onChanged() } }
  return (
    <div className="group grid min-w-0 grid-cols-[minmax(0,1fr)] gap-2">
      <button onClick={() => navigate(`/d/${d.id}`)} className="relative grid aspect-[4/3] place-items-center overflow-hidden rounded-[20px] border border-line bg-surface transition group-hover:-translate-y-0.5 group-hover:shadow-pop dark:bg-sunk">
        {d.thumbnail ? <img src={d.thumbnail} alt="" className="max-h-[86%] max-w-[86%] rounded-sm object-contain shadow-card" /> : <span className="font-display text-3xl font-bold text-line">Aa</span>}
        {d.is_template && <span className="absolute left-0 top-0 rounded-blob bg-navy px-3 py-1 text-[11px] font-semibold text-white">Template<span className="text-lila">.</span></span>}
        <span className="absolute right-2 top-2"><OnlineAvatars designId={d.id} /></span>
      </button>
      <div className="flex items-start gap-2">
        <div className="min-w-0 flex-1">
          {rename ? (
            <Input autoFocus value={name} onChange={(e) => setName(e.target.value)} onBlur={doRename} onKeyDown={(e) => e.key === 'Enter' && doRename()} className="h-7" />
          ) : (
            <div className="truncate font-semibold" title={d.title}>{d.title}</div>
          )}
          <div className="flex items-center gap-1.5 text-xs text-muted">
            {d.visibility === 'team' ? <Globe2 size={12} aria-label="Gedeeld met team" /> : <Lock size={12} aria-label="Privé" />}
            <span className="truncate">{mine ? 'Jij' : owner ? displayName(owner) : 'Teamlid'} · {timeAgo(d.updated_at)}</span>
          </div>
        </div>
        <Menu>
          <MenuTrigger className="rounded-full p-1.5 text-muted hover:bg-sunk hover:text-ink" aria-label="Meer acties"><MoreHorizontal size={18} /></MenuTrigger>
          <MenuContent>
            <MenuItem onSelect={() => navigate(`/d/${d.id}`)}><Pencil size={15} /> Openen</MenuItem>
            <MenuItem onSelect={() => setRename(true)}><Pencil size={15} /> Naam wijzigen</MenuItem>
            <MenuItem onSelect={async () => { const id = await duplicateDesign(d.id); toast('Kopie gemaakt'); onChanged(); void id }}><Copy size={15} /> Dupliceren</MenuItem>
            <MenuItem onSelect={async () => { await saveDesign(d.id, { visibility: d.visibility === 'team' ? 'private' : 'team' }, me); toast(d.visibility === 'team' ? 'Alleen nog zichtbaar voor jou' : 'Gedeeld met het team'); onChanged() }}><Share2 size={15} /> {d.visibility === 'team' ? 'Niet meer delen' : 'Delen met team'}</MenuItem>
            <MenuItem onSelect={async () => { await saveDesign(d.id, { is_template: !d.is_template }, me); toast(d.is_template ? 'Geen template meer' : 'Opgeslagen als teamtemplate'); onChanged() }}><LayoutTemplate size={15} /> {d.is_template ? 'Geen template meer' : 'Maak teamtemplate'}</MenuItem>
            {folders.length > 0 && <MenuSep />}
            {folders.map((f) => (
              <MenuItem key={f.id} onSelect={async () => { await saveDesign(d.id, { folder_id: f.id }, me); toast(`Verplaatst naar ${f.name}`); onChanged() }}><FolderInput size={15} /> Naar {f.name}</MenuItem>
            ))}
            {d.folder_id && <MenuItem onSelect={async () => { await saveDesign(d.id, { folder_id: null }, me); onChanged() }}><FolderInput size={15} /> Uit project halen</MenuItem>}
            {mine && <><MenuSep /><MenuItem danger onSelect={async () => { await deleteDesign(d.id); toast('Verwijderd'); onChanged() }}><Trash2 size={15} /> Verwijderen</MenuItem></>}
          </MenuContent>
        </Menu>
      </div>
    </div>
  )
}

export default function Home({ route }: { route: string }) {
  const { user } = useSession()
  const me = user!.id
  const [rows, setRows] = useState<Row[]>([])
  const [folders, setFolders] = useState<Folder[]>([])
  const [profiles, setProfiles] = useState<Profile[]>([])
  const [loading, setLoading] = useState(true)
  const [newOpen, setNewOpen] = useState(false)
  const [folderOpen, setFolderOpen] = useState(false)
  const [folderName, setFolderName] = useState('')
  const [folderVis, setFolderVis] = useState<'team' | 'private'>('team')
  const [q, setQ] = useState('')
  const [toastText, setToastText] = useState<string | null>(null)
  const toast = (t: string) => { setToastText(t); setTimeout(() => setToastText(null), 2200) }

  const scope: 'recent' | 'mine' | 'team' | 'templates' | 'folder' | 'brand' =
    route.startsWith('/folder/') ? 'folder' : route === '/mine' ? 'mine' : route === '/team' ? 'team' : route === '/templates' ? 'templates' : route === '/brand' ? 'brand' : 'recent'
  const folderId = scope === 'folder' ? route.split('/')[2] : undefined
  const folder = folders.find((f) => f.id === folderId)

  const load = useCallback(async () => {
    if (scope === 'brand') { setLoading(false); return }
    setLoading(true)
    try { setRows(await listDesigns({ scope, userId: me, folderId })) } finally { setLoading(false) }
  }, [scope, me, folderId])

  useEffect(() => { load() }, [load])
  useEffect(() => { listFolders().then(setFolders); listProfiles().then(setProfiles) }, [])

  // live bijwerken (zonder laadscherm) als iemand iets wijzigt
  useLiveReload(['designs', 'design_members'], () => { if (scope !== 'brand') listDesigns({ scope, userId: me, folderId }).then(setRows).catch(() => {}) })
  useLiveReload(['folders'], () => { listFolders().then(setFolders) })
  useLiveReload(['profiles'], () => { listProfiles().then(setProfiles) })

  const pmap = useMemo(() => new Map(profiles.map((p) => [p.id, p])), [profiles])
  const shown = rows.filter((r) => r.title.toLowerCase().includes(q.toLowerCase()))
  const titles: Record<string, string> = { recent: 'Recent', mine: 'Mijn bestanden', team: 'Gedeeld met mij', templates: 'Teamtemplates', folder: folder?.name || 'Project', brand: 'Merksets' }

  const Nav = ({ to, icon, children }: { to: string; icon: React.ReactNode; children: React.ReactNode }) => {
    const active = (to === '/' && scope === 'recent') || route === to
    return (
      <a href={`#${to}`} aria-current={active ? 'page' : undefined} className={cn('flex items-center gap-3 rounded-full px-3.5 py-2 text-[14px] font-medium transition', active ? 'bg-accent-soft text-accent-fg' : 'text-ink hover:bg-sunk')}>
        {icon}<span className="truncate">{children}</span>
      </a>
    )
  }

  const [navOpen, setNavOpen] = useState(false)
  const startSet = async (keys: string[], name: string) => { const id = await createDesign(name, docFromFormats(keys), { folder_id: folderId || null, visibility: folderId ? 'team' : 'private' }); navigate(`/d/${id}`) }

  const sidebar = (
    <>
      <div className="flex items-center justify-between px-2 pb-4"><a href="#/" aria-label="Adwerk home"><Logo size={40} /></a>
        <button className="rounded-full p-2 text-muted hover:bg-sunk md:hidden" aria-label="Menu sluiten" onClick={() => setNavOpen(false)}><X size={18} /></button></div>
      <Button variant="primary" className="mb-4 w-full" onClick={() => { setNavOpen(false); setNewOpen(true) }}><Plus size={18} /> Nieuw ontwerp</Button>
      <nav className="grid gap-0.5" aria-label="Hoofdmenu" onClick={() => setNavOpen(false)}>
        <Nav to="/" icon={<HomeIcon size={18} />}>Home</Nav>
        <Nav to="/mine" icon={<User size={18} />}>Mijn bestanden</Nav>
        <Nav to="/team" icon={<Users size={18} />}>Gedeeld met mij</Nav>
        <Nav to="/templates" icon={<LayoutTemplate size={18} />}>Teamtemplates</Nav>
        <Nav to="/brand" icon={<Palette size={18} />}>Merksets</Nav>
      </nav>
      <div className="mt-6 flex items-center justify-between px-3"><Label>Projecten</Label>
        <Tip label="Nieuw project"><button className="rounded-full p-1 text-muted hover:bg-sunk hover:text-ink" aria-label="Nieuw project" onClick={() => setFolderOpen(true)}><Plus size={16} /></button></Tip>
      </div>
      <div className="mt-1 grid gap-0.5" onClick={() => setNavOpen(false)}>
        {folders.map((f) => (
          <Nav key={f.id} to={`/folder/${f.id}`} icon={<FolderIcon size={17} />}>{f.name}</Nav>
        ))}
        {!folders.length && <p className="px-3 py-1 text-xs leading-relaxed text-muted">Maak een project per klant, bijvoorbeeld "Interieurwereld".</p>}
      </div>
      <div className="mt-6"><OnlineList /></div>
      <div className="mt-auto border-t border-line pt-3"><AccountMenu /></div>
    </>
  )

  return (
    <div className="flex h-full">
      <aside className="hidden w-[272px] shrink-0 flex-col overflow-y-auto border-r border-line bg-surface p-4 md:flex">{sidebar}</aside>
      <Sheet open={navOpen} onClose={() => setNavOpen(false)} side="left" label="Menu" z={60} className="w-[min(300px,86vw)] overflow-y-auto p-4 md:hidden">{sidebar}</Sheet>

      <main className="min-w-0 flex-1 overflow-auto">
        <div className="sticky top-0 z-20 flex items-center gap-2 border-b border-line bg-surface/90 px-3 py-2.5 backdrop-blur md:border-0 md:bg-transparent md:px-10 md:pt-5 md:backdrop-blur-0">
          <button className="rounded-full p-2 hover:bg-sunk md:hidden" aria-label="Menu openen" onClick={() => setNavOpen(true)}><MenuIcon size={20} /></button>
          <span className="md:hidden"><Logo size={32} /></span>
          <span className="flex-1" />
          <span className="flex items-center gap-1.5 rounded-full md:border md:border-line md:bg-surface md:p-1 md:pl-2 md:shadow-sm">
            <span className="hidden lg:block"><OnlineStack /></span>
            <ChatButton />
            <AccountMenu compact side="bottom" align="end" />
          </span>
        </div>
        <button onClick={() => setNewOpen(true)} className="press fixed bottom-5 right-4 z-30 flex h-14 items-center gap-2 rounded-full bg-[#CC4A25] pl-4 pr-5 font-semibold text-white shadow-pop md:hidden" aria-label="Nieuw ontwerp"><Plus size={22} /> Nieuw ontwerp</button>
        <div className="mx-auto max-w-6xl px-4 pb-24 pt-4 sm:px-6 md:px-10 md:pb-10 md:pt-2">

          {scope === 'recent' && (
            <>
              <section className="relative mb-6 overflow-hidden rounded-[20px] rounded-br-[90px] bg-navy px-6 dark:bg-gradient-to-br dark:from-[#1a5fc4] dark:to-[#1b213b] py-8 text-white md:px-10 md:py-10">
                <h1 className="max-w-2xl font-display text-[32px] font-medium leading-[1.1] tracking-tight md:text-5xl">Wat ga je <strong className="font-bold">vandaag</strong> maken<span className="text-lila">?</span></h1>
                <p className="mt-3 max-w-xl text-white/80">Kies een set hieronder. Je ontwerpt één keer en Adwerk zet het om naar alle formaten.</p>
                <div className="mt-6 flex flex-wrap items-center gap-3">
                  <Button variant="primary" size="lg" onClick={() => setNewOpen(true)}><Plus size={18} /> Nieuw ontwerp</Button>
                  <Button size="lg" className="border-white/25 bg-transparent text-white hover:bg-white/10" onClick={() => navigate('/templates')}><LayoutTemplate size={18} /> Teamtemplates</Button>
                </div>
                <span aria-hidden className="pointer-events-none absolute bottom-6 right-10 hidden items-end gap-1 xl:flex">
                  <span className="font-hand text-[26px] leading-none text-white/90">Kies je formaat!</span>
                  <img src={brandUrl('pijl-oranje-1.svg')} alt="" className="h-14 w-14 translate-y-6" />
                </span>
              </section>
              <div className="mb-12 grid grid-cols-1 gap-4 sm:grid-cols-2 lg:grid-cols-3">
                {SETS.map((s) => <SetCard key={s.key} set={s} onClick={() => startSet(s.formats, s.name)} />)}
              </div>
            </>
          )}
          {scope === 'brand' ? <BrandKits /> : (
            <>
              <div className="mb-5 flex flex-wrap items-center gap-3">
                <h2 className="mr-auto font-display text-2xl font-semibold">{titles[scope]}<span className="text-accent-fg">.</span></h2>
                <div className="relative w-full sm:w-64"><Search size={16} className="absolute left-3 top-1/2 -translate-y-1/2 text-muted" /><Input placeholder="Zoek op naam" aria-label="Zoek ontwerpen" value={q} onChange={(e) => setQ(e.target.value)} className="h-10 rounded-full bg-surface pl-9" /></div>
                {scope === 'folder' && folder && folder.owner_id === me && (
                  <Button size="sm" variant="danger" onClick={async () => { await deleteFolder(folder.id); setFolders(await listFolders()); navigate('/') }}>Project verwijderen</Button>
                )}
              </div>
              {loading ? (
                <div className="grid grid-cols-2 gap-4 sm:grid-cols-3 sm:gap-5 lg:grid-cols-4">{Array.from({ length: 8 }).map((_, i) => <div key={i} className="aspect-[4/3] animate-pulse rounded-[20px] bg-sunk" />)}</div>
              ) : shown.length ? (
                <div className="grid grid-cols-2 gap-4 sm:grid-cols-3 sm:gap-5 lg:grid-cols-4">
                  {shown.map((d) => <DesignCard key={d.id} d={d} me={me} owner={pmap.get(d.owner_id)} folders={folders} onChanged={load} toast={toast} />)}
                </div>
              ) : (
                <div className="grid place-items-center rounded-[20px] border-2 border-dashed border-line px-6 py-16 text-center">
                  <p className="font-display text-xl font-semibold">Nog niets hier<span className="text-accent-fg">.</span></p>
                  <p className="mt-1 max-w-sm text-sm text-muted">
                    {scope === 'team' ? 'Ontwerpen die collega\'s met het team delen, verschijnen hier.' : scope === 'templates' ? 'Zet een ontwerp om naar teamtemplate via het menu bij een ontwerp.' : 'Maak je eerste ontwerp en het verschijnt hier.'}
                  </p>
                  {scope !== 'team' && scope !== 'templates' && <Button variant="primary" className="mt-5" onClick={() => setNewOpen(true)}><Plus size={18} /> Nieuw ontwerp</Button>}
                </div>
              )}
            </>
          )}
        </div>
      </main>

      <NewDesignDialog open={newOpen} onOpenChange={setNewOpen} folderId={folderId} />
      <Dialog open={folderOpen} onOpenChange={setFolderOpen} title="Nieuw project" description="Een project bundelt ontwerpen, bijvoorbeeld per klant.">
        <div className="grid gap-4">
          <Input autoFocus placeholder="Bijvoorbeeld: Interieurwereld" value={folderName} onChange={(e) => setFolderName(e.target.value)} />
          <Segmented value={folderVis} onChange={setFolderVis} options={[{ value: 'team', label: 'Hele team' }, { value: 'private', label: 'Alleen ik' }]} />
          <Button variant="primary" disabled={!folderName.trim()} onClick={async () => { const f = await createFolder(folderName.trim(), folderVis); setFolders(await listFolders()); setFolderOpen(false); setFolderName(''); navigate(`/folder/${f.id}`) }}>Project maken</Button>
        </div>
      </Dialog>
      <Toast text={toastText} />
    </div>
  )
}
