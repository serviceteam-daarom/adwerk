import { useCallback, useEffect, useMemo, useState } from 'react'
import { Plus, Home as HomeIcon, User, Users, LayoutTemplate, Folder as FolderIcon, Palette, LogOut, MoreHorizontal, Copy, Trash2, Share2, FolderInput, Pencil, Search, Lock, Globe2} from 'lucide-react'
import { supabase } from '../lib/supabase'
import { useSession, displayName } from '../store/session'
import { createDesign, createFolder, deleteDesign, deleteFolder, duplicateDesign, listDesigns, listFolders, listProfiles, saveDesign } from '../lib/api'
import type { DesignRow, Folder, Profile } from '../lib/types'
import { SETS, PLATFORMS, ALL_FORMATS } from '../lib/formats'
import { docFromFormats, makeFrame } from '../lib/factory'
import { Avatar, Button, Dialog, Input, Label, Menu, MenuContent, MenuItem, MenuSep, MenuTrigger, Segmented, cn, Toast } from '../ui/ui'
import { PlatformLogos } from '../ui/PlatformLogo'
import { Logo } from './Login'
import { navigate } from '../App'
import BrandKits from './BrandKits'

type Row = Omit<DesignRow, 'data'>

function timeAgo(iso: string) {
  const s = (Date.now() - new Date(iso).getTime()) / 1000
  if (s < 60) return 'zojuist'
  if (s < 3600) return `${Math.floor(s / 60)} min geleden`
  if (s < 86400) return `${Math.floor(s / 3600)} uur geleden`
  if (s < 86400 * 7) return `${Math.floor(s / 86400)} dagen geleden`
  return new Date(iso).toLocaleDateString('nl-NL', { day: 'numeric', month: 'short', year: 'numeric' })
}

export function NewDesignDialog({ open, onOpenChange, folderId }: { open: boolean; onOpenChange: (o: boolean) => void; folderId?: string | null }) {
  const [sel, setSel] = useState<string[]>(['meta-sq', 'meta-45', 'meta-story'])
  const [title, setTitle] = useState('')
  const [cw, setCw] = useState(1080)
  const [ch, setCh] = useState(1080)
  const [busy, setBusy] = useState(false)
  const toggle = (k: string) => setSel((s) => (s.includes(k) ? s.filter((x) => x !== k) : [...s, k]))
  const create = async (keys: string[], name?: string, custom?: { w: number; h: number }) => {
    setBusy(true)
    try {
      const doc = docFromFormats(keys)
      if (custom) doc.frames.push(makeFrame({ key: 'custom', name: 'Eigen formaat', w: custom.w, h: custom.h, platform: 'Eigen' }))
      const id = await createDesign(name || title || 'Naamloos ontwerp', doc, { folder_id: folderId || null, visibility: folderId ? 'team' : 'private' })
      onOpenChange(false)
      navigate(`/d/${id}`)
    } finally { setBusy(false) }
  }
  return (
    <Dialog open={open} onOpenChange={onOpenChange} title="Nieuw ontwerp" description="Kies een set of stel zelf je formaten samen. Je kunt later altijd formaten toevoegen." wide>
      <div className="grid gap-6">
        <div className="grid grid-cols-2 gap-3 sm:grid-cols-3">
          {SETS.map((s) => (
            <button key={s.key} disabled={busy} onClick={() => create(s.formats, s.name)} className="group grid gap-2 overflow-hidden rounded-[20px] border border-line p-3 text-left transition hover:border-ink hover:shadow-card">
              <div className="flex h-16 items-end gap-1.5">
                {s.formats.slice(0, 5).map((k) => {
                  const f = ALL_FORMATS.find((x) => x.key === k)!
                  const sc = 56 / Math.max(f.w, f.h)
                  return <span key={k} className="rounded-[3px]" style={{ width: Math.max(6, f.w * sc), height: Math.max(6, f.h * sc), background: s.color, opacity: 0.9 }} />
                })}
              </div>
              <div className="flex items-center justify-between gap-2"><span className="font-semibold">{s.name}</span><PlatformLogos platforms={s.logos} size={16} /></div>
              <div className="text-xs text-muted">{s.description}</div>
            </button>
          ))}
        </div>
        <div className="grid gap-3 rounded-xl bg-mist p-4">
          <Label>Zelf samenstellen</Label>
          <div className="grid max-h-64 gap-4 overflow-auto pr-1 sm:grid-cols-2">
            {PLATFORMS.map((p) => (
              <div key={p.name} className="grid content-start gap-1">
                <div className="flex items-center gap-2 text-sm font-semibold"><PlatformLogos platforms={p.logos} size={16} />{p.name}</div>
                {p.formats.map((f) => (
                  <label key={f.key} className="flex cursor-pointer items-center gap-2 rounded-md px-1.5 py-1 text-sm hover:bg-white">
                    <input type="checkbox" checked={sel.includes(f.key)} onChange={() => toggle(f.key)} className="h-4 w-4 accent-[#EA5F39]" />
                    <span className="flex-1">{f.name}</span>
                    <span className="tabular-nums text-xs text-muted">{f.w}×{f.h}</span>
                  </label>
                ))}
              </div>
            ))}
          </div>
          <div className="flex flex-wrap items-center gap-2">
            <Input placeholder="Naam van het ontwerp" value={title} onChange={(e) => setTitle(e.target.value)} className="min-w-[200px] flex-1 bg-white" />
            <Button variant="primary" disabled={!sel.length || busy} onClick={() => create(sel)}>Maak {sel.length} formaten</Button>
          </div>
        </div>
        <div className="flex flex-wrap items-end gap-2">
          <div className="grid gap-1"><Label>Eigen formaat</Label>
            <div className="flex items-center gap-2"><Input type="number" value={cw} onChange={(e) => setCw(+e.target.value)} className="w-24" aria-label="Breedte" /><span className="text-muted">×</span><Input type="number" value={ch} onChange={(e) => setCh(+e.target.value)} className="w-24" aria-label="Hoogte" /><span className="text-sm text-muted">px</span></div>
          </div>
          <Button disabled={busy || cw < 10 || ch < 10} onClick={() => create([], title || `Eigen formaat ${cw}×${ch}`, { w: cw, h: ch })}>Maak eigen formaat</Button>
        </div>
      </div>
    </Dialog>
  )
}

function DesignCard({ d, me, owner, folders, onChanged, toast }: { d: Row; me: string; owner?: Profile; folders: Folder[]; onChanged: () => void; toast: (t: string) => void }) {
  const [rename, setRename] = useState(false)
  const [name, setName] = useState(d.title)
  const mine = d.owner_id === me
  const doRename = async () => { setRename(false); if (name.trim() && name !== d.title) { await saveDesign(d.id, { title: name.trim() }, me); onChanged() } }
  return (
    <div className="group grid gap-2">
      <button onClick={() => navigate(`/d/${d.id}`)} className="relative grid aspect-[4/3] place-items-center overflow-hidden rounded-[20px] border border-line bg-mist transition group-hover:shadow-pop">
        {d.thumbnail ? <img src={d.thumbnail} alt="" className="max-h-[86%] max-w-[86%] rounded-sm object-contain shadow-card" /> : <span className="font-display text-3xl font-bold text-line">Aa</span>}
        {d.is_template && <span className="absolute left-0 top-0 rounded-blob bg-white px-3 py-1 text-[11px] font-semibold text-ink">Template<span className="text-lila">.</span></span>}
      </button>
      <div className="flex items-start gap-2">
        <div className="min-w-0 flex-1">
          {rename ? (
            <Input autoFocus value={name} onChange={(e) => setName(e.target.value)} onBlur={doRename} onKeyDown={(e) => e.key === 'Enter' && doRename()} className="h-7" />
          ) : (
            <div className="truncate font-semibold" title={d.title}>{d.title}</div>
          )}
          <div className="flex items-center gap-1.5 text-xs text-muted">
            {d.visibility === 'team' ? <Globe2 size={12} aria-label="Gedeeld met team" /> : <Lock size={12} aria-label="Privé" />}
            <span className="truncate">{mine ? 'Jij' : owner ? displayName(owner) : 'Teamlid'} · {timeAgo(d.updated_at)}</span>
          </div>
        </div>
        <Menu>
          <MenuTrigger className="rounded-md p-1 text-muted opacity-70 hover:bg-sunk hover:opacity-100" aria-label="Meer acties"><MoreHorizontal size={18} /></MenuTrigger>
          <MenuContent>
            <MenuItem onSelect={() => navigate(`/d/${d.id}`)}><Pencil size={15} /> Openen</MenuItem>
            <MenuItem onSelect={() => setRename(true)}><Pencil size={15} /> Naam wijzigen</MenuItem>
            <MenuItem onSelect={async () => { const id = await duplicateDesign(d.id); toast('Kopie gemaakt'); onChanged(); void id }}><Copy size={15} /> Dupliceren</MenuItem>
            <MenuItem onSelect={async () => { await saveDesign(d.id, { visibility: d.visibility === 'team' ? 'private' : 'team' }, me); toast(d.visibility === 'team' ? 'Alleen nog zichtbaar voor jou' : 'Gedeeld met het team'); onChanged() }}><Share2 size={15} /> {d.visibility === 'team' ? 'Niet meer delen' : 'Delen met team'}</MenuItem>
            <MenuItem onSelect={async () => { await saveDesign(d.id, { is_template: !d.is_template }, me); toast(d.is_template ? 'Geen template meer' : 'Opgeslagen als teamtemplate'); onChanged() }}><LayoutTemplate size={15} /> {d.is_template ? 'Geen template meer' : 'Maak teamtemplate'}</MenuItem>
            {folders.length > 0 && <MenuSep />}
            {folders.map((f) => (
              <MenuItem key={f.id} onSelect={async () => { await saveDesign(d.id, { folder_id: f.id }, me); toast(`Verplaatst naar ${f.name}`); onChanged() }}><FolderInput size={15} /> Naar {f.name}</MenuItem>
            ))}
            {d.folder_id && <MenuItem onSelect={async () => { await saveDesign(d.id, { folder_id: null }, me); onChanged() }}><FolderInput size={15} /> Uit project halen</MenuItem>}
            {mine && <><MenuSep /><MenuItem danger onSelect={async () => { await deleteDesign(d.id); toast('Verwijderd'); onChanged() }}><Trash2 size={15} /> Verwijderen</MenuItem></>}
          </MenuContent>
        </Menu>
      </div>
    </div>
  )
}

export default function Home({ route }: { route: string }) {
  const { user, profile } = useSession()
  const me = user!.id
  const [rows, setRows] = useState<Row[]>([])
  const [folders, setFolders] = useState<Folder[]>([])
  const [profiles, setProfiles] = useState<Profile[]>([])
  const [loading, setLoading] = useState(true)
  const [newOpen, setNewOpen] = useState(false)
  const [folderOpen, setFolderOpen] = useState(false)
  const [folderName, setFolderName] = useState('')
  const [folderVis, setFolderVis] = useState<'team' | 'private'>('team')
  const [q, setQ] = useState('')
  const [toastText, setToastText] = useState<string | null>(null)
  const toast = (t: string) => { setToastText(t); setTimeout(() => setToastText(null), 2200) }

  const scope: 'recent' | 'mine' | 'team' | 'templates' | 'folder' | 'brand' =
    route.startsWith('/folder/') ? 'folder' : route === '/mine' ? 'mine' : route === '/team' ? 'team' : route === '/templates' ? 'templates' : route === '/brand' ? 'brand' : 'recent'
  const folderId = scope === 'folder' ? route.split('/')[2] : undefined
  const folder = folders.find((f) => f.id === folderId)

  const load = useCallback(async () => {
    if (scope === 'brand') { setLoading(false); return }
    setLoading(true)
    try { setRows(await listDesigns({ scope, userId: me, folderId })) } finally { setLoading(false) }
  }, [scope, me, folderId])

  useEffect(() => { load() }, [load])
  useEffect(() => { listFolders().then(setFolders); listProfiles().then(setProfiles) }, [])

  // live bijwerken als iemand anders iets opslaat
  useEffect(() => {
    const ch = supabase.channel('home-designs').on('postgres_changes', { event: '*', schema: 'public', table: 'designs' }, () => load()).subscribe()
    return () => { supabase.removeChannel(ch) }
  }, [load])

  const pmap = useMemo(() => new Map(profiles.map((p) => [p.id, p])), [profiles])
  const shown = rows.filter((r) => r.title.toLowerCase().includes(q.toLowerCase()))
  const titles: Record<string, string> = { recent: 'Recent', mine: 'Mijn bestanden', team: 'Gedeeld met mij', templates: 'Teamtemplates', folder: folder?.name || 'Project', brand: 'Merksets' }

  const Nav = ({ to, icon, children }: { to: string; icon: React.ReactNode; children: React.ReactNode }) => {
    const active = (to === '/' && scope === 'recent') || route === to
    return (
      <a href={`#${to}`} className={cn('flex items-center gap-3 rounded-full px-3.5 py-2 text-[14px] font-medium transition', active ? 'bg-accent-soft text-accent' : 'text-ink hover:bg-sunk')}>
        {icon}<span className="truncate">{children}</span>
      </a>
    )
  }

  return (
    <div className="flex h-full">
      <aside className="hidden w-64 shrink-0 flex-col gap-1 border-r border-line bg-white p-4 md:flex">
        <div className="mb-4 px-2"><Logo /></div>
        <Button variant="primary" className="mb-3 w-full" onClick={() => setNewOpen(true)}><Plus size={18} /> Nieuw ontwerp</Button>
        <Nav to="/" icon={<HomeIcon size={18} />}>Home</Nav>
        <Nav to="/mine" icon={<User size={18} />}>Mijn bestanden</Nav>
        <Nav to="/team" icon={<Users size={18} />}>Gedeeld met mij</Nav>
        <Nav to="/templates" icon={<LayoutTemplate size={18} />}>Teamtemplates</Nav>
        <Nav to="/brand" icon={<Palette size={18} />}>Merksets</Nav>
        <div className="mt-5 flex items-center justify-between px-3"><Label>Projecten</Label>
          <button className="rounded-md p-1 text-muted hover:bg-sunk" aria-label="Nieuw project" onClick={() => setFolderOpen(true)}><Plus size={16} /></button>
        </div>
        <div className="grid gap-0.5 overflow-auto">
          {folders.map((f) => (
            <Nav key={f.id} to={`/folder/${f.id}`} icon={<FolderIcon size={17} />}>{f.name}</Nav>
          ))}
          {!folders.length && <p className="px-3 py-1 text-xs text-muted">Maak een project per klant, bijvoorbeeld "Interieurwereld".</p>}
        </div>
        <div className="mt-auto flex items-center gap-2.5 rounded-xl p-2">
          <Avatar name={displayName(profile, user)} color={profile?.color} src={profile?.avatar_url} size={34} />
          <div className="min-w-0 flex-1"><div className="truncate text-sm font-semibold">{displayName(profile, user)}</div><div className="truncate text-xs text-muted">{user?.email}</div></div>
          <button className="rounded-md p-1.5 text-muted hover:bg-sunk" aria-label="Uitloggen" title="Uitloggen" onClick={() => supabase.auth.signOut()}><LogOut size={16} /></button>
        </div>
      </aside>

      <main className="min-w-0 flex-1 overflow-auto">
        <div className="mx-auto max-w-6xl px-5 py-6 md:px-10 md:py-10">
          <div className="mb-6 flex items-center justify-between md:hidden"><Logo /><Button variant="primary" size="sm" onClick={() => setNewOpen(true)}><Plus size={16} /> Nieuw</Button></div>

          {scope === 'recent' && (
            <section className="relative mb-10 overflow-hidden rounded-[20px] rounded-br-[90px] bg-ink p-6 text-white md:p-8">
              <h1 className="font-display text-3xl font-medium tracking-tight md:text-5xl">Wat ga je <strong className="font-bold">vandaag</strong> maken<span className="text-lila">?</span></h1>
              <p className="mt-2 max-w-xl text-white/75">Kies een set. Je ontwerpt één keer en Adwerk zet het om naar alle formaten.</p>
              <span className="pointer-events-none absolute right-10 top-6 hidden font-hand text-2xl text-white/85 lg:block">Kies je formaat!</span>
              <div className="mt-6 grid grid-cols-2 gap-3 sm:grid-cols-3 lg:grid-cols-6">
                {SETS.map((s) => (
                  <button key={s.key} onClick={async () => { const id = await createDesign(s.name, docFromFormats(s.formats)); navigate(`/d/${id}`) }} className="grid gap-2 overflow-hidden rounded-[20px] bg-white/[0.07] p-3 text-left transition hover:bg-white/[0.14]">
                    <div className="flex h-12 items-end gap-1">
                      {s.formats.slice(0, 4).map((k) => { const f = ALL_FORMATS.find((x) => x.key === k)!; const sc = 44 / Math.max(f.w, f.h); return <span key={k} className="rounded-[3px]" style={{ width: Math.max(5, f.w * sc), height: Math.max(5, f.h * sc), background: s.color }} /> })}
                    </div>
                    <div className="flex items-center justify-between gap-1"><span className="text-sm font-semibold leading-tight">{s.name}</span><PlatformLogos platforms={s.logos} size={14} mono="#ffffff" /></div>
                  </button>
                ))}
              </div>
            </section>
          )}

          {scope === 'brand' ? <BrandKits /> : (
            <>
              <div className="mb-5 flex flex-wrap items-center gap-3">
                <h2 className="mr-auto font-display text-2xl font-semibold">{titles[scope]}<span className="text-accent">.</span></h2>
                <div className="relative"><Search size={16} className="absolute left-3 top-1/2 -translate-y-1/2 text-muted" /><Input placeholder="Zoeken" value={q} onChange={(e) => setQ(e.target.value)} className="w-56 bg-white pl-9" /></div>
                {scope === 'folder' && folder && folder.owner_id === me && (
                  <Button size="sm" variant="danger" onClick={async () => { await deleteFolder(folder.id); setFolders(await listFolders()); navigate('/') }}>Project verwijderen</Button>
                )}
              </div>
              {loading ? (
                <div className="grid grid-cols-2 gap-5 sm:grid-cols-3 lg:grid-cols-4">{Array.from({ length: 8 }).map((_, i) => <div key={i} className="aspect-[4/3] animate-pulse rounded-xl bg-sunk" />)}</div>
              ) : shown.length ? (
                <div className="grid grid-cols-2 gap-5 sm:grid-cols-3 lg:grid-cols-4">
                  {shown.map((d) => <DesignCard key={d.id} d={d} me={me} owner={pmap.get(d.owner_id)} folders={folders} onChanged={load} toast={toast} />)}
                </div>
              ) : (
                <div className="grid place-items-center rounded-2xl border-2 border-dashed border-line px-6 py-16 text-center">
                  <p className="font-display text-xl font-bold">Nog niets hier</p>
                  <p className="mt-1 max-w-sm text-sm text-muted">
                    {scope === 'team' ? 'Ontwerpen die collega\'s met het team delen, verschijnen hier.' : scope === 'templates' ? 'Zet een ontwerp om naar teamtemplate via het menu bij een ontwerp.' : 'Maak je eerste ontwerp en het verschijnt hier.'}
                  </p>
                  {scope !== 'team' && scope !== 'templates' && <Button variant="primary" className="mt-5" onClick={() => setNewOpen(true)}><Plus size={18} /> Nieuw ontwerp</Button>}
                </div>
              )}
            </>
          )}
        </div>
      </main>

      <NewDesignDialog open={newOpen} onOpenChange={setNewOpen} folderId={folderId} />
      <Dialog open={folderOpen} onOpenChange={setFolderOpen} title="Nieuw project" description="Een project bundelt ontwerpen, bijvoorbeeld per klant.">
        <div className="grid gap-4">
          <Input autoFocus placeholder="Bijvoorbeeld: Interieurwereld" value={folderName} onChange={(e) => setFolderName(e.target.value)} />
          <Segmented value={folderVis} onChange={setFolderVis} options={[{ value: 'team', label: 'Hele team' }, { value: 'private', label: 'Alleen ik' }]} />
          <Button variant="primary" disabled={!folderName.trim()} onClick={async () => { const f = await createFolder(folderName.trim(), folderVis); setFolders(await listFolders()); setFolderOpen(false); setFolderName(''); navigate(`/folder/${f.id}`) }}>Project maken</Button>
        </div>
      </Dialog>
      <Toast text={toastText} />
    </div>
  )
}
