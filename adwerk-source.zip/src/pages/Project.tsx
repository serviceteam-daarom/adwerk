import { useEffect, useMemo, useRef, useState } from 'react'
import { LayoutGrid, Columns3, CalendarDays, GanttChartSquare, ClipboardList, Lock, Globe2, ChevronLeft, ChevronRight, Plus, Trash2, MoreHorizontal, Pencil, Link2, ExternalLink, CalendarPlus, X, Pin } from 'lucide-react'
import type { ClientBrief, ClientCampaign, DesignRow, Folder, DesignStatus } from '../lib/types'
import { saveDesign, updateFolder, deleteFolder } from '../lib/api'
import { STATUSES, statusOf, setStatus } from '../lib/workflow'
import { StatusDot } from '../ui/StatusDot'
import { Combobox } from '../ui/Combobox'
import { Button, Input, Label, Menu, MenuContent, MenuItem, MenuSep, MenuTrigger, Tip, cn, Dialog, Segmented, Select } from '../ui/ui'
import { navigate } from '../App'
import { ProjectIcon } from '../ui/ProjectIcon'

export type Row = Omit<DesignRow, 'data'>
export type ProjectView = 'grid' | 'board' | 'calendar' | 'timeline' | 'brief'
export const VIEWS: { key: ProjectView; label: string; icon: React.ReactNode }[] = [
  { key: 'grid', label: 'Raster', icon: <LayoutGrid size={16} /> },
  { key: 'board', label: 'Bord', icon: <Columns3 size={16} /> },
  { key: 'calendar', label: 'Kalender', icon: <CalendarDays size={16} /> },
  { key: 'timeline', label: 'Tijdlijn', icon: <GanttChartSquare size={16} /> },
  { key: 'brief', label: 'Klantbrief', icon: <ClipboardList size={16} /> },
]
export const PROJECT_COLORS = ['#1A5FC4', '#5B3FD9', '#EA5F39', '#13A06B', '#E0337A', '#F2B42C', '#0E8FA3', '#1B213B']

/* ---------- datums ---------- */
const DAY = 86400000
const iso = (d: Date) => `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}-${String(d.getDate()).padStart(2, '0')}`
const parse = (s?: string | null) => (s ? new Date(s + 'T00:00:00') : null)
const addDays = (d: Date, n: number) => new Date(d.getFullYear(), d.getMonth(), d.getDate() + n)
const diffDays = (a: Date, b: Date) => Math.round((b.getTime() - a.getTime()) / DAY)
const fmt = (s?: string | null) => (s ? parse(s)!.toLocaleDateString('nl-NL', { day: 'numeric', month: 'short' }) : '')
const range = (r: { start_date?: string | null; end_date?: string | null }) => {
  const s = parse(r.start_date) || parse(r.end_date), e = parse(r.end_date) || parse(r.start_date)
  return s && e ? { s, e: e < s ? s : e } : null
}
export const dateLabel = (r: { start_date?: string | null; end_date?: string | null }) => {
  const rg = range(r)
  if (!rg) return ''
  return iso(rg.s) === iso(rg.e) ? fmt(iso(rg.s)) : `${fmt(iso(rg.s))} t/m ${fmt(iso(rg.e))}`
}

/* ---------- projectkop ---------- */
export function ProjectHeader({ folder, me, view, setView, onChanged, pinned, onPin }: { folder: Folder; me: string; view: ProjectView; setView: (v: ProjectView) => void; onChanged: () => void; pinned?: boolean; onPin?: () => void }) {
  const [edit, setEdit] = useState(false)
  const mine = folder.owner_id === me
  return (
    <div className="mb-5 grid gap-4">
      <div className="flex min-w-0 flex-wrap items-center gap-3">
        <span className="flex min-w-0 max-w-full items-center gap-3 max-sm:basis-full">
          <ProjectIcon f={folder} size={36} />
          <h2 className="min-w-0 truncate font-display text-2xl font-semibold" title={folder.name}>{folder.name}<span className="text-accent-fg">.</span></h2>
        </span>
        <Tip label={folder.visibility === 'private' ? 'Privé: alleen jij ziet dit project' : 'Team: iedereen bij daar-om.nl ziet dit project'}>
          <span className="flex shrink-0 items-center gap-1 rounded-full bg-sunk px-2.5 py-1 text-xs font-semibold text-muted">{folder.visibility === 'private' ? <Lock size={12} /> : <Globe2 size={12} />}{folder.visibility === 'private' ? 'Privé' : 'Team'}</span>
        </Tip>
        {folder.website && <a href={folder.website} target="_blank" rel="noreferrer" className="flex min-w-0 shrink items-center gap-1 truncate text-xs font-semibold text-violet hover:underline"><Link2 size={13} className="shrink-0" /><span className="truncate">{folder.website.replace(/^https?:\/\/(www\.)?/, '').replace(/\/$/, '')}</span></a>}
        <span className="flex-1" />
        {onPin && <Tip label={pinned ? 'Losmaken uit je zijbalk' : 'Vastzetten bovenaan je zijbalk'}><button onClick={onPin} aria-pressed={!!pinned} aria-label={pinned ? 'Project losmaken' : 'Project vastzetten'} className={cn('press grid h-9 w-9 place-items-center rounded-full transition', pinned ? 'bg-accent-soft text-accent-fg' : 'text-muted hover:bg-sunk hover:text-ink')}><Pin size={17} className={cn('transition-transform', pinned && '-rotate-45')} /></button></Tip>}
        <Menu>
          <MenuTrigger className="grid h-9 w-9 place-items-center rounded-full text-muted hover:bg-sunk hover:text-ink" aria-label="Projectinstellingen"><MoreHorizontal size={18} /></MenuTrigger>
          <MenuContent>
            <MenuItem onSelect={() => setEdit(true)}><Pencil size={15} /> Project bewerken</MenuItem>
            {mine && <><MenuSep /><MenuItem danger onSelect={async () => { if (!confirm(`Project "${folder.name}" verwijderen? De ontwerpen blijven bestaan.`)) return; await deleteFolder(folder.id); navigate('/'); onChanged() }}><Trash2 size={15} /> Project verwijderen</MenuItem></>}
          </MenuContent>
        </Menu>
      </div>
      <div className="flex max-w-full gap-1 overflow-x-auto rounded-xl bg-sunk p-1 sm:w-fit" role="tablist" aria-label="Weergave">
        {VIEWS.map((v) => (
          <button key={v.key} role="tab" aria-selected={view === v.key} onClick={() => setView(v.key)} className={cn('flex shrink-0 items-center gap-1.5 rounded-lg px-3 py-1.5 text-[13px] font-semibold transition', view === v.key ? 'bg-surface text-ink shadow-card' : 'text-muted hover:text-ink')}>{v.icon}{v.label}</button>
        ))}
      </div>
      <ProjectEditDialog folder={folder} open={edit} onOpenChange={setEdit} onChanged={onChanged} mine={mine} />
    </div>
  )
}

function ProjectEditDialog({ folder, open, onOpenChange, onChanged, mine }: { folder: Folder; open: boolean; onOpenChange: (o: boolean) => void; onChanged: () => void; mine: boolean }) {
  const [name, setName] = useState(folder.name)
  const [website, setWebsite] = useState(folder.website || '')
  const [color, setColor] = useState(folder.color || '#1A5FC4')
  const [vis, setVis] = useState(folder.visibility)
  useEffect(() => { if (open) { setName(folder.name); setWebsite(folder.website || ''); setColor(folder.color || '#1A5FC4'); setVis(folder.visibility) } }, [open, folder])
  const save = async () => {
    const w = website.trim() && !/^https?:\/\//.test(website.trim()) ? 'https://' + website.trim() : website.trim()
    await updateFolder(folder.id, { name: name.trim() || folder.name, website: w || null, color, ...(mine ? { visibility: vis } : {}) })
    onOpenChange(false); onChanged()
  }
  return (
    <Dialog open={open} onOpenChange={onOpenChange} title="Project bewerken">
      <div className="grid gap-4">
        <div className="flex items-center gap-3 rounded-2xl bg-mist p-3 dark:bg-sunk">
          <ProjectIcon f={{ name: name || folder.name, website: website.trim() || null, color }} size={52} />
          <div className="min-w-0"><div className="truncate font-display text-lg font-semibold" title={name}>{name || folder.name}</div><p className="text-xs leading-relaxed text-muted">Met een website toont Adwerk de favicon van de klant als voorste kaart, in de zijbalk en bovenaan het project.</p></div>
        </div>
        <label className="grid gap-1.5"><Label>Naam</Label><Input value={name} onChange={(e) => setName(e.target.value)} /></label>
        <label className="grid gap-1.5"><Label>Website van de klant</Label><Input value={website} onChange={(e) => setWebsite(e.target.value)} placeholder="www.klant.nl" /></label>
        <div className="grid gap-1.5"><Label>Kleur</Label>
          <div className="flex flex-wrap gap-2">{PROJECT_COLORS.map((c) => <button key={c} onClick={() => setColor(c)} className={cn('h-8 w-8 rounded-full transition', color === c ? 'ring-2 ring-ink ring-offset-2 ring-offset-surface' : 'hover:scale-110')} style={{ background: c }} aria-label={`Kleur ${c}`} />)}</div>
        </div>
        <div className="grid gap-1.5"><Label>Wie mag dit project zien?</Label>
          <Segmented value={vis} onChange={(v) => mine && setVis(v)} options={[{ value: 'private', label: 'Alleen ik' }, { value: 'team', label: 'Hele team' }]} />
          <p className="text-xs text-muted">{vis === 'team' ? 'Ontwerpen in een teamproject zijn voor iedereen bij daar-om.nl zichtbaar.' : 'Alleen jij ziet dit project. Ontwerpen erin houden hun eigen zichtbaarheid.'}{!mine && ' Alleen de maker kan dit wijzigen.'}</p>
        </div>
        <div className="flex justify-end gap-2"><Button onClick={() => onOpenChange(false)}>Annuleren</Button><Button variant="primary" onClick={save}>Opslaan</Button></div>
      </div>
    </Dialog>
  )
}

/* ---------- planning instellen ---------- */
export function PlanDialog({ row, open, onOpenChange, onSaved }: { row: Row | null; open: boolean; onOpenChange: (o: boolean) => void; onSaved: (patch: Partial<Row>) => void }) {
  const [s, setS] = useState(''), [e, setE] = useState('')
  useEffect(() => { if (row) { setS(row.start_date || ''); setE(row.end_date || '') } }, [row])
  if (!row) return null
  return (
    <Dialog open={open} onOpenChange={onOpenChange} title="Planning" description={row.title}>
      <div className="grid gap-4">
        <div className="grid grid-cols-2 gap-3">
          <label className="grid gap-1.5"><Label>Begindatum</Label><Input type="date" value={s} onChange={(ev) => { setS(ev.target.value); if (!e || ev.target.value > e) setE(ev.target.value) }} /></label>
          <label className="grid gap-1.5"><Label>Einddatum</Label><Input type="date" value={e} min={s || undefined} onChange={(ev) => setE(ev.target.value)} /></label>
        </div>
        <div className="flex justify-between gap-2">
          <Button onClick={() => { onSaved({ start_date: null, end_date: null }); onOpenChange(false) }}>Planning wissen</Button>
          <Button variant="primary" onClick={() => { onSaved({ start_date: s || null, end_date: e || s || null }); onOpenChange(false) }}>Opslaan</Button>
        </div>
      </div>
    </Dialog>
  )
}

function Thumb({ r, className }: { r: Row; className?: string }) {
  return <span className={cn('grid shrink-0 place-items-center overflow-hidden rounded-lg bg-sunk', className)}>{r.thumbnail ? <img src={r.thumbnail} alt="" className="max-h-full max-w-full object-contain" draggable={false} /> : <span className="text-xs font-bold text-line">Aa</span>}</span>
}

/* ---------- bord (Trello) ---------- */
export function BoardView({ rows, me, onPatch }: { rows: Row[]; me: string; onPatch: (id: string, patch: Partial<Row>) => void }) {
  const [over, setOver] = useState<string | null>(null)
  const [drag, setDrag] = useState<string | null>(null)
  const [plan, setPlan] = useState<Row | null>(null)
  const move = async (id: string, status: DesignStatus) => {
    const r = rows.find((x) => x.id === id)
    if (!r || (r.status || 'concept') === status) return
    onPatch(id, { status, status_at: new Date().toISOString() })
    try { await setStatus(id, status, me) } catch { onPatch(id, { status: r.status }) }
  }
  return (
    <div className="-mx-4 overflow-x-auto px-4 pb-4 sm:-mx-6 sm:px-6 md:-mx-10 md:px-10">
      <div className="flex min-w-max gap-3">
        {STATUSES.map((st) => {
          const items = rows.filter((r) => (r.status || 'concept') === st.key)
          return (
            <section key={st.key} onDragOver={(e) => { e.preventDefault(); setOver(st.key) }} onDragLeave={() => setOver((o) => (o === st.key ? null : o))} onDrop={(e) => { e.preventDefault(); setOver(null); const id = e.dataTransfer.getData('text/adwerk-design'); if (id) move(id, st.key) }}
              className={cn('flex w-[264px] shrink-0 flex-col rounded-2xl bg-sunk/70 p-2 transition-[background,box-shadow] duration-200', over === st.key && 'bg-accent-soft/60 shadow-[inset_0_0_0_2px_rgb(var(--accent)/.5)]')} aria-label={st.label}>
              <header className="flex items-center gap-2 px-2 pb-2 pt-1"><StatusDot status={st.key} /><span className="min-w-0 flex-1 truncate text-sm font-semibold">{st.label}</span><span className="rounded-full bg-surface px-2 py-0.5 text-xs font-semibold tabular-nums text-muted">{items.length}</span></header>
              <div className="grid min-h-[80px] content-start gap-2">
                {items.map((r) => (
                  <article key={r.id} draggable onDragStart={(e) => { e.dataTransfer.setData('text/adwerk-design', r.id); e.dataTransfer.effectAllowed = 'move'; setDrag(r.id) }} onDragEnd={() => setDrag(null)}
                    className={cn('anim-rise group cursor-grab rounded-xl border border-line bg-surface p-2.5 shadow-card transition-[transform,opacity,box-shadow] hover:-translate-y-0.5 hover:shadow-pop active:cursor-grabbing', drag === r.id && 'rotate-1 opacity-50')}>
                    <button onClick={() => navigate(`/d/${r.id}`)} className="block w-full text-left">
                      <Thumb r={r} className="mb-2 aspect-[16/9] w-full" />
                      <span className="line-clamp-2 break-words text-[13px] font-semibold leading-snug" title={r.title}>{r.title}</span>
                    </button>
                    <div className="mt-1.5 flex items-center gap-1.5">
                      <button onClick={() => setPlan(r)} className={cn('flex min-w-0 items-center gap-1 rounded-md px-1.5 py-0.5 text-[11px] font-medium transition hover:bg-sunk', r.start_date ? 'text-ink' : 'text-muted')}><CalendarDays size={12} className="shrink-0" /><span className="truncate">{dateLabel(r) || 'Plannen'}</span></button>
                      <span className="flex-1" />
                      <Select value={r.status || 'concept'} onChange={(v) => move(r.id, v as DesignStatus)} variant="ghost" size="xs" fullWidth={false} align="end" className="max-w-[120px] text-muted" ariaLabel="Status" options={STATUSES.map((s) => ({ value: s.key, label: s.label, dot: s.color }))} />
                    </div>
                  </article>
                ))}
                {!items.length && <p className={cn('rounded-xl border-2 border-dashed border-line px-3 py-5 text-center text-xs text-muted transition', over === st.key && 'border-accent text-accent-fg')}>Sleep hier een ontwerp naartoe</p>}
              </div>
            </section>
          )
        })}
      </div>
      <PlanDialog row={plan} open={!!plan} onOpenChange={(o) => !o && setPlan(null)} onSaved={async (p) => { if (!plan) return; onPatch(plan.id, p); await saveDesign(plan.id, p, me) }} />
    </div>
  )
}

/* ---------- kalender ---------- */
type Item = { id: string; title: string; s: Date; e: Date; color: string; kind: 'design' | 'campaign'; row?: Row }
const campaignItems = (b?: ClientBrief | null): Item[] => (b?.campaigns || []).flatMap((c) => { const rg = range({ start_date: c.start, end_date: c.end }); return rg ? [{ id: 'c' + c.id, title: c.name || 'Campagne', s: rg.s, e: rg.e, color: '#5B3FD9', kind: 'campaign' as const }] : [] })

export function CalendarView({ rows, brief, me, onPatch }: { rows: Row[]; brief?: ClientBrief | null; me: string; onPatch: (id: string, patch: Partial<Row>) => void }) {
  const [month, setMonth] = useState(() => { const d = new Date(); return new Date(d.getFullYear(), d.getMonth(), 1) })
  const [over, setOver] = useState<string | null>(null)
  const items: Item[] = [...rows.flatMap((r) => { const rg = range(r); return rg ? [{ id: r.id, title: r.title, s: rg.s, e: rg.e, color: statusOf(r.status).color, kind: 'design' as const, row: r }] : [] }), ...campaignItems(brief)]
  const unplanned = rows.filter((r) => !range(r))
  const first = addDays(month, -((month.getDay() + 6) % 7))
  const days = Array.from({ length: 42 }, (_, i) => addDays(first, i))
  const today = iso(new Date())
  const drop = async (id: string, day: Date) => {
    const r = rows.find((x) => x.id === id)
    if (!r) return
    const rg = range(r)
    const len = rg ? diffDays(rg.s, rg.e) : 0
    const p = { start_date: iso(day), end_date: iso(addDays(day, len)) }
    onPatch(id, p)
    await saveDesign(id, p, me)
  }
  return (
    <div className="grid gap-4 lg:grid-cols-[minmax(0,1fr)_220px]">
      <div className="min-w-0 overflow-hidden rounded-2xl border border-line bg-surface">
        <div className="flex items-center gap-2 border-b border-line px-3 py-2.5">
          <span className="flex-1 font-display text-lg font-semibold capitalize">{month.toLocaleDateString('nl-NL', { month: 'long', year: 'numeric' })}</span>
          <Button size="sm" onClick={() => { const d = new Date(); setMonth(new Date(d.getFullYear(), d.getMonth(), 1)) }}>Vandaag</Button>
          <button onClick={() => setMonth(new Date(month.getFullYear(), month.getMonth() - 1, 1))} className="grid h-8 w-8 place-items-center rounded-full hover:bg-sunk" aria-label="Vorige maand"><ChevronLeft size={18} /></button>
          <button onClick={() => setMonth(new Date(month.getFullYear(), month.getMonth() + 1, 1))} className="grid h-8 w-8 place-items-center rounded-full hover:bg-sunk" aria-label="Volgende maand"><ChevronRight size={18} /></button>
        </div>
        <div className="grid grid-cols-7 border-b border-line text-center text-[11px] font-bold uppercase tracking-wide text-muted">{['ma', 'di', 'wo', 'do', 'vr', 'za', 'zo'].map((d) => <span key={d} className="py-2">{d}</span>)}</div>
        <div key={iso(month)} className="anim-tabswap grid grid-cols-7">
          {days.map((d) => {
            const k = iso(d), list = items.filter((it) => d >= it.s && d <= it.e)
            const inMonth = d.getMonth() === month.getMonth()
            return (
              <div key={k} onDragOver={(e) => { e.preventDefault(); setOver(k) }} onDragLeave={() => setOver((o) => (o === k ? null : o))} onDrop={(e) => { e.preventDefault(); setOver(null); const id = e.dataTransfer.getData('text/adwerk-design'); if (id) drop(id, d) }}
                className={cn('min-h-[92px] min-w-0 border-b border-r border-line p-1 transition-colors [&:nth-child(7n)]:border-r-0', !inMonth && 'bg-sunk/40', over === k && 'bg-accent-soft/60')}>
                <span className={cn('mb-0.5 inline-grid h-6 min-w-6 place-items-center rounded-full px-1 text-xs font-semibold', k === today ? 'bg-accent text-white' : inMonth ? 'text-ink' : 'text-muted/60')}>{d.getDate()}</span>
                <div className="grid gap-0.5">
                  {list.slice(0, 3).map((it) => (
                    <button key={it.id} draggable={it.kind === 'design'} onDragStart={(e) => e.dataTransfer.setData('text/adwerk-design', it.id)} onClick={() => it.row && navigate(`/d/${it.id}`)} title={`${it.title} · ${dateLabel({ start_date: iso(it.s), end_date: iso(it.e) })}`}
                      className={cn('flex min-w-0 items-center gap-1 rounded-md px-1.5 py-0.5 text-left text-[11px] font-semibold leading-tight text-white transition hover:brightness-110', it.kind === 'campaign' && 'border border-dashed border-white/50')} style={{ background: it.color }}>
                      <span className="truncate">{it.title}</span>
                    </button>
                  ))}
                  {list.length > 3 && <span className="px-1 text-[10px] font-semibold text-muted">+{list.length - 3} meer</span>}
                </div>
              </div>
            )
          })}
        </div>
      </div>
      <aside className="grid content-start gap-2">
        <Label className="px-1">Nog niet gepland ({unplanned.length})</Label>
        <p className="px-1 text-xs text-muted">Sleep een ontwerp naar een dag om het in te plannen.</p>
        {unplanned.map((r) => (
          <div key={r.id} draggable onDragStart={(e) => e.dataTransfer.setData('text/adwerk-design', r.id)} className="flex min-w-0 cursor-grab items-center gap-2 rounded-xl border border-line bg-surface p-2 shadow-card active:cursor-grabbing">
            <Thumb r={r} className="h-9 w-9" /><span className="min-w-0 flex-1 truncate text-[13px] font-medium" title={r.title}>{r.title}</span><StatusDot status={r.status} />
          </div>
        ))}
        <div className="mt-2 grid gap-1 px-1 text-[11px] text-muted"><span className="flex items-center gap-1.5"><span className="h-2.5 w-4 rounded-sm border border-dashed border-white/60" style={{ background: "#5B3FD9" }} /> Campagne uit de klantbrief</span><span className="flex items-center gap-1.5"><span className="h-2.5 w-4 rounded-sm bg-gradient-to-r from-[#8A90A2] via-[#1A5FC4] to-[#13A06B]" /> Ontwerp (kleur = status)</span></div>
      </aside>
    </div>
  )
}

/* ---------- tijdlijn (Gantt) ---------- */
export function TimelineView({ rows, brief, me, onPatch, onBrief }: { rows: Row[]; brief?: ClientBrief | null; me: string; onPatch: (id: string, patch: Partial<Row>) => void; onBrief: (b: ClientBrief) => void }) {
  const DW = 34
  const items = useMemo(() => [...rows.map((r) => ({ key: r.id, title: r.title, rg: range(r), color: statusOf(r.status).color, row: r as Row | undefined, camp: undefined as ClientCampaign | undefined })), ...(brief?.campaigns || []).map((c) => ({ key: 'c' + c.id, title: c.name || 'Campagne', rg: range({ start_date: c.start, end_date: c.end }), color: '#5B3FD9', row: undefined, camp: c }))], [rows, brief])
  const planned = items.filter((i) => i.rg)
  const today = new Date(); today.setHours(0, 0, 0, 0)
  const min = planned.length ? new Date(Math.min(...planned.map((i) => i.rg!.s.getTime()))) : today
  const max = planned.length ? new Date(Math.max(...planned.map((i) => i.rg!.e.getTime()))) : today
  const start = addDays(min < addDays(today, -7) ? min : addDays(today, -7), -((((min < addDays(today, -7) ? min : addDays(today, -7)).getDay()) + 6) % 7) - 7)
  const total = Math.max(42, diffDays(start, max) + 21)
  const days = Array.from({ length: total }, (_, i) => addDays(start, i))
  const [drag, setDrag] = useState<{ key: string; mode: 'move' | 'l' | 'r'; dx: number } | null>(null)
  const scroller = useRef<HTMLDivElement>(null)
  useEffect(() => { const el = scroller.current; if (el) el.scrollLeft = Math.max(0, diffDays(start, today) * DW - 120) }, []) // eslint-disable-line react-hooks/exhaustive-deps

  const commit = async (it: (typeof items)[number], s: Date, e: Date) => {
    if (it.row) { const p = { start_date: iso(s), end_date: iso(e) }; onPatch(it.row.id, p); await saveDesign(it.row.id, p, me) }
    else if (it.camp && brief) onBrief({ ...brief, campaigns: brief.campaigns.map((c) => (c.id === it.camp!.id ? { ...c, start: iso(s), end: iso(e) } : c)) })
  }
  const startDrag = (ev: React.PointerEvent, it: (typeof items)[number], mode: 'move' | 'l' | 'r') => {
    ev.preventDefault(); ev.stopPropagation()
    const x0 = ev.clientX
    let dx = 0
    const mv = (e: PointerEvent) => { dx = Math.round((e.clientX - x0) / DW); setDrag({ key: it.key, mode, dx }) }
    const up = () => {
      window.removeEventListener('pointermove', mv); window.removeEventListener('pointerup', up)
      setDrag(null)
      if (!dx || !it.rg) return
      let s = it.rg.s, e = it.rg.e
      if (mode === 'move') { s = addDays(s, dx); e = addDays(e, dx) }
      if (mode === 'l') s = addDays(s, Math.min(dx, diffDays(s, e)))
      if (mode === 'r') e = addDays(e, Math.max(dx, -diffDays(s, e)))
      commit(it, s, e)
    }
    window.addEventListener('pointermove', mv); window.addEventListener('pointerup', up)
  }
  return (
    <div className="overflow-hidden rounded-2xl border border-line bg-surface">
      <div className="flex">
        <div className="w-[200px] shrink-0 border-r border-line sm:w-[240px]">
          <div className="flex h-14 items-end border-b border-line px-3 pb-2 text-[11px] font-bold uppercase tracking-wide text-muted">Ontwerp of campagne</div>
          {items.map((it) => (
            <div key={it.key} className="flex h-11 min-w-0 items-center gap-2 border-b border-line px-3">
              {it.camp ? <span className="h-2.5 w-2.5 shrink-0 rounded-sm bg-violet" /> : <StatusDot status={it.row?.status} />}
              <button onClick={() => it.row && navigate(`/d/${it.row.id}`)} className="min-w-0 flex-1 truncate text-left text-[13px] font-medium hover:underline" title={it.title}>{it.title}</button>
            </div>
          ))}
          {!items.length && <p className="p-4 text-sm text-muted">Nog niets in dit project.</p>}
        </div>
        <div ref={scroller} className="min-w-0 flex-1 overflow-x-auto">
          <div style={{ width: total * DW }} className="relative">
            <div className="flex h-14 border-b border-line">
              {days.map((d) => (
                <div key={iso(d)} className={cn('grid shrink-0 content-end justify-items-center border-r border-line/60 pb-1.5 text-[10px]', (d.getDay() === 0 || d.getDay() === 6) && 'bg-sunk/50')} style={{ width: DW }}>
                  {d.getDate() === 1 || iso(d) === iso(start) ? <span className="mb-0.5 whitespace-nowrap text-[10px] font-bold capitalize text-ink">{d.toLocaleDateString('nl-NL', { month: 'short' })}</span> : null}
                  <span className={cn('grid h-5 w-5 place-items-center rounded-full font-semibold', iso(d) === iso(today) ? 'bg-accent text-white' : 'text-muted')}>{d.getDate()}</span>
                </div>
              ))}
            </div>
            <span className="pointer-events-none absolute bottom-0 top-14 z-10 w-0.5 bg-accent/70" style={{ left: diffDays(start, today) * DW + DW / 2 }} />
            {items.map((it) => {
              const d = drag?.key === it.key ? drag : null
              let s = it.rg?.s, e = it.rg?.e
              if (s && e && d) { if (d.mode === 'move') { s = addDays(s, d.dx); e = addDays(e, d.dx) } else if (d.mode === 'l') s = addDays(s, Math.min(d.dx, diffDays(s, e))); else e = addDays(e, Math.max(d.dx, -diffDays(s, e))) }
              return (
                <div key={it.key} className="relative h-11 border-b border-line" style={{ backgroundImage: `repeating-linear-gradient(90deg, transparent 0 ${DW - 1}px, rgb(var(--line) / .5) ${DW - 1}px ${DW}px)` }}
                  onDoubleClick={(ev) => { if (it.rg) return; const r = (ev.currentTarget as HTMLDivElement).getBoundingClientRect(); const day = addDays(start, Math.floor((ev.clientX - r.left) / DW)); commit(it, day, addDays(day, 6)) }}>
                  {s && e ? (
                    <div onPointerDown={(ev) => startDrag(ev, it, 'move')} title={`${it.title} · ${dateLabel({ start_date: iso(s), end_date: iso(e) })}`}
                      className={cn('group absolute top-2 flex h-7 cursor-grab items-center rounded-lg px-2 text-[11px] font-semibold text-white shadow-card transition-shadow hover:shadow-pop active:cursor-grabbing', d && 'shadow-pop ring-2 ring-white', it.camp && 'border border-dashed border-white/60')}
                      style={{ left: diffDays(start, s) * DW + 2, width: (diffDays(s, e) + 1) * DW - 4, background: it.color }}>
                      <span onPointerDown={(ev) => startDrag(ev, it, 'l')} className="absolute inset-y-0 left-0 w-2 cursor-ew-resize rounded-l-lg opacity-0 group-hover:bg-white/30 group-hover:opacity-100" />
                      <span className="truncate">{it.title}</span>
                      <span onPointerDown={(ev) => startDrag(ev, it, 'r')} className="absolute inset-y-0 right-0 w-2 cursor-ew-resize rounded-r-lg opacity-0 group-hover:bg-white/30 group-hover:opacity-100" />
                    </div>
                  ) : (
                    <span className="pointer-events-none absolute left-3 top-1/2 flex -translate-y-1/2 items-center gap-1.5 text-[11px] text-muted" style={{ left: Math.max(0, diffDays(start, today) * DW - 40) }}><CalendarPlus size={13} /> Dubbelklik op een dag om in te plannen</span>
                  )}
                </div>
              )
            })}
          </div>
        </div>
      </div>
    </div>
  )
}

/* ---------- klantbrief ---------- */
const DEFAULT_SECTIONS = ['Afspraken', 'Doelen', 'Doelgroepen', 'Budget', 'Tone of voice', 'Huisstijl en links', 'Contactpersonen']
const CAMP_STATUS = ['Idee', 'Gepland', 'Loopt', 'Afgerond', 'Gepauzeerd']
const CAMP_COLORS: Record<string, string> = { Idee: '#8A90A2', Gepland: '#1A5FC4', Loopt: '#13A06B', Afgerond: '#1B213B', Gepauzeerd: '#F2B42C' }
const uid = () => Math.random().toString(36).slice(2, 10)
export const emptyClientBrief = (): ClientBrief => ({ sections: DEFAULT_SECTIONS.map((l) => ({ id: uid(), label: l, value: '' })), campaigns: [] })

function AutoArea({ value, onChange, placeholder }: { value: string; onChange: (v: string) => void; placeholder?: string }) {
  const ref = useRef<HTMLTextAreaElement>(null)
  useEffect(() => { const t = ref.current; if (t) { t.style.height = 'auto'; t.style.height = t.scrollHeight + 2 + 'px' } }, [value])
  return <textarea ref={ref} rows={2} value={value} placeholder={placeholder} onChange={(e) => onChange(e.target.value)} className="w-full resize-none rounded-xl bg-sunk px-3 py-2.5 text-sm leading-relaxed outline-none ring-violet placeholder:text-muted focus:ring-2" />
}

const HINTS: Record<string, string> = {
  Afspraken: 'Bijv. maandelijks overleg, oplevering op dinsdag, akkoord via de feedbacklink',
  Doelen: 'Bijv. 40 leads per maand, ROAS boven 4, meer bekendheid in Groningen',
  Doelgroepen: 'Bijv. huiseigenaren 35 tot 60 in Noord-Nederland',
  Budget: 'Bijv. €1.500 per maand mediabudget, waarvan 60% Meta',
  'Tone of voice': 'Bijv. je-vorm, nuchter, vakkundig, geen uitroeptekens',
  'Huisstijl en links': 'Bijv. merkset in Adwerk, Drive-map, Canva-map',
  Contactpersonen: 'Bijv. Sanne de Vries, marketing, 06 12345678',
}

export function ClientBriefView({ folder, onSaved }: { folder: Folder; onSaved: (b: ClientBrief) => void }) {
  const [b, setB] = useState<ClientBrief>(() => folder.brief || emptyClientBrief())
  const [state, setState] = useState<'saved' | 'saving' | 'dirty'>('saved')
  const timer = useRef<ReturnType<typeof setTimeout>>()
  const latest = useRef(b)
  useEffect(() => { if (state === 'saved' && folder.brief && JSON.stringify(folder.brief) !== JSON.stringify(latest.current)) { setB(folder.brief); latest.current = folder.brief } }, [folder.brief]) // eslint-disable-line react-hooks/exhaustive-deps
  const change = (fn: (x: ClientBrief) => ClientBrief) => {
    setB((cur) => { const n = fn(cur); latest.current = n; return n })
    setState('dirty')
    clearTimeout(timer.current)
    timer.current = setTimeout(async () => { setState('saving'); await updateFolder(folder.id, { brief: latest.current }); onSaved(latest.current); setState('saved') }, 700)
  }
  const setCamp = (id: string, p: Partial<ClientCampaign>) => change((x) => ({ ...x, campaigns: x.campaigns.map((c) => (c.id === id ? { ...c, ...p } : c)) }))
  return (
    <div className="grid gap-8">
      <div className="flex items-center justify-between gap-3">
        <p className="max-w-2xl text-sm text-muted">De vaste afspraken met deze klant. Collega's en Claude lezen dit bij elk ontwerp in dit project.</p>
        <span className="shrink-0 text-xs text-muted">{state === 'saved' ? 'Opgeslagen' : 'Opslaan…'}</span>
      </div>
      <section className="grid gap-3 md:grid-cols-2">
        {b.sections.map((s) => (
          <div key={s.id} className="anim-rise group grid content-start gap-1.5 rounded-2xl border border-line bg-surface p-3">
            <div className="flex items-center gap-2">
              <input value={s.label} onChange={(e) => change((x) => ({ ...x, sections: x.sections.map((y) => (y.id === s.id ? { ...y, label: e.target.value } : y)) }))} className="min-w-0 flex-1 bg-transparent text-[11px] font-bold uppercase tracking-[0.08em] text-muted outline-none focus:text-ink" aria-label="Naam van het onderdeel" />
              <button onClick={() => change((x) => ({ ...x, sections: x.sections.filter((y) => y.id !== s.id) }))} className="grid h-6 w-6 place-items-center rounded-md text-muted opacity-0 transition hover:bg-sunk hover:text-ink group-hover:opacity-100" aria-label={`${s.label} verwijderen`}><X size={14} /></button>
            </div>
            <AutoArea value={s.value} onChange={(v) => change((x) => ({ ...x, sections: x.sections.map((y) => (y.id === s.id ? { ...y, value: v } : y)) }))} placeholder={HINTS[s.label] || 'Vrij invullen'} />
          </div>
        ))}
        <button onClick={() => change((x) => ({ ...x, sections: [...x.sections, { id: uid(), label: 'Nieuw onderdeel', value: '' }] }))} className="grid min-h-[110px] place-items-center rounded-2xl border-2 border-dashed border-line text-sm font-semibold text-muted transition hover:border-ink/30 hover:text-ink"><span className="flex items-center gap-2"><Plus size={16} /> Onderdeel toevoegen</span></button>
      </section>

      <section className="grid gap-3">
        <div className="flex items-center justify-between"><h3 className="font-display text-xl font-semibold">Campagnes<span className="text-accent-fg">.</span></h3>
          <Button size="sm" onClick={() => change((x) => ({ ...x, campaigns: [...x.campaigns, { id: uid(), name: '', channel: '', goal: '', budget: '', start: null, end: null, status: 'Idee', note: '' }] }))}><Plus size={15} /> Campagne</Button></div>
        {b.campaigns.length ? (
          <div className="grid grid-cols-[repeat(auto-fill,minmax(min(100%,300px),1fr))] gap-3">
            {b.campaigns.map((c) => {
              return (
                <div key={c.id} className="anim-rise group/c grid min-w-0 gap-2.5 rounded-2xl border border-line bg-surface p-3 transition hover:shadow-card">
                  <div className="flex min-w-0 items-center gap-2">
                    <input value={c.name} onChange={(e) => setCamp(c.id, { name: e.target.value })} placeholder="Naam, bijv. Herfstactie" title={c.name} aria-label="Naam campagne" className="h-9 min-w-0 flex-1 truncate rounded-lg bg-transparent px-2 font-display text-[15px] font-semibold outline-none ring-violet hover:bg-sunk/60 focus:bg-sunk focus:ring-2" />
                    <Select value={c.status} onChange={(v) => setCamp(c.id, { status: v })} ariaLabel="Status campagne" size="sm" fullWidth={false} align="end" className="shrink-0 rounded-full text-xs font-semibold" options={CAMP_STATUS.map((x) => ({ value: x, label: x, dot: CAMP_COLORS[x] }))} />
                    <Tip label="Campagne verwijderen"><button onClick={() => change((x) => ({ ...x, campaigns: x.campaigns.filter((y) => y.id !== c.id) }))} className="grid h-8 w-8 shrink-0 place-items-center rounded-lg text-muted opacity-60 transition hover:bg-sunk hover:text-accent-fg group-hover/c:opacity-100" aria-label="Campagne verwijderen"><Trash2 size={15} /></button></Tip>
                  </div>
                  <div className="grid grid-cols-2 gap-2">
                    <label className="grid min-w-0 gap-1"><span className="px-1 text-[11px] font-semibold uppercase tracking-wide text-muted">Kanaal</span><Combobox value={c.channel} onChange={(v) => setCamp(c.id, { channel: v })} suggestions={['Meta Ads', 'LinkedIn Ads', 'Google Ads', 'Google Display', 'Demand Gen', 'TikTok', 'Nieuwsbrief', 'Organisch social']} placeholder="Kanaal" ariaLabel="Kanaal" /></label>
                    <label className="grid min-w-0 gap-1"><span className="px-1 text-[11px] font-semibold uppercase tracking-wide text-muted">Doel</span><Combobox value={c.goal} onChange={(v) => setCamp(c.id, { goal: v })} suggestions={['Websiteverkeer', 'Leads', 'Verkoop', 'Naamsbekendheid', 'Bereik', 'Werving']} placeholder="Doel" ariaLabel="Doel" /></label>
                    <label className="col-span-2 grid min-w-0 gap-1"><span className="px-1 text-[11px] font-semibold uppercase tracking-wide text-muted">Budget</span><input value={c.budget} onChange={(e) => setCamp(c.id, { budget: e.target.value })} placeholder="€500 per maand" className="h-9 w-full min-w-0 rounded-lg bg-sunk px-3 text-sm outline-none ring-violet focus:ring-2" /></label>
                    <label className="grid min-w-0 gap-1"><span className="px-1 text-[11px] font-semibold uppercase tracking-wide text-muted">Start</span><input type="date" value={c.start || ''} onChange={(e) => setCamp(c.id, { start: e.target.value || null, end: c.end && e.target.value > c.end ? e.target.value : c.end })} className="h-9 w-full min-w-0 rounded-lg bg-sunk px-2 text-sm outline-none ring-violet focus:ring-2" /></label>
                    <label className="grid min-w-0 gap-1"><span className="px-1 text-[11px] font-semibold uppercase tracking-wide text-muted">Eind</span><input type="date" value={c.end || ''} min={c.start || undefined} onChange={(e) => setCamp(c.id, { end: e.target.value || null })} className="h-9 w-full min-w-0 rounded-lg bg-sunk px-2 text-sm outline-none ring-violet focus:ring-2" /></label>
                  </div>
                  <AutoArea value={c.note} onChange={(v) => setCamp(c.id, { note: v })} placeholder="Notitie, bijv. doelgroep of aanbod" />
                </div>
              )
            })}
          </div>
        ) : <p className="rounded-2xl border-2 border-dashed border-line px-4 py-8 text-center text-sm text-muted">Nog geen campagnes. Voeg er een toe; met een start- en einddatum verschijnt hij ook in de kalender en de tijdlijn.</p>}
      </section>
      {folder.website && <a href={folder.website} target="_blank" rel="noreferrer" className="flex w-fit items-center gap-1.5 text-sm font-semibold text-violet hover:underline"><ExternalLink size={15} /> Website van de klant openen</a>}
    </div>
  )
}
