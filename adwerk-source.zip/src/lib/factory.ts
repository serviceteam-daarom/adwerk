import { nanoid } from 'nanoid'
import type { DesignDoc, El, ElAnim, ElType, Frame } from './types'
import { formatByKey, type FormatPreset } from './formats'

export const uid = () => nanoid(10)

export const defaultAnim = (): ElAnim => ({
  in: { type: 'none', delay: 0, duration: 0.6 },
  out: { type: 'none', delay: 0, duration: 0.5 },
  emph: { type: 'none', speed: 1 },
})

const NAMES: Record<ElType, string> = {
  text: 'Tekst', rect: 'Rechthoek', ellipse: 'Cirkel', triangle: 'Driehoek', star: 'Ster', line: 'Lijn', image: 'Afbeelding', icon: 'Icoon',
}

export function makeEl(type: ElType, frame: { w: number; h: number }, patch: Partial<El> = {}): El {
  const base = Math.min(frame.w, frame.h)
  const size = Math.round(base * 0.3)
  const el: El = {
    id: uid(),
    type,
    name: NAMES[type],
    x: Math.round(frame.w / 2 - size / 2),
    y: Math.round(frame.h / 2 - size / 2),
    width: size,
    height: size,
    rotation: 0,
    opacity: 1,
    visible: true,
    locked: false,
    fill: '#EA5F39',
    stroke: '#1B213B',
    strokeWidth: 0,
    cornerRadius: 0,
    shadow: { enabled: false, color: '#000000', blur: 20, x: 0, y: 8, opacity: 0.25 },
    blend: 'source-over',
    anim: defaultAnim(),
  }
  if (type === 'text') {
    const fs = Math.max(12, Math.round(base * 0.08))
    Object.assign(el, {
      text: 'Jouw tekst hier', fontFamily: 'Poppins', fontSize: fs, fontWeight: 700, italic: false, underline: false,
      align: 'center', lineHeight: 1.15, letterSpacing: 0, uppercase: false, fill: '#1B213B',
      width: Math.round(frame.w * 0.7), height: Math.round(fs * 1.2),
    })
    el.x = Math.round((frame.w - el.width) / 2)
    el.y = Math.round((frame.h - el.height) / 2)
  }
  if (type === 'line') Object.assign(el, { height: Math.max(4, Math.round(base * 0.01)), fill: '#1B213B', width: size * 1.5, y: Math.round(frame.h / 2) })
  if (type === 'star') Object.assign(el, { points: 5, innerRatio: 0.45, fill: '#FFC233' })
  if (type === 'icon') Object.assign(el, { icon: 'star', fill: '#1B213B', width: Math.round(base * 0.16), height: Math.round(base * 0.16), strokeWidth: 2 })
  if (type === 'image') Object.assign(el, { cropZoom: 1, cropX: 0.5, cropY: 0.5, fill: '#D9D6E3' })
  Object.assign(el, patch)
  return el
}

export function makeFrame(preset: FormatPreset, patch: Partial<Frame> = {}): Frame {
  return {
    id: uid(),
    name: `${preset.name} ${preset.w}×${preset.h}`,
    w: preset.w,
    h: preset.h,
    platform: preset.platform,
    background: { type: 'solid', color: '#FFFFFF', color2: '#F6F5FA', angle: 135 },
    elements: [],
    duration: 6,
    safeZone: preset.h / preset.w > 1.7,
    ...patch,
  }
}

export function docFromFormats(keys: string[]): DesignDoc {
  return { version: 1, frames: keys.map((k) => makeFrame(formatByKey(k))) }
}

/** Slim meeschalen: zet de inhoud van een bronformaat om naar een ander formaat. */
export function resizeElements(src: Frame, target: { w: number; h: number }): El[] {
  const sx = target.w / src.w
  const sy = target.h / src.h
  const s = Math.min(sx, sy)
  const sMax = Math.max(sx, sy)
  const textK = (_e?: El) => Math.min(Math.max(s, Math.sqrt(sx * sy) * 0.85), sMax)
  // stories: inhoud binnen de veilige zones houden
  const story = target.h / target.w > 1.7 && !(src.h / src.w > 1.7)
  const mapY = (cy: number) => (story ? target.h * 0.14 + (cy / src.h) * target.h * 0.66 : cy * sy)
  // vormen achter een tekst (zoals een knop) krijgen dezelfde schaal als die tekst
  const pairK = new Map<string, { k: number; cx: number; cy: number }>()
  for (const e of src.elements) {
    if (e.type === 'text' || e.width * e.height > src.w * src.h * 0.3) continue
    const t = src.elements.find((t) => t.type === 'text' && t.x + t.width / 2 > e.x && t.x + t.width / 2 < e.x + e.width && t.y + t.height / 2 > e.y && t.y + t.height / 2 < e.y + e.height && t.width <= e.width * 1.2)
    if (t) pairK.set(e.id, { k: textK(t), cx: t.x + t.width / 2, cy: t.y + t.height / 2 })
  }
  return src.elements.map((e) => {
    const n: El = JSON.parse(JSON.stringify(e))
    n.id = uid()
    const coversFrame = e.width >= src.w * 0.9 && e.height >= src.h * 0.9
    if (coversFrame) {
      const k = e.type === 'image' ? sMax : 1
      n.width = e.type === 'image' ? e.width * k : e.width * sx
      n.height = e.type === 'image' ? e.height * k : e.height * sy
      n.x = (target.w - n.width) / 2
      n.y = (target.h - n.height) / 2
      return n
    }
    const pair = pairK.get(e.id)
    const ocx = e.x + e.width / 2, ocy = e.y + e.height / 2
    // gekoppelde vorm: zelfde middelpunt-verschuiving als de tekst
    const cx = pair ? pair.cx * sx + (ocx - pair.cx) * pair.k : ocx * sx
    const cy = pair ? mapY(pair.cy) + (ocy - pair.cy) * pair.k : mapY(ocy)
    // tekst mag breder worden in brede formaten zodat het niet onleesbaar klein wordt
    let k = s
    if (e.type === 'text') k = textK(e)
    if (pair) k = pair.k
    n.width = e.width * k
    n.height = e.height * k
    if (e.type === 'text') {
      n.fontSize = Math.max(8, Math.round((e.fontSize || 24) * k))
      n.width = Math.min(n.width, target.w * 0.94)
    }
    n.strokeWidth = e.strokeWidth * s
    n.cornerRadius = e.cornerRadius * s
    n.shadow = { ...e.shadow, blur: e.shadow.blur * s, x: e.shadow.x * s, y: e.shadow.y * s }
    n.x = cx - n.width / 2
    n.y = cy - n.height / 2
    // binnen het canvas houden
    n.x = Math.min(Math.max(n.x, -n.width * 0.4), target.w - n.width * 0.6)
    n.y = Math.min(Math.max(n.y, -n.height * 0.4), target.h - n.height * 0.6)
    return n
  })
}

export function cloneFrameTo(src: Frame, preset: FormatPreset): Frame {
  return {
    ...makeFrame(preset),
    background: { ...src.background },
    duration: src.duration,
    elements: resizeElements(src, preset),
  }
}

export const clone = <T,>(v: T): T => JSON.parse(JSON.stringify(v))
