import Konva from 'konva'
import type { El, Frame } from './types'
import { stateAt } from './anim'
import { iconDataUrl } from './icons'
import { loadFontsForDoc, nearestWeight } from './fonts'

Konva.pixelRatio = Math.min(2, window.devicePixelRatio || 1)

const imgCache = new Map<string, Promise<HTMLImageElement | null>>()

export function loadImage(src: string): Promise<HTMLImageElement | null> {
  if (!src) return Promise.resolve(null)
  if (imgCache.has(src)) return imgCache.get(src)!
  const p = new Promise<HTMLImageElement | null>((resolve) => {
    const img = new Image()
    if (!src.startsWith('data:')) img.crossOrigin = 'anonymous'
    img.onload = () => resolve(img)
    img.onerror = () => resolve(null)
    img.src = src
  })
  imgCache.set(src, p)
  return p
}

function starPoints(w: number, h: number, n: number, ratio: number) {
  const pts: number[] = []
  for (let i = 0; i < n * 2; i++) {
    const r = i % 2 === 0 ? 1 : ratio
    const a = (Math.PI * i) / n - Math.PI / 2
    pts.push(w / 2 + Math.cos(a) * (w / 2) * r, h / 2 + Math.sin(a) * (h / 2) * r)
  }
  return pts
}

function coverCrop(img: HTMLImageElement, w: number, h: number, zoom = 1, fx = 0.5, fy = 0.5) {
  const iw = img.naturalWidth, ih = img.naturalHeight
  const scale = Math.max(w / iw, h / ih) * Math.max(1, zoom)
  const cw = w / scale, ch = h / scale
  return { x: (iw - cw) * Math.min(1, Math.max(0, fx)), y: (ih - ch) * Math.min(1, Math.max(0, fy)), width: cw, height: ch }
}

export function fontStyle(el: El) {
  const w = nearestWeight(el.fontFamily || 'Figtree', el.fontWeight || 400)
  return `${el.italic ? 'italic ' : ''}${w}`
}

function applyShadow(shape: Konva.Shape, el: El) {
  const s = el.shadow
  shape.shadowEnabled(!!s?.enabled)
  if (s?.enabled) {
    shape.shadowColor(s.color)
    shape.shadowBlur(s.blur)
    shape.shadowOffset({ x: s.x, y: s.y })
    shape.shadowOpacity(s.opacity)
  }
}

function applyFilters(shape: Konva.Shape, el: El) {
  const f = el.filters
  const active = f && (f.brightness || f.contrast || f.saturation || f.hue || f.blur || f.grayscale)
  if (!active) {
    shape.filters([])
    shape.clearCache()
    return
  }
  const list: typeof Konva.Filters.Blur[] = []
  if (f!.brightness) list.push(Konva.Filters.Brighten)
  if (f!.contrast) list.push(Konva.Filters.Contrast)
  if (f!.saturation || f!.hue) list.push(Konva.Filters.HSL)
  if (f!.blur) list.push(Konva.Filters.Blur)
  if (f!.grayscale) list.push(Konva.Filters.Grayscale)
  shape.filters(list)
  shape.brightness(f!.brightness || 0)
  shape.contrast(f!.contrast || 0)
  shape.saturation(f!.saturation || 0)
  shape.hue(f!.hue || 0)
  shape.blurRadius(f!.blur || 0)
  try { shape.cache({ pixelRatio: 1 }) } catch { /* lege vorm */ }
}

export interface RenderOpts { interactive: boolean; onMeasure?: (id: string, h: number) => void; onImageLoaded?: () => void }

export class FrameRenderer {
  root: Konva.Group
  content: Konva.Group
  bg: Konva.Rect
  bgImage: Konva.Image
  nodes = new Map<string, Konva.Group>()
  frame: Frame | null = null
  pending: Promise<unknown>[] = []
  opts: RenderOpts

  constructor(layer: Konva.Layer, opts: RenderOpts) {
    this.opts = opts
    this.root = new Konva.Group({ name: 'frame-root' })
    this.bg = new Konva.Rect({ name: 'bg', x: 0, y: 0 })
    this.bgImage = new Konva.Image({ name: 'bg', image: undefined, listening: true })
    this.content = new Konva.Group({ name: 'content' })
    this.root.add(this.bg, this.bgImage, this.content)
    layer.add(this.root)
  }

  sync(frame: Frame) {
    this.frame = frame
    this.pending = []
    this.root.clip({ x: 0, y: 0, width: frame.w, height: frame.h })
    const b = frame.background
    this.bg.size({ width: frame.w, height: frame.h })
    if (b.type === 'gradient') {
      const a = ((b.angle || 0) * Math.PI) / 180
      const cx = frame.w / 2, cy = frame.h / 2
      const r = Math.abs(frame.w / 2 * Math.cos(a)) + Math.abs(frame.h / 2 * Math.sin(a))
      this.bg.fill(null as unknown as string)
      this.bg.fillLinearGradientStartPoint({ x: cx - Math.cos(a) * r, y: cy - Math.sin(a) * r })
      this.bg.fillLinearGradientEndPoint({ x: cx + Math.cos(a) * r, y: cy + Math.sin(a) * r })
      this.bg.fillLinearGradientColorStops([0, b.color, 1, b.color2])
      this.bg.fillPriority('linear-gradient')
    } else {
      this.bg.fillPriority('color')
      this.bg.fill(b.color)
    }
    if (b.type === 'image' && b.src) {
      const src = b.src
      this.pending.push(loadImage(src).then((img) => {
        if (!img || this.frame?.background.src !== src) return
        this.bgImage.image(img)
        this.bgImage.size({ width: frame.w, height: frame.h })
        this.bgImage.crop(coverCrop(img, frame.w, frame.h))
        this.bgImage.visible(true)
        this.bgImage.getLayer()?.batchDraw()
        this.opts.onImageLoaded?.()
      }))
    } else {
      this.bgImage.visible(false)
    }

    const ids = new Set(frame.elements.map((e) => e.id))
    for (const [id, g] of this.nodes) if (!ids.has(id)) { g.destroy(); this.nodes.delete(id) }
    frame.elements.forEach((el, i) => {
      let g = this.nodes.get(el.id)
      if (!g) {
        g = new Konva.Group({ id: el.id, name: 'el' })
        this.nodes.set(el.id, g)
        this.content.add(g)
      }
      this.updateGroup(g, el)
      g.zIndex(i)
    })
    return Promise.all(this.pending)
  }

  private updateGroup(g: Konva.Group, el: El) {
    const json = JSON.stringify(el)
    const changed = g.getAttr('json') !== json
    g.setAttr('json', json)
    g.setAttr('el', el)
    if (changed) this.buildShape(g, el)
    const h = g.getAttr('h') ?? el.height
    g.setAttrs({
      x: el.x + el.width / 2, y: el.y + h / 2, offsetX: el.width / 2, offsetY: h / 2,
      rotation: el.rotation, opacity: el.opacity, visible: el.visible, scaleX: 1, scaleY: 1,
      draggable: this.opts.interactive && !el.locked, listening: this.opts.interactive ? el.visible : false,
      globalCompositeOperation: (el.blend || 'source-over') as GlobalCompositeOperation,
    })
  }

  private buildShape(g: Konva.Group, el: El) {
    g.destroyChildren()
    const w = el.width, h = el.height
    let shape: Konva.Shape
    const common = { fill: el.fill, stroke: el.strokeWidth > 0 ? el.stroke : undefined, strokeWidth: el.strokeWidth, name: 'shape' }
    switch (el.type) {
      case 'text': {
        const t = new Konva.Text({
          ...common, width: w, text: el.uppercase ? (el.text || '').toUpperCase() : el.text || '',
          fontFamily: `"${el.fontFamily || 'Figtree'}", sans-serif`, fontSize: el.fontSize || 24, fontStyle: fontStyle(el),
          textDecoration: el.underline ? 'underline' : '', align: el.align || 'left', lineHeight: el.lineHeight || 1.2,
          letterSpacing: el.letterSpacing || 0, fillAfterStrokeEnabled: true, wrap: 'word',
        })
        shape = t
        const mh = Math.ceil(t.height())
        g.setAttr('h', mh)
        if (Math.abs(mh - el.height) > 0.5) this.opts.onMeasure?.(el.id, mh)
        break
      }
      case 'ellipse':
        shape = new Konva.Ellipse({ ...common, x: w / 2, y: h / 2, radiusX: w / 2, radiusY: h / 2 })
        break
      case 'triangle':
        shape = new Konva.Line({ ...common, points: [w / 2, 0, w, h, 0, h], closed: true, lineJoin: 'round' })
        break
      case 'star':
        shape = new Konva.Line({ ...common, points: starPoints(w, h, el.points || 5, el.innerRatio || 0.45), closed: true, lineJoin: 'round' })
        break
      case 'line':
        shape = new Konva.Rect({ ...common, width: w, height: h, cornerRadius: Math.min(el.cornerRadius, h / 2) })
        break
      case 'image': {
        const img = new Konva.Image({ ...common, image: undefined, width: w, height: h, cornerRadius: el.cornerRadius, fill: el.src ? undefined : el.fill })
        img.scaleX(el.flipX ? -1 : 1); img.scaleY(el.flipY ? -1 : 1)
        img.x(el.flipX ? w : 0); img.y(el.flipY ? h : 0)
        shape = img
        if (el.src) {
          const src = el.src
          this.pending.push(loadImage(src).then((im) => {
            if (!im || (g.getAttr('el') as El)?.src !== src) return
            img.image(im)
            img.crop(coverCrop(im, w, h, el.cropZoom, el.cropX, el.cropY))
            applyFilters(img, el)
            img.getLayer()?.batchDraw()
            this.opts.onImageLoaded?.()
          }))
        }
        break
      }
      case 'icon': {
        const img = new Konva.Image({ name: 'shape', image: undefined, width: w, height: h })
        shape = img
        const src = iconDataUrl(el.icon || 'star', el.fill, el.strokeWidth || 2, 256)
        this.pending.push(loadImage(src).then((im) => {
          if (!im) return
          img.image(im)
          applyFilters(img, el)
          img.getLayer()?.batchDraw()
        }))
        break
      }
      default:
        shape = new Konva.Rect({ ...common, width: w, height: h, cornerRadius: el.cornerRadius })
    }
    if (el.type !== 'text') g.setAttr('h', h)
    applyShadow(shape, el)
    g.add(shape)
    if (el.type !== 'image' && el.type !== 'icon') applyFilters(shape, el)
  }

  /** Zet alle elementen in hun animatietoestand op tijdstip t (null = rusttoestand). */
  applyTime(t: number | null) {
    if (!this.frame) return
    for (const el of this.frame.elements) {
      const g = this.nodes.get(el.id)
      if (!g) continue
      const h = g.getAttr('h') ?? el.height
      const bx = el.x + el.width / 2, by = el.y + h / 2
      if (t === null) {
        g.setAttrs({ x: bx, y: by, scaleX: 1, scaleY: 1, rotation: el.rotation, opacity: el.opacity })
        continue
      }
      const s = stateAt(el, this.frame, t)
      g.setAttrs({ x: bx + s.dx, y: by + s.dy, scaleX: s.scale, scaleY: s.scale, rotation: el.rotation + s.rotation, opacity: el.opacity * s.opacity })
    }
    this.root.getLayer()?.batchDraw()
  }

  destroy() { this.root.destroy(); this.nodes.clear() }
}

/** Offscreen renderer voor export en thumbnails. */
export async function createOffscreen(frame: Frame) {
  await loadFontsForDoc(frame.elements.filter((e) => e.type === 'text').map((e) => e.fontFamily || 'Figtree'))
  const container = document.createElement('div')
  container.style.cssText = 'position:fixed;left:-99999px;top:0;'
  document.body.appendChild(container)
  const stage = new Konva.Stage({ container, width: frame.w, height: frame.h })
  const layer = new Konva.Layer()
  stage.add(layer)
  const r = new FrameRenderer(layer, { interactive: false })
  await r.sync(frame)
  // tweede ronde zodat tekstmaten met geladen fonts kloppen
  r.nodes.forEach((g) => g.setAttr('json', ''))
  await r.sync(frame)
  layer.draw()
  return {
    stage, layer, renderer: r,
    canvasAt(t: number | null, pixelRatio = 1) {
      r.applyTime(t)
      layer.draw()
      return stage.toCanvas({ pixelRatio, x: 0, y: 0, width: frame.w, height: frame.h })
    },
    destroy() { stage.destroy(); container.remove() },
  }
}
