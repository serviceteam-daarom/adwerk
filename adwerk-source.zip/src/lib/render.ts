import Konva from 'konva'
import type { El, Frame } from './types'
import { stateAt, animStateAt, aroundPivot, type AnimState } from './anim'
import { iconDataUrl } from './icons'
import { colorSvg, svgDataUrl } from './iconify'
import { loadFontsForDoc, nearestWeight } from './fonts'

Konva.pixelRatio = Math.min(2, window.devicePixelRatio || 1)

import { normalizeSvg, isSvgSrc } from './svg'
const imgCache = new Map<string, Promise<HTMLImageElement | null>>()

export function loadImage(src: string): Promise<HTMLImageElement | null> {
  if (!src) return Promise.resolve(null)
  if (imgCache.has(src)) return imgCache.get(src)!
  const plain = (url: string, cors: boolean) => new Promise<HTMLImageElement | null>((resolve) => {
    const img = new Image()
    if (cors) img.crossOrigin = 'anonymous'
    img.onload = () => resolve(img)
    img.onerror = () => resolve(null)
    img.src = url
  })
  const p = isSvgSrc(src) ? loadSvg(src).then((im) => im || plain(src, !src.startsWith('data:'))) : plain(src, !src.startsWith('data:'))
  imgCache.set(src, p)
  return p
}

/** SVG scherp en met de juiste verhouding laden: maat vastzetten op 2048 px aan de lange kant. */
async function loadSvg(src: string): Promise<HTMLImageElement | null> {
  try {
    let text: string
    if (src.startsWith('data:')) {
      const i = src.indexOf(',')
      const meta = src.slice(0, i), body = src.slice(i + 1)
      text = /;base64/i.test(meta) ? new TextDecoder().decode(Uint8Array.from(atob(body), (c) => c.charCodeAt(0))) : (() => { try { return decodeURIComponent(body) } catch { return body } })()
    } else {
      const r = await fetch(src)
      if (!r.ok) return null
      text = await r.text()
    }
    const n = normalizeSvg(text, 2048)
    if (!n) return null
    const url = URL.createObjectURL(new Blob([n.svg], { type: 'image/svg+xml' }))
    return await new Promise((resolve) => {
      const img = new Image()
      img.onload = () => resolve(img.naturalWidth ? img : null)
      img.onerror = () => resolve(null)
      img.src = url
    })
  } catch { return null }
}

function starPoints(w: number, h: number, n: number, ratio: number) {
  const pts: number[] = []
  for (let i = 0; i < n * 2; i++) {
    const r = i % 2 === 0 ? 1 : ratio
    const a = (Math.PI * i) / n - Math.PI / 2
    pts.push(w / 2 + Math.cos(a) * (w / 2) * r, h / 2 + Math.sin(a) * (h / 2) * r)
  }
  return pts
}

function coverCrop(img: HTMLImageElement, w: number, h: number, zoom = 1, fx = 0.5, fy = 0.5) {
  const iw = img.naturalWidth, ih = img.naturalHeight
  const scale = Math.max(w / iw, h / ih) * Math.max(1, zoom)
  const cw = w / scale, ch = h / scale
  return { x: (iw - cw) * Math.min(1, Math.max(0, fx)), y: (ih - ch) * Math.min(1, Math.max(0, fy)), width: cw, height: ch }
}

export function fontStyle(el: El) {
  const w = nearestWeight(el.fontFamily || 'Poppins', el.fontWeight || 400)
  return `${el.italic ? 'italic ' : ''}${w}`
}

function applyShadow(shape: Konva.Shape, el: El) {
  const s = el.shadow
  shape.shadowEnabled(!!s?.enabled)
  if (s?.enabled) {
    shape.shadowColor(s.color)
    shape.shadowBlur(s.blur)
    shape.shadowOffset({ x: s.x, y: s.y })
    shape.shadowOpacity(s.opacity)
  }
}

function applyFilters(shape: Konva.Shape, el: El) {
  const f = el.filters
  const active = f && (f.brightness || f.contrast || f.saturation || f.hue || f.blur || f.grayscale)
  if (!active) {
    shape.filters([])
    shape.clearCache()
    return
  }
  const list: typeof Konva.Filters.Blur[] = []
  if (f!.brightness) list.push(Konva.Filters.Brighten)
  if (f!.contrast) list.push(Konva.Filters.Contrast)
  if (f!.saturation || f!.hue) list.push(Konva.Filters.HSL)
  if (f!.blur) list.push(Konva.Filters.Blur)
  if (f!.grayscale) list.push(Konva.Filters.Grayscale)
  shape.filters(list)
  shape.brightness(f!.brightness || 0)
  shape.contrast(f!.contrast || 0)
  shape.saturation(f!.saturation || 0)
  shape.hue(f!.hue || 0)
  shape.blurRadius(f!.blur || 0)
  try { shape.cache({ pixelRatio: 1 }) } catch { /* lege vorm */ }
}

export interface RenderOpts { interactive: boolean; onMeasure?: (id: string, h: number) => void; onImageLoaded?: () => void }

export class FrameRenderer {
  root: Konva.Group
  content: Konva.Group
  bg: Konva.Rect
  bgImage: Konva.Image
  nodes = new Map<string, Konva.Group>()
  frame: Frame | null = null
  pending: Promise<unknown>[] = []
  peerLocked = new Set<string>()
  opts: RenderOpts

  constructor(layer: Konva.Layer, opts: RenderOpts) {
    this.opts = opts
    this.root = new Konva.Group({ name: 'frame-root' })
    this.bg = new Konva.Rect({ name: 'bg', x: 0, y: 0 })
    this.bgImage = new Konva.Image({ name: 'bg', image: undefined, listening: true })
    this.content = new Konva.Group({ name: 'content' })
    this.root.add(this.bg, this.bgImage, this.content)
    layer.add(this.root)
  }

  sync(frame: Frame) {
    this.frame = frame
    this.pending = []
    this.root.clip({ x: 0, y: 0, width: frame.w, height: frame.h })
    const b = frame.background
    this.bg.size({ width: frame.w, height: frame.h })
    if (b.type === 'gradient') {
      const a = ((b.angle || 0) * Math.PI) / 180
      const cx = frame.w / 2, cy = frame.h / 2
      const r = Math.abs(frame.w / 2 * Math.cos(a)) + Math.abs(frame.h / 2 * Math.sin(a))
      this.bg.fill(null as unknown as string)
      this.bg.fillLinearGradientStartPoint({ x: cx - Math.cos(a) * r, y: cy - Math.sin(a) * r })
      this.bg.fillLinearGradientEndPoint({ x: cx + Math.cos(a) * r, y: cy + Math.sin(a) * r })
      this.bg.fillLinearGradientColorStops([0, b.color, 1, b.color2])
      this.bg.fillPriority('linear-gradient')
    } else {
      this.bg.fillPriority('color')
      this.bg.fill(b.color)
    }
    if (b.type === 'image' && b.src) {
      const src = b.src
      this.pending.push(loadImage(src).then((img) => {
        if (!img || this.frame?.background.src !== src) return
        this.bgImage.image(img)
        this.bgImage.size({ width: frame.w, height: frame.h })
        this.bgImage.crop(coverCrop(img, frame.w, frame.h))
        this.bgImage.visible(true)
        this.bgImage.getLayer()?.batchDraw()
        this.opts.onImageLoaded?.()
      }))
    } else {
      this.bgImage.visible(false)
    }

    const ids = new Set(frame.elements.map((e) => e.id))
    for (const [id, g] of this.nodes) if (!ids.has(id)) { g.destroy(); this.nodes.delete(id) }
    frame.elements.forEach((el, i) => {
      let g = this.nodes.get(el.id)
      if (!g) {
        g = new Konva.Group({ id: el.id, name: 'el' })
        this.nodes.set(el.id, g)
        this.content.add(g)
      }
      this.updateGroup(g, el)
      g.zIndex(i)
    })
    return Promise.all(this.pending)
  }

  private updateGroup(g: Konva.Group, el: El) {
    const json = JSON.stringify(el)
    const changed = g.getAttr('json') !== json
    g.setAttr('json', json)
    g.setAttr('el', el)
    if (changed) this.buildShape(g, el)
    const h = g.getAttr('h') ?? el.height
    g.setAttrs({
      x: el.x + el.width / 2, y: el.y + h / 2, offsetX: el.width / 2, offsetY: h / 2,
      rotation: el.rotation, opacity: el.opacity, visible: el.visible, scaleX: 1, scaleY: 1,
      draggable: this.opts.interactive && !el.locked && !this.peerLocked.has(el.id), listening: this.opts.interactive ? el.visible : false,
      globalCompositeOperation: (el.blend || 'source-over') as GlobalCompositeOperation,
    })
  }

  private buildShape(g: Konva.Group, el: El) {
    g.destroyChildren()
    const w = el.width, h = el.height
    let shape: Konva.Shape
    const common = { fill: el.fill, stroke: el.strokeWidth > 0 ? el.stroke : undefined, strokeWidth: el.strokeWidth, name: 'shape' }
    switch (el.type) {
      case 'text': {
        const t = new Konva.Text({
          ...common, width: w, text: el.uppercase ? (el.text || '').toUpperCase() : el.text || '',
          fontFamily: `"${el.fontFamily || 'Poppins'}", sans-serif`, fontSize: el.fontSize || 24, fontStyle: fontStyle(el),
          textDecoration: el.underline ? 'underline' : '', align: el.align || 'left', lineHeight: el.lineHeight || 1.2,
          letterSpacing: el.letterSpacing || 0, fillAfterStrokeEnabled: true, wrap: 'word',
        })
        // een woord dat breder is dan het tekstvak breekt niet midden in het woord af: letter iets kleiner
        const words = (t.text() || '').split(/\s+/).filter(Boolean)
        if (words.length) {
          const widest = Math.max(...words.map((wd) => t.measureSize(wd).width + (el.letterSpacing || 0) * wd.length))
          if (widest > w && w > 0) t.fontSize(Math.max(4, (el.fontSize || 24) * (w / widest) * 0.98))
        }
        shape = t
        const mh = Math.ceil(t.height())
        g.setAttr('h', mh)
        if (Math.abs(mh - el.height) > 0.5) this.opts.onMeasure?.(el.id, mh)
        break
      }
      case 'ellipse':
        shape = new Konva.Ellipse({ ...common, x: w / 2, y: h / 2, radiusX: w / 2, radiusY: h / 2 })
        break
      case 'triangle':
        shape = new Konva.Line({ ...common, points: [w / 2, 0, w, h, 0, h], closed: true, lineJoin: 'round' })
        break
      case 'star':
        shape = new Konva.Line({ ...common, points: starPoints(w, h, el.points || 5, el.innerRatio || 0.45), closed: true, lineJoin: 'round' })
        break
      case 'line':
        shape = new Konva.Rect({ ...common, width: w, height: h, cornerRadius: Math.min(el.cornerRadius, h / 2) })
        break
      case 'image': {
        const m = el.mask || 'none'
        const cr = m === 'leaf' ? [Math.min(w, h) * 0.45, 0, Math.min(w, h) * 0.45, 0] : el.cornerRadius
        const img = new Konva.Image({ ...common, image: undefined, width: w, height: h, cornerRadius: cr, fill: el.src ? undefined : el.fill })
        img.scaleX(el.flipX ? -1 : 1); img.scaleY(el.flipY ? -1 : 1)
        img.x(el.flipX ? w : 0); img.y(el.flipY ? h : 0)
        shape = img
        if (m === 'circle' || m === 'oval' || m === 'arch' || m === 'blob') {
          const clip = new Konva.Group({
            clipFunc: (ctx) => {
              ctx.beginPath()
              if (m === 'circle') ctx.arc(w / 2, h / 2, Math.min(w, h) / 2, 0, Math.PI * 2)
              else if (m === 'oval') ctx.ellipse(w / 2, h / 2, w / 2, h / 2, 0, 0, Math.PI * 2)
              else if (m === 'arch') { const r = Math.min(w / 2, h); ctx.moveTo(0, h); ctx.lineTo(0, r); ctx.ellipse(w / 2, r, w / 2, r, 0, Math.PI, 0); ctx.lineTo(w, h); ctx.closePath() }
              else { ctx.ellipse(w * 0.66, h * 0.66, w * 0.8, h * 0.8, 0, 0, Math.PI * 2) }
            },
          })
          clip.add(img)
          g.add(clip)
        }
        if (el.src) {
          const src = el.src
          this.pending.push(loadImage(src).then((im) => {
            if (!im || (g.getAttr('el') as El)?.src !== src) return
            img.image(im)
            img.crop(coverCrop(im, w, h, el.cropZoom, el.cropX, el.cropY))
            applyFilters(img, el)
            img.getLayer()?.batchDraw()
            this.opts.onImageLoaded?.()
          }))
        }
        break
      }
      case 'icon': {
        const img = new Konva.Image({ name: 'shape', image: undefined, width: w, height: h })
        shape = img
        const src = el.iconSvg ? svgDataUrl(el.iconMulti ? el.iconSvg : colorSvg(el.iconSvg, el.fill)) : iconDataUrl(el.icon || 'star', el.fill, el.strokeWidth || 2, 256)
        this.pending.push(loadImage(src).then((im) => {
          if (!im) return
          img.image(im)
          applyFilters(img, el)
          img.getLayer()?.batchDraw()
        }))
        break
      }
      default:
        shape = new Konva.Rect({ ...common, width: w, height: h, cornerRadius: el.cornerRadius })
    }
    if (el.type !== 'text') g.setAttr('h', h)
    applyShadow(shape, el)
    if (!shape.getParent()) g.add(shape)
    if (el.type === 'image' && !el.src && /logo/i.test(el.name || '')) {
      // logovak: doorzichtig vlak met stippellijn en LOGO, zodat duidelijk is dat hier het klantlogo komt
      const col = el.fill || '#FFFFFF'
      shape.opacity(0.14)
      const fs = Math.max(8, Math.min(h * 0.42, w / 4.4))
      const sw = Math.max(1.5, Math.min(w, h) * 0.035)
      const par = shape.getParent() as Konva.Container
      par.add(new Konva.Rect({ width: w, height: h, stroke: col, strokeWidth: sw, dash: [sw * 3, sw * 2], cornerRadius: el.cornerRadius, opacity: 0.8, listening: false, name: 'placeholder' }))
      par.add(new Konva.Text({ width: w, height: h, text: 'LOGO', align: 'center', verticalAlign: 'middle', fontFamily: '"Figtree", "Poppins", sans-serif', fontStyle: '800', fontSize: fs, letterSpacing: fs * 0.14, fill: col, opacity: 0.9, listening: false, name: 'placeholder' }))
    } else if (el.type === 'image' && !el.src) {
      // fotovak: icoontje zodat duidelijk is dat hier een eigen foto in moet
      const sz = Math.max(16, Math.min(w, h) * 0.16)
      const ic = new Konva.Path({
        data: 'M21 15l-5-5L5 21 M3 5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2v14a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z M9 9m-2 0a2 2 0 1 0 4 0a2 2 0 1 0-4 0',
        stroke: '#FFFFFF', strokeWidth: 1.6, opacity: 0.75, lineCap: 'round', lineJoin: 'round', listening: false,
        x: w / 2 - sz / 2, y: h / 2 - sz / 2, scaleX: sz / 24, scaleY: sz / 24, name: 'placeholder',
      })
      ;(shape.getParent() as Konva.Container).add(ic)
    }
    if (el.type !== 'image' && el.type !== 'icon') applyFilters(shape, el)
  }

  setPeerLocked(ids: Set<string>) {
    this.peerLocked = ids
    this.nodes.forEach((g, id) => { const el = g.getAttr('el') as El; g.draggable(this.opts.interactive && !el.locked && !ids.has(id)) })
  }

  /** Zet alle elementen in hun animatietoestand op tijdstip t (null = rusttoestand). */
  applyTime(t: number | null) {
    if (!this.frame) return
    const f = this.frame
    // groepen met een eigen animatie bewegen als één geheel rond hun midden
    const gstate = new Map<string, { s: AnimState; px: number; py: number }>()
    if (t !== null) for (const gr of f.groups || []) {
      if (!gr.anim) continue
      const m = f.elements.filter((e) => e.groupId === gr.id)
      if (!m.length) continue
      const hOf = (e: El) => this.nodes.get(e.id)?.getAttr('h') ?? e.height
      const x0 = Math.min(...m.map((e) => e.x)), y0 = Math.min(...m.map((e) => e.y))
      const x1 = Math.max(...m.map((e) => e.x + e.width)), y1 = Math.max(...m.map((e) => e.y + hOf(e)))
      gstate.set(gr.id, { s: animStateAt(gr.anim, f, t), px: (x0 + x1) / 2, py: (y0 + y1) / 2 })
    }
    for (const el of f.elements) {
      const g = this.nodes.get(el.id)
      if (!g) continue
      const h = g.getAttr('h') ?? el.height
      const bx = el.x + el.width / 2, by = el.y + h / 2
      if (t === null) {
        g.setAttrs({ x: bx, y: by, scaleX: 1, scaleY: 1, rotation: el.rotation, opacity: el.opacity })
        continue
      }
      const s = stateAt(el, f, t)
      let x = bx + s.dx, y = by + s.dy, sc = s.scale, rot = el.rotation + s.rotation, op = el.opacity * s.opacity
      const gs = el.groupId ? gstate.get(el.groupId) : undefined
      if (gs) { const p = aroundPivot(x, y, gs.px, gs.py, gs.s); x = p.x; y = p.y; sc *= gs.s.scale; rot += gs.s.rotation; op *= gs.s.opacity }
      g.setAttrs({ x, y, scaleX: sc, scaleY: sc, rotation: rot, opacity: op })
    }
    this.root.getLayer()?.batchDraw()
  }

  destroy() { this.root.destroy(); this.nodes.clear() }
}

/** Offscreen renderer voor export en thumbnails. */
export async function createOffscreen(frame: Frame) {
  await loadFontsForDoc(frame.elements.filter((e) => e.type === 'text').map((e) => e.fontFamily || 'Poppins'))
  const container = document.createElement('div')
  container.style.cssText = 'position:fixed;left:-99999px;top:0;'
  document.body.appendChild(container)
  const stage = new Konva.Stage({ container, width: frame.w, height: frame.h })
  const layer = new Konva.Layer()
  stage.add(layer)
  const r = new FrameRenderer(layer, { interactive: false })
  await r.sync(frame)
  // tweede ronde zodat tekstmaten met geladen fonts kloppen
  r.nodes.forEach((g) => g.setAttr('json', ''))
  await r.sync(frame)
  layer.draw()
  return {
    stage, layer, renderer: r,
    canvasAt(t: number | null, pixelRatio = 1) {
      r.applyTime(t)
      layer.draw()
      return stage.toCanvas({ pixelRatio, x: 0, y: 0, width: frame.w, height: frame.h })
    },
    destroy() { stage.destroy(); container.remove() },
  }
}
