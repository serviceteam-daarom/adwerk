import type { El, Frame, InAnim, EmphAnim } from './types'
import { makeEl, uid, defaultAnim } from './factory'
import { brandUrl, DAAROM } from './brand'

/*
  Templatebibliotheek. Opbouw en patronen gebaseerd op onderzoek in de Meta Ad Library, LinkedIn Ad Library
  en banny.io (oktober 2026): prijsknallers met prijslabel, foto in organisch masker, collages, USP-lijsten,
  vacatures met labelkaart, B2B met accentwoord, leadmagnets, thought leadership, carrousels en stories.
  Alle teksten en merken zijn fictief; foto's zijn vakken waar je je eigen beeld in sleept.
*/

export type TemplateType = 'Afbeelding' | 'Carrousel' | 'Story en Reels' | 'Collectie' | 'Leadadvertentie' | 'Catalogus'
export type Segment = 'B2C' | 'B2B' | 'B2B en B2C'

export interface Template {
  key: string
  name: string
  branche: string
  segment: Segment
  type: TemplateType
  frames: () => Frame[]
}

export const BRANCHES = ['daar-om.nl', 'Retail en webshop', 'Interieur en wonen', 'Food en horeca', 'Mode en beauty', 'Auto en mobiliteit', 'Bouw en installatie', 'Zakelijke dienstverlening', 'Software en tech', 'Recruitment', 'Zorg en welzijn', 'Events en opleidingen', 'Lokaal ondernemen']
export const TYPES: TemplateType[] = ['Afbeelding', 'Carrousel', 'Story en Reels', 'Collectie', 'Leadadvertentie', 'Catalogus']

type Size = { w: number; h: number }
const SQ: Size = { w: 1080, h: 1080 }
const ST: Size = { w: 1080, h: 1920 }

function anim(el: El, type: InAnim, delay: number, emph: EmphAnim = 'none', duration = 0.7): El {
  el.anim = { ...defaultAnim(), in: { type, delay, duration }, emph: { type: emph, speed: 1 } }
  return el
}
const T = (F: Size, p: Partial<El>) => makeEl('text', F, { align: 'left', fontFamily: 'Poppins', fontWeight: 700, lineHeight: 1.1, ...p })
const R = (F: Size, p: Partial<El>) => makeEl('rect', F, p)
const C = (F: Size, p: Partial<El>) => makeEl('ellipse', F, p)
const PH = (F: Size, p: Partial<El>) => makeEl('image', F, { name: 'Jouw foto', fill: '#C9D6DF', ...p })
const I = (F: Size, icon: string, p: Partial<El>) => makeEl('icon', F, { icon, strokeWidth: 2.25, ...p })
const IMG = (F: Size, file: string, p: Partial<El>) => makeEl('image', F, { src: brandUrl(file), name: file.replace('.svg', ''), ...p })

function btn(F: Size, label: string, x: number, y: number, w: number, bg: string, color: string, delay: number, h = 104, font = 'Poppins', radius = 52): El[] {
  return [
    anim(R(F, { name: 'Knop', x, y, width: w, height: h, fill: bg, cornerRadius: radius }), 'pop', delay, 'pulse', 0.5),
    anim(T(F, { name: 'Knoptekst', text: label, x, y: y + h / 2 - 26, width: w, align: 'center', fontSize: 40, fontWeight: 600, fill: color, fontFamily: font }), 'pop', delay, 'pulse', 0.5),
  ]
}
const frame = (F: Size, bg: Frame['background'], elements: El[], duration = 6): Frame => ({ id: uid(), name: 'Template', w: F.w, h: F.h, platform: 'Template', background: bg, elements, duration })
const solid = (color: string): Frame['background'] => ({ type: 'solid', color, color2: color, angle: 0 })
const grad = (color: string, color2: string, angle = 135): Frame['background'] => ({ type: 'gradient', color, color2, angle })

export const TEMPLATES: Template[] = [
  /* ---------------- daar-om.nl (huisstijlhandboek 2026) ---------------- */
  {
    key: 'do-vooruitzicht', name: 'Vooruitzicht', branche: 'daar-om.nl', segment: 'B2B', type: 'Afbeelding',
    frames: () => [frame(SQ, solid(DAAROM.navy), [
      anim(IMG(SQ, 'beeldmerk-stadsblauw.svg', { name: 'Beeldmerk groot', x: -260, y: 380, width: 900, height: 900, opacity: 0.35 }), 'fade', 0, 'none', 1.2),
      anim(IMG(SQ, 'martinitoren.svg', { x: 770, y: 170, width: 260, height: 915 }), 'slideUp', 0.1, 'float', 1),
      anim(IMG(SQ, 'daar-om-logo-wit.svg', { name: 'Logo', x: 80, y: 80, width: 270, height: 60 }), 'fade', 0.1),
      anim(T(SQ, { text: 'Ambitieus uitzicht op', x: 80, y: 330, width: 680, fontSize: 66, fontWeight: 500, fill: '#FFFFFF' }), 'slideUp', 0.3),
      anim(T(SQ, { text: 'digitale groei.', x: 80, y: 404, width: 680, fontSize: 66, fill: '#FFFFFF' }), 'slideUp', 0.45),
      anim(T(SQ, { text: 'Strategie, creatie en uitvoering onder één dak.', x: 80, y: 530, width: 620, fontSize: 36, fontWeight: 400, fill: '#FFFFFF', lineHeight: 1.4 }), 'fade', 0.8),
      ...btn(SQ, 'Plan een afspraak', 80, 760, 470, DAAROM.orange, '#FFFFFF', 1.2),
      anim(T(SQ, { name: 'Notitie', text: 'Vrijblijvend!', x: 580, y: 900, width: 260, fontSize: 54, fontWeight: 600, fontFamily: 'Caveat', fill: DAAROM.lila }), 'fade', 1.6),
      anim(IMG(SQ, 'pijl-oranje-2.svg', { name: 'Pijl', x: 540, y: 860, width: 70, height: 72, rotation: -10 }), 'pop', 1.8),
    ])],
  },
  {
    key: 'do-case', name: 'Resultaat in cijfers', branche: 'daar-om.nl', segment: 'B2B', type: 'Afbeelding',
    frames: () => [frame(SQ, solid(DAAROM.mist), [
      anim(IMG(SQ, 'gradientlijn.svg', { x: 520, y: 40, width: 520, height: 520 }), 'fade', 0.2, 'none', 1),
      anim(R(SQ, { name: 'Kaart', x: 70, y: 300, width: 940, height: 690, fill: '#FFFFFF', cornerRadius: 20, stroke: '#E0F1F7', strokeWidth: 3 }), 'slideUp', 0),
      anim(IMG(SQ, 'daar-om-logo.svg', { name: 'Logo', x: 80, y: 90, width: 250, height: 56 }), 'fade', 0.1),
      anim(T(SQ, { text: '+43%', x: 140, y: 360, width: 800, fontSize: 210, fill: DAAROM.blue, lineHeight: 1 }), 'zoomIn', 0.4, 'none', 0.8),
      anim(T(SQ, { text: 'meer aanvragen in drie maanden.', x: 140, y: 600, width: 760, fontSize: 56, fontWeight: 700, fill: DAAROM.navy }), 'slideUp', 0.7),
      anim(T(SQ, { text: 'Hoe? Lees de case van Bakkerij Noord.', x: 140, y: 760, width: 760, fontSize: 34, fontWeight: 400, fill: '#5F6676' }), 'fade', 1),
      ...btn(SQ, 'Bekijk de case', 140, 850, 400, DAAROM.blue, '#FFFFFF', 1.3, 96),
    ])],
  },
  {
    key: 'do-team', name: 'Wij zoeken jou', branche: 'daar-om.nl', segment: 'B2C', type: 'Afbeelding',
    frames: () => [frame(SQ, solid(DAAROM.lila), [
      anim(IMG(SQ, 'beeldmerk-wit.svg', { name: 'Beeldmerk groot', x: 420, y: -180, width: 820, height: 820, opacity: 0.4 }), 'fade', 0, 'none', 1.2),
      anim(PH(SQ, { x: 560, y: 360, width: 430, height: 620, mask: 'arch', fill: '#D1C1F0' }), 'slideUp', 0.2),
      anim(T(SQ, { text: 'Wij zoeken een', x: 80, y: 330, width: 460, fontSize: 64, fontWeight: 500, fill: DAAROM.navy }), 'slideUp', 0.4),
      anim(T(SQ, { text: 'SEA-specialist.', x: 80, y: 404, width: 480, fontSize: 64, fill: DAAROM.navy }), 'slideUp', 0.55),
      anim(T(SQ, { text: '32 tot 40 uur · Groningen · hybride', x: 80, y: 560, width: 460, fontSize: 32, fontWeight: 400, fill: DAAROM.navy }), 'fade', 0.9),
      ...btn(SQ, 'Solliciteer', 80, 840, 380, DAAROM.navy, '#FFFFFF', 1.2),
      anim(IMG(SQ, 'daar-om-logo.svg', { name: 'Logo', x: 80, y: 80, width: 250, height: 56 }), 'fade', 0.1),
    ])],
  },

  /* ---------------- Retail en webshop ---------------- */
  {
    key: 'retail-prijs', name: 'Prijsknaller', branche: 'Retail en webshop', segment: 'B2C', type: 'Afbeelding',
    frames: () => [frame(SQ, grad('#1F7AE0', '#58B4FF', 160), [
      anim(T(SQ, { text: 'ALTIJD', x: 60, y: 60, width: 960, align: 'center', fontSize: 210, fontFamily: 'Anton', fontWeight: 400, fill: '#FFFFFF', lineHeight: 0.95 }), 'slideDown', 0),
      anim(T(SQ, { text: 'VOORDELIG!', x: 60, y: 260, width: 960, align: 'center', fontSize: 170, fontFamily: 'Anton', fontWeight: 400, fill: '#FFFFFF', lineHeight: 0.95 }), 'slideDown', 0.15),
      anim(PH(SQ, { name: 'Productfoto (vrijstaand)', x: 150, y: 470, width: 520, height: 520, fill: '#9CCBF5', cornerRadius: 24 }), 'zoomIn', 0.4),
      anim(R(SQ, { name: 'Prijslabel', x: 640, y: 600, width: 340, height: 300, fill: '#FFFFFF', cornerRadius: 18, rotation: -4, shadow: { enabled: true, color: '#0B3A7A', blur: 30, x: 0, y: 12, opacity: 0.35 } }), 'pop', 0.8),
      anim(T(SQ, { text: 'Prijsfavoriet', x: 660, y: 625, width: 300, align: 'center', fontSize: 34, fill: '#0B3A7A', rotation: -4 }), 'pop', 0.8),
      anim(T(SQ, { text: '1,99', x: 650, y: 680, width: 320, align: 'center', fontSize: 140, fontFamily: 'Archivo Black', fontWeight: 400, fill: '#111111', rotation: -4 }), 'pop', 0.85, 'pulse'),
      anim(R(SQ, { name: 'Labelbalk', x: 680, y: 840, width: 260, height: 56, fill: '#FFD400', cornerRadius: 8, rotation: -4 }), 'pop', 0.9),
      anim(T(SQ, { text: 'Deze week!', x: 680, y: 848, width: 260, align: 'center', fontSize: 32, fill: '#111111', rotation: -4 }), 'pop', 0.9),
    ])],
  },
  {
    key: 'retail-usp', name: 'Product met USP\'s', branche: 'Retail en webshop', segment: 'B2C', type: 'Afbeelding',
    frames: () => [frame(SQ, solid('#FFFFFF'), [
      anim(PH(SQ, { x: 0, y: 0, width: 1080, height: 600, fill: '#E7DED3' }), 'fade', 0, 'none', 0.8),
      anim(T(SQ, { text: 'Slimme tuinlamp Aura', x: 70, y: 650, width: 940, fontSize: 64, fill: '#1C1C1C' }), 'slideUp', 0.3),
      ...['16 sfeerkleuren met afstandsbediening', 'Waterdicht, voor binnen en buiten', 'Gratis verzending, morgen in huis'].flatMap((t, i) => [
        anim(I(SQ, 'check-circle', { x: 70, y: 765 + i * 72, width: 48, height: 48, fill: '#1E9E5A' }), 'pop', 0.6 + i * 0.2),
        anim(T(SQ, { text: t, x: 140, y: 768 + i * 72, width: 640, fontSize: 34, fontWeight: 500, fill: '#1C1C1C' }), 'slideLeft', 0.6 + i * 0.2),
      ]),
      ...btn(SQ, 'Shop nu', 780, 860, 240, '#1C1C1C', '#FFFFFF', 1.4, 96),
      anim(R(SQ, { name: 'Rating', x: 70, y: 60, width: 330, height: 76, fill: '#FFFFFF', cornerRadius: 38 }), 'slideDown', 0.5),
      ...[0, 1, 2, 3, 4].map((i) => anim(makeEl('star', SQ, { x: 92 + i * 42, y: 76, width: 40, height: 40, fill: '#F5B301' }), 'pop', 0.7 + i * 0.06)),
      anim(T(SQ, { text: '4,8', x: 312, y: 77, width: 80, fontSize: 34, fill: '#1C1C1C' }), 'fade', 1),
    ])],
  },
  {
    key: 'retail-collectie', name: 'Collectie met producten', branche: 'Retail en webshop', segment: 'B2C', type: 'Collectie',
    frames: () => [frame(SQ, solid('#F4EFE9'), [
      anim(PH(SQ, { name: 'Omslagfoto', x: 0, y: 0, width: 1080, height: 640, fill: '#D8CBBB' }), 'fade', 0, 'none', 0.8),
      anim(T(SQ, { text: 'Nieuwe najaarscollectie', x: 60, y: 520, width: 960, fontSize: 60, fill: '#FFFFFF' }), 'slideUp', 0.3),
      ...[0, 1, 2].flatMap((i) => [
        anim(PH(SQ, { name: `Product ${i + 1}`, x: 60 + i * 330, y: 680, width: 300, height: 300, cornerRadius: 16, fill: ['#C9B9A6', '#B9C7C2', '#D4C3C8'][i] }), 'slideUp', 0.6 + i * 0.15),
        anim(T(SQ, { text: ['€ 49,95', '€ 79,95', '€ 34,95'][i], x: 60 + i * 330, y: 1000, width: 300, fontSize: 32, fill: '#2B2420' }), 'fade', 0.9 + i * 0.15),
      ]),
    ])],
  },
  {
    key: 'retail-catalogus', name: 'Productkaart (catalogus)', branche: 'Retail en webshop', segment: 'B2C', type: 'Catalogus',
    frames: () => [frame(SQ, solid('#FFFFFF'), [
      anim(PH(SQ, { name: 'Productfoto uit feed', x: 90, y: 90, width: 900, height: 700, cornerRadius: 24, fill: '#EEF1F4' }), 'fade', 0),
      anim(R(SQ, { name: 'Kortingsbadge', x: 760, y: 60, width: 260, height: 260, fill: '#E5243B', cornerRadius: 130 }), 'pop', 0.4, 'wiggle'),
      anim(T(SQ, { text: '-25%', x: 760, y: 140, width: 260, align: 'center', fontSize: 84, fontFamily: 'Archivo Black', fontWeight: 400, fill: '#FFFFFF' }), 'pop', 0.4, 'wiggle'),
      anim(R(SQ, { name: 'Prijsbalk', x: 0, y: 840, width: 1080, height: 240, fill: '#111827' }), 'slideUp', 0.2),
      anim(T(SQ, { text: 'Productnaam uit je feed', x: 90, y: 875, width: 640, fontSize: 44, fill: '#FFFFFF' }), 'fade', 0.5),
      anim(T(SQ, { text: 'Gratis verzending · 30 dagen retour', x: 90, y: 950, width: 640, fontSize: 30, fontWeight: 400, fill: '#C7CDD8' }), 'fade', 0.6),
      anim(T(SQ, { text: '€ 59,95', x: 700, y: 880, width: 320, align: 'right', fontSize: 72, fill: '#FFFFFF' }), 'slideLeft', 0.7),
    ])],
  },
  {
    key: 'retail-carrousel', name: 'Productcarrousel', branche: 'Retail en webshop', segment: 'B2C', type: 'Carrousel',
    frames: () => ['Bestseller', 'Nieuw', 'Laatste stuks'].map((label, i) => frame(SQ, solid(['#FFF4E8', '#EAF4FF', '#F2ECFF'][i]), [
      anim(PH(SQ, { name: `Product ${i + 1}`, x: 90, y: 90, width: 900, height: 760, cornerRadius: 28, fill: ['#F2D9BD', '#C8DDF5', '#DCD0F5'][i] }), 'zoomOut', 0, 'none', 0.9),
      anim(R(SQ, { name: 'Label', x: 120, y: 120, width: 300, height: 80, fill: '#111111', cornerRadius: 12 }), 'slideRight', 0.3),
      anim(T(SQ, { text: label, x: 120, y: 136, width: 300, align: 'center', fontSize: 36, fill: '#FFFFFF' }), 'slideRight', 0.3),
      anim(T(SQ, { text: ['Linnen overhemd', 'Wollen trui', 'Suède sneaker'][i], x: 90, y: 890, width: 640, fontSize: 52, fill: '#111111' }), 'slideUp', 0.5),
      anim(T(SQ, { text: ['€ 59,95', '€ 89,95', '€ 119,-'][i], x: 700, y: 890, width: 290, align: 'right', fontSize: 52, fill: '#111111' }), 'slideUp', 0.6),
      anim(I(SQ, 'arrow-right', { name: 'Swipe', x: 940, y: 980, width: 64, height: 64, fill: '#111111' }), 'slideRight', 0.9, 'float'),
    ])),
  },

  /* ---------------- Interieur en wonen ---------------- */
  {
    key: 'wonen-collage', name: 'Sfeercollage', branche: 'Interieur en wonen', segment: 'B2C', type: 'Afbeelding',
    frames: () => [frame(SQ, solid('#F3EEE7'), [
      anim(PH(SQ, { x: 40, y: 40, width: 490, height: 470, cornerRadius: 14, fill: '#D9CBB8' }), 'fade', 0),
      anim(PH(SQ, { x: 550, y: 40, width: 490, height: 470, cornerRadius: 14, fill: '#CDBDA9' }), 'fade', 0.15),
      anim(PH(SQ, { x: 40, y: 530, width: 490, height: 360, cornerRadius: 14, fill: '#E2D6C6' }), 'fade', 0.3),
      anim(PH(SQ, { x: 550, y: 530, width: 490, height: 360, cornerRadius: 14, fill: '#C4B29C' }), 'fade', 0.45),
      anim(T(SQ, { text: 'Zomersale tot 30% op spiegels', x: 40, y: 935, width: 700, fontSize: 46, fontFamily: 'Playfair Display', fill: '#3B2F25' }), 'slideUp', 0.7),
      ...btn(SQ, 'Shoppen', 790, 915, 250, '#3B2F25', '#FFFFFF', 1, 96),
    ])],
  },
  {
    key: 'wonen-boog', name: 'Woonstijl in boog', branche: 'Interieur en wonen', segment: 'B2C', type: 'Afbeelding',
    frames: () => [frame(SQ, solid('#E9E2D6'), [
      anim(PH(SQ, { x: 520, y: 90, width: 470, height: 900, mask: 'arch', fill: '#C9B79E' }), 'slideUp', 0.1, 'none', 0.9),
      anim(T(SQ, { text: 'JAPANDI', x: 90, y: 260, width: 420, fontSize: 30, fontWeight: 600, letterSpacing: 8, fill: '#7A6A55' }), 'fade', 0.3),
      anim(T(SQ, { text: 'Rust in huis begint bij minder.', x: 90, y: 320, width: 420, fontSize: 62, fontFamily: 'Playfair Display', fontWeight: 500, fill: '#2E2A24', lineHeight: 1.15 }), 'slideUp', 0.4),
      anim(makeEl('line', SQ, { x: 90, y: 640, width: 120, height: 4, fill: '#2E2A24' }), 'slideRight', 0.7),
      anim(T(SQ, { text: 'Ontdek de woonstijl →', x: 90, y: 690, width: 420, fontSize: 34, fontWeight: 500, fill: '#2E2A24' }), 'fade', 0.9),
    ])],
  },

  /* ---------------- Food en horeca ---------------- */
  {
    key: 'food-nieuw', name: 'Nieuw op de kaart', branche: 'Food en horeca', segment: 'B2C', type: 'Afbeelding',
    frames: () => [frame(SQ, solid('#2A1E18'), [
      anim(PH(SQ, { name: 'Gerecht', x: 240, y: 200, width: 600, height: 600, mask: 'circle', fill: '#6B4A3A' }), 'zoomIn', 0.1, 'none', 0.9),
      anim(T(SQ, { text: 'Nieuw op de kaart', x: 90, y: 70, width: 900, align: 'center', fontSize: 72, fontFamily: 'Caveat', fontWeight: 700, fill: '#F2C14E' }), 'fade', 0.3),
      anim(T(SQ, { text: 'Pompoen-risotto met salie', x: 90, y: 840, width: 900, align: 'center', fontSize: 52, fill: '#FFFFFF' }), 'slideUp', 0.6),
      anim(T(SQ, { text: 'Alleen deze herfst · reserveer je tafel', x: 90, y: 920, width: 900, align: 'center', fontSize: 30, fontWeight: 400, fill: '#D9C9BC' }), 'fade', 0.9),
    ])],
  },

  /* ---------------- Mode en beauty ---------------- */
  {
    key: 'mode-editorial', name: 'Editorial', branche: 'Mode en beauty', segment: 'B2C', type: 'Afbeelding',
    frames: () => [frame(SQ, solid('#111111'), [
      anim(PH(SQ, { name: 'Modefoto', x: 0, y: 0, width: 1080, height: 1080, fill: '#3A3A3A' }), 'zoomOut', 0, 'none', 1.4),
      anim(R(SQ, { name: 'Donker vlak', x: 0, y: 620, width: 1080, height: 460, fill: '#000000', opacity: 0.45 }), 'fade', 0.2),
      anim(T(SQ, { text: "Herfst '26", x: 70, y: 700, width: 900, fontSize: 130, fontFamily: 'Playfair Display', fontWeight: 500, italic: true, fill: '#FFFFFF' }), 'slideUp', 0.4, 'none', 0.9),
      anim(T(SQ, { text: 'SHOP DE COLLECTIE  →', x: 76, y: 900, width: 700, fontSize: 32, fontWeight: 500, letterSpacing: 6, fill: '#FFFFFF' }), 'fade', 0.9),
    ])],
  },

  /* ---------------- Auto en mobiliteit ---------------- */
  {
    key: 'auto-lease', name: 'Occasion of lease', branche: 'Auto en mobiliteit', segment: 'B2B en B2C', type: 'Catalogus',
    frames: () => [frame(SQ, solid('#F2F4F7'), [
      anim(T(SQ, { text: 'Elektrisch rijden vanaf', x: 80, y: 80, width: 920, fontSize: 44, fontWeight: 500, fill: '#1A2433' }), 'fade', 0.1),
      anim(T(SQ, { text: '€ 349 p/m', x: 80, y: 140, width: 920, fontSize: 130, fill: '#0055FF' }), 'slideUp', 0.2),
      anim(PH(SQ, { name: 'Auto (vrijstaand)', x: 60, y: 360, width: 960, height: 450, cornerRadius: 24, fill: '#DCE3EC' }), 'slideLeft', 0.4, 'none', 0.9),
      ...[['zap', '100% elektrisch'], ['calendar', '48 maanden'], ['car', '10.000 km/jr']].flatMap(([ic, t], i) => [
        anim(I(SQ, ic, { x: 80 + i * 320, y: 860, width: 56, height: 56, fill: '#0055FF' }), 'pop', 0.8 + i * 0.15),
        anim(T(SQ, { text: t, x: 150 + i * 320, y: 868, width: 240, fontSize: 30, fontWeight: 500, fill: '#1A2433' }), 'fade', 0.8 + i * 0.15),
      ]),
      ...btn(SQ, 'Bereken je lease', 80, 950, 460, '#0055FF', '#FFFFFF', 1.3, 96),
    ])],
  },

  /* ---------------- Bouw en installatie ---------------- */
  {
    key: 'bouw-voorna', name: 'Voor en na', branche: 'Bouw en installatie', segment: 'B2C', type: 'Afbeelding',
    frames: () => [frame(SQ, solid('#FFFFFF'), [
      anim(PH(SQ, { name: 'Foto voor', x: 0, y: 0, width: 538, height: 760, fill: '#B9B2A8' }), 'slideRight', 0),
      anim(PH(SQ, { name: 'Foto na', x: 542, y: 0, width: 538, height: 760, fill: '#9DB7C9' }), 'slideLeft', 0.2),
      anim(R(SQ, { name: 'Label voor', x: 30, y: 30, width: 150, height: 64, fill: '#111111', cornerRadius: 10 }), 'pop', 0.5),
      anim(T(SQ, { text: 'VOOR', x: 30, y: 40, width: 150, align: 'center', fontSize: 32, fill: '#FFFFFF' }), 'pop', 0.5),
      anim(R(SQ, { name: 'Label na', x: 572, y: 30, width: 150, height: 64, fill: '#C2410C', cornerRadius: 10 }), 'pop', 0.7),
      anim(T(SQ, { text: 'NA', x: 572, y: 40, width: 150, align: 'center', fontSize: 32, fill: '#FFFFFF' }), 'pop', 0.7),
      anim(T(SQ, { text: 'Dakgoot vervangen? Binnen 1 dag klaar.', x: 60, y: 800, width: 620, fontSize: 48, fill: '#14213D' }), 'slideUp', 0.9),
      ...btn(SQ, 'Gratis offerte', 700, 830, 320, '#C2410C', '#FFFFFF', 1.2, 100),
    ])],
  },
  {
    key: 'bouw-lead', name: 'Offerte aanvragen', branche: 'Bouw en installatie', segment: 'B2B en B2C', type: 'Leadadvertentie',
    frames: () => [frame(SQ, solid('#0F2A3F'), [
      anim(PH(SQ, { x: 600, y: 0, width: 480, height: 1080, fill: '#2C4A61' }), 'fade', 0),
      anim(T(SQ, { text: 'Zonnepanelen? Vraag je offerte aan.', x: 70, y: 90, width: 500, fontSize: 60, fill: '#FFFFFF' }), 'slideUp', 0.2),
      ...['Naam', 'Postcode', 'Telefoonnummer'].flatMap((t, i) => [
        anim(R(SQ, { name: `Veld ${t}`, x: 70, y: 470 + i * 120, width: 470, height: 92, fill: '#FFFFFF', cornerRadius: 14 }), 'slideRight', 0.5 + i * 0.15),
        anim(T(SQ, { text: t, x: 100, y: 498 + i * 120, width: 400, fontSize: 30, fontWeight: 400, fill: '#6B7785' }), 'slideRight', 0.5 + i * 0.15),
      ]),
      ...btn(SQ, 'Verstuur aanvraag', 70, 860, 470, '#FFB703', '#0F2A3F', 1.1, 100, 'Poppins', 14),
      anim(T(SQ, { text: 'Binnen 24 uur reactie', x: 70, y: 990, width: 470, align: 'center', fontSize: 26, fontWeight: 400, fill: '#C9D6E2' }), 'fade', 1.4),
    ])],
  },

  /* ---------------- Zakelijke dienstverlening ---------------- */
  {
    key: 'zak-quote', name: 'Thought leadership', branche: 'Zakelijke dienstverlening', segment: 'B2B', type: 'Afbeelding',
    frames: () => [frame(SQ, solid('#F5F3EE'), [
      anim(T(SQ, { text: '"', x: 70, y: 20, width: 300, fontSize: 340, fontFamily: 'Playfair Display', fill: '#B08A35', lineHeight: 1 }), 'fade', 0),
      anim(T(SQ, { text: 'Wie in 2027 nog groeit, investeert nu in data in plaats van in gevoel.', x: 90, y: 260, width: 900, fontSize: 60, fontFamily: 'Playfair Display', fontWeight: 500, fill: '#1E2430', lineHeight: 1.2 }), 'fade', 0.3, 'none', 1),
      anim(PH(SQ, { name: 'Portret', x: 90, y: 790, width: 170, height: 170, mask: 'circle', fill: '#C9C2B5' }), 'pop', 0.9),
      anim(T(SQ, { text: 'Sanne de Boer', x: 290, y: 815, width: 600, fontSize: 40, fill: '#1E2430' }), 'slideLeft', 1),
      anim(T(SQ, { text: 'Partner, Boer & Co Advies', x: 290, y: 875, width: 600, fontSize: 30, fontWeight: 400, fill: '#5F6470' }), 'slideLeft', 1.1),
    ])],
  },
  {
    key: 'zak-whitepaper', name: 'Gratis gids (leadmagnet)', branche: 'Zakelijke dienstverlening', segment: 'B2B', type: 'Leadadvertentie',
    frames: () => [frame(SQ, grad('#EEF3FF', '#DCE6FF', 160), [
      anim(R(SQ, { name: 'Gids', x: 560, y: 150, width: 420, height: 580, fill: '#14213D', cornerRadius: 10, rotation: 6, shadow: { enabled: true, color: '#14213D', blur: 50, x: 0, y: 24, opacity: 0.3 } }), 'slideUp', 0.2, 'float'),
      anim(T(SQ, { text: 'De gids voor\nAI in je\nmarketing\n2027', x: 610, y: 230, width: 340, fontSize: 48, fill: '#FFFFFF', rotation: 6 }), 'slideUp', 0.2, 'float'),
      anim(T(SQ, { text: 'GRATIS DOWNLOAD', x: 80, y: 180, width: 440, fontSize: 30, fontWeight: 600, letterSpacing: 4, fill: '#3557D4' }), 'fade', 0.4),
      anim(T(SQ, { text: '12 kansen die je concurrent nog laat liggen', x: 80, y: 240, width: 450, fontSize: 56, fill: '#14213D' }), 'slideUp', 0.5),
      ...btn(SQ, 'Download de gids', 80, 840, 460, '#3557D4', '#FFFFFF', 1, 100, 'Poppins', 14),
    ])],
  },

  /* ---------------- Software en tech ---------------- */
  {
    key: 'tech-dark', name: 'SaaS met accentwoord', branche: 'Software en tech', segment: 'B2B', type: 'Afbeelding',
    frames: () => [frame(SQ, grad('#06121E', '#0B2B3A', 145), [
      anim(T(SQ, { text: 'Maximaliseer je', x: 80, y: 110, width: 920, fontSize: 76, fill: '#FFFFFF' }), 'slideUp', 0.1),
      anim(T(SQ, { text: 'uptime.', x: 80, y: 200, width: 920, fontSize: 76, fill: '#2EE6A6' }), 'slideUp', 0.25),
      ...btn(SQ, 'Plan een demo', 80, 330, 340, '#2EE6A6', '#06121E', 0.6, 84, 'Poppins', 10),
      anim(R(SQ, { name: 'Dashboard', x: 200, y: 500, width: 820, height: 520, fill: '#10283A', cornerRadius: 24, stroke: '#1E4A63', strokeWidth: 3 }), 'slideUp', 0.7, 'float', 0.9),
      ...[0, 1, 2, 3].map((i) => anim(R(SQ, { name: `Grafiek ${i + 1}`, x: 280 + i * 170, y: 900 - [180, 260, 210, 340][i], width: 110, height: [180, 260, 210, 340][i], fill: i === 3 ? '#2EE6A6' : '#2A5670', cornerRadius: 10 }), 'slideUp', 1 + i * 0.12)),
      anim(T(SQ, { text: '99,98% beschikbaar', x: 260, y: 540, width: 600, fontSize: 36, fill: '#FFFFFF' }), 'fade', 1.2),
    ])],
  },
  {
    key: 'tech-carrousel', name: 'Kennis-carrousel', branche: 'Software en tech', segment: 'B2B', type: 'Carrousel',
    frames: () => {
      const cards = [['3 fouten die je Google Ads-budget opeten', 'Swipe →'], ['1. Geen negatieve zoekwoorden', 'Je betaalt voor klikken die nooit kopen.'], ['2. Eén campagne voor alles', 'Splits op intentie en marge.'], ['Laat je account gratis scannen', 'Binnen 5 werkdagen advies.']]
      return cards.map(([h, sub], i) => {
        const dark = i === 0 || i === cards.length - 1
        return frame(SQ, solid(dark ? '#1B213B' : '#FFFFFF'), [
          anim(T(SQ, { text: `${i + 1}/${cards.length}`, x: 80, y: 80, width: 300, fontSize: 30, fontWeight: 600, fill: dark ? '#A2D6ED' : '#1A5FC4' }), 'fade', 0),
          anim(T(SQ, { text: h, x: 80, y: 320, width: 900, fontSize: i === 0 ? 82 : 68, fill: dark ? '#FFFFFF' : '#1B213B' }), 'slideUp', 0.2),
          anim(T(SQ, { text: sub, x: 80, y: 760, width: 900, fontSize: 40, fontWeight: 400, fill: dark ? '#E6A4FF' : '#5F6676' }), 'fade', 0.6),
          ...(i === cards.length - 1 ? btn(SQ, 'Gratis scan', 80, 880, 380, '#EA5F39', '#FFFFFF', 0.9) : []),
        ])
      })
    },
  },

  /* ---------------- Recruitment ---------------- */
  {
    key: 'rec-label', name: 'Vacature met labelkaart', branche: 'Recruitment', segment: 'B2C', type: 'Afbeelding',
    frames: () => [frame(SQ, solid('#1D1D1D'), [
      anim(PH(SQ, { name: 'Foto werkplek', x: 0, y: 0, width: 1080, height: 1080, fill: '#4B5563' }), 'zoomOut', 0, 'none', 1.2),
      anim(R(SQ, { name: 'Kaart', x: 60, y: 430, width: 720, height: 590, fill: '#FFFFFF', cornerRadius: 24 }), 'slideUp', 0.3),
      anim(T(SQ, { text: 'Vacature', x: 110, y: 470, width: 600, fontSize: 32, fontWeight: 500, fill: '#5F6676' }), 'fade', 0.5),
      anim(T(SQ, { text: 'Logistiek medewerker', x: 110, y: 515, width: 640, fontSize: 56, fill: '#111827' }), 'slideUp', 0.6),
      ...['Salaris tot € 3.000 bruto per maand', 'Vast contract na 7 maanden', 'Vlak bij huis, regio Zwolle'].flatMap((t, i) => [
        anim(C(SQ, { name: 'Punt', x: 110, y: 660 + i * 70, width: 26, height: 26, fill: '#FACC15' }), 'pop', 0.8 + i * 0.15),
        anim(T(SQ, { text: t, x: 156, y: 652 + i * 70, width: 600, fontSize: 32, fontWeight: 500, fill: '#111827' }), 'slideLeft', 0.8 + i * 0.15),
      ]),
      ...btn(SQ, 'Solliciteer zonder cv', 110, 890, 470, '#FACC15', '#111827', 1.4, 92, 'Poppins', 12),
    ])],
  },
  {
    key: 'rec-bold', name: 'Vacature krachtig', branche: 'Recruitment', segment: 'B2C', type: 'Afbeelding',
    frames: () => [frame(SQ, solid('#0E2240'), [
      anim(PH(SQ, { name: 'Foto medewerkers', x: 0, y: 0, width: 1080, height: 1080, fill: '#36506F' }), 'fade', 0),
      anim(R(SQ, { name: 'Overlay', x: 0, y: 480, width: 1080, height: 600, fill: '#0E2240', opacity: 0.8 }), 'slideUp', 0.2),
      anim(T(SQ, { text: 'WERK SAMEN ALS', x: 70, y: 540, width: 940, fontSize: 52, fontFamily: 'Barlow Condensed', fontWeight: 700, italic: true, fill: '#FFFFFF' }), 'slideRight', 0.4),
      anim(T(SQ, { text: 'PROJECTLEIDER', x: 70, y: 600, width: 940, fontSize: 150, fontFamily: 'Barlow Condensed', fontWeight: 800, italic: true, fill: '#FFFFFF', lineHeight: 1 }), 'slideRight', 0.55),
      anim(T(SQ, { text: 'Tot € 5.500 bruto · gevelbouw · regio Utrecht', x: 70, y: 790, width: 940, fontSize: 34, fontWeight: 500, fill: '#BFD3EA' }), 'fade', 0.9),
      ...btn(SQ, 'Bekijk vacature', 70, 880, 400, '#FFFFFF', '#0E2240', 1.2, 96),
    ])],
  },
  {
    key: 'rec-story', name: 'Vacature story', branche: 'Recruitment', segment: 'B2C', type: 'Story en Reels',
    frames: () => [frame(ST, solid('#0B1F33'), [
      anim(PH(ST, { name: 'Foto (portret)', x: 0, y: 0, width: 1080, height: 1920, fill: '#2E4A66' }), 'zoomOut', 0, 'none', 1.5),
      anim(R(ST, { name: 'Overlay', x: 0, y: 1060, width: 1080, height: 860, fill: '#0B1F33', opacity: 0.75 }), 'slideUp', 0.2),
      anim(T(ST, { text: 'We zoeken een', x: 80, y: 300, width: 920, fontSize: 70, fontWeight: 500, fill: '#FFFFFF' }), 'slideDown', 0.3),
      anim(T(ST, { text: 'Verpleegkundige', x: 80, y: 385, width: 920, fontSize: 100, fill: '#FFFFFF' }), 'slideDown', 0.45),
      ...['24 tot 36 uur', 'Eigen rooster', 'Fijn team in Assen'].map((t, i) => anim(T(ST, { text: '✓  ' + t, x: 80, y: 1130 + i * 90, width: 920, fontSize: 52, fontWeight: 500, fill: '#FFFFFF' }), 'slideLeft', 0.8 + i * 0.2)),
      ...btn(ST, 'Solliciteer in 1 minuut', 140, 1460, 800, '#D9363E', '#FFFFFF', 1.5, 120),
    ])],
  },

  /* ---------------- Zorg en welzijn ---------------- */
  {
    key: 'zorg-warm', name: 'Zorg met aandacht', branche: 'Zorg en welzijn', segment: 'B2C', type: 'Afbeelding',
    frames: () => [frame(SQ, solid('#FBF4EE'), [
      anim(PH(SQ, { x: 80, y: 80, width: 460, height: 920, mask: 'arch', fill: '#E7CFC0' }), 'slideUp', 0.1, 'none', 0.9),
      anim(T(SQ, { text: 'Thuiszorg met aandacht voor jou.', x: 590, y: 300, width: 420, fontSize: 58, fontFamily: 'Fraunces', fontWeight: 600, fill: '#4A2E2A', lineHeight: 1.15 }), 'slideUp', 0.4),
      anim(T(SQ, { text: 'Vaste gezichten, dichtbij in de buurt.', x: 590, y: 560, width: 420, fontSize: 32, fontWeight: 400, fill: '#6E524B', lineHeight: 1.4 }), 'fade', 0.8),
      ...btn(SQ, 'Neem contact op', 590, 760, 400, '#C2185B', '#FFFFFF', 1.1, 96),
    ])],
  },

  /* ---------------- Events en opleidingen ---------------- */
  {
    key: 'event-webinar', name: 'Webinar met sprekers', branche: 'Events en opleidingen', segment: 'B2B', type: 'Afbeelding',
    frames: () => [frame(SQ, grad('#1B1446', '#3B1E7A', 140), [
      anim(T(SQ, { text: 'LIVE WEBINAR · 21 NOV · 16:00', x: 80, y: 100, width: 920, fontSize: 30, fontWeight: 600, letterSpacing: 3, fill: '#C4B5FD' }), 'fade', 0.1),
      anim(T(SQ, { text: 'Groeien met AI in je marketing', x: 80, y: 160, width: 920, fontSize: 76, fill: '#FFFFFF' }), 'slideUp', 0.3),
      ...[0, 1].flatMap((i) => [
        anim(PH(SQ, { name: `Spreker ${i + 1}`, x: 80 + i * 300, y: 520, width: 240, height: 240, mask: 'circle', fill: ['#6D5BD0', '#8B7BE0'][i] }), 'pop', 0.6 + i * 0.2),
        anim(T(SQ, { text: ['Lotte Visser', 'Rémon Bakker'][i], x: 80 + i * 300, y: 785, width: 260, fontSize: 32, fill: '#FFFFFF' }), 'fade', 0.8 + i * 0.2),
        anim(T(SQ, { text: ['Strateeg', 'Data-specialist'][i], x: 80 + i * 300, y: 830, width: 260, fontSize: 26, fontWeight: 400, fill: '#C4B5FD' }), 'fade', 0.9 + i * 0.2),
      ]),
      ...btn(SQ, 'Meld je gratis aan', 80, 930, 440, '#C2410C', '#FFFFFF', 1.3, 96),
    ])],
  },

  /* ---------------- Lokaal ondernemen ---------------- */
  {
    key: 'lokaal-open', name: 'Openingsactie', branche: 'Lokaal ondernemen', segment: 'B2C', type: 'Afbeelding',
    frames: () => [frame(SQ, solid('#FFD43B'), [
      anim(T(SQ, { text: 'Nu open in Assen!', x: 70, y: 90, width: 940, fontSize: 104, fontFamily: 'Archivo Black', fontWeight: 400, fill: '#1A1A1A', lineHeight: 1 }), 'slideDown', 0.1),
      anim(PH(SQ, { name: 'Winkelfoto', x: 70, y: 360, width: 600, height: 460, fill: '#E9B806', mask: 'leaf' }), 'zoomIn', 0.3),
      anim(I(SQ, 'map-pin', { x: 710, y: 400, width: 70, height: 70, fill: '#1A1A1A' }), 'pop', 0.6),
      anim(T(SQ, { text: 'Marktstraat 12\nza 10:00 tot 17:00', x: 710, y: 490, width: 320, fontSize: 36, fontWeight: 500, fill: '#1A1A1A', lineHeight: 1.35 }), 'fade', 0.7),
      anim(R(SQ, { name: 'Bon', x: 70, y: 870, width: 940, height: 140, fill: '#FFFFFF', cornerRadius: 18, stroke: '#1A1A1A', strokeWidth: 4 }), 'slideUp', 0.9),
      anim(T(SQ, { text: '-15% op alles met deze advertentie', x: 70, y: 915, width: 940, align: 'center', fontSize: 44, fill: '#1A1A1A' }), 'slideUp', 1, 'pulse'),
    ])],
  },
  {
    key: 'lokaal-story', name: 'Actie story', branche: 'Lokaal ondernemen', segment: 'B2C', type: 'Story en Reels',
    frames: () => [frame(ST, grad('#E8462A', '#D61F69', 160), [
      anim(T(ST, { text: 'Alleen dit weekend', x: 80, y: 290, width: 920, align: 'center', fontSize: 64, fontFamily: 'Caveat', fontWeight: 700, fill: '#FFFFFF' }), 'fade', 0.1),
      anim(T(ST, { text: '2e GRATIS', x: 60, y: 380, width: 960, align: 'center', fontSize: 190, fontFamily: 'Anton', fontWeight: 400, fill: '#FFFFFF' }), 'zoomIn', 0.3, 'pulse'),
      anim(PH(ST, { name: 'Productfoto', x: 190, y: 700, width: 700, height: 700, mask: 'circle', fill: '#F59B85' }), 'pop', 0.6),
      ...btn(ST, 'Bekijk de actie', 190, 1500, 700, '#FFFFFF', '#B5124F', 1, 120),
      anim(I(ST, 'arrow-up', { name: 'Swipe omhoog', x: 500, y: 1400, width: 80, height: 80, fill: '#FFFFFF' }), 'slideUp', 1.3, 'float'),
    ])],
  },
  {
    key: 'social-proof', name: 'Reviews', branche: 'Lokaal ondernemen', segment: 'B2B en B2C', type: 'Afbeelding',
    frames: () => [frame(SQ, solid('#FFFFFF'), [
      anim(R(SQ, { name: 'Vlak', x: 0, y: 0, width: 1080, height: 420, fill: '#0F5132' }), 'slideDown', 0),
      ...[0, 1, 2, 3, 4].map((i) => anim(makeEl('star', SQ, { x: 300 + i * 100, y: 110, width: 84, height: 84, fill: '#FFC107' }), 'pop', 0.2 + i * 0.1)),
      anim(T(SQ, { text: '4,9 uit 312 Google-reviews', x: 80, y: 240, width: 920, align: 'center', fontSize: 44, fill: '#FFFFFF' }), 'fade', 0.8),
      anim(T(SQ, { text: '"Snel, netjes en precies volgens afspraak. Echte vakmensen."', x: 120, y: 500, width: 840, align: 'center', fontSize: 52, fontFamily: 'Fraunces', fontWeight: 500, fill: '#14281D', lineHeight: 1.25 }), 'fade', 1, 'none', 1),
      anim(T(SQ, { text: 'Mark, uit Haren', x: 120, y: 790, width: 840, align: 'center', fontSize: 32, fontWeight: 500, fill: '#4F5E54' }), 'fade', 1.4),
      ...btn(SQ, 'Lees alle reviews', 320, 880, 440, '#0F5132', '#FFFFFF', 1.6, 96),
    ])],
  },
]
