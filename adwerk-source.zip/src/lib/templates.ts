import type { El, Frame } from './types'
import { makeEl, uid, defaultAnim } from './factory'
import type { InAnim, EmphAnim } from './types'
import { brandUrl, DAAROM } from './brand'

const F = { w: 1080, h: 1080 }

function anim(el: El, type: InAnim, delay: number, emph: EmphAnim = 'none', duration = 0.7): El {
  el.anim = { ...defaultAnim(), in: { type, delay, duration }, emph: { type: emph, speed: 1 } }
  return el
}
const text = (p: Partial<El>) => makeEl('text', F, p)
const rect = (p: Partial<El>) => makeEl('rect', F, p)

function cta(label: string, x: number, y: number, w: number, bg: string, color: string, delay: number, font = 'Poppins'): El[] {
  const btn = anim(rect({ name: 'Knop', x, y, width: w, height: 110, fill: bg, cornerRadius: 55 }), 'pop', delay, 'pulse', 0.6)
  const t = anim(text({ name: 'Knoptekst', text: label, x, y: y + 30, width: w, fontSize: 42, fontWeight: 600, fill: color, fontFamily: font }), 'pop', delay, 'pulse', 0.6)
  return [btn, t]
}

export interface Template { key: string; name: string; tags: string; frame: () => Frame }

const base = (bg: Frame['background'], elements: El[], duration = 6): Frame => ({
  id: uid(), name: 'Template', w: F.w, h: F.h, platform: 'Template', background: bg, elements, duration,
})

export const TEMPLATES: Template[] = [
  {
    key: 'daarom-groei', name: 'daar-om.nl donker', tags: 'daar-om huisstijl',
    frame: () => base({ type: 'solid', color: DAAROM.navy, color2: DAAROM.navy, angle: 0 }, [
      anim(makeEl('image', F, { name: 'Martinitoren', src: brandUrl('martinitoren.svg'), x: 760, y: 150, width: 266, height: 936 }), 'slideUp', 0, 'float', 1),
      anim(makeEl('image', F, { name: 'Logo', src: brandUrl('daar-om-logo-wit.svg'), x: 90, y: 90, width: 270, height: 60 }), 'fade', 0.1),
      anim(text({ text: 'Jouw vooruitzicht op', x: 90, y: 340, width: 760, align: 'left', fontSize: 64, fontWeight: 500, fontFamily: 'Poppins', fill: '#FFFFFF', lineHeight: 1.1 }), 'slideUp', 0.3),
      anim(text({ text: 'digitale groei.', x: 90, y: 414, width: 760, align: 'left', fontSize: 64, fontWeight: 700, fontFamily: 'Poppins', fill: '#FFFFFF', lineHeight: 1.1 }), 'slideUp', 0.45),
      anim(text({ text: 'Wij laten ambitieuze MKB-bedrijven opvallen in de digitale menigte.', x: 90, y: 540, width: 600, align: 'left', fontSize: 36, fontWeight: 400, fontFamily: 'Poppins', fill: '#FFFFFF', lineHeight: 1.4 }), 'fade', 0.8),
      ...cta('Contact opnemen', 90, 760, 500, DAAROM.orange, '#FFFFFF', 1.2, 'Poppins'),
      anim(text({ name: 'Notitie', text: 'Plan direct een afspraak!', x: 90, y: 920, width: 520, align: 'left', fontSize: 52, fontWeight: 600, fontFamily: 'Caveat', fill: DAAROM.lila }), 'fade', 1.6),
      anim(makeEl('image', F, { name: 'Pijl', src: brandUrl('pijl-oranje-3.svg'), x: 600, y: 820, width: 120, height: 120 }), 'pop', 1.8),
    ]),
  },
  {
    key: 'daarom-licht', name: 'daar-om.nl licht', tags: 'daar-om huisstijl',
    frame: () => base({ type: 'solid', color: DAAROM.mist, color2: DAAROM.mist, angle: 0 }, [
      anim(rect({ name: 'Kaart', x: 70, y: 70, width: 940, height: 940, fill: '#FFFFFF', cornerRadius: 20, stroke: DAAROM.line, strokeWidth: 3 }), 'fade', 0),
      anim(makeEl('image', F, { name: 'Logo', src: brandUrl('daar-om-logo.svg'), x: 140, y: 140, width: 250, height: 56 }), 'fade', 0.1),
      anim(text({ text: 'Hoe wij jou laten', x: 140, y: 330, width: 800, align: 'left', fontSize: 76, fontWeight: 500, fontFamily: 'Poppins', fill: DAAROM.navy, lineHeight: 1.1 }), 'slideUp', 0.3),
      anim(text({ text: 'opvallen online.', x: 140, y: 416, width: 800, align: 'left', fontSize: 76, fontWeight: 700, fontFamily: 'Poppins', fill: DAAROM.navy, lineHeight: 1.1 }), 'slideUp', 0.45),
      anim(text({ text: 'Strategie, creatie en uitvoering onder één dak. Praktisch, eerlijk en to-the-point.', x: 140, y: 560, width: 760, align: 'left', fontSize: 34, fontWeight: 400, fontFamily: 'Poppins', fill: '#6B7280', lineHeight: 1.45 }), 'fade', 0.8),
      ...cta('Plan een afspraak in', 140, 790, 560, DAAROM.blue, '#FFFFFF', 1.2, 'Poppins'),
      anim(makeEl('image', F, { name: 'Beeldmerk', src: brandUrl('favicon-roze-192.png'), x: 800, y: 780, width: 130, height: 130 }), 'pop', 1.5, 'float'),
    ]),
  },
  {
    key: 'sale', name: 'Sale', tags: 'korting actie webshop',
    frame: () => base({ type: 'gradient', color: '#EA5F39', color2: '#E0337A', angle: 135 }, [
      anim(makeEl('star', F, { name: 'Badge', x: 640, y: 90, width: 360, height: 360, fill: '#FFC233', points: 14, innerRatio: 0.8, rotation: 12 }), 'spin', 0.2, 'wiggle'),
      anim(text({ text: '-30%', x: 660, y: 205, width: 320, fontSize: 112, fontWeight: 900, fontFamily: 'Archivo Black', fill: '#1B213B', rotation: 12 }), 'spin', 0.2, 'wiggle'),
      anim(text({ text: 'Mega sale', x: 90, y: 470, width: 900, align: 'left', fontSize: 150, fontWeight: 900, fontFamily: 'Archivo Black', fill: '#FFFFFF', lineHeight: 1 }), 'slideUp', 0.5),
      anim(text({ text: 'Alleen dit weekend op de hele collectie', x: 90, y: 650, width: 760, align: 'left', fontSize: 48, fontWeight: 500, fill: '#FFFFFF' }), 'fade', 0.9),
      ...cta('Shop nu', 90, 850, 380, '#1B213B', '#FFFFFF', 1.4),
    ]),
  },
  {
    key: 'collectie', name: 'Nieuwe collectie', tags: 'mode interieur product',
    frame: () => base({ type: 'solid', color: '#1B213B', color2: '#2E2550', angle: 160 }, [
      anim(makeEl('ellipse', F, { name: 'Cirkel', x: 520, y: -160, width: 760, height: 760, fill: '#EA5F39' }), 'zoomIn', 0, 'float', 1),
      anim(makeEl('image', F, { name: 'Productfoto', x: 560, y: 380, width: 440, height: 560, cornerRadius: 28, fill: '#3A3450' }), 'slideLeft', 0.4),
      anim(text({ text: 'NIEUW BINNEN', x: 90, y: 300, width: 460, align: 'left', fontSize: 34, fontWeight: 700, letterSpacing: 6, fill: '#FFC233' }), 'fade', 0.3),
      anim(text({ text: 'De herfst collectie', x: 90, y: 360, width: 460, align: 'left', fontSize: 104, fontWeight: 800, fontFamily: 'Poppins', fill: '#FFFFFF', lineHeight: 1 }), 'slideUp', 0.5),
      ...cta('Bekijk alles', 90, 820, 400, '#FFFFFF', '#1B213B', 1.2),
    ]),
  },
  {
    key: 'vacature', name: 'Vacature', tags: 'werken recruitment baan',
    frame: () => base({ type: 'solid', color: '#FFC233', color2: '#FFC233', angle: 0 }, [
      anim(rect({ name: 'Vlak', x: 0, y: 700, width: 1080, height: 380, fill: '#1B213B' }), 'slideUp', 0),
      anim(text({ text: 'Wij zoeken jou!', x: 90, y: 150, width: 900, align: 'left', fontSize: 118, fontWeight: 900, fontFamily: 'Unbounded', fill: '#1B213B', lineHeight: 1 }), 'slideUp', 0.3),
      anim(text({ text: 'Allround monteur · 32 tot 40 uur · Groningen', x: 90, y: 500, width: 900, align: 'left', fontSize: 46, fontWeight: 600, fill: '#1B213B' }), 'fade', 0.8),
      ...cta('Solliciteer nu', 90, 830, 460, '#FFC233', '#1B213B', 1.2),
      anim(makeEl('icon', F, { icon: 'arrow-right', x: 860, y: 815, width: 140, height: 140, fill: '#FFC233', strokeWidth: 2.5 }), 'slideRight', 1.4, 'float'),
    ]),
  },
  {
    key: 'advies', name: 'Gratis advies', tags: 'b2b dienst leadgen',
    frame: () => base({ type: 'gradient', color: '#1A5FC4', color2: '#2E2550', angle: 120 }, [
      anim(text({ text: 'Plan een gratis adviesgesprek', x: 90, y: 120, width: 900, align: 'left', fontSize: 96, fontWeight: 800, fontFamily: 'Plus Jakarta Sans', fill: '#FFFFFF', lineHeight: 1.05 }), 'slideUp', 0.2),
      ...['Binnen 24 uur reactie', 'Persoonlijk en vrijblijvend', 'Concreet plan van aanpak'].flatMap((t, i) => [
        anim(makeEl('icon', F, { icon: 'check-circle', x: 90, y: 470 + i * 100, width: 64, height: 64, fill: '#13B58C', strokeWidth: 2.5 }), 'pop', 0.8 + i * 0.25),
        anim(text({ text: t, x: 180, y: 478 + i * 100, width: 760, align: 'left', fontSize: 44, fontWeight: 500, fill: '#FFFFFF' }), 'slideLeft', 0.8 + i * 0.25),
      ]),
      ...cta('Plan direct in', 90, 850, 440, '#13B58C', '#FFFFFF', 1.8),
    ]),
  },
  {
    key: 'event', name: 'Event of webinar', tags: 'evenement datum aanmelden',
    frame: () => base({ type: 'solid', color: '#F6F5FA', color2: '#F6F5FA', angle: 0 }, [
      anim(rect({ name: 'Datumblok', x: 90, y: 90, width: 260, height: 300, fill: '#EA5F39', cornerRadius: 32 }), 'pop', 0.1),
      anim(text({ text: '21', x: 90, y: 120, width: 260, fontSize: 150, fontWeight: 900, fill: '#FFFFFF', fontFamily: 'Outfit' }), 'pop', 0.1),
      anim(text({ text: 'NOVEMBER', x: 90, y: 300, width: 260, fontSize: 36, fontWeight: 700, letterSpacing: 3, fill: '#FFFFFF' }), 'pop', 0.1),
      anim(text({ text: 'Live webinar: groeien met online marketing', x: 90, y: 470, width: 900, align: 'left', fontSize: 84, fontWeight: 800, fontFamily: 'Outfit', fill: '#1B213B', lineHeight: 1.05 }), 'slideUp', 0.5),
      anim(text({ text: '20:00 uur · online · gratis', x: 90, y: 740, width: 900, align: 'left', fontSize: 44, fontWeight: 500, fill: '#6B6880' }), 'fade', 0.9),
      ...cta('Meld je aan', 90, 860, 420, '#1B213B', '#FFFFFF', 1.3),
    ]),
  },
  {
    key: 'review', name: 'Klantreview', tags: 'quote review vertrouwen',
    frame: () => base({ type: 'solid', color: '#13B58C', color2: '#13B58C', angle: 0 }, [
      ...[0, 1, 2, 3, 4].map((i) => anim(makeEl('star', F, { x: 90 + i * 100, y: 140, width: 80, height: 80, fill: '#FFC233' }), 'pop', 0.2 + i * 0.12)),
      anim(text({ text: '"Binnen drie maanden verdubbelden onze aanvragen. Echt een team dat meedenkt."', x: 90, y: 300, width: 900, align: 'left', fontSize: 66, fontWeight: 700, fontFamily: 'Fraunces', fill: '#FFFFFF', lineHeight: 1.15 }), 'fade', 0.9, 'none', 1),
      anim(text({ text: 'Lisa de Vries, eigenaar', x: 90, y: 840, width: 900, align: 'left', fontSize: 40, fontWeight: 600, fill: '#E9FFF7' }), 'slideUp', 1.6),
    ]),
  },
  {
    key: 'foto', name: 'Foto met tekst', tags: 'beeld lokaal sfeer',
    frame: () => base({ type: 'solid', color: '#2E2550', color2: '#2E2550', angle: 0 }, [
      anim(makeEl('image', F, { name: 'Achtergrondfoto', x: 0, y: 0, width: 1080, height: 1080, fill: '#6B6880' }), 'zoomOut', 0, 'none', 1.5),
      anim(rect({ name: 'Donker vlak', x: 0, y: 560, width: 1080, height: 520, fill: '#1B213B', opacity: 0.75 }), 'slideUp', 0.3),
      anim(text({ text: 'Nu ook in Groningen', x: 90, y: 620, width: 900, align: 'left', fontSize: 104, fontWeight: 800, fontFamily: 'Poppins', fill: '#FFFFFF', lineHeight: 1 }), 'slideUp', 0.6),
      ...cta('Route plannen', 90, 880, 460, '#EA5F39', '#FFFFFF', 1.1),
    ]),
  },
  {
    key: 'minimal', name: 'Strak en simpel', tags: 'minimal merk tekst',
    frame: () => base({ type: 'solid', color: '#FFFFFF', color2: '#FFFFFF', angle: 0 }, [
      anim(makeEl('line', F, { x: 90, y: 160, width: 160, height: 14, fill: '#EA5F39', cornerRadius: 7 }), 'slideRight', 0.1),
      anim(text({ text: 'Minder zoeken, meer vinden.', x: 90, y: 230, width: 900, align: 'left', fontSize: 120, fontWeight: 800, fontFamily: 'Inter', fill: '#1B213B', lineHeight: 1.02, letterSpacing: -3 }), 'slideUp', 0.3),
      anim(text({ text: 'Ontdek hoe het werkt in twee minuten.', x: 90, y: 690, width: 900, align: 'left', fontSize: 46, fontWeight: 400, fill: '#6B6880' }), 'fade', 0.8),
      ...cta('Meer info', 90, 860, 360, '#1B213B', '#FFFFFF', 1.2),
    ]),
  },
]
