// Open iconsets via de Iconify API (200.000+ iconen uit 150+ open source sets)
const API = 'https://api.iconify.design'

export interface IconHit { id: string; prefix: string; name: string }
export interface IconSet { prefix: string; name: string; total: number; license: string; spdx?: string; palette?: boolean }

export const PACKS: { prefix: string; name: string }[] = [
  { prefix: '', name: 'Alle packs' },
  { prefix: 'material-symbols', name: 'Material Symbols' },
  { prefix: 'ph', name: 'Phosphor' },
  { prefix: 'tabler', name: 'Tabler' },
  { prefix: 'lucide', name: 'Lucide' },
  { prefix: 'heroicons', name: 'Heroicons' },
  { prefix: 'ri', name: 'Remix Icon' },
  { prefix: 'fluent', name: 'Fluent UI' },
  { prefix: 'carbon', name: 'Carbon' },
  { prefix: 'iconoir', name: 'Iconoir' },
  { prefix: 'bi', name: 'Bootstrap Icons' },
  { prefix: 'fa6-solid', name: 'Font Awesome (gratis)' },
  { prefix: 'solar', name: 'Solar' },
  { prefix: 'mingcute', name: 'MingCute' },
  { prefix: 'hugeicons', name: 'Hugeicons' },
  { prefix: 'streamline', name: 'Streamline' },
  { prefix: 'simple-icons', name: 'Merklogo\'s (Simple Icons)' },
  { prefix: 'logos', name: 'Merklogo\'s in kleur' },
  { prefix: 'fluent-emoji-flat', name: 'Emoji (Fluent)' },
  { prefix: 'twemoji', name: 'Emoji (Twemoji)' },
  { prefix: 'flag', name: 'Vlaggen' },
  { prefix: 'noto', name: 'Noto (kleur)' },
]

export async function searchIcons(query: string, prefix = '', limit = 96): Promise<{ hits: IconHit[]; sets: Record<string, IconSet> }> {
  const url = `${API}/search?query=${encodeURIComponent(query)}&limit=${limit}${prefix ? `&prefix=${prefix}` : ''}`
  const r = await fetch(url)
  if (!r.ok) throw new Error('Iconen zoeken lukt nu niet')
  const j = await r.json() as { icons: string[]; collections: Record<string, { name: string; total: number; license?: { title: string; spdx?: string }; palette?: boolean }> }
  const sets: Record<string, IconSet> = {}
  for (const [p, c] of Object.entries(j.collections || {})) sets[p] = { prefix: p, name: c.name, total: c.total, license: c.license?.title || '', spdx: c.license?.spdx, palette: c.palette }
  return { hits: (j.icons || []).map((id) => { const [prefix, name] = id.split(':'); return { id, prefix, name } }), sets }
}

export async function packIcons(prefix: string, limit = 120): Promise<IconHit[]> {
  const r = await fetch(`${API}/collection?prefix=${prefix}`)
  if (!r.ok) return []
  const j = await r.json() as { uncategorized?: string[]; categories?: Record<string, string[]> }
  const names = [...(j.uncategorized || []), ...Object.values(j.categories || {}).flat()]
  return [...new Set(names)].slice(0, limit).map((name) => ({ id: `${prefix}:${name}`, prefix, name }))
}

export const previewUrl = (h: IconHit, color = '#1B213B') => `${API}/${h.prefix}/${h.name}.svg?color=${encodeURIComponent(color)}`

const cache = new Map<string, Promise<string>>()
export function fetchIconSvg(h: IconHit): Promise<string> {
  if (!cache.has(h.id)) cache.set(h.id, fetch(`${API}/${h.prefix}/${h.name}.svg?height=256`).then((r) => { if (!r.ok) throw new Error('Icoon niet gevonden'); return r.text() }))
  return cache.get(h.id)!
}

/** Kleurt een monochroom icoon (currentColor) in; kleurenicoontjes blijven zoals ze zijn. */
export function colorSvg(svg: string, color: string) {
  return svg.replace(/currentColor/g, color)
}
export const svgDataUrl = (svg: string) => 'data:image/svg+xml;charset=utf-8,' + encodeURIComponent(svg)
