// Open iconsets via de Iconify API (200.000+ iconen uit 150+ open source sets).
// Voorbeelden worden per pack in één verzoek opgehaald (bulk JSON), anders blokkeert de API ons.
const API = 'https://api.iconify.design'

export interface IconHit { id: string; prefix: string; name: string }
export interface IconSet { prefix: string; name: string; total: number; license: string; spdx?: string; palette?: boolean }

export const PACKS: { prefix: string; name: string }[] = [
  { prefix: '', name: 'Alle packs' },
  { prefix: 'material-symbols', name: 'Material Symbols' },
  { prefix: 'ph', name: 'Phosphor' },
  { prefix: 'tabler', name: 'Tabler' },
  { prefix: 'lucide', name: 'Lucide' },
  { prefix: 'heroicons', name: 'Heroicons' },
  { prefix: 'ri', name: 'Remix Icon' },
  { prefix: 'fluent', name: 'Fluent UI' },
  { prefix: 'carbon', name: 'Carbon' },
  { prefix: 'iconoir', name: 'Iconoir' },
  { prefix: 'bi', name: 'Bootstrap Icons' },
  { prefix: 'fa6-solid', name: 'Font Awesome (gratis)' },
  { prefix: 'solar', name: 'Solar' },
  { prefix: 'mingcute', name: 'MingCute' },
  { prefix: 'hugeicons', name: 'Hugeicons' },
  { prefix: 'streamline', name: 'Streamline' },
  { prefix: 'mdi', name: 'Material Design Icons' },
  { prefix: 'simple-icons', name: 'Merklogo\'s (Simple Icons)' },
  { prefix: 'logos', name: 'Merklogo\'s in kleur' },
  { prefix: 'fluent-emoji-flat', name: 'Emoji (Fluent)' },
  { prefix: 'twemoji', name: 'Emoji (Twemoji)' },
  { prefix: 'flag', name: 'Vlaggen' },
  { prefix: 'noto', name: 'Noto (kleur)' },
]

async function getJson<T>(url: string, tries = 3): Promise<T> {
  let last: unknown
  for (let i = 0; i < tries; i++) {
    try {
      const r = await fetch(url)
      if (r.ok) return await r.json() as T
      last = new Error(String(r.status))
    } catch (e) { last = e }
    await new Promise((res) => setTimeout(res, 400 * (i + 1)))
  }
  void last
  throw new Error('De iconenbibliotheek reageert even niet. Probeer het zo opnieuw.')
}

const searchCache = new Map<string, Promise<{ hits: IconHit[]; sets: Record<string, IconSet> }>>()
export function searchIcons(query: string, prefix = '', limit = 96) {
  const key = `${query}|${prefix}|${limit}`
  if (!searchCache.has(key)) {
    const p = getJson<{ icons: string[]; collections: Record<string, { name: string; total: number; license?: { title: string; spdx?: string }; palette?: boolean }> }>(
      `${API}/search?query=${encodeURIComponent(query)}&limit=${Math.max(32, limit)}${prefix ? `&prefix=${prefix}` : ''}`,
    ).then((j) => {
      const sets: Record<string, IconSet> = {}
      for (const [p, c] of Object.entries(j.collections || {})) sets[p] = { prefix: p, name: c.name, total: c.total, license: c.license?.title || '', spdx: c.license?.spdx, palette: c.palette }
      return { hits: (j.icons || []).map((id) => { const [pre, name] = id.split(':'); return { id, prefix: pre, name } }), sets }
    })
    p.catch(() => searchCache.delete(key))
    searchCache.set(key, p)
  }
  return searchCache.get(key)!
}

const packCache = new Map<string, Promise<string[]>>()
export async function packIcons(prefix: string, limit = 120): Promise<IconHit[]> {
  if (!packCache.has(prefix)) {
    let stored: string[] | null = null
    try { stored = JSON.parse(sessionStorage.getItem('adwerk.pack.' + prefix) || 'null') } catch { /* leeg */ }
    const p = stored ? Promise.resolve(stored) : getJson<{ uncategorized?: string[]; categories?: Record<string, string[]>; hidden?: string[] }>(`${API}/collection?prefix=${prefix}`).then((j) => {
      const names = [...new Set([...Object.values(j.categories || {}).flat(), ...(j.uncategorized || [])])].slice(0, 600)
      try { sessionStorage.setItem('adwerk.pack.' + prefix, JSON.stringify(names)) } catch { /* vol */ }
      return names
    })
    p.catch(() => packCache.delete(prefix))
    packCache.set(prefix, p)
  }
  const names = await packCache.get(prefix)!
  return names.slice(0, limit).map((name) => ({ id: `${prefix}:${name}`, prefix, name }))
}

/* ---------- svg-data in bulk ---------- */
interface IconJson { prefix: string; width?: number; height?: number; icons: Record<string, { body: string; width?: number; height?: number; left?: number; top?: number }>; aliases?: Record<string, { parent: string; hFlip?: boolean; vFlip?: boolean; rotate?: number }> }
const svgCache = new Map<string, string>()
const pending = new Map<string, Promise<void>>()

function buildSvg(j: IconJson, name: string): string | null {
  let icon = j.icons[name]
  let flip = { h: false, v: false, rotate: 0 }
  if (!icon && j.aliases?.[name]) {
    const a = j.aliases[name]
    icon = j.icons[a.parent]
    flip = { h: !!a.hFlip, v: !!a.vFlip, rotate: a.rotate || 0 }
  }
  if (!icon) return null
  const w = icon.width ?? j.width ?? 16, h = icon.height ?? j.height ?? 16, l = icon.left ?? 0, t = icon.top ?? 0
  let body = icon.body
  const tr: string[] = []
  if (flip.h) tr.push(`translate(${w + 2 * l} 0) scale(-1 1)`)
  if (flip.v) tr.push(`translate(0 ${h + 2 * t}) scale(1 -1)`)
  if (flip.rotate) tr.push(`rotate(${flip.rotate * 90} ${l + w / 2} ${t + h / 2})`)
  if (tr.length) body = `<g transform="${tr.join(' ')}">${body}</g>`
  const size = 256, ratio = w / h
  return `<svg xmlns="http://www.w3.org/2000/svg" width="${Math.round(ratio >= 1 ? size : size * ratio)}" height="${Math.round(ratio >= 1 ? size / ratio : size)}" viewBox="${l} ${t} ${w} ${h}">${body}</svg>`
}

/** Haalt de svg's van een lijst iconen op in zo weinig mogelijk verzoeken (per pack, blokken van 80). */
export async function loadIcons(hits: IconHit[]): Promise<void> {
  const byPrefix = new Map<string, string[]>()
  for (const h of hits) if (!svgCache.has(h.id) && !pending.has(h.id)) byPrefix.set(h.prefix, [...(byPrefix.get(h.prefix) || []), h.name])
  const jobs: Promise<void>[] = []
  for (const [prefix, names] of byPrefix) {
    for (let i = 0; i < names.length; i += 80) {
      const chunk = names.slice(i, i + 80)
      const job = getJson<IconJson>(`${API}/${prefix}.json?icons=${chunk.map(encodeURIComponent).join(',')}`).then((j) => {
        for (const n of chunk) { const s = buildSvg(j, n); if (s) svgCache.set(`${prefix}:${n}`, s) }
      }).finally(() => chunk.forEach((n) => pending.delete(`${prefix}:${n}`)))
      chunk.forEach((n) => pending.set(`${prefix}:${n}`, job))
      jobs.push(job)
    }
  }
  for (const h of hits) { const p = pending.get(h.id); if (p && !jobs.includes(p)) jobs.push(p) }
  await Promise.allSettled(jobs)
}

export const cachedSvg = (id: string) => svgCache.get(id)

export async function fetchIconSvg(h: IconHit): Promise<string> {
  if (!svgCache.has(h.id)) await loadIcons([h])
  const s = svgCache.get(h.id)
  if (!s) throw new Error('Icoon niet gevonden')
  return s
}

/** Kleurt een monochroom icoon (currentColor) in; kleurenicoontjes blijven zoals ze zijn. */
export function colorSvg(svg: string, color: string) {
  return svg.replace(/currentColor/g, color)
}
export const svgDataUrl = (svg: string) => 'data:image/svg+xml;charset=utf-8,' + encodeURIComponent(svg)
