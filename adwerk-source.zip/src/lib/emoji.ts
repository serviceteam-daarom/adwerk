// Unicode-emoji per categorie (geen externe bibliotheek nodig)
const Seg = (Intl as unknown as { Segmenter: new (l: string, o: { granularity: string }) => { segment: (s: string) => Iterable<{ segment: string }> } }).Segmenter
const g = (s: string) => [...new Seg('nl', { granularity: 'grapheme' }).segment(s.replace(/\s+/g, ''))].map((x) => x.segment)

export const EMOJI: { name: string; icon: string; list: string[] }[] = [
  { name: 'Smileys', icon: '😀', list: g('😀😃😄😁😆😅🤣😂🙂🙃😉😊😇🥰😍🤩😘😗😚😙🥲😋😛😜🤪😝🤑🤗🤭🤫🤔🫡🤐🤨😐😑😶🫥😏😒🙄😬😮‍💨🤥😌😔😪🤤😴😷🤒🤕🤢🤮🤧🥵🥶🥴😵🤯🤠🥳🥸😎🤓🧐😕🫤😟🙁☹️😮😯😲😳🥺🥹😦😧😨😰😥😢😭😱😖😣😞😓😩😫🥱😤😡😠🤬😈👿💀☠️💩🤡👻👽🤖😺😸😹😻😼😽🙀😿😾') },
  { name: 'Gebaren', icon: '👍', list: g('👋🤚🖐️✋🖖👌🤌🤏✌️🤞🫰🤟🤘🤙👈👉👆🖕👇☝️🫵👍👎✊👊🤛🤜👏🙌🫶👐🤲🤝🙏✍️💅🤳💪🦾🧠👀👁️👅👄🫦') },
  { name: 'Mensen', icon: '🧑', list: g('👶🧒👦👧🧑👱👨🧔👩🧓👴👵🙍🙎🙅🙆💁🙋🧏🙇🤦🤷🧑‍💻👩‍💻👨‍💻🧑‍🎨👩‍🎨🧑‍💼👩‍💼👨‍💼🧑‍🔧🧑‍🍳🧑‍🏫🧑‍⚕️🦸🦹🧙🧚🧛🧜🧝🕺💃👯🧘🏃🚶🧍') },
  { name: 'Hartjes', icon: '❤️', list: g('❤️🧡💛💚💙🩵💜🤎🖤🩶🤍💔❣️💕💞💓💗💖💘💝💟❤️‍🔥❤️‍🩹💋💯💢💥💫💦💨🕳️💬🗨️🗯️💭💤') },
  { name: 'Natuur', icon: '🌿', list: g('🐶🐱🐭🐹🐰🦊🐻🐼🐨🐯🦁🐮🐷🐸🐵🙈🙉🙊🐔🐧🐦🐤🦆🦅🦉🐺🐴🦄🐝🦋🐌🐞🐢🐍🐙🐬🐳🐟🦈🌵🎄🌲🌳🌴🌱🌿☘️🍀🍁🍂🍃🌷🌹🌺🌸🌼🌻🌞🌝🌚🌙⭐🌟✨⚡🔥🌈☀️⛅☁️🌧️⛈️❄️☃️🌊💧') },
  { name: 'Eten', icon: '🍕', list: g('🍏🍎🍐🍊🍋🍌🍉🍇🍓🫐🍒🍑🥭🍍🥥🥝🍅🥑🥦🥕🌽🌶️🥐🥖🧀🥚🍳🥞🥓🍔🍟🍕🌭🥪🌮🌯🥗🍝🍜🍣🍱🍤🍦🍩🍪🎂🍰🧁🍫🍬🍭☕🍵🧃🥤🧋🍺🍻🥂🍷🍸🍹🍾') },
  { name: 'Activiteit', icon: '⚽', list: g('⚽🏀🏈⚾🎾🏐🏉🎱🏓🏸🥅⛳🏹🎣🥊🥋⛸️🎿🏂🏋️🚴🏊🏄🏆🥇🥈🥉🏅🎖️🎗️🎫🎟️🎪🎭🎨🎬🎤🎧🎼🎹🥁🎷🎺🎸🎻🎲♟️🎯🎳🎮🕹️🧩') },
  { name: 'Reizen', icon: '🚀', list: g('🚗🚕🚙🚌🏎️🚓🚑🚒🚚🚛🚜🛵🚲🛴✈️🛫🛬🚀🛸🚁⛵🚤🛳️🚢⚓🚧⛽🚦🗺️🗽🗼🏰🏯🏟️🎡🎢🏖️🏝️🏜️🌋⛰️🏔️🏕️🏠🏡🏢🏬🏭🏗️⛪🕌🌁🌃🏙️🌄🌅🌆🌇🌉') },
  { name: 'Objecten', icon: '💡', list: g('⌚📱💻⌨️🖥️🖨️🖱️💾💿📷📸📹🎥📞☎️📺📻🎙️⏰⏳💡🔦🕯️💸💵💶💰💳💎⚖️🧰🔧🔨⚙️🧲🔫💣🔪🛡️🔮🧿💈🔬🔭🩺💊🩹🧬🧪🌡️🧹🧺🧻🚽🛁🔑🗝️🚪🛋️🛏️🖼️🛍️🛒🎁🎈🎉🎊🪅✉️📩📨📧💌📦🏷️📪📬📮📝📄📃📑📊📈📉📆📅🗓️📇🗃️🗄️📋📁📂🗂️📰📓📔📒📕📗📘📙📚📖🔖🔗📎🖇️📐📏📌📍✂️🖊️🖋️✒️🖌️🖍️✏️🔍🔎🔒🔓') },
  { name: 'Symbolen', icon: '✅', list: g('✅☑️✔️❌❎➕➖➗✖️♾️‼️⁉️❓❔❕❗〰️💲⚠️🚸⛔🚫🔞📵🔅🔆🔱⚜️🔰♻️🆕🆓🆒🆗🆙🆘🔟🔢#️⃣*️⃣0️⃣1️⃣2️⃣3️⃣4️⃣5️⃣6️⃣7️⃣8️⃣9️⃣▶️⏸️⏹️⏺️⏭️⏮️⏩⏪🔀🔁🔂◀️🔼🔽➡️⬅️⬆️⬇️↗️↘️↙️↖️↕️↔️🔄🎵🎶💱©️®️™️🔴🟠🟡🟢🔵🟣⚫⚪🟤🟥🟧🟨🟩🟦🟪⬛⬜🔶🔷🔸🔹🔺🔻💠🔘🔳🔲🏁🚩🎌🏴🏳️🏳️‍🌈🇳🇱🇧🇪🇩🇪🇬🇧🇺🇸🇪🇺') },
]

const KEY = 'adwerk.emoji.recent'
export function recentEmoji(): string[] { try { return JSON.parse(localStorage.getItem(KEY) || '[]') } catch { return [] } }
export function pushRecent(e: string) {
  try { localStorage.setItem(KEY, JSON.stringify([e, ...recentEmoji().filter((x) => x !== e)].slice(0, 24))) } catch { /* privémodus */ }
}
