import type { Brief, BriefField, BriefKind } from './types'

/** Standaardvelden met suggesties. Alles blijft vrij invulbaar; de suggesties zijn alleen snelkeuzes. */
export interface Preset { key: string; label: string; kind: BriefKind; placeholder: string; suggestions?: string[]; limit?: number; hint?: string }
export const PRESETS: Preset[] = [
  { key: 'doelgroep', label: 'Doelgroep', kind: 'text', placeholder: 'Bijv. remarketing doelgroep websitebezoekers', suggestions: ['Remarketing websitebezoekers (30 dagen)', 'Remarketing winkelwagenverlaters', 'Lookalike van klanten', 'Bestaande klanten', 'Breed met interesses', 'Zakelijke beslissers (LinkedIn)', 'Lokaal binnen straal'] },
  { key: 'budget', label: 'Budget', kind: 'text', placeholder: '15' },
  { key: 'doel', label: 'Campagnedoelstelling', kind: 'text', placeholder: 'Bijv. websiteverkeer', suggestions: ['Websiteverkeer', 'Leads', 'Verkoop', 'Naamsbekendheid', 'Bereik', 'Interactie', 'Videoweergaven', 'App-promotie'] },
  { key: 'landing', label: 'Landingspagina', kind: 'url', placeholder: 'https://' },
  { key: 'vorm', label: 'Vorm', kind: 'text', placeholder: 'Kies of typ een vorm', suggestions: ['Enkele afbeelding', 'Carrousel', 'Video', 'Story of Reel', 'Collectie', 'HTML5-banner', 'GIF', 'Responsive display', 'LinkedIn document', 'Organische post'] },
  { key: 'koppen', label: 'Koppen', kind: 'list', placeholder: 'Kop', limit: 40, hint: 'Meta toont ongeveer 40 tekens' },
  { key: 'teksten', label: 'Teksten', kind: 'list', placeholder: 'Primaire tekst', limit: 125, hint: 'Na ongeveer 125 tekens verschijnt "Meer weergeven"' },
]
export const presetOf = (f: BriefField) => PRESETS.find((p) => p.key === f.preset)

/** Extra veldtypes die je zelf kunt toevoegen. */
export const EXTRA_SUGGESTIONS: { label: string; kind: BriefKind; suggestions?: string[] }[] = [
  { label: 'Platform', kind: 'text', suggestions: ['Meta (Facebook en Instagram)', 'LinkedIn', 'Google Display', 'TikTok', 'Pinterest'] },
  { label: 'Call to action', kind: 'text', suggestions: ['Meer informatie', 'Nu kopen', 'Offerte aanvragen', 'Aanmelden', 'Contact opnemen', 'Bekijk aanbod', 'Downloaden'] },
  { label: 'Looptijd', kind: 'text' },
  { label: 'Beschrijving', kind: 'longtext' },
  { label: 'UTM-parameters', kind: 'text' },
  { label: 'Notitie', kind: 'longtext' },
]
export const SUGGESTIONS_BY_LABEL: Record<string, string[]> = Object.fromEntries([...PRESETS, ...EXTRA_SUGGESTIONS].filter((p) => p.suggestions).map((p) => [p.label.toLowerCase(), p.suggestions!]))

export function defaultBrief(): Brief {
  return { showClient: true, fields: PRESETS.map((p) => ({ id: 'p-' + p.key, label: p.label, kind: p.kind, value: '', preset: p.key, ...(p.kind === 'list' ? { items: [''] } : {}) })) }
}
export const filled = (f: BriefField) => (f.kind === 'list' ? (f.items || []).some((x) => x.trim()) : !!f.value.trim())
export const filledCount = (b?: Brief) => (b ? b.fields.filter(filled).length : 0)
