import { createClient } from '@supabase/supabase-js'

// Publieke projectgegevens (de publishable key is bedoeld voor gebruik in de browser; toegang wordt afgeschermd met Row Level Security)
export const SUPABASE_URL = 'https://udjhmftluyaohwuslfeg.supabase.co'
export const SUPABASE_KEY = 'sb_publishable_6030ItL8h1NthRYmKvuhvg_97qFOXiS'
export const ALLOWED_DOMAIN = 'daar-om.nl'

export const supabase = createClient(SUPABASE_URL, SUPABASE_KEY, {
  auth: { flowType: 'pkce', persistSession: true, autoRefreshToken: true, detectSessionInUrl: true },
  // worker: hartslag in een Web Worker, zodat een tabblad op de achtergrond verbonden blijft
  realtime: { params: { eventsPerSecond: 40 }, worker: true },
})

export function appUrl() {
  return window.location.origin + window.location.pathname
}

export async function signInWithGoogle() {
  return supabase.auth.signInWithOAuth({
    provider: 'google',
    options: { redirectTo: appUrl(), queryParams: { hd: ALLOWED_DOMAIN, prompt: 'select_account' } },
  })
}
