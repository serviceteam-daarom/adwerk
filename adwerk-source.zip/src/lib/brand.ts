import type { BrandKit } from './types'

/** Huisstijl daar-om.nl: website + Huisstijlhandboek daar-om.nl 2026 (Nacht blauw, Stads blauw, Hemels blauw, Studio Paars, Spot Oranje; Poppins Bold koppen, Poppins Regular tekst, Caveat bij de pijl). */
export const brandUrl = (file: string) => new URL(`./brand-${file}`, window.location.href.split('#')[0]).href

export const DAAROM = {
  navy: '#1B213B', orange: '#EA5F39', blue: '#1A5FC4', lila: '#E6A4FF', sky: '#A2D6ED', mist: '#F1F9FC', line: '#E0F1F7', white: '#FFFFFF',
}

export const DAAROM_KIT = (): BrandKit => ({
  id: 'daar-om-builtin',
  name: 'daar-om.nl',
  owner_id: '',
  colors: [DAAROM.navy, DAAROM.orange, DAAROM.blue, DAAROM.lila, DAAROM.sky, DAAROM.mist, DAAROM.white],
  fonts: ['Poppins', 'Caveat'],
  logos: [
    { url: brandUrl('daar-om-logo.svg'), name: 'Logo donkerblauw' },
    { url: brandUrl('daar-om-logo-wit.svg'), name: 'Logo wit' },
    { url: brandUrl('beeldmerk-lila.svg'), name: 'Beeldmerk Studio Paars' },
    { url: brandUrl('beeldmerk-stadsblauw.svg'), name: 'Beeldmerk Stads blauw' },
    { url: brandUrl('martinitoren.svg'), name: 'Martinitoren' },
  ],
})

export const BRAND_ELEMENTS = [
  { file: 'gradientlijn.svg', name: 'Gradient lijn (omhoog)', w: 600, h: 600 },
  { file: 'gradientlijn-verticaal.svg', name: 'Gradient lijn verticaal', w: 300, h: 900 },
  { file: 'beeldmerk-lila.svg', name: 'Beeldmerk Studio Paars', w: 404, h: 404 },
  { file: 'beeldmerk-stadsblauw.svg', name: 'Beeldmerk Stads blauw', w: 404, h: 404 },
  { file: 'beeldmerk-hemelsblauw.svg', name: 'Beeldmerk Hemels blauw', w: 404, h: 404 },
  { file: 'beeldmerk-oranje.svg', name: 'Beeldmerk Spot Oranje', w: 404, h: 404 },
  { file: 'beeldmerk-nachtblauw.svg', name: 'Beeldmerk Nacht blauw', w: 404, h: 404 },
  { file: 'beeldmerk-wit.svg', name: 'Beeldmerk wit', w: 404, h: 404 },
  { file: 'pijl-oranje-1.svg', name: 'Pijl oranje', w: 77, h: 79 },
  { file: 'pijl-oranje-2.svg', name: 'Pijl oranje', w: 77, h: 79 },
  { file: 'pijl-oranje-3.svg', name: 'Pijl oranje', w: 80, h: 80 },
  { file: 'pijl-navy-01.svg', name: 'Pijl donkerblauw', w: 78, h: 78 },
  { file: 'pijl-navy-02.svg', name: 'Pijl donkerblauw', w: 78, h: 78 },
  { file: 'pijl-navy-03.svg', name: 'Pijl donkerblauw', w: 78, h: 78 },
  { file: 'pijl-navy-04.svg', name: 'Pijl donkerblauw', w: 78, h: 78 },
  { file: 'martinitoren.svg', name: 'Martinitoren', w: 282, h: 992 },
  { file: 'daar-om-logo.svg', name: 'Logo daar-om.nl', w: 359, h: 80 },
  { file: 'daar-om-logo-wit.svg', name: 'Logo daar-om.nl wit', w: 359, h: 80 },
]
