import type { BrandKit } from './types'

/** Huisstijl daar-om.nl, gemeten op www.daar-om.nl (homepage en /team). */
export const brandUrl = (file: string) => new URL(`./brand-${file}`, window.location.href.split('#')[0]).href

export const DAAROM = {
  navy: '#1B213B', orange: '#EA5F39', blue: '#1A5FC4', lila: '#E6A4FF', sky: '#A2D6ED', mist: '#F1F9FC', line: '#E0F1F7', white: '#FFFFFF',
}

export const DAAROM_KIT = (): BrandKit => ({
  id: 'daar-om-builtin',
  name: 'daar-om.nl',
  owner_id: '',
  colors: [DAAROM.navy, DAAROM.orange, DAAROM.blue, DAAROM.lila, DAAROM.sky, DAAROM.mist, DAAROM.white],
  fonts: ['Poppins', 'Caveat'],
  logos: [
    { url: brandUrl('daar-om-logo.svg'), name: 'Logo donkerblauw' },
    { url: brandUrl('daar-om-logo-wit.svg'), name: 'Logo wit' },
    { url: brandUrl('favicon-roze-192.png'), name: 'Beeldmerk lila' },
    { url: brandUrl('martinitoren.svg'), name: 'Martinitoren' },
  ],
})

export const BRAND_ELEMENTS = [
  { file: 'pijl-oranje-1.svg', name: 'Pijl oranje', w: 77, h: 79 },
  { file: 'pijl-oranje-2.svg', name: 'Pijl oranje', w: 77, h: 79 },
  { file: 'pijl-oranje-3.svg', name: 'Pijl oranje', w: 80, h: 80 },
  { file: 'pijl-navy-01.svg', name: 'Pijl donkerblauw', w: 78, h: 78 },
  { file: 'pijl-navy-02.svg', name: 'Pijl donkerblauw', w: 78, h: 78 },
  { file: 'pijl-navy-03.svg', name: 'Pijl donkerblauw', w: 78, h: 78 },
  { file: 'pijl-navy-04.svg', name: 'Pijl donkerblauw', w: 78, h: 78 },
  { file: 'martinitoren.svg', name: 'Martinitoren', w: 282, h: 992 },
  { file: 'favicon-roze-192.png', name: 'Beeldmerk', w: 192, h: 192 },
  { file: 'daar-om-logo.svg', name: 'Logo daar-om.nl', w: 359, h: 80 },
  { file: 'daar-om-logo-wit.svg', name: 'Logo daar-om.nl wit', w: 359, h: 80 },
]
