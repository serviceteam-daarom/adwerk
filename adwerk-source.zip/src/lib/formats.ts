export interface FormatPreset { key: string; name: string; w: number; h: number; platform: string }

export const PLATFORMS: { name: string; logos: string[]; formats: FormatPreset[] }[] = [
  {
    name: 'Meta (Facebook en Instagram)',
    logos: ['Facebook', 'Instagram'],
    formats: [
      { key: 'meta-sq', name: 'Feed vierkant', w: 1080, h: 1080, platform: 'Meta' },
      { key: 'meta-45', name: 'Feed staand 4:5', w: 1080, h: 1350, platform: 'Meta' },
      { key: 'meta-story', name: 'Story en Reels', w: 1080, h: 1920, platform: 'Meta' },
      { key: 'meta-land', name: 'Liggend 1.91:1', w: 1200, h: 628, platform: 'Meta' },
    ],
  },
  {
    name: 'LinkedIn',
    logos: ['LinkedIn'],
    formats: [
      { key: 'li-land', name: 'Liggend', w: 1200, h: 627, platform: 'LinkedIn' },
      { key: 'li-sq', name: 'Vierkant', w: 1200, h: 1200, platform: 'LinkedIn' },
      { key: 'li-vert', name: 'Staand', w: 720, h: 900, platform: 'LinkedIn' },
    ],
  },
  {
    name: 'Google Display (HTML5 en GIF)',
    logos: ['Google Display'],
    formats: [
      { key: 'g-300x250', name: 'Medium rectangle', w: 300, h: 250, platform: 'Google Display' },
      { key: 'g-336x280', name: 'Large rectangle', w: 336, h: 280, platform: 'Google Display' },
      { key: 'g-728x90', name: 'Leaderboard', w: 728, h: 90, platform: 'Google Display' },
      { key: 'g-300x600', name: 'Half page', w: 300, h: 600, platform: 'Google Display' },
      { key: 'g-160x600', name: 'Wide skyscraper', w: 160, h: 600, platform: 'Google Display' },
      { key: 'g-320x50', name: 'Mobile banner', w: 320, h: 50, platform: 'Google Display' },
      { key: 'g-320x100', name: 'Large mobile banner', w: 320, h: 100, platform: 'Google Display' },
      { key: 'g-970x250', name: 'Billboard', w: 970, h: 250, platform: 'Google Display' },
      { key: 'g-468x60', name: 'Banner', w: 468, h: 60, platform: 'Google Display' },
      { key: 'g-250x250', name: 'Square', w: 250, h: 250, platform: 'Google Display' },
    ],
  },
  {
    name: 'Google Demand Gen en PMax',
    logos: ['Google Ads', 'YouTube'],
    formats: [
      { key: 'dg-land', name: 'Liggend', w: 1200, h: 628, platform: 'Google Ads' },
      { key: 'dg-sq', name: 'Vierkant', w: 1200, h: 1200, platform: 'Google Ads' },
      { key: 'dg-port', name: 'Staand 4:5', w: 960, h: 1200, platform: 'Google Ads' },
    ],
  },
  {
    name: 'Overig',
    logos: ['TikTok', 'Pinterest', 'YouTube'],
    formats: [
      { key: 'tiktok', name: 'TikTok', w: 1080, h: 1920, platform: 'TikTok' },
      { key: 'pin', name: 'Pinterest pin', w: 1000, h: 1500, platform: 'Pinterest' },
      { key: 'yt-thumb', name: 'YouTube thumbnail', w: 1280, h: 720, platform: 'YouTube' },
    ],
  },
]

export const ALL_FORMATS = PLATFORMS.flatMap((p) => p.formats)
export const formatByKey = (k: string) => ALL_FORMATS.find((f) => f.key === k)!

export const SETS: { key: string; name: string; description: string; formats: string[]; color: string; logos: string[] }[] = [
  { key: 'meta-set', name: 'Social ad set', description: 'Feed, 4:5 en story voor Meta', formats: ['meta-sq', 'meta-45', 'meta-story'], color: '#FFFFFF', logos: ['Facebook', 'Instagram'] },
  { key: 'google-set', name: 'Google bannerset', description: '7 IAB-formaten, HTML5 of GIF', formats: ['g-300x250', 'g-336x280', 'g-728x90', 'g-300x600', 'g-160x600', 'g-320x50', 'g-970x250'], color: '#EA5F39', logos: ['Google Display'] },
  { key: 'li-set', name: 'LinkedIn set', description: 'Liggend, vierkant en staand', formats: ['li-land', 'li-sq', 'li-vert'], color: '#1A5FC4', logos: ['LinkedIn'] },
  { key: 'pmax-set', name: 'Demand Gen en PMax', description: 'Liggend, vierkant en staand', formats: ['dg-land', 'dg-sq', 'dg-port'], color: '#A2D6ED', logos: ['Google Ads', 'YouTube'] },
  { key: 'ig-post', name: 'Instagram post', description: '1080 × 1080', formats: ['meta-sq'], color: '#E6A4FF', logos: ['Instagram', 'Facebook'] },
  { key: 'story', name: 'Story of Reel', description: '1080 × 1920', formats: ['meta-story'], color: '#EA5F39', logos: ['Instagram', 'Facebook', 'TikTok'] },
]
