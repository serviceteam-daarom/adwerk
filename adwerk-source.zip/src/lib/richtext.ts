/**
 * Opmaak binnen één tekstvak. `el.runs` is een lijst stukjes tekst die samen precies `el.text` vormen,
 * elk met eigen opmaak: b (vet), i (cursief), u (onderstreept), c (kleur). Ontbreekt een eigenschap,
 * dan geldt die van het tekstvak zelf.
 */
export type Run = { t: string; b?: 1 | 0; i?: 1 | 0; u?: 1 | 0; c?: string }
export type RunStyle = Omit<Run, 't'>
export type StylePatch = { b?: boolean | null; i?: boolean | null; u?: boolean | null; c?: string | null }

const same = (a: RunStyle, b: RunStyle) => a.b === b.b && a.i === b.i && a.u === b.u && (a.c || '') === (b.c || '')
const styleOf = (r: Run): RunStyle => { const s: RunStyle = {}; if (r.b !== undefined) s.b = r.b; if (r.i !== undefined) s.i = r.i; if (r.u !== undefined) s.u = r.u; if (r.c) s.c = r.c; return s }
const plain = (s: RunStyle) => s.b === undefined && s.i === undefined && s.u === undefined && !s.c

/** Lege stukjes weg, gelijke buren samenvoegen. Geeft undefined als er geen opmaak meer over is. */
export function normalizeRuns(runs: Run[] | undefined): Run[] | undefined {
  if (!runs?.length) return undefined
  const out: Run[] = []
  for (const r of runs) {
    if (!r.t) continue
    const last = out[out.length - 1]
    if (last && same(styleOf(last), styleOf(r))) last.t += r.t
    else out.push({ t: r.t, ...styleOf(r) })
  }
  if (!out.length || out.every((r) => plain(styleOf(r)))) return undefined
  return out
}

/** Per teken de opmaak (handig voor bewerkingen op posities). */
function perChar(text: string, runs?: Run[]): RunStyle[] {
  const out: RunStyle[] = []
  if (runs) for (const r of runs) for (let k = 0; k < r.t.length; k++) out.push(styleOf(r))
  while (out.length < text.length) out.push({})
  return out.slice(0, text.length)
}
function fromChars(text: string, st: RunStyle[]): Run[] | undefined {
  return normalizeRuns(text.split('').map((ch, k) => ({ t: ch, ...st[k] })))
}

/** Nieuwe tekst, oude opmaak: wat gelijk bleef aan begin en eind houdt zijn opmaak, ingetypte tekst neemt die van het teken ervoor over. */
export function remapRuns(oldText: string, newText: string, runs?: Run[]): Run[] | undefined {
  if (!runs || oldText === newText) return runs
  const st = perChar(oldText, runs)
  let p = 0
  while (p < oldText.length && p < newText.length && oldText[p] === newText[p]) p++
  let s = 0
  while (s < oldText.length - p && s < newText.length - p && oldText[oldText.length - 1 - s] === newText[newText.length - 1 - s]) s++
  const inserted = newText.length - p - s
  const inherit = st[p - 1] || st[p] || {}
  const next = [...st.slice(0, p), ...Array(inserted).fill(inherit), ...st.slice(oldText.length - s)]
  return fromChars(newText, next)
}

/** Opmaak toepassen op tekens start..end. null in de patch haalt die eigenschap weg (terug naar het tekstvak). */
export function applyStyle(text: string, runs: Run[] | undefined, start: number, end: number, patch: StylePatch): Run[] | undefined {
  const st = perChar(text, runs).map((s, k) => {
    if (k < start || k >= end) return s
    const n = { ...s }
    for (const key of ['b', 'i', 'u'] as const) if (key in patch) { const v = patch[key]; if (v === null || v === undefined) delete n[key]; else n[key] = v ? 1 : 0 }
    if ('c' in patch) { if (patch.c) n.c = patch.c; else delete n.c }
    return n
  })
  return fromChars(text, st)
}

/** Effectieve opmaak van een selectie: true/false als alles gelijk is, anders 'mixed'. */
export function styleRange(text: string, runs: Run[] | undefined, start: number, end: number, base: { b: boolean; i: boolean; u: boolean; c: string }) {
  const st = perChar(text, runs)
  const range = end > start ? st.slice(start, end) : [st[Math.max(0, start - 1)] || {}]
  const eff = range.map((s) => ({ b: s.b === undefined ? base.b : !!s.b, i: s.i === undefined ? base.i : !!s.i, u: s.u === undefined ? base.u : !!s.u, c: s.c || base.c }))
  const pick = <K extends 'b' | 'i' | 'u' | 'c'>(k: K) => (eff.every((e) => e[k] === eff[0][k]) ? eff[0][k] : 'mixed')
  return { b: pick('b'), i: pick('i'), u: pick('u'), c: pick('c') }
}

/** Stukjes met opmaak voor de renderer, ook als er geen runs zijn (dan één stuk). */
export function segments(text: string, runs?: Run[]): Run[] {
  if (!runs?.length) return [{ t: text }]
  const joined = runs.map((r) => r.t).join('')
  return joined === text ? runs : remapRuns(joined, text, runs) || [{ t: text }]
}

export const isBold = (baseWeight: number, r: RunStyle) => (r.b === undefined ? baseWeight >= 600 : !!r.b)
export const runWeight = (baseWeight: number, r: RunStyle) => (r.b === undefined ? baseWeight : r.b ? Math.min(900, Math.max(700, baseWeight + 200)) : Math.min(baseWeight, 400))
