import { normalizeSvg } from './svg'
import { supabase, SUPABASE_URL, SUPABASE_KEY } from './supabase'
import type { Asset, BrandKit, DesignDoc, DesignRow, Folder, Profile } from './types'

const LIST_COLS = 'id,title,owner_id,folder_id,visibility,is_template,thumbnail,updated_at,created_at,updated_by,status,status_at,start_date,end_date'

export async function getProfile(id: string) {
  const { data } = await supabase.from('profiles').select('*').eq('id', id).maybeSingle()
  return data as Profile | null
}
export async function listProfiles() {
  const { data } = await supabase.from('profiles').select('*').order('full_name')
  return (data || []) as Profile[]
}

export async function listDesigns(filter: { scope: 'mine' | 'team' | 'recent' | 'templates' | 'folder'; userId: string; folderId?: string }) {
  let q = supabase.from('designs').select(LIST_COLS).order('updated_at', { ascending: false }).limit(200)
  if (filter.scope === 'mine') q = q.eq('owner_id', filter.userId).eq('is_template', false)
  if (filter.scope === 'team') q = q.neq('owner_id', filter.userId).eq('is_template', false)
  if (filter.scope === 'recent') q = q.eq('is_template', false).limit(24)
  if (filter.scope === 'templates') q = q.eq('is_template', true)
  if (filter.scope === 'folder' && filter.folderId) q = q.eq('folder_id', filter.folderId)
  const { data, error } = await q
  if (error) throw error
  return (data || []) as Omit<DesignRow, 'data'>[]
}

export async function getDesign(id: string) {
  const { data, error } = await supabase.from('designs').select('*').eq('id', id).single()
  if (error) throw error
  return data as DesignRow
}

export async function createDesign(title: string, doc: DesignDoc, extra: Partial<DesignRow> = {}) {
  const { data, error } = await supabase.from('designs').insert({ title, data: doc, ...extra }).select('id').single()
  if (error) throw error
  return data.id as string
}

export async function saveDesign(id: string, patch: Partial<DesignRow>, userId: string) {
  const { error } = await supabase.from('designs').update({ ...patch, updated_at: new Date().toISOString(), updated_by: userId }).eq('id', id)
  if (error) throw error
}

export async function deleteDesign(id: string) {
  const { error } = await supabase.from('designs').delete().eq('id', id)
  if (error) throw error
}

export async function duplicateDesign(id: string) {
  const d = await getDesign(id)
  return createDesign(`${d.title} (kopie)`, d.data, { folder_id: d.folder_id, visibility: d.visibility, thumbnail: d.thumbnail })
}

export async function listFolders() {
  const { data } = await supabase.from('folders').select('*').order('name')
  return (data || []) as Folder[]
}
export async function createFolder(name: string, visibility: 'private' | 'team') {
  const { data, error } = await supabase.from('folders').insert({ name, visibility }).select('*').single()
  if (error) throw error
  return data as Folder
}
export async function updateFolder(id: string, patch: Partial<Folder>) {
  const { error } = await supabase.from('folders').update({ ...patch, updated_at: new Date().toISOString() }).eq('id', id)
  if (error) throw new Error('Project bijwerken lukt niet')
}
/** Persoonlijk vastgezette projecten (alleen voor jezelf zichtbaar). Valt terug op dit apparaat als de tabel er nog niet is. */
const PIN_KEY = 'adwerk-pins'
const localPins = (): string[] => { try { return JSON.parse(localStorage.getItem(PIN_KEY) || '[]') } catch { return [] } }
export async function listPins(userId: string): Promise<string[]> {
  const { data, error } = await supabase.from('folder_pins').select('folder_id,position').eq('user_id', userId).order('position').order('created_at')
  if (error) return localPins()
  const ids = (data || []).map((r: { folder_id: string }) => r.folder_id)
  try { localStorage.setItem(PIN_KEY, JSON.stringify(ids)) } catch { /* */ }
  return ids
}
export async function setPin(userId: string, folderId: string, pinned: boolean, position = 0) {
  try { const l = localPins().filter((x) => x !== folderId); localStorage.setItem(PIN_KEY, JSON.stringify(pinned ? [...l, folderId] : l)) } catch { /* */ }
  const q = pinned ? supabase.from('folder_pins').upsert({ user_id: userId, folder_id: folderId, position }) : supabase.from('folder_pins').delete().eq('user_id', userId).eq('folder_id', folderId)
  await q
}
export async function deleteFolder(id: string) {
  await supabase.from('folders').delete().eq('id', id)
}

export async function getMembers(designId: string) {
  const { data } = await supabase.from('design_members').select('user_id').eq('design_id', designId)
  return (data || []).map((r: { user_id: string }) => r.user_id)
}
export async function addMember(designId: string, userId: string) {
  await supabase.from('design_members').upsert({ design_id: designId, user_id: userId })
}
export async function removeMember(designId: string, userId: string) {
  await supabase.from('design_members').delete().eq('design_id', designId).eq('user_id', userId)
}

export async function listKits() {
  const { data } = await supabase.from('brand_kits').select('*').order('name')
  return (data || []) as BrandKit[]
}
export async function saveKit(kit: Partial<BrandKit>) {
  if (kit.id) {
    const { error } = await supabase.from('brand_kits').update({ name: kit.name, colors: kit.colors, fonts: kit.fonts, logos: kit.logos }).eq('id', kit.id)
    if (error) throw error
    return kit.id
  }
  const { data, error } = await supabase.from('brand_kits').insert({ name: kit.name, colors: kit.colors || [], fonts: kit.fonts || [], logos: kit.logos || [] }).select('id').single()
  if (error) throw error
  return data.id as string
}
export async function deleteKit(id: string) {
  await supabase.from('brand_kits').delete().eq('id', id)
}

function imageSize(file: File): Promise<{ width: number; height: number }> {
  return new Promise((resolve) => {
    const url = URL.createObjectURL(file)
    const img = new Image()
    img.onload = () => { resolve({ width: img.naturalWidth, height: img.naturalHeight }); URL.revokeObjectURL(url) }
    img.onerror = () => resolve({ width: 0, height: 0 })
    img.src = url
  })
}

export async function uploadAsset(file: File, userId: string, shared = false) {
  // svg's opschonen en een vaste maat geven, zodat ze overal goed tekenen
  if (file.type === 'image/svg+xml' || /\.svg$/i.test(file.name)) {
    const n = normalizeSvg(await file.text())
    if (!n) throw new Error('Dit svg-bestand kan niet worden gelezen')
    file = new File([n.svg], file.name.replace(/\.svg$/i, '') + '.svg', { type: 'image/svg+xml' })
  }
  const ext = (file.name.split('.').pop() || 'png').toLowerCase()
  const path = `${userId}/${crypto.randomUUID()}.${ext}`
  const { error } = await supabase.storage.from('assets').upload(path, file, { contentType: file.type, cacheControl: '31536000' })
  if (error) throw error
  const { data } = supabase.storage.from('assets').getPublicUrl(path)
  const size = await imageSize(file)
  const { data: row, error: e2 } = await supabase.from('assets').insert({ url: data.publicUrl, path, name: file.name, width: size.width, height: size.height, shared }).select('*').single()
  if (e2) throw e2
  return row as Asset
}

export async function listAssets(userId: string, scope: 'mine' | 'shared') {
  let q = supabase.from('assets').select('*').order('created_at', { ascending: false }).limit(200)
  q = scope === 'mine' ? q.eq('owner_id', userId) : q.eq('shared', true)
  const { data } = await q
  return (data || []) as Asset[]
}
export async function deleteAsset(a: Asset) {
  await supabase.storage.from('assets').remove([a.path])
  await supabase.from('assets').delete().eq('id', a.id)
}
export async function shareAsset(id: string, shared: boolean) {
  await supabase.from('assets').update({ shared }).eq('id', id)
}

/* ---------- Merkset vanaf website (Supabase Edge Function brand-scan) ---------- */
export interface BrandScan { url: string; name: string; title: string; themeColor: string; brandColors: { hex: string; score: number }[]; neutralColors: { hex: string; score: number }[]; fonts: string[]; logos: { url?: string; svg?: string; source: string; score: number }[]; images: string[] }

export async function scanBrand(url: string): Promise<BrandScan> {
  const { data, error } = await supabase.functions.invoke('brand-scan', { body: { url } })
  if (error) throw new Error('Scannen lukt niet. Controleer de URL of probeer het later opnieuw.')
  if ((data as { error?: string }).error) throw new Error((data as { error: string }).error)
  return data as BrandScan
}

/** Haalt een beeld van een andere site op via de proxy en zet het in de opslag van Adwerk. */
export async function importRemoteImage(url: string, userId: string, name: string, shared = true): Promise<Asset> {
  const { data: s } = await supabase.auth.getSession()
  const r = await fetch(`${SUPABASE_URL}/functions/v1/brand-scan`, {
    method: 'POST', headers: { 'Content-Type': 'application/json', apikey: SUPABASE_KEY, Authorization: `Bearer ${s.session?.access_token}` }, body: JSON.stringify({ proxy: url }),
  })
  if (!r.ok) throw new Error('Beeld kon niet worden opgehaald')
  const blob = await r.blob()
  const ext = (blob.type.split('/')[1] || 'png').replace('svg+xml', 'svg').replace('jpeg', 'jpg').replace('x-icon', 'ico').replace('vnd.microsoft.icon', 'ico')
  return uploadAsset(new File([blob], `${name}.${ext}`, { type: blob.type }), userId, shared)
}

export async function importSvg(svg: string, userId: string, name: string, shared = true): Promise<Asset> {
  return uploadAsset(new File([svg], `${name}.svg`, { type: 'image/svg+xml' }), userId, shared)
}
