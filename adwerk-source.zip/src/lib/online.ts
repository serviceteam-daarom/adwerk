import { create } from 'zustand'
import type { RealtimeChannel } from '@supabase/supabase-js'
import { supabase } from './supabase'

export interface OnlineUser { id: string; name: string; color: string; avatar?: string | null; designId?: string | null; designTitle?: string | null; since: number }

interface OnlineState { users: OnlineUser[] }
export const useOnline = create<OnlineState>(() => ({ users: [] }))

let ch: RealtimeChannel | null = null
let me: Omit<OnlineUser, 'since' | 'designId' | 'designTitle'> | null = null
let where: { designId: string | null; designTitle: string | null } = { designId: null, designTitle: null }
const since = Date.now()

/** Teambrede aanwezigheid: wie is er nu in Adwerk en in welk ontwerp. */
export function startOnline(user: Omit<OnlineUser, 'since' | 'designId' | 'designTitle'>) {
  if (ch) return
  me = user
  ch = supabase.channel('adwerk-online', { config: { presence: { key: user.id + ':' + Math.random().toString(36).slice(2, 7) } } })
  ch.on('presence', { event: 'sync' }, () => {
    const state = ch!.presenceState() as unknown as Record<string, OnlineUser[]>
    // per persoon één regel (meerdere tabbladen samenvoegen)
    const byId = new Map<string, OnlineUser>()
    for (const metas of Object.values(state)) for (const m of metas) {
      const cur = byId.get(m.id)
      if (!cur || (m.designId && !cur.designId)) byId.set(m.id, m)
    }
    useOnline.setState({ users: [...byId.values()].sort((a, b) => a.name.localeCompare(b.name)) })
  })
  ch.subscribe((s) => { if (s === 'SUBSCRIBED') push() })
}

document.addEventListener('visibilitychange', () => { if (document.visibilityState === 'visible') push() })

function push() {
  if (ch && me) ch.track({ ...me, ...where, since })
}

export function setWhere(designId: string | null, designTitle: string | null) {
  where = { designId, designTitle }
  push()
}

export function stopOnline() {
  if (ch) supabase.removeChannel(ch)
  ch = null
  useOnline.setState({ users: [] })
}
