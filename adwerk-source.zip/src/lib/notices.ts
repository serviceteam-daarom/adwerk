import { create } from 'zustand'

/** Korte meldingen rechtsboven (bijv. nieuwe feedback). Verdwijnen vanzelf na een paar seconden. */
export interface Notice { id: string; title: string; body?: string; tone?: 'team' | 'client' | 'info'; action?: { label: string; run: () => void }; leaving?: boolean }
export const useNotices = create<{ list: Notice[] }>(() => ({ list: [] }))

export function dismissNotice(id: string) {
  useNotices.setState((s) => ({ list: s.list.map((n) => (n.id === id ? { ...n, leaving: true } : n)) }))
  setTimeout(() => useNotices.setState((s) => ({ list: s.list.filter((n) => n.id !== id) })), 200)
}
export function notice(n: Omit<Notice, 'id'>, ms = 7000) {
  const id = Math.random().toString(36).slice(2)
  useNotices.setState((s) => ({ list: [...s.list.slice(-3), { ...n, id }] }))
  setTimeout(() => dismissNotice(id), ms)
  return id
}
