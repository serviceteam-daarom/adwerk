import { create } from 'zustand'
import type { RealtimeChannel } from '@supabase/supabase-js'
import { supabase } from './supabase'
import { notice } from './notices'

export interface CommentAuthor { id?: string; name: string; avatar?: string | null; color?: string | null; team: boolean }
export interface Comment {
  id: string; design_id?: string; frame_id: string | null; x: number | null; y: number | null; parent_id: string | null
  body: string; resolved: boolean; created_at: string; author_id?: string | null; guest_name?: string | null; author?: CommentAuthor
}

interface CommentsState {
  designId: string | null
  list: Comment[]
  mode: boolean              // reageer-modus: klik op het canvas om een punt te plaatsen
  panel: boolean
  active: string | null      // geopende draad
  draft: { frame_id: string; x: number; y: number } | null
  showResolved: boolean
}
export const useComments = create<CommentsState>(() => ({ designId: null, list: [], mode: false, panel: false, active: null, draft: null, showResolved: false }))

let ch: RealtimeChannel | null = null
let me: { id: string; name: string } | null = null
let profiles: Record<string, { full_name: string; email: string; avatar_url: string | null; color: string | null }> = {}

const authorOf = (c: Comment): CommentAuthor => {
  if (c.author) return c.author
  if (c.author_id) { const p = profiles[c.author_id]; return { id: c.author_id, name: p?.full_name || p?.email?.split('@')[0] || 'Collega', avatar: p?.avatar_url, color: p?.color, team: true } }
  return { name: c.guest_name || 'Gast', team: false }
}
const upsert = (c: Comment) => useComments.setState((s) => {
  const withAuthor = { ...c, author: authorOf(c) }
  const i = s.list.findIndex((x) => x.id === c.id)
  const list = i >= 0 ? s.list.map((x) => (x.id === c.id ? withAuthor : x)) : [...s.list, withAuthor]
  return { list: list.sort((a, b) => a.created_at.localeCompare(b.created_at)) }
})

export async function startComments(designId: string, user: { id: string; name: string }) {
  stopComments()
  me = user
  useComments.setState({ designId, list: [], active: null, draft: null, mode: false })
  const [{ data }, { data: profs }] = await Promise.all([
    supabase.from('comments').select('*').eq('design_id', designId).order('created_at'),
    supabase.from('profiles').select('id,full_name,email,avatar_url,color'),
  ])
  profiles = Object.fromEntries(((profs || []) as { id: string; full_name: string; email: string; avatar_url: string | null; color: string | null }[]).map((p) => [p.id, p]))
  useComments.setState({ list: ((data || []) as Comment[]).map((c) => ({ ...c, author: authorOf(c) })) })
  ch = supabase.channel(`comments:${designId}`)
    .on('broadcast', { event: 'comment' }, ({ payload }) => {
      const c = payload as Comment
      const isNew = !useComments.getState().list.some((x) => x.id === c.id)
      upsert(c)
      if (isNew && c.author_id !== me?.id) notice({ title: `${authorOf(c).name} ${c.parent_id ? 'reageerde' : 'gaf feedback'}`, body: c.body, tone: authorOf(c).team ? 'team' : 'client', action: { label: 'Bekijken', run: () => openThread(c.parent_id || c.id) } })
    })
    .on('broadcast', { event: 'update' }, ({ payload }) => upsert(payload as Comment))
    .on('broadcast', { event: 'delete' }, ({ payload }) => useComments.setState((s) => ({ list: s.list.filter((x) => x.id !== (payload as { id: string }).id && x.parent_id !== (payload as { id: string }).id) })))
    .subscribe()
}
export function stopComments() {
  if (ch) supabase.removeChannel(ch)
  ch = null
  useComments.setState({ designId: null, list: [], mode: false, panel: false, active: null, draft: null })
}

export function openThread(id: string) { useComments.setState({ active: id, panel: true, draft: null }) }
export const setCommentMode = (on: boolean) => useComments.setState({ mode: on, draft: on ? useComments.getState().draft : null, ...(on ? { panel: true } : {}) })

export async function addComment(p: { frame_id: string | null; x?: number | null; y?: number | null; body: string; parent_id?: string | null }) {
  const designId = useComments.getState().designId
  if (!designId || !me) return
  const { data, error } = await supabase.from('comments').insert({ design_id: designId, frame_id: p.frame_id, x: p.x ?? null, y: p.y ?? null, body: p.body.trim(), parent_id: p.parent_id || null, author_id: me.id }).select('*').single()
  if (error) throw new Error('Opmerking plaatsen lukt niet')
  const c = data as Comment
  upsert(c)
  ch?.send({ type: 'broadcast', event: 'comment', payload: c })
  return c
}
export async function setResolved(id: string, resolved: boolean) {
  const { data } = await supabase.from('comments').update({ resolved, resolved_by: resolved ? me?.id : null, updated_at: new Date().toISOString() }).eq('id', id).select('*').single()
  if (data) { upsert(data as Comment); ch?.send({ type: 'broadcast', event: 'update', payload: data }) }
}
export async function deleteComment(id: string) {
  await supabase.from('comments').delete().eq('id', id)
  useComments.setState((s) => ({ list: s.list.filter((x) => x.id !== id && x.parent_id !== id), active: s.active === id ? null : s.active }))
  ch?.send({ type: 'broadcast', event: 'delete', payload: { id } })
}

/* ---------- deellinks voor klanten ---------- */
export interface ShareLink { id: string; token: string; can_comment: boolean; label: string | null; created_at: string; revoked: boolean; last_used_at: string | null }
export const reviewUrl = (token: string) => `${location.origin}${location.pathname}#/review/${token}`
export async function listLinks(designId: string) {
  const { data } = await supabase.from('share_links').select('*').eq('design_id', designId).eq('revoked', false).order('created_at', { ascending: false })
  return (data || []) as ShareLink[]
}
export async function createLink(designId: string, label: string, canComment = true) {
  const abc = 'ABCDEFGHJKLMNPQRSTUVWXYZabcdefghijkmnopqrstuvwxyz23456789'
  const token = [...crypto.getRandomValues(new Uint8Array(32))].map((x) => abc[x % abc.length]).join('')
  const { data, error } = await supabase.from('share_links').insert({ design_id: designId, token, label: label || null, can_comment: canComment }).select('*').single()
  if (error) throw new Error('Link maken lukt niet')
  return data as ShareLink
}
export async function updateLink(id: string, patch: Partial<ShareLink>) { await supabase.from('share_links').update(patch).eq('id', id) }
