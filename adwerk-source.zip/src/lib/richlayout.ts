import type { El } from './types'
import { segments, runWeight, type Run } from './richtext'

/** Eén stukje tekst op een regel, met zijn eigen opmaak en x-positie. */
export type Piece = { t: string; x: number; w: number; weight: number; italic: boolean; underline: boolean; color: string }
export type Line = { pieces: Piece[]; width: number }
export type RichLayout = { lines: Line[]; fontSize: number; lineHeight: number; height: number }

type Measure = (text: string, weight: number, italic: boolean, size: number) => number
type Tok = { kind: 'word' | 'space' | 'nl'; parts: { t: string; r: Run }[] }

function tokens(text: string, runs?: Run[]): Tok[] {
  const out: Tok[] = []
  for (const r of segments(text, runs)) {
    for (const m of r.t.match(/\n| +|[^ \n]+/g) || []) {
      const kind = m === '\n' ? 'nl' : m[0] === ' ' ? 'space' : 'word'
      const last = out[out.length - 1]
      // een woord dat over twee opmaakstukjes loopt (half vet) blijft één woord bij het afbreken
      if (kind === 'word' && last?.kind === 'word') last.parts.push({ t: m, r })
      else out.push({ kind, parts: [{ t: m, r }] })
    }
  }
  return out
}

/** Regels en posities voor tekst met opmaak per stukje, op dezelfde manier als Konva.Text (woordafbreking, uitlijning, verkleinen). */
export function layoutRich(el: El, measure: Measure, opts: { nearest?: (w: number) => number } = {}): RichLayout {
  const base = el.fontWeight || 400
  const W = el.width
  const ls = el.letterSpacing || 0
  const up = (s: string) => (el.uppercase ? s.toUpperCase() : s)
  const nearest = opts.nearest || ((w: number) => w)
  const toks = tokens(el.text || '', el.runs)
  const styleOf = (r: Run) => ({ weight: nearest(runWeight(base, r)), italic: r.i === undefined ? !!el.italic : !!r.i, underline: r.u === undefined ? !!el.underline : !!r.u, color: r.c || el.fill })
  const width = (t: string, r: Run, size: number) => { const s = styleOf(r); return measure(up(t), s.weight, s.italic, size) + ls * t.length }
  const tokW = (k: Tok, size: number) => k.parts.reduce((a, p) => a + width(p.t, p.r, size), 0)

  let size = el.fontSize || 24
  const widest = Math.max(0, ...toks.filter((k) => k.kind === 'word').map((k) => tokW(k, size)))
  if (widest > W && W > 0) size = Math.max(4, size * (W / widest) * 0.98)

  const lines: Line[] = []
  let cur: Line = { pieces: [], width: 0 }
  let pendingSpace: Tok | null = null
  const push = (k: Tok) => {
    for (const p of k.parts) {
      const w = width(p.t, p.r, size)
      cur.pieces.push({ t: up(p.t), x: cur.width, w, ...styleOf(p.r) })
      cur.width += w
    }
  }
  const breakLine = () => { lines.push(cur); cur = { pieces: [], width: 0 }; pendingSpace = null }
  for (const k of toks) {
    if (k.kind === 'nl') { breakLine(); continue }
    if (k.kind === 'space') { if (cur.pieces.length) pendingSpace = k; continue }
    const ww = tokW(k, size)
    const sw = pendingSpace ? tokW(pendingSpace, size) : 0
    if (cur.pieces.length && cur.width + sw + ww > W + 0.5) breakLine()
    else if (pendingSpace) push(pendingSpace)
    pendingSpace = null
    push(k)
  }
  lines.push(cur)
  const lh = size * (el.lineHeight || 1.2)
  return { lines, fontSize: size, lineHeight: lh, height: lines.length * lh }
}
