import {
  ArrowRight, ArrowLeft, ArrowUp, ArrowDown, ArrowUpRight, ChevronRight, Check, CheckCircle2, X, Plus, Star, Heart, ThumbsUp,
  ShoppingCart, ShoppingBag, Tag, Percent, Gift, Truck, Package, CreditCard, Euro, Phone, Mail, MapPin, Clock, Calendar,
  Zap, Sparkles, Flame, Sun, Leaf, Home, Building2, Briefcase, Users, User, Award, Trophy, Target, TrendingUp, BarChart3,
  Rocket, Lightbulb, Shield, Lock, Bell, Camera, Play, Music, Wifi, Smartphone, Laptop, Car, Bike, Coffee, Utensils, Wrench,
  Hammer, Paintbrush, Scissors, Megaphone, MessageCircle, Search, Globe, Download, Send, Info, AlertCircle, Smile, Sofa, Bed, Lamp,
} from 'lucide'

type Node = [string, Record<string, string | number>, Node[]?]

export const ICONS: Record<string, unknown> = {
  'arrow-right': ArrowRight, 'arrow-left': ArrowLeft, 'arrow-up': ArrowUp, 'arrow-down': ArrowDown, 'arrow-up-right': ArrowUpRight,
  'chevron-right': ChevronRight, check: Check, 'check-circle': CheckCircle2, x: X, plus: Plus, star: Star, heart: Heart,
  'thumbs-up': ThumbsUp, cart: ShoppingCart, bag: ShoppingBag, tag: Tag, percent: Percent, gift: Gift, truck: Truck, package: Package,
  card: CreditCard, euro: Euro, phone: Phone, mail: Mail, 'map-pin': MapPin, clock: Clock, calendar: Calendar, zap: Zap,
  sparkles: Sparkles, flame: Flame, sun: Sun, leaf: Leaf, home: Home, building: Building2, briefcase: Briefcase, users: Users,
  user: User, award: Award, trophy: Trophy, target: Target, trending: TrendingUp, chart: BarChart3, rocket: Rocket, lightbulb: Lightbulb,
  shield: Shield, lock: Lock, bell: Bell, camera: Camera, play: Play, music: Music, wifi: Wifi, smartphone: Smartphone, laptop: Laptop,
  car: Car, bike: Bike, coffee: Coffee, utensils: Utensils, wrench: Wrench, hammer: Hammer, paintbrush: Paintbrush, scissors: Scissors,
  megaphone: Megaphone, message: MessageCircle, search: Search, globe: Globe, download: Download, send: Send, info: Info,
  alert: AlertCircle, smile: Smile, sofa: Sofa, bed: Bed, lamp: Lamp,
}

function nodeToString(n: Node): string {
  const [tag, attrs, children] = n
  const a = Object.entries(attrs).map(([k, v]) => `${k}="${v}"`).join(' ')
  const inner = (children || []).map(nodeToString).join('')
  return `<${tag} ${a}>${inner}</${tag}>`
}

export function iconSvg(name: string, color: string, strokeWidth = 2, size = 24) {
  const node = ICONS[name] as Node | undefined
  if (!node) return ''
  const [, attrs, children] = node
  const at = { ...attrs, width: size, height: size, stroke: color, 'stroke-width': strokeWidth }
  return nodeToString(['svg', at, children])
}

export function iconDataUrl(name: string, color: string, strokeWidth = 2, size = 256) {
  return 'data:image/svg+xml;charset=utf-8,' + encodeURIComponent(iconSvg(name, color, strokeWidth, size))
}
