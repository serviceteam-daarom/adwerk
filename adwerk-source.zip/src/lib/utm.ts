/** UTM-links bouwen: vaste namen, kleine letters, geen spaties. */
export const UTM_KEYS = ['utm_source', 'utm_medium', 'utm_campaign', 'utm_content', 'utm_term'] as const
export type Utm = Partial<Record<(typeof UTM_KEYS)[number], string>>

export const UTM_PRESETS: { key: string; label: string; utm: Utm; hint: string }[] = [
  { key: 'meta-dyn', label: 'Meta dynamisch', hint: 'Meta vult bron, campagne en advertentie zelf in', utm: { utm_source: '{{site_source_name}}', utm_medium: 'paid_social', utm_campaign: '{{campaign.name}}', utm_content: '{{ad.name}}', utm_term: '{{adset.name}}' } },
  { key: 'meta', label: 'Meta vast', hint: 'Vaste waarden voor Facebook en Instagram', utm: { utm_source: 'facebook', utm_medium: 'paid_social' } },
  { key: 'linkedin', label: 'LinkedIn Ads', hint: 'Betaalde LinkedIn-campagne', utm: { utm_source: 'linkedin', utm_medium: 'paid_social' } },
  { key: 'organic', label: 'Organisch', hint: 'Posts zonder budget', utm: { utm_source: 'instagram', utm_medium: 'social' } },
  { key: 'display', label: 'Google Display', hint: 'Bannerset in Google Ads', utm: { utm_source: 'google', utm_medium: 'display' } },
]
export const SOURCES = ['facebook', 'instagram', 'linkedin', 'tiktok', 'pinterest', 'google', 'newsletter', '{{site_source_name}}']
export const MEDIUMS = ['paid_social', 'social', 'cpc', 'display', 'email', 'referral']

/** Waarde netjes maken: kleine letters, spaties en rare tekens worden een liggend streepje. Dynamische {{...}} blijft staan. */
export const cleanUtm = (v: string) => (/^\{\{.*\}\}$/.test(v.trim()) ? v.trim() : v.trim().toLowerCase().normalize('NFD').replace(/[̀-ͯ]/g, '').replace(/[^a-z0-9._{}-]+/g, '_').replace(/^_+|_+$/g, ''))
export const slugify = (v: string) => cleanUtm(v).replace(/_+/g, '_')

export function buildUtmUrl(base: string, utm: Utm) {
  if (!base.trim()) return ''
  let u: URL
  try { u = new URL(/^https?:\/\//.test(base.trim()) ? base.trim() : 'https://' + base.trim()) } catch { return '' }
  for (const k of UTM_KEYS) u.searchParams.delete(k)
  for (const k of UTM_KEYS) { const v = utm[k] && cleanUtm(utm[k]!); if (v) u.searchParams.set(k, v) }
  // {{ }} niet laten coderen, zodat Meta ze kan invullen
  return u.toString().replace(/%7B%7B/g, '{{').replace(/%7D%7D/g, '}}')
}
