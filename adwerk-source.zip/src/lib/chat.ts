import { create } from 'zustand'
import type { RealtimeChannel } from '@supabase/supabase-js'
import { supabase } from './supabase'
import type { Profile } from './types'

export interface Message {
  id: string; sender_id: string; recipient_id: string | null; body: string
  kind: 'text' | 'help'; design_id: string | null; design_title: string | null; created_at: string
}
export interface ChatToast { id: string; msg: Message }

/** Gesprek: 'team' of het id van een collega. */
export type Thread = string

interface ChatState {
  me: string | null
  messages: Message[]
  profiles: Record<string, Profile>
  open: boolean
  thread: Thread | null
  read: Record<string, string>
  toasts: ChatToast[]
  notifyPerm: NotificationPermission | 'unsupported'
}

const READ_KEY = 'adwerk.chat.read'
const loadRead = (): Record<string, string> => { try { return JSON.parse(localStorage.getItem(READ_KEY) || '{}') } catch { return {} } }

export const useChat = create<ChatState>(() => ({
  me: null, messages: [], profiles: {}, open: false, thread: null, read: loadRead(), toasts: [],
  notifyPerm: typeof Notification === 'undefined' ? 'unsupported' : Notification.permission,
}))

export const threadOf = (m: Message, me: string): Thread => (m.recipient_id === null ? 'team' : m.sender_id === me ? m.recipient_id : m.sender_id)

export function unreadCount(thread?: Thread) {
  const { messages, read, me } = useChat.getState()
  if (!me) return 0
  return messages.filter((m) => m.sender_id !== me && (!thread || threadOf(m, me) === thread) && m.created_at > (read[threadOf(m, me)] || '')).length
}

export function markRead(thread: Thread) {
  const s = useChat.getState()
  const last = s.messages.filter((m) => s.me && threadOf(m, s.me) === thread).slice(-1)[0]?.created_at || new Date().toISOString()
  const read = { ...s.read, [thread]: last }
  try { localStorage.setItem(READ_KEY, JSON.stringify(read)) } catch { /* privémodus */ }
  useChat.setState({ read })
}

export function openChat(thread: Thread | null = null) {
  useChat.setState({ open: true, thread })
  if (thread) markRead(thread)
}
export const closeChat = () => useChat.setState({ open: false })

let ch: RealtimeChannel | null = null

function beep() {
  try {
    const Ctx = window.AudioContext || (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext
    const ctx = new Ctx(), o = ctx.createOscillator(), g = ctx.createGain()
    o.type = 'sine'; o.frequency.setValueAtTime(880, ctx.currentTime); o.frequency.setValueAtTime(1320, ctx.currentTime + 0.09)
    g.gain.setValueAtTime(0.0001, ctx.currentTime); g.gain.exponentialRampToValueAtTime(0.08, ctx.currentTime + 0.02); g.gain.exponentialRampToValueAtTime(0.0001, ctx.currentTime + 0.32)
    o.connect(g).connect(ctx.destination); o.start(); o.stop(ctx.currentTime + 0.34)
  } catch { /* geen geluid */ }
}

export const nameOf = (id: string) => {
  const p = useChat.getState().profiles[id]
  return p?.full_name || p?.email?.split('@')[0] || 'Collega'
}

function notify(m: Message) {
  const s = useChat.getState()
  const thread = threadOf(m, s.me!)
  const watching = s.open && s.thread === thread && document.visibilityState === 'visible'
  if (watching) { markRead(thread); return }
  beep()
  useChat.setState({ toasts: [...s.toasts.filter((t) => t.msg.id !== m.id), { id: m.id, msg: m }].slice(-4) })
  if (m.kind !== 'help') setTimeout(() => dismissToast(m.id), 7000)
  if (document.visibilityState !== 'visible' && s.notifyPerm === 'granted') {
    const title = m.kind === 'help' ? `${nameOf(m.sender_id)} vraagt om hulp` : thread === 'team' ? `${nameOf(m.sender_id)} in Team` : nameOf(m.sender_id)
    try {
      const n = new Notification(title, { body: m.kind === 'help' ? `${m.design_title || 'Een ontwerp'}: ${m.body}` : m.body, icon: './adwerk-icon-192.png', tag: m.id })
      n.onclick = () => { window.focus(); openChat(thread); n.close() }
    } catch { /* niet ondersteund */ }
  }
}
export const dismissToast = (id: string) => useChat.setState((s) => ({ toasts: s.toasts.filter((t) => t.id !== id) }))

let started: string | null = null
export async function startChat(me: string) {
  if (ch || started === me) return
  started = me
  useChat.setState({ me })
  const [{ data: msgs }, { data: profs }] = await Promise.all([
    supabase.from('messages').select('*').order('created_at', { ascending: false }).limit(400),
    supabase.from('profiles').select('*'),
  ])
  useChat.setState({
    messages: ((msgs || []) as Message[]).reverse(),
    profiles: Object.fromEntries(((profs || []) as Profile[]).map((p) => [p.id, p])),
  })
  ch = supabase.channel('adwerk-chat')
    .on('postgres_changes', { event: 'INSERT', schema: 'public', table: 'messages' }, ({ new: row }) => {
      const m = row as Message
      const s = useChat.getState()
      if (s.messages.some((x) => x.id === m.id)) return
      useChat.setState({ messages: [...s.messages, m] })
      if (m.sender_id !== me) notify(m)
    })
    .on('postgres_changes', { event: 'DELETE', schema: 'public', table: 'messages' }, ({ old }) => {
      useChat.setState((s) => ({ messages: s.messages.filter((x) => x.id !== (old as Message).id) }))
    })
    .on('postgres_changes', { event: 'INSERT', schema: 'public', table: 'profiles' }, ({ new: p }) => {
      useChat.setState((s) => ({ profiles: { ...s.profiles, [(p as Profile).id]: p as Profile } }))
    })
    .subscribe()
}

export function stopChat() {
  if (ch) supabase.removeChannel(ch)
  ch = null
  started = null
  useChat.setState({ me: null, messages: [], toasts: [], open: false })
}

export async function sendMessage(thread: Thread, body: string, extra: Partial<Message> = {}) {
  const me = useChat.getState().me!
  const row = { sender_id: me, recipient_id: thread === 'team' ? null : thread, body: body.trim(), kind: 'text', ...extra }
  const { data, error } = await supabase.from('messages').insert(row).select('*').single()
  if (error) throw new Error('Bericht versturen lukt niet')
  const s = useChat.getState()
  if (!s.messages.some((x) => x.id === data.id)) useChat.setState({ messages: [...s.messages, data as Message] })
  markRead(thread)
  return data as Message
}

export async function requestHelp(designId: string, designTitle: string, to: Thread, note: string) {
  return sendMessage(to, note.trim() || 'Kun je even meekijken?', { kind: 'help', design_id: designId, design_title: designTitle })
}

export async function acceptHelp(m: Message) {
  const { data, error } = await supabase.rpc('adwerk_accept_help', { msg: m.id })
  if (error) throw new Error(error.message)
  dismissToast(m.id)
  await sendMessage(m.recipient_id === null ? 'team' : m.sender_id, `Ik kom je helpen in ${m.design_title || 'je ontwerp'}`)
  return data as string
}

export async function enableNotifications() {
  if (typeof Notification === 'undefined') return
  const p = await Notification.requestPermission()
  useChat.setState({ notifyPerm: p })
}
