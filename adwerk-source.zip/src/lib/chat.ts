import { create } from 'zustand'
import type { RealtimeChannel } from '@supabase/supabase-js'
import { supabase } from './supabase'
import type { Profile } from './types'
import { useLive } from './live'

export interface Attachment { type: 'image' | 'gif'; url: string; w?: number; h?: number; title?: string; still?: string }
export interface Message {
  id: string; sender_id: string; recipient_id: string | null; body: string
  kind: 'text' | 'help' | 'mention'; design_id: string | null; design_title: string | null; created_at: string
  mentions?: string[]; attachments?: Attachment[]
}
export interface ChatToast { id: string; msg: Message; leaving?: boolean }

/** Gesprek: 'team' of het id van een collega. */
export type Thread = string

interface ChatState {
  me: string | null
  messages: Message[]
  profiles: Record<string, Profile>
  open: boolean
  thread: Thread | null
  read: Record<string, string>
  toasts: ChatToast[]
  notifyPerm: NotificationPermission | 'unsupported'
  typing: Record<string, { thread: Thread; until: number }>
}

const READ_KEY = 'adwerk.chat.read'
const loadRead = (): Record<string, string> => { try { return JSON.parse(localStorage.getItem(READ_KEY) || '{}') } catch { return {} } }

export const useChat = create<ChatState>(() => ({
  me: null, messages: [], profiles: {}, open: false, thread: null, read: loadRead(), toasts: [], typing: {},
  notifyPerm: typeof Notification === 'undefined' ? 'unsupported' : Notification.permission,
}))

export const threadOf = (m: Message, me: string): Thread => (m.recipient_id === null ? 'team' : m.sender_id === me ? m.recipient_id : m.sender_id)

export function unreadCount(thread?: Thread) {
  const { messages, read, me } = useChat.getState()
  if (!me) return 0
  return messages.filter((m) => m.sender_id !== me && (!thread || threadOf(m, me) === thread) && m.created_at > (read[threadOf(m, me)] || '')).length
}

export function markRead(thread: Thread) {
  const s = useChat.getState()
  const last = s.messages.filter((m) => s.me && threadOf(m, s.me) === thread).slice(-1)[0]?.created_at || new Date().toISOString()
  const read = { ...s.read, [thread]: last }
  try { localStorage.setItem(READ_KEY, JSON.stringify(read)) } catch { /* privémodus */ }
  useChat.setState({ read })
}

export function openChat(thread: Thread | null = null) {
  useChat.setState({ open: true, thread })
  if (thread) markRead(thread)
}
export const closeChat = () => useChat.setState({ open: false })

let ch: RealtimeChannel | null = null

function beep() {
  try {
    const Ctx = window.AudioContext || (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext
    const ctx = new Ctx(), o = ctx.createOscillator(), g = ctx.createGain()
    o.type = 'sine'; o.frequency.setValueAtTime(880, ctx.currentTime); o.frequency.setValueAtTime(1320, ctx.currentTime + 0.09)
    g.gain.setValueAtTime(0.0001, ctx.currentTime); g.gain.exponentialRampToValueAtTime(0.08, ctx.currentTime + 0.02); g.gain.exponentialRampToValueAtTime(0.0001, ctx.currentTime + 0.32)
    o.connect(g).connect(ctx.destination); o.start(); o.stop(ctx.currentTime + 0.34)
  } catch { /* geen geluid */ }
}

export const nameOf = (id: string) => {
  const p = useChat.getState().profiles[id]
  return p?.full_name || p?.email?.split('@')[0] || 'Collega'
}

function notify(m: Message) {
  const s = useChat.getState()
  const thread = threadOf(m, s.me!)
  const watching = s.open && s.thread === thread && document.visibilityState === 'visible'
  if (watching) { markRead(thread); return }
  beep()
  useChat.setState({ toasts: [...s.toasts.filter((t) => t.msg.id !== m.id), { id: m.id, msg: m }].slice(-4) })
  if (m.kind !== 'help' && m.kind !== 'mention') setTimeout(() => dismissToast(m.id), 7000)
  if (document.visibilityState !== 'visible' && s.notifyPerm === 'granted') {
    const mentioned = m.kind === 'mention' || (m.mentions || []).includes(s.me!)
    const title = m.kind === 'help' ? `${nameOf(m.sender_id)} vraagt om hulp` : mentioned ? `${nameOf(m.sender_id)} noemde je` : thread === 'team' ? `${nameOf(m.sender_id)} in Team` : nameOf(m.sender_id)
    try {
      const n = new Notification(title, { body: m.design_id ? `${m.design_title || 'Een ontwerp'}: ${m.body}` : m.body || (m.attachments?.length ? 'Stuurde een afbeelding' : ''), icon: './adwerk-icon-192.png', tag: m.id })
      n.onclick = () => { window.focus(); openChat(thread); n.close() }
    } catch { /* niet ondersteund */ }
  }
}
export const dismissToast = (id: string) => {
  useChat.setState((s) => ({ toasts: s.toasts.map((t) => (t.id === id ? { ...t, leaving: true } : t)) }))
  setTimeout(() => useChat.setState((s) => ({ toasts: s.toasts.filter((t) => t.id !== id) })), 200)
}

let started: string | null = null
let unLive: (() => void) | null = null
export async function startChat(me: string) {
  if (ch || started === me) return
  started = me
  useChat.setState({ me })
  const [{ data: msgs }, { data: profs }] = await Promise.all([
    supabase.from('messages').select('*').order('created_at', { ascending: false }).limit(400),
    supabase.from('profiles').select('*'),
  ])
  useChat.setState({
    messages: ((msgs || []) as Message[]).reverse(),
    profiles: Object.fromEntries(((profs || []) as Profile[]).map((p) => [p.id, p])),
  })
  // nieuwe collega's en profielwijzigingen
  unLive?.()
  unLive = useLive.subscribe((st, prev) => {
    if (st.v.profiles !== prev.v.profiles) supabase.from('profiles').select('*').then(({ data }) => useChat.setState({ profiles: Object.fromEntries(((data || []) as Profile[]).map((p) => [p.id, p])) }))
  })
  ch = supabase.channel('adwerk-chat')
    .on('postgres_changes', { event: 'INSERT', schema: 'public', table: 'messages' }, ({ new: row }) => {
      const m = row as Message
      const s = useChat.getState()
      if (s.messages.some((x) => x.id === m.id)) return
      useChat.setState({ messages: [...s.messages, m] })
      if (m.sender_id !== me) notify(m)
    })
    .on('postgres_changes', { event: 'DELETE', schema: 'public', table: 'messages' }, ({ old }) => {
      useChat.setState((s) => ({ messages: s.messages.filter((x) => x.id !== (old as Message).id) }))
    })
    .on('broadcast', { event: 'typing' }, ({ payload }) => {
      const { from, to } = payload as { from: string; to: string }
      if (from === me || (to !== 'team' && to !== me)) return
      const thread = to === 'team' ? 'team' : from
      useChat.setState((s) => ({ typing: { ...s.typing, [from]: { thread, until: Date.now() + 4000 } } }))
      setTimeout(() => useChat.setState((s) => { const t = { ...s.typing }; if (t[from] && t[from].until <= Date.now()) delete t[from]; return { typing: t } }), 4100)
    })
    .subscribe((status) => { if (status === 'SUBSCRIBED') syncMessages() })
  document.addEventListener('visibilitychange', () => { if (document.visibilityState === 'visible') syncMessages() })
}

/** Haalt berichten op die binnenkwamen terwijl de verbinding even weg was. */
export async function syncMessages() {
  const s = useChat.getState()
  if (!s.me) return
  const since = s.messages.length ? s.messages[s.messages.length - 1].created_at : new Date(Date.now() - 864e5).toISOString()
  const { data } = await supabase.from('messages').select('*').gt('created_at', since).order('created_at').limit(200)
  const fresh = ((data || []) as Message[]).filter((m) => !useChat.getState().messages.some((x) => x.id === m.id))
  if (fresh.length) useChat.setState((st) => ({ messages: [...st.messages, ...fresh].sort((a, b) => a.created_at.localeCompare(b.created_at)) }))
}

export function stopChat() {
  if (ch) supabase.removeChannel(ch)
  ch = null
  started = null
  unLive?.(); unLive = null
  useChat.setState({ me: null, messages: [], toasts: [], open: false })
}

export async function sendMessage(thread: Thread, body: string, extra: Partial<Message> = {}) {
  const me = useChat.getState().me!
  const row = { sender_id: me, recipient_id: thread === 'team' ? null : thread, body: body.trim(), kind: 'text', ...extra }
  const { data, error } = await supabase.from('messages').insert(row).select('*').single()
  if (error) throw new Error('Bericht versturen lukt niet')
  const s = useChat.getState()
  if (!s.messages.some((x) => x.id === data.id)) useChat.setState({ messages: [...s.messages, data as Message] })
  markRead(thread)
  return data as Message
}

export async function requestHelp(designId: string, designTitle: string, to: Thread, note: string) {
  return sendMessage(to, note.trim() || 'Kun je even meekijken?', { kind: 'help', design_id: designId, design_title: designTitle })
}

export async function acceptHelp(m: Message) {
  const { data, error } = await supabase.rpc('adwerk_accept_help', { msg: m.id })
  if (error) throw new Error(error.message)
  dismissToast(m.id)
  await sendMessage(m.recipient_id === null ? 'team' : m.sender_id, `Ik kom je helpen in ${m.design_title || 'je ontwerp'}`)
  return data as string
}

export async function enableNotifications() {
  if (typeof Notification === 'undefined') return
  const p = await Notification.requestPermission()
  useChat.setState({ notifyPerm: p })
}

let lastTyping = 0
/** Laat de ander zien dat je typt (hooguit elke 2 seconden). */
export function sendTyping(thread: Thread) {
  const me = useChat.getState().me
  if (!ch || !me || Date.now() - lastTyping < 2000) return
  lastTyping = Date.now()
  ch.send({ type: 'broadcast', event: 'typing', payload: { from: me, to: thread } })
}

export async function uploadChatImage(file: File): Promise<Attachment> {
  const me = useChat.getState().me!
  if (!file.type.startsWith('image/')) throw new Error('Alleen afbeeldingen')
  if (file.size > 15 * 1024 * 1024) throw new Error('Afbeelding is groter dan 15 MB')
  const ext = (file.name.split('.').pop() || 'png').toLowerCase()
  const path = `${me}/chat/${crypto.randomUUID()}.${ext}`
  const { error } = await supabase.storage.from('assets').upload(path, file, { contentType: file.type, cacheControl: '31536000' })
  if (error) throw new Error('Uploaden mislukt')
  const url = supabase.storage.from('assets').getPublicUrl(path).data.publicUrl
  const dims = await new Promise<{ w: number; h: number }>((res) => { const i = new Image(); i.onload = () => res({ w: i.naturalWidth, h: i.naturalHeight }); i.onerror = () => res({ w: 0, h: 0 }); i.src = URL.createObjectURL(file) })
  return { type: 'image', url, ...dims, title: file.name }
}

export interface Gif { id: string; title: string; url: string; still: string; w: number; h: number }
export async function searchGifs(q: string): Promise<Gif[]> {
  const { data, error } = await supabase.functions.invoke('giphy-search', { body: { q } })
  if (error) throw new Error('GIPHY reageert even niet')
  const d = data as { gifs?: Gif[]; error?: string }
  if (d.error === 'not_configured') throw new Error('GIF\'s staan nog niet aan: de GIPHY-sleutel moet nog in Supabase worden gezet.')
  if (d.error === 'rate_limited') throw new Error('Even te veel GIF-zoekopdrachten, probeer het over een paar minuten opnieuw.')
  if (d.error) throw new Error('GIPHY reageert even niet')
  return d.gifs || []
}

export async function tagInDesign(designId: string, designTitle: string, people: string[], note: string) {
  for (const p of people) await sendMessage(p, note.trim() || 'Kijk je even mee?', { kind: 'mention', design_id: designId, design_title: designTitle, mentions: [p] })
}
