import type { El, Frame } from './types'

// Advertentiecontrole: dezelfde regels als de MCP-server (supabase/functions/adwerk-mcp, checkFrame),
// zodat mens en AI exact dezelfde feedback krijgen.
export interface AdCheck { ok: boolean; text: string; ids?: string[] }

function lum(hex: string) {
  const m = (hex || '').replace('#', '').match(/^([0-9a-f]{6}|[0-9a-f]{3})/i)
  if (!m) return 0.5
  const h = m[1].length === 3 ? m[1].split('').map((c) => c + c).join('') : m[1]
  const c = [0, 2, 4].map((i) => parseInt(h.slice(i, i + 2), 16) / 255).map((x) => (x <= 0.03928 ? x / 12.92 : ((x + 0.055) / 1.055) ** 2.4))
  return 0.2126 * c[0] + 0.7152 * c[1] + 0.0722 * c[2]
}
export const contrast = (a: string, b: string) => { const x = lum(a), y = lum(b); return (Math.max(x, y) + 0.05) / (Math.min(x, y) + 0.05) }

export function adChecks(f: Frame): AdCheck[] {
  const issues: AdCheck[] = []
  const minSide = Math.min(f.w, f.h), story = f.h / f.w > 1.7, banner = minSide <= 320
  const box = (e: El) => ({ x: e.x, y: e.y, w: e.width, h: e.height })
  const inside = (p: { x: number; y: number }, b: { x: number; y: number; w: number; h: number }) => p.x >= b.x && p.x <= b.x + b.w && p.y >= b.y && p.y <= b.y + b.h
  const overlap = (a: { x: number; y: number; w: number; h: number }, b: { x: number; y: number; w: number; h: number }) => Math.max(0, Math.min(a.x + a.w, b.x + b.w) - Math.max(a.x, b.x)) * Math.max(0, Math.min(a.y + a.h, b.y + b.h) - Math.max(a.y, b.y))
  const short = (e: El) => `"${String(e.text || e.name).replace(/\n/g, ' ').slice(0, 24)}"`
  const vis = f.elements.filter((e) => e.visible)
  const texts = vis.filter((e) => e.type === 'text')
  let words = 0, tooSmall = 0, small: El[] = []
  f.elements.forEach((e, i) => {
    if (!e.visible) return
    const b = box(e)
    const outPart = (Math.max(0, -b.x) + Math.max(0, b.x + b.w - f.w)) / Math.max(1, b.w) + (Math.max(0, -b.y) + Math.max(0, b.y + b.h - f.h)) / Math.max(1, b.h)
    if (e.type === 'text') {
      words += String(e.text || '').split(/\s+/).filter(Boolean).length
      if (outPart > 0.01) issues.push({ ok: false, text: `Tekst ${short(e)} valt buiten het formaat.`, ids: [e.id] })
      const fs = e.fontSize || 24, minFs = banner ? 11 : Math.round(minSide * 0.028)
      if (fs < minFs) { tooSmall = Math.max(tooSmall, minFs); small = [...small, e] }
      const m = minSide * 0.04
      if (outPart <= 0.01 && (b.x < m || b.y < m || b.x + b.w > f.w - m || b.y + b.h > f.h - m)) issues.push({ ok: false, text: `Tekst ${short(e)} staat te dicht op de rand (houd ${Math.round(m)} px marge).`, ids: [e.id] })
      if (story && (b.y < f.h * 0.14 || b.y + b.h > f.h * 0.8)) issues.push({ ok: false, text: `Tekst ${short(e)} staat in een veilige zone van de story.`, ids: [e.id] })
      const c = { x: b.x + b.w / 2, y: b.y + b.h / 2 }
      let under: string[] | null = null, onPhoto = false
      for (let j = i - 1; j >= 0; j--) {
        const o = f.elements[j]
        if (!o.visible || o.type === 'text' || o.type === 'icon' || o.type === 'line') continue
        if (!inside(c, box(o))) continue
        if (o.type === 'image') { onPhoto = !!o.src; under = o.src ? null : [o.fill]; break }
        if ((o.opacity ?? 1) > 0.6) { under = [o.fill]; break }
      }
      if (!under && !onPhoto) under = f.background.type === 'gradient' ? [f.background.color, f.background.color2] : f.background.type === 'image' ? null : [f.background.color]
      if (f.background.type === 'image' && !under) onPhoto = true
      if (onPhoto) issues.push({ ok: false, text: `Tekst ${short(e)} staat op een foto: check leesbaarheid en of er geen gezicht achter valt.`, ids: [e.id] })
      else if (under) {
        const large = fs >= minSide * 0.05 || ((e.fontWeight || 400) >= 700 && fs >= minSide * 0.035)
        const worst = Math.min(...under.map((u) => contrast(e.fill, u)))
        if (worst < (large ? 3 : 4.5)) issues.push({ ok: false, text: `Tekst ${short(e)} heeft te weinig contrast (${worst.toFixed(1)}:1, minimaal ${large ? '3' : '4,5'}:1).`, ids: [e.id] })
      }
      for (let j = i - 1; j >= 0; j--) {
        const o = f.elements[j]
        if (!o.visible || o.type !== 'rect') continue
        const ob = box(o)
        if (!inside(c, ob) || ob.w * ob.h >= f.w * f.h * 0.3) continue
        if (b.x < ob.x - 1 || b.x + b.w > ob.x + ob.w + 1 || b.y < ob.y - 1 || b.y + b.h > ob.y + ob.h + 1) { issues.push({ ok: false, text: `Tekst ${short(e)} steekt buiten de knop of het vlak eronder.`, ids: [e.id, o.id] }); break }
        const dy = Math.abs((b.y + b.h / 2) - (ob.y + ob.h / 2)), dx = e.align === 'center' ? Math.abs((b.x + b.w / 2) - (ob.x + ob.w / 2)) : 0
        if (dy > ob.h * 0.12 || dx > ob.w * 0.06) issues.push({ ok: false, text: `Tekst ${short(e)} staat niet in het midden van de knop.`, ids: [e.id, o.id] })
        break
      }
      for (let j = i + 1; j < f.elements.length; j++) {
        const o = f.elements[j]
        if (o.visible && o.type === 'text' && overlap(b, box(o)) > 4) issues.push({ ok: false, text: `Tekst ${short(e)} overlapt met ${short(o)}.`, ids: [e.id, o.id] })
      }
    } else if (e.type === 'image') {
      if (!e.src) issues.push({ ok: false, text: `Leeg fotokader "${e.name}".`, ids: [e.id] })
      if (outPart > 0.35) issues.push({ ok: false, text: `Afbeelding "${e.name}" valt grotendeels buiten het formaat.`, ids: [e.id] })
    } else if (e.type === 'icon' && outPart > 0.01) issues.push({ ok: false, text: `Icoon "${e.name}" valt buiten het formaat.`, ids: [e.id] })
  })
  const out: AdCheck[] = []
  out.push(small.length ? { ok: false, text: `${small.length === 1 ? 'Eén tekst is' : `${small.length} teksten zijn`} te klein voor mobiel; houd minimaal ${tooSmall} px aan.`, ids: small.map((e) => e.id) } : { ok: true, text: 'Tekstgrootte is goed leesbaar.' })
  const area = texts.reduce((s, t) => s + t.width * t.height, 0) / (f.w * f.h)
  out.push(area > 0.25 ? { ok: false, text: `Tekst bedekt ongeveer ${Math.round(area * 100)}% van het beeld. Minder tekst presteert meestal beter.` } : { ok: true, text: 'Verhouding tekst en beeld is in orde.' })
  if (banner && words > 20) out.push({ ok: false, text: `${words} woorden is te veel voor een banner van ${f.w}×${f.h}.` })
  else if (!banner && words > 40) out.push({ ok: false, text: `${words} woorden: veel tekst voor een advertentie.` })
  if (story && !issues.some((x) => x.text.includes('veilige zone'))) out.push({ ok: true, text: 'Tekst staat buiten de veilige zones.' })
  if (!issues.some((x) => x.text.includes('contrast'))) out.push({ ok: true, text: 'Contrast van de tekst is goed.' })
  if (f.platform === 'Google Display' && f.duration > 30) out.push({ ok: false, text: `Animatie duurt ${f.duration}s; Google Ads staat maximaal 30s toe.` })
  if (!texts.length) out.push({ ok: false, text: 'Er staat nog geen tekst in dit formaat.' })
  return [...issues, ...out].sort((a, b) => Number(a.ok) - Number(b.ok))
}
