export interface FontDef { name: string; weights: number[]; category: 'sans' | 'serif' | 'display' | 'script' }

export const FONTS: FontDef[] = [
  { name: 'Figtree', weights: [400, 500, 700, 800, 900], category: 'sans' },
  { name: 'Inter', weights: [400, 500, 700, 800, 900], category: 'sans' },
  { name: 'Poppins', weights: [400, 500, 700, 800, 900], category: 'sans' },
  { name: 'Montserrat', weights: [400, 500, 700, 800, 900], category: 'sans' },
  { name: 'DM Sans', weights: [400, 500, 700, 800, 900], category: 'sans' },
  { name: 'Plus Jakarta Sans', weights: [400, 500, 700, 800], category: 'sans' },
  { name: 'Manrope', weights: [400, 500, 700, 800], category: 'sans' },
  { name: 'Outfit', weights: [400, 500, 700, 800, 900], category: 'sans' },
  { name: 'Sora', weights: [400, 500, 700, 800], category: 'sans' },
  { name: 'Roboto', weights: [400, 500, 700, 900], category: 'sans' },
  { name: 'Open Sans', weights: [400, 500, 700, 800], category: 'sans' },
  { name: 'Lato', weights: [400, 700, 900], category: 'sans' },
  { name: 'Nunito', weights: [400, 500, 700, 800, 900], category: 'sans' },
  { name: 'Rubik', weights: [400, 500, 700, 800, 900], category: 'sans' },
  { name: 'Work Sans', weights: [400, 500, 700, 800, 900], category: 'sans' },
  { name: 'Raleway', weights: [400, 500, 700, 800, 900], category: 'sans' },
  { name: 'Barlow', weights: [400, 500, 700, 800, 900], category: 'sans' },
  { name: 'Barlow Condensed', weights: [400, 500, 700, 800, 900], category: 'sans' },
  { name: 'Josefin Sans', weights: [400, 500, 700], category: 'sans' },
  { name: 'Quicksand', weights: [400, 500, 700], category: 'sans' },
  { name: 'Kanit', weights: [400, 500, 700, 800, 900], category: 'sans' },
  { name: 'Space Grotesk', weights: [400, 500, 700], category: 'sans' },
  { name: 'Bricolage Grotesque', weights: [400, 500, 700, 800], category: 'display' },
  { name: 'Syne', weights: [400, 500, 700, 800], category: 'display' },
  { name: 'Unbounded', weights: [400, 500, 700, 800, 900], category: 'display' },
  { name: 'Archivo Black', weights: [400], category: 'display' },
  { name: 'Anton', weights: [400], category: 'display' },
  { name: 'Bebas Neue', weights: [400], category: 'display' },
  { name: 'Oswald', weights: [400, 500, 700], category: 'display' },
  { name: 'Teko', weights: [400, 500, 700], category: 'display' },
  { name: 'Bungee', weights: [400], category: 'display' },
  { name: 'Righteous', weights: [400], category: 'display' },
  { name: 'Fredoka', weights: [400, 500, 700], category: 'display' },
  { name: 'Alfa Slab One', weights: [400], category: 'display' },
  { name: 'Abril Fatface', weights: [400], category: 'display' },
  { name: 'Playfair Display', weights: [400, 500, 700, 800, 900], category: 'serif' },
  { name: 'DM Serif Display', weights: [400], category: 'serif' },
  { name: 'Fraunces', weights: [400, 500, 700, 800, 900], category: 'serif' },
  { name: 'Instrument Serif', weights: [400], category: 'serif' },
  { name: 'Lora', weights: [400, 500, 700], category: 'serif' },
  { name: 'Merriweather', weights: [400, 700, 900], category: 'serif' },
  { name: 'Libre Baskerville', weights: [400, 700], category: 'serif' },
  { name: 'Pacifico', weights: [400], category: 'script' },
  { name: 'Caveat', weights: [400, 500, 700], category: 'script' },
  { name: 'Permanent Marker', weights: [400], category: 'script' },
  { name: 'Lobster', weights: [400], category: 'script' },
]

const loaded = new Map<string, Promise<void>>()

export function fontDef(name: string) {
  return FONTS.find((f) => f.name === name)
}

export function nearestWeight(name: string, w: number) {
  const def = fontDef(name)
  if (!def) return w
  return def.weights.reduce((a, b) => (Math.abs(b - w) < Math.abs(a - w) ? b : a), def.weights[0])
}

export function loadFont(name: string): Promise<void> {
  if (!name) return Promise.resolve()
  if (loaded.has(name)) return loaded.get(name)!
  const def = fontDef(name)
  const weights = def ? def.weights : [400, 700]
  const p = new Promise<void>((resolve) => {
    const link = document.createElement('link')
    link.rel = 'stylesheet'
    link.href = `https://fonts.googleapis.com/css2?family=${encodeURIComponent(name).replace(/%20/g, '+')}:wght@${weights.join(';')}&display=swap`
    link.onload = async () => {
      try {
        await Promise.all(weights.map((w) => document.fonts.load(`${w} 32px "${name}"`)))
      } catch { /* negeren */ }
      resolve()
    }
    link.onerror = () => resolve()
    document.head.appendChild(link)
  })
  loaded.set(name, p)
  return p
}

export function loadFontsForDoc(families: string[]) {
  return Promise.all([...new Set(families.filter(Boolean))].map(loadFont))
}
