export interface FontDef { name: string; weights: number[]; category: 'sans' | 'serif' | 'display' | 'script' }

export const FONTS: FontDef[] = [
  { name: 'Figtree', weights: [400, 500, 700, 800, 900], category: 'sans' },
  { name: 'Inter', weights: [400, 500, 700, 800, 900], category: 'sans' },
  { name: 'Poppins', weights: [400, 500, 700, 800, 900], category: 'sans' },
  { name: 'Montserrat', weights: [400, 500, 700, 800, 900], category: 'sans' },
  { name: 'DM Sans', weights: [400, 500, 700, 800, 900], category: 'sans' },
  { name: 'Plus Jakarta Sans', weights: [400, 500, 700, 800], category: 'sans' },
  { name: 'Manrope', weights: [400, 500, 700, 800], category: 'sans' },
  { name: 'Outfit', weights: [400, 500, 700, 800, 900], category: 'sans' },
  { name: 'Sora', weights: [400, 500, 700, 800], category: 'sans' },
  { name: 'Roboto', weights: [400, 500, 700, 900], category: 'sans' },
  { name: 'Open Sans', weights: [400, 500, 700, 800], category: 'sans' },
  { name: 'Lato', weights: [400, 700, 900], category: 'sans' },
  { name: 'Nunito', weights: [400, 500, 700, 800, 900], category: 'sans' },
  { name: 'Rubik', weights: [400, 500, 700, 800, 900], category: 'sans' },
  { name: 'Work Sans', weights: [400, 500, 700, 800, 900], category: 'sans' },
  { name: 'Raleway', weights: [400, 500, 700, 800, 900], category: 'sans' },
  { name: 'Barlow', weights: [400, 500, 700, 800, 900], category: 'sans' },
  { name: 'Barlow Condensed', weights: [400, 500, 700, 800, 900], category: 'sans' },
  { name: 'Josefin Sans', weights: [400, 500, 700], category: 'sans' },
  { name: 'Quicksand', weights: [400, 500, 700], category: 'sans' },
  { name: 'Kanit', weights: [400, 500, 700, 800, 900], category: 'sans' },
  { name: 'Space Grotesk', weights: [400, 500, 700], category: 'sans' },
  { name: 'Bricolage Grotesque', weights: [400, 500, 700, 800], category: 'display' },
  { name: 'Syne', weights: [400, 500, 700, 800], category: 'display' },
  { name: 'Unbounded', weights: [400, 500, 700, 800, 900], category: 'display' },
  { name: 'Archivo Black', weights: [400], category: 'display' },
  { name: 'Anton', weights: [400], category: 'display' },
  { name: 'Bebas Neue', weights: [400], category: 'display' },
  { name: 'Oswald', weights: [400, 500, 700], category: 'display' },
  { name: 'Teko', weights: [400, 500, 700], category: 'display' },
  { name: 'Bungee', weights: [400], category: 'display' },
  { name: 'Righteous', weights: [400], category: 'display' },
  { name: 'Fredoka', weights: [400, 500, 700], category: 'display' },
  { name: 'Alfa Slab One', weights: [400], category: 'display' },
  { name: 'Abril Fatface', weights: [400], category: 'display' },
  { name: 'Playfair Display', weights: [400, 500, 700, 800, 900], category: 'serif' },
  { name: 'DM Serif Display', weights: [400], category: 'serif' },
  { name: 'Fraunces', weights: [400, 500, 700, 800, 900], category: 'serif' },
  { name: 'Instrument Serif', weights: [400], category: 'serif' },
  { name: 'Lora', weights: [400, 500, 700], category: 'serif' },
  { name: 'Merriweather', weights: [400, 700, 900], category: 'serif' },
  { name: 'Libre Baskerville', weights: [400, 700], category: 'serif' },
  { name: 'Pacifico', weights: [400], category: 'script' },
  { name: 'Caveat', weights: [400, 500, 700], category: 'script' },
  { name: 'Permanent Marker', weights: [400], category: 'script' },
  { name: 'Lobster', weights: [400], category: 'script' },
]

const loaded = new Map<string, Promise<void>>()

export function fontDef(name: string) {
  return FONTS.find((f) => f.name === name)
}

/* ---------- lokaal geïnstalleerde lettertypes ---------- */
export interface LocalFont { name: string; weights: number[] }
const LKEY = 'adwerk-local-fonts'
const ALL_W = [300, 400, 500, 600, 700, 800, 900]
export function localFonts(): LocalFont[] {
  try { const v = JSON.parse(localStorage.getItem(LKEY) || '[]'); return Array.isArray(v) ? v.filter((x) => x && typeof x.name === 'string') : [] } catch { return [] }
}
function saveLocal(list: LocalFont[]) {
  try { localStorage.setItem(LKEY, JSON.stringify(list.sort((a, b) => a.name.localeCompare(b.name)))) } catch { /* */ }
  window.dispatchEvent(new Event('adwerk-local-fonts'))
}
export function addLocalFonts(add: LocalFont[]) {
  const map = new Map(localFonts().map((f) => [f.name.toLowerCase(), f]))
  for (const f of add) if (f.name.trim() && !fontDef(f.name)) map.set(f.name.toLowerCase(), { name: f.name.trim(), weights: f.weights.length ? [...new Set(f.weights)].sort((a, b) => a - b) : [400, 700] })
  saveLocal([...map.values()])
}
export function removeLocalFont(name: string) { saveLocal(localFonts().filter((f) => f.name !== name)) }
export const localFont = (name: string) => localFonts().find((f) => f.name === name)

/** Staat dit lettertype op deze computer? Meet tekst tegen twee standaardletters. */
export function isInstalled(name: string) {
  try {
    const c = document.createElement('canvas').getContext('2d')!
    const t = 'mmmmmmmmlli1WQ@#'
    return ['monospace', 'serif', 'sans-serif'].some((base) => {
      c.font = `72px ${base}`; const a = c.measureText(t).width
      c.font = `72px "${name}", ${base}`; return c.measureText(t).width !== a
    })
  } catch { return false }
}

export const canQueryLocalFonts = () => typeof window !== 'undefined' && 'queryLocalFonts' in window
const styleWeight = (style: string) => {
  const s = style.toLowerCase()
  if (/thin|hairline/.test(s)) return 100
  if (/extra ?light|ultra ?light/.test(s)) return 200
  if (/light/.test(s)) return 300
  if (/medium/.test(s)) return 500
  if (/semi ?bold|demi/.test(s)) return 600
  if (/extra ?bold|ultra ?bold/.test(s)) return 800
  if (/black|heavy/.test(s)) return 900
  if (/bold/.test(s)) return 700
  return 400
}
/** Vraagt (met toestemming van de browser) alle lokaal geïnstalleerde lettertypes op. Alleen Chrome en Edge. */
export async function queryInstalledFonts(): Promise<LocalFont[]> {
  const q = (window as unknown as { queryLocalFonts?: () => Promise<{ family: string; style: string }[]> }).queryLocalFonts
  if (!q) throw new Error('unsupported')
  const list = await q()
  const map = new Map<string, Set<number>>()
  for (const f of list) { if (!map.has(f.family)) map.set(f.family, new Set()); map.get(f.family)!.add(styleWeight(f.style)) }
  return [...map.entries()].map(([name, w]) => ({ name, weights: [...w].sort((a, b) => a - b) })).sort((a, b) => a.name.localeCompare(b.name))
}

export function fontWeights(name: string) {
  return fontDef(name)?.weights || localFont(name)?.weights || ALL_W
}

export function nearestWeight(name: string, w: number) {
  const def = fontDef(name) || localFont(name)
  if (!def) return w
  return def.weights.reduce((a, b) => (Math.abs(b - w) < Math.abs(a - w) ? b : a), def.weights[0])
}

export function loadFont(name: string): Promise<void> {
  if (!name) return Promise.resolve()
  if (loaded.has(name)) return loaded.get(name)!
  const def = fontDef(name)
  if (!def && (localFont(name) || isInstalled(name))) {
    // lokaal lettertype: niets downloaden, de browser gebruikt het geïnstalleerde bestand
    const p = Promise.all((localFont(name)?.weights || [400, 700]).map((w) => document.fonts.load(`${w} 32px "${name}"`).catch(() => null))).then(() => undefined)
    loaded.set(name, p)
    return p
  }
  const weights = def ? def.weights : [400, 700]
  const p = new Promise<void>((resolve) => {
    const link = document.createElement('link')
    link.rel = 'stylesheet'
    link.href = `https://fonts.googleapis.com/css2?family=${encodeURIComponent(name).replace(/%20/g, '+')}:wght@${weights.join(';')}&display=swap`
    link.onload = async () => {
      try {
        await Promise.all(weights.map((w) => document.fonts.load(`${w} 32px "${name}"`)))
      } catch { /* negeren */ }
      resolve()
    }
    link.onerror = () => resolve()
    document.head.appendChild(link)
  })
  loaded.set(name, p)
  return p
}

export function loadFontsForDoc(families: string[]) {
  return Promise.all([...new Set(families.filter(Boolean))].map(loadFont))
}
