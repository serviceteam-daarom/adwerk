import { useEffect } from 'react'
import { create } from 'zustand'
import type { RealtimeChannel } from '@supabase/supabase-js'
import { supabase } from './supabase'

/** Tabellen die live meeveranderen in de hele app. Elk krijgt een eigen kanaal, zodat een fout bij de één de rest niet raakt. */
export type LiveTable = 'designs' | 'folders' | 'brand_kits' | 'assets' | 'profiles' | 'design_members' | 'comments' | 'design_versions' | 'approvals'
const TABLES: LiveTable[] = ['designs', 'folders', 'brand_kits', 'assets', 'profiles', 'design_members', 'comments', 'design_versions', 'approvals']

type Row = Record<string, unknown>
interface LiveState { v: Record<LiveTable, number>; last: Partial<Record<LiveTable, { event: string; new: Row; old: Row }>> }
export const useLive = create<LiveState>(() => ({ v: Object.fromEntries(TABLES.map((t) => [t, 0])) as Record<LiveTable, number>, last: {} }))

let channels: RealtimeChannel[] = []
const timers: Partial<Record<LiveTable, ReturnType<typeof setTimeout>>> = {}

export function startLive() {
  if (channels.length) return
  channels = TABLES.map((t) => supabase.channel(`live-${t}`)
    .on('postgres_changes', { event: '*', schema: 'public', table: t }, (p) => {
      useLive.setState((s) => ({ last: { ...s.last, [t]: { event: p.eventType, new: p.new as Row, old: p.old as Row } } }))
      // kort samenvoegen: bij snel opslaan niet tien keer opnieuw laden
      clearTimeout(timers[t])
      timers[t] = setTimeout(() => useLive.setState((s) => ({ v: { ...s.v, [t]: s.v[t] + 1 } })), 250)
    })
    .subscribe())
  // terug naar het tabblad: alles één keer verversen (gemiste wijzigingen)
  document.addEventListener('visibilitychange', onVisible)
}
function onVisible() {
  if (document.visibilityState !== 'visible') return
  useLive.setState((s) => ({ v: Object.fromEntries(TABLES.map((t) => [t, s.v[t] + 1])) as Record<LiveTable, number> }))
}
export function stopLive() {
  channels.forEach((c) => supabase.removeChannel(c))
  channels = []
  document.removeEventListener('visibilitychange', onVisible)
}

/** Voert fn opnieuw uit zodra een van de tabellen verandert (niet bij de eerste render). */
export function useLiveReload(tables: LiveTable[], fn: () => void) {
  const key = useLive((s) => tables.map((t) => s.v[t]).join(','))
  useEffect(() => {
    if (key.split(',').every((x) => x === '0')) return
    fn()
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [key])
}
