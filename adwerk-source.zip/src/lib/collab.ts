import type { RealtimeChannel } from '@supabase/supabase-js'
import { supabase } from './supabase'
import type { DesignDoc } from './types'
import { useEditor, setBroadcaster, type Peer } from '../store/editor'
import { diffDocs, applyPatch, type DocPatch } from './patch'

export interface Me { id: string; name: string; color: string; avatar?: string | null }
export interface LiveItem { id: string; x: number; y: number; width?: number; height?: number; rotation: number; fontSize?: number }

let channel: RealtimeChannel | null = null
const sessionId = Math.random().toString(36).slice(2, 8)
let myKey = ''
let lastCursor = 0
let selectedAt = 0
let liveHandler: ((frameId: string, items: LiveItem[], duration?: number) => void) | null = null
export const onLive = (fn: typeof liveHandler) => { liveHandler = fn }

export function startCollab(designId: string, me: Me) {
  stopCollab()
  let synced = false
  myKey = `${me.id}:${sessionId}`
  const ch = supabase.channel(`design:${designId}`, { config: { broadcast: { self: false }, presence: { key: myKey } } })
  channel = ch

  ch.on('broadcast', { event: 'patch' }, ({ payload }) => {
    const s = useEditor.getState()
    s.setDoc(applyPatch(s.doc, payload as DocPatch), { remote: true })
  })
  // live slepen en schalen: direct op het canvas tonen, de definitieve stand komt als patch
  ch.on('broadcast', { event: 'live' }, ({ payload }) => {
    const { frameId, items, duration } = payload as { frameId: string; items: LiveItem[]; duration?: number }
    liveHandler?.(frameId, items, duration)
  })
  // live beelden voor AI-agents: één open editor (de eerste in de lijst) rendert pixel-exact
  ch.on('broadcast', { event: 'render-request' }, async ({ payload }) => {
    const { reqId, frameIds, time, maxSide } = payload as { reqId: string; frameIds: string[]; time: number | null; maxSide: number }
    const keys = Object.keys(ch.presenceState()).sort()
    if (keys.length && keys[0] !== myKey) return
    const folder = `previews/${reqId}`
    await supabase.storage.from('assets').upload(`${folder}/_ack`, new Blob(['1']), { upsert: true }).catch(() => null)
    const { createOffscreen } = await import('./render')
    for (const fid of frameIds) {
      const frame = useEditor.getState().doc.frames.find((f) => f.id === fid)
      if (!frame) continue
      try {
        const off = await createOffscreen(frame)
        try {
          const r = Math.min(2, maxSide / Math.max(frame.w, frame.h))
          const c = off.canvasAt(typeof time === 'number' ? time : null, r)
          const flat = document.createElement('canvas')
          flat.width = c.width; flat.height = c.height
          const cx = flat.getContext('2d')!
          cx.fillStyle = '#fff'; cx.fillRect(0, 0, flat.width, flat.height); cx.drawImage(c, 0, 0)
          const png = maxSide >= Math.max(frame.w, frame.h)
          const blob = await new Promise<Blob | null>((res) => flat.toBlob(res, png ? 'image/png' : 'image/jpeg', 0.9))
          if (blob) await supabase.storage.from('assets').upload(`${folder}/${fid}.${png ? 'png' : 'jpg'}`, blob, { contentType: blob.type, upsert: true })
        } finally { off.destroy() }
      } catch { /* de server rendert dan zelf */ }
    }
  })
  // AI-agents (via de Adwerk MCP-server): cursor, actie en selectie
  ch.on('broadcast', { event: 'agent' }, ({ payload }) => {
    const a = payload as Peer
    useEditor.setState((st) => ({ agents: { ...st.agents, [a.key!]: { ...st.agents[a.key!], ...a, agent: true, seen: Date.now() } } }))
  })
  ch.on('broadcast', { event: 'cursor' }, ({ payload }) => {
    const { key, cursor, frameId } = payload as { key: string; cursor: Peer['cursor']; frameId: string }
    useEditor.setState((st) => (st.peers[key] ? { peers: { ...st.peers, [key]: { ...st.peers[key], cursor, frameId } } } : st))
  })
  ch.on('broadcast', { event: 'sync-req' }, () => {
    if (synced) ch.send({ type: 'broadcast', event: 'sync-full', payload: { doc: useEditor.getState().doc } })
  })
  ch.on('broadcast', { event: 'sync-full' }, ({ payload }) => {
    if (synced) return
    synced = true
    useEditor.getState().setDoc((payload as { doc: DesignDoc }).doc, { remote: true })
  })
  ch.on('presence', { event: 'sync' }, () => {
    const state = ch.presenceState() as unknown as Record<string, (Peer & { selectedAt?: number })[]>
    const peers: Record<string, Peer> = {}
    const prev = useEditor.getState().peers
    const mySel = useEditor.getState().selectedIds
    let drop: string[] = []
    for (const [key, metas] of Object.entries(state)) {
      if (key === myKey) continue
      const m = metas[0]
      peers[key] = { ...m, key, cursor: prev[key]?.cursor ?? null }
      // zelfde element tegelijk geselecteerd: wie het eerst koos, houdt het
      const clash = (m.selection || []).filter((id) => mySel.includes(id))
      if (clash.length && m.frameId === useEditor.getState().activeFrameId && (m.selectedAt || 0) < selectedAt) drop = drop.concat(clash)
    }
    useEditor.setState({ peers, ...(drop.length ? { selectedIds: mySel.filter((i) => !drop.includes(i)) } : {}) })
  })

  ch.subscribe(async (status) => {
    if (status !== 'SUBSCRIBED') return
    await track(me)
    ch.send({ type: 'broadcast', event: 'sync-req', payload: {} })
    setTimeout(() => { synced = true }, 1500)
  })

  setBroadcaster((prev, next) => {
    const p = diffDocs(prev, next)
    if (p && channel) channel.send({ type: 'broadcast', event: 'patch', payload: p })
  })

  let lastKey = ''
  const unsub = useEditor.subscribe((s) => {
    const key = s.activeFrameId + '|' + s.selectedIds.join(',')
    if (key === lastKey || !channel) return
    lastKey = key
    selectedAt = Date.now()
    track(me)
  })
  // agents die even niets doen verdwijnen weer
  const sweep = setInterval(() => {
    const ag = useEditor.getState().agents
    const now = Date.now()
    const keep = Object.fromEntries(Object.entries(ag).filter(([, a]) => now - (a.seen || 0) < 25000))
    if (Object.keys(keep).length !== Object.keys(ag).length) useEditor.setState({ agents: keep })
  }, 3000)
  ;(ch as unknown as { _unsub: () => void })._unsub = () => { unsub(); clearInterval(sweep) }
}

const joined = () => (channel as unknown as { state?: string } | null)?.state === 'joined'

// terug naar het tabblad: aanwezigheid opnieuw doorgeven
let currentMe: Me | null = null
document.addEventListener('visibilitychange', () => { if (document.visibilityState === 'visible' && currentMe && joined()) track(currentMe) })

function track(me: Me) {
  currentMe = me
  const s = useEditor.getState()
  return channel?.track({ id: me.id, name: me.name, color: me.color, avatar: me.avatar, frameId: s.activeFrameId, selection: s.selectedIds, selectedAt })
}

export function sendCursor(cursor: { x: number; y: number } | null) {
  const now = performance.now()
  if (!joined() || (cursor && now - lastCursor < 40)) return
  lastCursor = now
  channel?.send({ type: 'broadcast', event: 'cursor', payload: { key: myKey, cursor, frameId: useEditor.getState().activeFrameId } })
}

let lastLive = 0
let pendingLive: LiveItem[] | null = null
let liveTimer: ReturnType<typeof setTimeout> | undefined
export function sendLive(items: LiveItem[]) {
  if (!joined()) return
  const now = performance.now()
  const send = (it: LiveItem[]) => { lastLive = performance.now(); channel?.send({ type: 'broadcast', event: 'live', payload: { frameId: useEditor.getState().activeFrameId, items: it } }) }
  if (now - lastLive >= 33) { send(items); pendingLive = null; return }
  pendingLive = items
  clearTimeout(liveTimer)
  liveTimer = setTimeout(() => { if (pendingLive) send(pendingLive); pendingLive = null }, 34)
}

export function stopCollab() {
  setBroadcaster(null)
  if (channel) {
    ;(channel as unknown as { _unsub?: () => void })._unsub?.()
    supabase.removeChannel(channel)
    channel = null
  }
  useEditor.setState({ peers: {}, agents: {} })
}

export { diffDocs, applyPatch }

// Diagnose in de console: adwerkCollab()
;(window as unknown as { adwerkCollab: () => unknown }).adwerkCollab = () => ({
  key: myKey, state: (channel as unknown as { state?: string } | null)?.state, presence: channel?.presenceState(),
  sockets: supabase.realtime.isConnected(), channels: supabase.getChannels().map((c) => [c.topic, (c as unknown as { state: string }).state]),
})
