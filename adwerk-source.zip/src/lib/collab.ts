import type { RealtimeChannel } from '@supabase/supabase-js'
import { supabase } from './supabase'
import type { DesignDoc } from './types'
import { useEditor, setBroadcaster, type Peer } from '../store/editor'
import { diffDocs, applyPatch, type DocPatch } from './patch'

export interface Me { id: string; name: string; color: string; avatar?: string | null }
export interface LiveItem { id: string; x: number; y: number; width?: number; height?: number; rotation: number; fontSize?: number }

let channel: RealtimeChannel | null = null
const sessionId = Math.random().toString(36).slice(2, 8)
let myKey = ''
let lastCursor = 0
let selectedAt = 0
let liveHandler: ((frameId: string, items: LiveItem[]) => void) | null = null
export const onLive = (fn: typeof liveHandler) => { liveHandler = fn }

export function startCollab(designId: string, me: Me) {
  stopCollab()
  let synced = false
  myKey = `${me.id}:${sessionId}`
  const ch = supabase.channel(`design:${designId}`, { config: { broadcast: { self: false }, presence: { key: myKey } } })
  channel = ch

  ch.on('broadcast', { event: 'patch' }, ({ payload }) => {
    const s = useEditor.getState()
    s.setDoc(applyPatch(s.doc, payload as DocPatch), { remote: true })
  })
  // live slepen en schalen: direct op het canvas tonen, de definitieve stand komt als patch
  ch.on('broadcast', { event: 'live' }, ({ payload }) => {
    const { frameId, items } = payload as { frameId: string; items: LiveItem[] }
    liveHandler?.(frameId, items)
  })
  ch.on('broadcast', { event: 'cursor' }, ({ payload }) => {
    const { key, cursor, frameId } = payload as { key: string; cursor: Peer['cursor']; frameId: string }
    useEditor.setState((st) => (st.peers[key] ? { peers: { ...st.peers, [key]: { ...st.peers[key], cursor, frameId } } } : st))
  })
  ch.on('broadcast', { event: 'sync-req' }, () => {
    if (synced) ch.send({ type: 'broadcast', event: 'sync-full', payload: { doc: useEditor.getState().doc } })
  })
  ch.on('broadcast', { event: 'sync-full' }, ({ payload }) => {
    if (synced) return
    synced = true
    useEditor.getState().setDoc((payload as { doc: DesignDoc }).doc, { remote: true })
  })
  ch.on('presence', { event: 'sync' }, () => {
    const state = ch.presenceState() as unknown as Record<string, (Peer & { selectedAt?: number })[]>
    const peers: Record<string, Peer> = {}
    const prev = useEditor.getState().peers
    const mySel = useEditor.getState().selectedIds
    let drop: string[] = []
    for (const [key, metas] of Object.entries(state)) {
      if (key === myKey) continue
      const m = metas[0]
      peers[key] = { ...m, key, cursor: prev[key]?.cursor ?? null }
      // zelfde element tegelijk geselecteerd: wie het eerst koos, houdt het
      const clash = (m.selection || []).filter((id) => mySel.includes(id))
      if (clash.length && m.frameId === useEditor.getState().activeFrameId && (m.selectedAt || 0) < selectedAt) drop = drop.concat(clash)
    }
    useEditor.setState({ peers, ...(drop.length ? { selectedIds: mySel.filter((i) => !drop.includes(i)) } : {}) })
  })

  ch.subscribe(async (status) => {
    if (status !== 'SUBSCRIBED') return
    await track(me)
    ch.send({ type: 'broadcast', event: 'sync-req', payload: {} })
    setTimeout(() => { synced = true }, 1500)
  })

  setBroadcaster((prev, next) => {
    const p = diffDocs(prev, next)
    if (p && channel) channel.send({ type: 'broadcast', event: 'patch', payload: p })
  })

  let lastKey = ''
  const unsub = useEditor.subscribe((s) => {
    const key = s.activeFrameId + '|' + s.selectedIds.join(',')
    if (key === lastKey || !channel) return
    lastKey = key
    selectedAt = Date.now()
    track(me)
  })
  ;(ch as unknown as { _unsub: () => void })._unsub = unsub
}

function track(me: Me) {
  const s = useEditor.getState()
  return channel?.track({ id: me.id, name: me.name, color: me.color, avatar: me.avatar, frameId: s.activeFrameId, selection: s.selectedIds, selectedAt })
}

export function sendCursor(cursor: { x: number; y: number } | null) {
  const now = performance.now()
  if (!channel || (cursor && now - lastCursor < 40)) return
  lastCursor = now
  channel.send({ type: 'broadcast', event: 'cursor', payload: { key: myKey, cursor, frameId: useEditor.getState().activeFrameId } })
}

let lastLive = 0
let pendingLive: LiveItem[] | null = null
let liveTimer: ReturnType<typeof setTimeout> | undefined
export function sendLive(items: LiveItem[]) {
  if (!channel) return
  const now = performance.now()
  const send = (it: LiveItem[]) => { lastLive = performance.now(); channel?.send({ type: 'broadcast', event: 'live', payload: { frameId: useEditor.getState().activeFrameId, items: it } }) }
  if (now - lastLive >= 33) { send(items); pendingLive = null; return }
  pendingLive = items
  clearTimeout(liveTimer)
  liveTimer = setTimeout(() => { if (pendingLive) send(pendingLive); pendingLive = null }, 34)
}

export function stopCollab() {
  setBroadcaster(null)
  if (channel) {
    ;(channel as unknown as { _unsub?: () => void })._unsub?.()
    supabase.removeChannel(channel)
    channel = null
  }
  useEditor.setState({ peers: {} })
}

export { diffDocs, applyPatch }
