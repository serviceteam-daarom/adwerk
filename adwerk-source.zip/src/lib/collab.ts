import type { RealtimeChannel } from '@supabase/supabase-js'
import { supabase } from './supabase'
import type { DesignDoc, El, Frame } from './types'
import { useEditor, setBroadcaster, type Peer } from '../store/editor'
import { clone } from './factory'

interface FramePatch {
  id: string
  meta?: Partial<Omit<Frame, 'elements'>>
  full?: Frame
  upserts?: El[]
  deletes?: string[]
  order?: string[]
}
interface DocPatch { frameOrder?: string[]; removed?: string[]; frames: FramePatch[]; colors?: string[] }

const META_KEYS = ['name', 'w', 'h', 'platform', 'background', 'duration', 'safeZone'] as const

export function diffDocs(a: DesignDoc, b: DesignDoc): DocPatch | null {
  const patch: DocPatch = { frames: [] }
  const aMap = new Map(a.frames.map((f) => [f.id, f]))
  const bIds = b.frames.map((f) => f.id)
  if (bIds.join() !== a.frames.map((f) => f.id).join()) patch.frameOrder = bIds
  const removed = a.frames.filter((f) => !bIds.includes(f.id)).map((f) => f.id)
  if (removed.length) patch.removed = removed
  if (JSON.stringify(a.colors || []) !== JSON.stringify(b.colors || [])) patch.colors = b.colors || []
  for (const f of b.frames) {
    const pf = aMap.get(f.id)
    if (!pf) { patch.frames.push({ id: f.id, full: f }); continue }
    const fp: FramePatch = { id: f.id }
    const meta: Record<string, unknown> = {}
    for (const k of META_KEYS) if (JSON.stringify(pf[k]) !== JSON.stringify(f[k])) meta[k] = f[k]
    if (Object.keys(meta).length) fp.meta = meta as FramePatch['meta']
    const pe = new Map(pf.elements.map((e) => [e.id, JSON.stringify(e)]))
    const ups = f.elements.filter((e) => pe.get(e.id) !== JSON.stringify(e))
    if (ups.length) fp.upserts = ups
    const ids = f.elements.map((e) => e.id)
    const dels = pf.elements.filter((e) => !ids.includes(e.id)).map((e) => e.id)
    if (dels.length) fp.deletes = dels
    const hasNew = ids.some((i) => !pe.has(i))
    const sameOrder = ids.filter((i) => pe.has(i)).join() === pf.elements.map((e) => e.id).filter((i) => ids.includes(i)).join()
    if (hasNew || !sameOrder) fp.order = ids
    if (fp.meta || fp.upserts || fp.deletes || fp.order) patch.frames.push(fp)
  }
  if (!patch.frames.length && !patch.frameOrder && !patch.removed && !patch.colors) return null
  return patch
}

export function applyPatch(doc: DesignDoc, p: DocPatch): DesignDoc {
  const d = clone(doc)
  if (p.removed) d.frames = d.frames.filter((f) => !p.removed!.includes(f.id))
  if (p.colors) d.colors = p.colors
  for (const fp of p.frames) {
    const i = d.frames.findIndex((f) => f.id === fp.id)
    if (fp.full) { if (i >= 0) d.frames[i] = fp.full; else d.frames.push(fp.full); continue }
    if (i < 0) continue
    const f = d.frames[i]
    if (fp.meta) Object.assign(f, fp.meta)
    if (fp.deletes) f.elements = f.elements.filter((e) => !fp.deletes!.includes(e.id))
    for (const u of fp.upserts || []) {
      const j = f.elements.findIndex((e) => e.id === u.id)
      if (j >= 0) f.elements[j] = u; else f.elements.push(u)
    }
    if (fp.order) {
      const pos = new Map(fp.order.map((id, k) => [id, k]))
      f.elements.sort((x, y) => (pos.get(x.id) ?? 1e9) - (pos.get(y.id) ?? 1e9))
    }
  }
  if (p.frameOrder) {
    const pos = new Map(p.frameOrder.map((id, k) => [id, k]))
    d.frames.sort((x, y) => (pos.get(x.id) ?? 1e9) - (pos.get(y.id) ?? 1e9))
  }
  return d
}

export interface Me { id: string; name: string; color: string; avatar?: string | null }

let channel: RealtimeChannel | null = null
const sessionId = Math.random().toString(36).slice(2, 8)
let lastCursor = 0

export function startCollab(designId: string, me: Me) {
  stopCollab()
  let synced = false
  const ch = supabase.channel(`design:${designId}`, { config: { broadcast: { self: false }, presence: { key: `${me.id}:${sessionId}` } } })
  channel = ch

  ch.on('broadcast', { event: 'patch' }, ({ payload }) => {
    const s = useEditor.getState()
    s.setDoc(applyPatch(s.doc, payload as DocPatch), { remote: true })
  })
  ch.on('broadcast', { event: 'live' }, ({ payload }) => {
    const { frameId, items } = payload as { frameId: string; items: { id: string; x: number; y: number; rotation: number }[] }
    const s = useEditor.getState()
    const d = clone(s.doc)
    const f = d.frames.find((x) => x.id === frameId)
    if (!f) return
    for (const it of items) {
      const e = f.elements.find((x) => x.id === it.id)
      if (e) Object.assign(e, { x: it.x, y: it.y, rotation: it.rotation })
    }
    s.setDoc(d, { remote: true })
  })
  ch.on('broadcast', { event: 'cursor' }, ({ payload }) => {
    const { key, cursor, frameId } = payload as { key: string; cursor: Peer['cursor']; frameId: string }
    useEditor.setState((st) => (st.peers[key] ? { peers: { ...st.peers, [key]: { ...st.peers[key], cursor, frameId } } } : st))
  })
  ch.on('broadcast', { event: 'sync-req' }, () => {
    if (synced) ch.send({ type: 'broadcast', event: 'sync-full', payload: { doc: useEditor.getState().doc } })
  })
  ch.on('broadcast', { event: 'sync-full' }, ({ payload }) => {
    if (synced) return
    synced = true
    useEditor.getState().setDoc((payload as { doc: DesignDoc }).doc, { remote: true })
  })
  ch.on('presence', { event: 'sync' }, () => {
    const state = ch.presenceState() as Record<string, Peer[]>
    const peers: Record<string, Peer> = {}
    const prev = useEditor.getState().peers
    for (const [key, metas] of Object.entries(state)) {
      if (key === `${me.id}:${sessionId}`) continue
      const m = metas[0]
      peers[key] = { ...m, cursor: prev[key]?.cursor ?? null }
    }
    useEditor.setState({ peers })
  })

  ch.subscribe(async (status) => {
    if (status !== 'SUBSCRIBED') return
    const st = useEditor.getState()
    await ch.track({ id: me.id, name: me.name, color: me.color, avatar: me.avatar, frameId: st.activeFrameId, selection: st.selectedIds })
    ch.send({ type: 'broadcast', event: 'sync-req', payload: {} })
    setTimeout(() => { synced = true }, 1500)
  })

  setBroadcaster((prev, next) => {
    const p = diffDocs(prev, next)
    if (p && channel) channel.send({ type: 'broadcast', event: 'patch', payload: p })
  })

  // presence bijwerken bij wisselen van formaat of selectie
  let lastKey = ''
  const unsub = useEditor.subscribe((s) => {
    const key = s.activeFrameId + '|' + s.selectedIds.join(',')
    if (key === lastKey || !channel) return
    lastKey = key
    channel.track({ id: me.id, name: me.name, color: me.color, avatar: me.avatar, frameId: s.activeFrameId, selection: s.selectedIds })
  })
  ;(ch as unknown as { _unsub: () => void })._unsub = unsub
}

export function sendCursor(cursor: { x: number; y: number } | null) {
  const now = performance.now()
  if (!channel || (cursor && now - lastCursor < 45)) return
  lastCursor = now
  const s = useEditor.getState()
  const me = Object.keys(channel.presenceState()).find((k) => k.endsWith(':' + sessionId))
  channel.send({ type: 'broadcast', event: 'cursor', payload: { key: me, cursor, frameId: s.activeFrameId } })
}

let lastLive = 0
export function sendLive(items: { id: string; x: number; y: number; rotation: number }[]) {
  const now = performance.now()
  if (!channel || now - lastLive < 50) return
  lastLive = now
  channel.send({ type: 'broadcast', event: 'live', payload: { frameId: useEditor.getState().activeFrameId, items } })
}

export function stopCollab() {
  setBroadcaster(null)
  if (channel) {
    ;(channel as unknown as { _unsub?: () => void })._unsub?.()
    supabase.removeChannel(channel)
    channel = null
  }
  useEditor.setState({ peers: {} })
}
