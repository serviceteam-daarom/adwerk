/** SVG's betrouwbaar laten tekenen: xmlns, viewBox en een vaste (grote) breedte/hoogte, zonder scripts.
 *  Zonder vaste maat tekent een browser een SVG op 0×0 of 300×150, en een klein icoon (24×24) wordt wazig opgeschaald. */
export function normalizeSvg(text: string, longSide?: number): { svg: string; w: number; h: number } | null {
  let s = text.replace(/^﻿/, '').trim()
  const start = s.search(/<svg[\s>]/i)
  if (start < 0) return null
  s = s.slice(start)
  s = s.replace(/<script[\s\S]*?<\/script>/gi, '').replace(/\son[a-z]+\s*=\s*("[^"]*"|'[^']*')/gi, '')
  const open = s.match(/<svg\b[^>]*>/i)
  if (!open) return null
  let tag = open[0]
  const attr = (n: string) => { const m = tag.match(new RegExp(`\\s${n}\\s*=\\s*("([^"]*)"|'([^']*)')`, 'i')); return m ? (m[2] ?? m[3]) : null }
  const num = (v: string | null) => { if (!v || /%$/.test(v.trim())) return 0; const n = parseFloat(v); if (!isFinite(n) || n <= 0) return 0; const u = v.trim().replace(/^[-+]?[\d.]+(e[-+]?\d+)?/i, '').trim().toLowerCase(); return n * ({ pt: 4 / 3, pc: 16, mm: 3.7795, cm: 37.795, in: 96, em: 16, rem: 16 } as Record<string, number>)[u] || n }
  const vb = (attr('viewBox') || '').trim().split(/[\s,]+/).map(Number)
  const hasVb = vb.length === 4 && vb.every(isFinite) && vb[2] > 0 && vb[3] > 0
  let w = num(attr('width')), h = num(attr('height'))
  if (hasVb) { if (!w && !h) { w = vb[2]; h = vb[3] } else if (!w) w = h * vb[2] / vb[3]; else if (!h) h = w * vb[3] / vb[2] }
  if (!w || !h) { w = w || 1000; h = h || 1000 }
  const strip = (n: string) => { tag = tag.replace(new RegExp(`\\s${n}\\s*=\\s*("[^"]*"|'[^']*')`, 'i'), '') }
  strip('width'); strip('height')
  const extra: string[] = []
  if (!hasVb) extra.push(`viewBox="0 0 ${+w.toFixed(3)} ${+h.toFixed(3)}"`)
  if (!/\sxmlns\s*=/.test(tag)) extra.push('xmlns="http://www.w3.org/2000/svg"')
  if (/xlink:/.test(s) && !/xmlns:xlink/.test(tag)) extra.push('xmlns:xlink="http://www.w3.org/1999/xlink"')
  const k = longSide ? longSide / Math.max(w, h) : 1
  const W = Math.round(w * k * 100) / 100, H = Math.round(h * k * 100) / 100
  if (!/\spreserveAspectRatio\s*=/.test(tag) && !hasVb) extra.push('preserveAspectRatio="xMidYMid meet"')
  tag = tag.replace(/^<svg\b/i, `<svg width="${W}" height="${H}" ${extra.join(' ')}`).replace(/\s+>$/, '>').replace(/\s{2,}/g, ' ')
  s = s.replace(open[0], tag)
  return { svg: s, w, h }
}

export const isSvgSrc = (src: string) => /^data:image\/svg/i.test(src) || /\.svg(\?|#|$)/i.test(src)
