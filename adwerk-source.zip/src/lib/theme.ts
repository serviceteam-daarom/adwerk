import { create } from 'zustand'

export type ThemeMode = 'light' | 'dark' | 'system'

const read = (): ThemeMode => { try { return (localStorage.getItem('adwerk.theme') as ThemeMode) || 'system' } catch { return 'system' } }
const mq = () => window.matchMedia('(prefers-color-scheme: dark)')

export function applyTheme(mode: ThemeMode) {
  const dark = mode === 'dark' || (mode === 'system' && mq().matches)
  document.documentElement.classList.toggle('dark', dark)
  document.querySelector('meta[name="theme-color"]')?.setAttribute('content', dark ? '#0B0E1E' : '#1B213B')
}

export const useTheme = create<{ mode: ThemeMode; setMode: (m: ThemeMode) => void }>((set) => ({
  mode: read(),
  setMode: (m) => { try { localStorage.setItem('adwerk.theme', m) } catch { /* */ } applyTheme(m); set({ mode: m }) },
}))

applyTheme(read())
mq().addEventListener('change', () => applyTheme(useTheme.getState().mode))
