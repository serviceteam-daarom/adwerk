import type { DesignDoc, El, Frame } from './types'
import { clone } from './factory'

export interface FramePatch {
  id: string
  meta?: Partial<Omit<Frame, 'elements'>>
  full?: Frame
  upserts?: El[]
  deletes?: string[]
  order?: string[]
}
export interface DocPatch { frameOrder?: string[]; removed?: string[]; frames: FramePatch[]; colors?: string[] }

const META_KEYS = ['name', 'w', 'h', 'platform', 'background', 'duration', 'safeZone', 'groups'] as const

export function diffDocs(a: DesignDoc, b: DesignDoc): DocPatch | null {
  const patch: DocPatch = { frames: [] }
  const aMap = new Map(a.frames.map((f) => [f.id, f]))
  const bIds = b.frames.map((f) => f.id)
  if (bIds.join() !== a.frames.map((f) => f.id).join()) patch.frameOrder = bIds
  const removed = a.frames.filter((f) => !bIds.includes(f.id)).map((f) => f.id)
  if (removed.length) patch.removed = removed
  if (JSON.stringify(a.colors || []) !== JSON.stringify(b.colors || [])) patch.colors = b.colors || []
  for (const f of b.frames) {
    const pf = aMap.get(f.id)
    if (!pf) { patch.frames.push({ id: f.id, full: f }); continue }
    const fp: FramePatch = { id: f.id }
    const meta: Record<string, unknown> = {}
    for (const k of META_KEYS) if (JSON.stringify(pf[k]) !== JSON.stringify(f[k])) meta[k] = f[k] === undefined ? null : f[k]
    if (Object.keys(meta).length) fp.meta = meta as FramePatch['meta']
    const pe = new Map(pf.elements.map((e) => [e.id, JSON.stringify(e)]))
    const ups = f.elements.filter((e) => pe.get(e.id) !== JSON.stringify(e))
    if (ups.length) fp.upserts = ups
    const ids = f.elements.map((e) => e.id)
    const dels = pf.elements.filter((e) => !ids.includes(e.id)).map((e) => e.id)
    if (dels.length) fp.deletes = dels
    const hasNew = ids.some((i) => !pe.has(i))
    const sameOrder = ids.filter((i) => pe.has(i)).join() === pf.elements.map((e) => e.id).filter((i) => ids.includes(i)).join()
    if (hasNew || !sameOrder) fp.order = ids
    if (fp.meta || fp.upserts || fp.deletes || fp.order) patch.frames.push(fp)
  }
  if (!patch.frames.length && !patch.frameOrder && !patch.removed && !patch.colors) return null
  return patch
}

export function applyPatch(doc: DesignDoc, p: DocPatch): DesignDoc {
  const d = clone(doc)
  if (p.removed) d.frames = d.frames.filter((f) => !p.removed!.includes(f.id))
  if (p.colors) d.colors = p.colors
  for (const fp of p.frames) {
    const i = d.frames.findIndex((f) => f.id === fp.id)
    if (fp.full) { if (i >= 0) d.frames[i] = fp.full; else d.frames.push(fp.full); continue }
    if (i < 0) continue
    const f = d.frames[i]
    if (fp.meta) for (const [k, v] of Object.entries(fp.meta)) { if (v === null) delete (f as unknown as Record<string, unknown>)[k]; else (f as unknown as Record<string, unknown>)[k] = v }
    if (fp.deletes) f.elements = f.elements.filter((e) => !fp.deletes!.includes(e.id))
    for (const u of fp.upserts || []) {
      const j = f.elements.findIndex((e) => e.id === u.id)
      if (j >= 0) f.elements[j] = u; else f.elements.push(u)
    }
    if (fp.order) {
      const pos = new Map(fp.order.map((id, k) => [id, k]))
      f.elements.sort((x, y) => (pos.get(x.id) ?? 1e9) - (pos.get(y.id) ?? 1e9))
    }
  }
  if (p.frameOrder) {
    const pos = new Map(p.frameOrder.map((id, k) => [id, k]))
    d.frames.sort((x, y) => (pos.get(x.id) ?? 1e9) - (pos.get(y.id) ?? 1e9))
  }
  return d
}

