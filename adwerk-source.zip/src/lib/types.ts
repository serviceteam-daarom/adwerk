export type ElType = 'text' | 'rect' | 'ellipse' | 'triangle' | 'star' | 'line' | 'image' | 'icon'

export type InAnim = 'none' | 'fade' | 'slideUp' | 'slideDown' | 'slideLeft' | 'slideRight' | 'zoomIn' | 'zoomOut' | 'pop' | 'spin'
export type EmphAnim = 'none' | 'pulse' | 'wiggle' | 'float' | 'blink'

export interface AnimStep { type: InAnim; delay: number; duration: number }
export interface ElAnim { in: AnimStep; out: AnimStep; emph: { type: EmphAnim; speed: number } }

export interface Shadow { enabled: boolean; color: string; blur: number; x: number; y: number; opacity: number }
export interface Filters { brightness: number; contrast: number; saturation: number; hue: number; blur: number; grayscale: boolean }

export interface El {
  id: string
  type: ElType
  name: string
  x: number
  y: number
  width: number
  height: number
  rotation: number
  opacity: number
  visible: boolean
  locked: boolean
  fill: string
  stroke: string
  strokeWidth: number
  cornerRadius: number
  shadow: Shadow
  blend: string
  filters?: Filters
  anim?: ElAnim
  // tekst
  text?: string
  fontFamily?: string
  fontSize?: number
  fontWeight?: number
  italic?: boolean
  underline?: boolean
  align?: 'left' | 'center' | 'right'
  lineHeight?: number
  letterSpacing?: number
  uppercase?: boolean
  /** opmaak per stukje tekst (vet, cursief, onderstreept, kleur); samen precies `text` */
  runs?: import('./richtext').Run[]
  // afbeelding
  src?: string
  cropZoom?: number
  cropX?: number
  cropY?: number
  flipX?: boolean
  flipY?: boolean
  // ster
  points?: number
  innerRatio?: number
  // icoon (lucide-naam of Iconify-svg)
  icon?: string
  iconSvg?: string
  iconId?: string
  iconMulti?: boolean
  // groep (elementen met dezelfde groupId bewegen, schalen en animeren samen)
  groupId?: string
  // afbeeldingsmasker
  mask?: 'none' | 'circle' | 'arch' | 'oval' | 'leaf' | 'blob'
}

export interface Background { type: 'solid' | 'gradient' | 'image'; color: string; color2: string; angle: number; src?: string }

export interface Frame {
  id: string
  name: string
  w: number
  h: number
  platform: string
  background: Background
  elements: El[]
  duration: number
  safeZone?: boolean
  groups?: Group[]
}

/** Groep binnen een formaat. Met anim beweegt de hele groep als één geheel (draaipunt = midden van de groep). */
export interface Group { id: string; name: string; anim?: ElAnim }

export interface DesignDoc { version: 1; frames: Frame[]; colors?: string[]; brief?: Brief }

/** Campagnebrief per ontwerp: vrij invulbare velden (doelgroep, budget, doel, landingspagina, vorm, koppen, teksten...). */
export type BriefKind = 'text' | 'longtext' | 'url' | 'list'
export interface BriefField { id: string; label: string; kind: BriefKind; value: string; items?: string[]; hidden?: boolean; preset?: string; utm?: Record<string, string> }
export interface Brief { fields: BriefField[]; showClient?: boolean }

export interface DesignRow {
  id: string
  title: string
  owner_id: string
  folder_id: string | null
  visibility: 'private' | 'team'
  is_template: boolean
  data: DesignDoc
  thumbnail: string | null
  updated_at: string
  created_at: string
  updated_by?: string | null
  status?: DesignStatus
  status_at?: string | null
  start_date?: string | null
  end_date?: string | null
  position?: number | null
}

export type DesignStatus = 'concept' | 'intern' | 'klant' | 'aanpassen' | 'goedgekeurd' | 'live' | 'analyseren'
export interface DesignVersion { id: string; design_id: string; number: number; note: string | null; data?: DesignDoc; thumbnail: string | null; created_by: string | null; created_at: string }
export interface Approval { id: string; design_id: string; version: number | null; decision: 'approved' | 'changes'; name: string; note: string | null; by_user: string | null; created_at: string }

export interface Profile { id: string; email: string; full_name: string; avatar_url: string | null; color: string | null }
export interface Folder { id: string; name: string; owner_id: string; visibility: 'private' | 'team'; created_at: string; brief?: ClientBrief | null; website?: string | null; color?: string | null; brand_kit_id?: string | null }

/** Klantbrief per project: afspraken, doelen, budget en campagnes. */
export interface ClientCampaign { id: string; name: string; channel: string; goal: string; budget: string; start: string | null; end: string | null; status: string; note: string }
export interface ClientBrief { sections: { id: string; label: string; value: string }[]; campaigns: ClientCampaign[] }
export interface BrandKit { id: string; name: string; owner_id: string; colors: string[]; fonts: string[]; logos: { url: string; name: string }[] }
export interface Asset { id: string; owner_id: string; url: string; path: string; name: string; width: number; height: number; shared: boolean; created_at: string }
