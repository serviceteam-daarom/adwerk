export type ElType = 'text' | 'rect' | 'ellipse' | 'triangle' | 'star' | 'line' | 'image' | 'icon'

export type InAnim = 'none' | 'fade' | 'slideUp' | 'slideDown' | 'slideLeft' | 'slideRight' | 'zoomIn' | 'zoomOut' | 'pop' | 'spin'
export type EmphAnim = 'none' | 'pulse' | 'wiggle' | 'float' | 'blink'

export interface AnimStep { type: InAnim; delay: number; duration: number }
export interface ElAnim { in: AnimStep; out: AnimStep; emph: { type: EmphAnim; speed: number } }

export interface Shadow { enabled: boolean; color: string; blur: number; x: number; y: number; opacity: number }
export interface Filters { brightness: number; contrast: number; saturation: number; hue: number; blur: number; grayscale: boolean }

export interface El {
  id: string
  type: ElType
  name: string
  x: number
  y: number
  width: number
  height: number
  rotation: number
  opacity: number
  visible: boolean
  locked: boolean
  fill: string
  stroke: string
  strokeWidth: number
  cornerRadius: number
  shadow: Shadow
  blend: string
  filters?: Filters
  anim?: ElAnim
  // tekst
  text?: string
  fontFamily?: string
  fontSize?: number
  fontWeight?: number
  italic?: boolean
  underline?: boolean
  align?: 'left' | 'center' | 'right'
  lineHeight?: number
  letterSpacing?: number
  uppercase?: boolean
  // afbeelding
  src?: string
  cropZoom?: number
  cropX?: number
  cropY?: number
  flipX?: boolean
  flipY?: boolean
  // ster
  points?: number
  innerRatio?: number
  // icoon
  icon?: string
}

export interface Background { type: 'solid' | 'gradient' | 'image'; color: string; color2: string; angle: number; src?: string }

export interface Frame {
  id: string
  name: string
  w: number
  h: number
  platform: string
  background: Background
  elements: El[]
  duration: number
  safeZone?: boolean
}

export interface DesignDoc { version: 1; frames: Frame[]; colors?: string[] }

export interface DesignRow {
  id: string
  title: string
  owner_id: string
  folder_id: string | null
  visibility: 'private' | 'team'
  is_template: boolean
  data: DesignDoc
  thumbnail: string | null
  updated_at: string
  created_at: string
  updated_by?: string | null
}

export interface Profile { id: string; email: string; full_name: string; avatar_url: string | null; color: string | null }
export interface Folder { id: string; name: string; owner_id: string; visibility: 'private' | 'team'; created_at: string }
export interface BrandKit { id: string; name: string; owner_id: string; colors: string[]; fonts: string[]; logos: { url: string; name: string }[] }
export interface Asset { id: string; owner_id: string; url: string; path: string; name: string; width: number; height: number; shared: boolean; created_at: string }
