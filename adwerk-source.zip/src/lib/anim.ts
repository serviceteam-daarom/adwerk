import type { El, ElAnim, Frame, InAnim, EmphAnim } from './types'

export interface AnimState { dx: number; dy: number; scale: number; rotation: number; opacity: number }

const clamp01 = (v: number) => Math.max(0, Math.min(1, v))
export const easeOutCubic = (t: number) => 1 - Math.pow(1 - t, 3)
export const easeOutBack = (t: number) => {
  const c1 = 1.70158, c3 = c1 + 1
  return 1 + c3 * Math.pow(t - 1, 3) + c1 * Math.pow(t - 1, 2)
}

export function slideDistance(frame: { w: number; h: number }) {
  return Math.round(Math.min(frame.w, frame.h) * 0.18)
}

/** Toestand van een in-animatie bij voortgang p (0 = start, 1 = rust). */
export function inState(type: InAnim, p: number, dist: number): AnimState {
  const e = easeOutCubic(p)
  const s: AnimState = { dx: 0, dy: 0, scale: 1, rotation: 0, opacity: 1 }
  switch (type) {
    case 'fade': s.opacity = e; break
    case 'slideUp': s.dy = (1 - e) * dist; s.opacity = e; break
    case 'slideDown': s.dy = -(1 - e) * dist; s.opacity = e; break
    case 'slideLeft': s.dx = (1 - e) * dist; s.opacity = e; break
    case 'slideRight': s.dx = -(1 - e) * dist; s.opacity = e; break
    case 'zoomIn': s.scale = 0.6 + 0.4 * e; s.opacity = e; break
    case 'zoomOut': s.scale = 1.4 - 0.4 * e; s.opacity = e; break
    case 'pop': s.scale = Math.max(0, easeOutBack(p)); s.opacity = clamp01(p * 3); break
    case 'spin': s.rotation = -120 * (1 - e); s.scale = 0.3 + 0.7 * e; s.opacity = e; break
  }
  return s
}

export function emphState(type: EmphAnim, t: number, speed: number): AnimState {
  const s: AnimState = { dx: 0, dy: 0, scale: 1, rotation: 0, opacity: 1 }
  const ph = (t * speed * Math.PI * 2) / 1.6
  switch (type) {
    case 'pulse': s.scale = 1 + 0.06 * (0.5 - 0.5 * Math.cos(ph)); break
    case 'wiggle': s.rotation = 4 * Math.sin(ph * 2); break
    case 'float': s.dy = -8 * (0.5 - 0.5 * Math.cos(ph)); break
    case 'blink': s.opacity = 0.35 + 0.65 * (0.5 + 0.5 * Math.cos(ph)); break
  }
  return s
}

export function stateAt(el: El, frame: Frame, t: number): AnimState { return animStateAt(el.anim, frame, t) }

/** Draait/schaalt punt (x,y) rond draaipunt (px,py) volgens toestand s en verschuift het. */
export function aroundPivot(x: number, y: number, px: number, py: number, s: AnimState) {
  const r = (s.rotation * Math.PI) / 180, c = Math.cos(r), n = Math.sin(r)
  const vx = (x - px) * s.scale, vy = (y - py) * s.scale
  return { x: px + vx * c - vy * n + s.dx, y: py + vx * n + vy * c + s.dy }
}

export function animStateAt(a: ElAnim | undefined, frame: Frame, t: number): AnimState {
  const st: AnimState = { dx: 0, dy: 0, scale: 1, rotation: 0, opacity: 1 }
  if (!a) return st
  const dist = slideDistance(frame)
  const parts: AnimState[] = []
  let inEnd = 0
  if (a.in.type !== 'none') {
    const p = clamp01((t - a.in.delay) / Math.max(0.01, a.in.duration))
    parts.push(inState(a.in.type, p, dist))
    inEnd = a.in.delay + a.in.duration
  }
  if (a.emph.type !== 'none' && t > inEnd) parts.push(emphState(a.emph.type, t - inEnd, a.emph.speed || 1))
  if (a.out.type !== 'none') {
    const start = frame.duration - a.out.duration - a.out.delay
    const q = clamp01((t - start) / Math.max(0.01, a.out.duration))
    if (q > 0) parts.push(inState(a.out.type, 1 - q, dist))
  }
  for (const p of parts) {
    st.dx += p.dx; st.dy += p.dy; st.scale *= p.scale; st.rotation += p.rotation; st.opacity *= p.opacity
  }
  return st
}

export const IN_ANIMS: { key: InAnim; name: string }[] = [
  { key: 'none', name: 'Geen' },
  { key: 'fade', name: 'Vervagen' },
  { key: 'slideUp', name: 'Omhoog schuiven' },
  { key: 'slideDown', name: 'Omlaag schuiven' },
  { key: 'slideLeft', name: 'Van rechts' },
  { key: 'slideRight', name: 'Van links' },
  { key: 'zoomIn', name: 'Inzoomen' },
  { key: 'zoomOut', name: 'Uitzoomen' },
  { key: 'pop', name: 'Ploppen' },
  { key: 'spin', name: 'Draaien' },
]

export const EMPH_ANIMS: { key: EmphAnim; name: string }[] = [
  { key: 'none', name: 'Geen' },
  { key: 'pulse', name: 'Pulseren' },
  { key: 'wiggle', name: 'Wiebelen' },
  { key: 'float', name: 'Zweven' },
  { key: 'blink', name: 'Knipperen' },
]
