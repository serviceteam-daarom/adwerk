import type { El, Frame, Group } from './types'
import { uid } from './factory'

export interface Box { x: number; y: number; w: number; h: number }
export const elBox = (e: El): Box => ({ x: e.x, y: e.y, w: e.width, h: e.height })
export const unionBox = (bs: Box[]): Box => {
  const x = Math.min(...bs.map((b) => b.x)), y = Math.min(...bs.map((b) => b.y))
  return { x, y, w: Math.max(...bs.map((b) => b.x + b.w)) - x, h: Math.max(...bs.map((b) => b.y + b.h)) - y }
}

export const groupOf = (f: Frame, gid?: string | null) => (gid ? (f.groups || []).find((g) => g.id === gid) || null : null)
export const membersOf = (f: Frame, gid: string) => f.elements.filter((e) => e.groupId === gid)
export function groupBox(f: Frame, gid: string): Box | null {
  const m = membersOf(f, gid)
  return m.length ? unionBox(m.map(elBox)) : null
}

/** Selectie uitbreiden met alle leden van de groepen waar iets uit geselecteerd is. */
export function expandToGroups(f: Frame, ids: string[]) {
  const gids = new Set(f.elements.filter((e) => ids.includes(e.id) && e.groupId).map((e) => e.groupId!))
  if (!gids.size) return ids
  const out = new Set(ids)
  for (const e of f.elements) if (e.groupId && gids.has(e.groupId)) out.add(e.id)
  return f.elements.filter((e) => out.has(e.id)).map((e) => e.id)
}

/** Is de selectie precies één volledige groep? Dan geeft dit die groep terug. */
export function selectedGroup(f: Frame, ids: string[]): Group | null {
  if (ids.length < 2) return null
  const els = f.elements.filter((e) => ids.includes(e.id))
  const gid = els[0]?.groupId
  if (!gid || els.some((e) => e.groupId !== gid)) return null
  return membersOf(f, gid).length === els.length ? groupOf(f, gid) : null
}

/** Eenheden voor uitlijnen en verdelen: een groep telt als één blok, losse elementen apart. */
export function unitsOf(f: Frame, ids: string[]) {
  const units: { key: string; ids: string[]; box: Box }[] = []
  const seen = new Set<string>()
  for (const e of f.elements) {
    if (!ids.includes(e.id) || seen.has(e.id)) continue
    const whole = e.groupId && membersOf(f, e.groupId).every((m) => ids.includes(m.id))
    if (whole) {
      const m = membersOf(f, e.groupId!)
      m.forEach((x) => seen.add(x.id))
      units.push({ key: e.groupId!, ids: m.map((x) => x.id), box: unionBox(m.map(elBox)) })
    } else { seen.add(e.id); units.push({ key: e.id, ids: [e.id], box: elBox(e) }) }
  }
  return units
}

export type AlignMode = 'left' | 'center' | 'right' | 'top' | 'middle' | 'bottom'
/** Verschuivingen per element om uit te lijnen. Eén eenheid wordt op het formaat uitgelijnd, meerdere onderling. */
export function alignDeltas(f: Frame, ids: string[], mode: AlignMode, to?: 'frame' | 'selection'): Record<string, { dx: number; dy: number }> {
  const units = unitsOf(f, ids)
  if (!units.length) return {}
  const rel = to || (units.length > 1 ? 'selection' : 'frame')
  const ref: Box = rel === 'frame' ? { x: 0, y: 0, w: f.w, h: f.h } : unionBox(units.map((u) => u.box))
  const out: Record<string, { dx: number; dy: number }> = {}
  for (const u of units) {
    const b = u.box
    let dx = 0, dy = 0
    if (mode === 'left') dx = ref.x - b.x
    if (mode === 'center') dx = ref.x + ref.w / 2 - (b.x + b.w / 2)
    if (mode === 'right') dx = ref.x + ref.w - (b.x + b.w)
    if (mode === 'top') dy = ref.y - b.y
    if (mode === 'middle') dy = ref.y + ref.h / 2 - (b.y + b.h / 2)
    if (mode === 'bottom') dy = ref.y + ref.h - (b.y + b.h)
    for (const id of u.ids) out[id] = { dx: Math.round(dx * 10) / 10, dy: Math.round(dy * 10) / 10 }
  }
  return out
}

/** Gelijke tussenruimte (of een vaste ruimte met gap) tussen de eenheden, horizontaal of verticaal. */
export function distributeDeltas(f: Frame, ids: string[], axis: 'horizontal' | 'vertical', gap?: number): Record<string, { dx: number; dy: number }> {
  const units = unitsOf(f, ids)
  const h = axis === 'horizontal'
  if (units.length < (gap === undefined ? 3 : 2)) return {}
  const sorted = [...units].sort((a, b) => (h ? a.box.x - b.box.x : a.box.y - b.box.y))
  const start = h ? sorted[0].box.x : sorted[0].box.y
  const last = sorted[sorted.length - 1].box
  const total = sorted.reduce((s, u) => s + (h ? u.box.w : u.box.h), 0)
  const space = gap ?? ((h ? last.x + last.w : last.y + last.h) - start - total) / (sorted.length - 1)
  const out: Record<string, { dx: number; dy: number }> = {}
  let pos = start
  for (const u of sorted) {
    const d = Math.round((pos - (h ? u.box.x : u.box.y)) * 10) / 10
    for (const id of u.ids) out[id] = h ? { dx: d, dy: 0 } : { dx: 0, dy: d }
    pos += (h ? u.box.w : u.box.h) + space
  }
  return out
}

/** Groepen opruimen: groepen met minder dan twee leden vervallen, losse verwijzingen worden gewist. */
export function normalizeGroups(f: Frame) {
  const count: Record<string, number> = {}
  for (const e of f.elements) if (e.groupId) count[e.groupId] = (count[e.groupId] || 0) + 1
  const keep = new Set((f.groups || []).filter((g) => (count[g.id] || 0) >= 2).map((g) => g.id))
  for (const e of f.elements) if (e.groupId && !keep.has(e.groupId)) delete e.groupId
  const groups = (f.groups || []).filter((g) => keep.has(g.id))
  if (groups.length) f.groups = groups; else delete f.groups
}

/** Groep maken van ids (bestaande groepen worden samengevoegd). Leden komen direct op elkaar te liggen in de laagvolgorde, op de plek van het bovenste lid. */
export function makeGroup(f: Frame, ids: string[], name?: string): string | null {
  const members = f.elements.filter((e) => ids.includes(e.id))
  if (members.length < 2) return null
  const gid = uid()
  const n = (f.groups || []).length + 1
  f.groups = [...(f.groups || []), { id: gid, name: name || `Groep ${n}` }]
  const top = Math.max(...members.map((m) => f.elements.indexOf(m)))
  const rest = f.elements.filter((e) => !ids.includes(e.id))
  const insertAt = rest.filter((e) => f.elements.indexOf(e) < top).length
  for (const m of members) m.groupId = gid
  rest.splice(insertAt, 0, ...members)
  f.elements = rest
  normalizeGroups(f)
  return gid
}
export function ungroup(f: Frame, gid: string) {
  for (const e of f.elements) if (e.groupId === gid) delete e.groupId
  normalizeGroups(f)
}

/** Groepen meenemen bij kopiëren: nieuwe groep-id's voor de kopieën. */
export function remapGroups(els: El[], srcGroups: Group[] | undefined, target: Frame) {
  const map: Record<string, string> = {}
  for (const e of els) {
    if (!e.groupId) continue
    if (!map[e.groupId]) {
      const src = (srcGroups || []).find((g) => g.id === e.groupId)
      const nid = uid()
      map[e.groupId] = nid
      target.groups = [...(target.groups || []), { ...(src ? JSON.parse(JSON.stringify(src)) : { name: 'Groep' }), id: nid }]
    }
    e.groupId = map[e.groupId]
  }
}
