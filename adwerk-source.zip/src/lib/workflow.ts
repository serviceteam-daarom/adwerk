import { supabase } from './supabase'
import type { Approval, DesignDoc, DesignStatus, DesignVersion } from './types'
import { listLinks, createLink, reviewUrl } from './comments'

/** De stappen van een ontwerp, van eerste opzet tot live. */
export const STATUSES: { key: DesignStatus; label: string; color: string; hint: string }[] = [
  { key: 'concept', label: 'Concept', color: '#8A879C', hint: 'Wordt aan gewerkt' },
  { key: 'intern', label: 'Interne check', color: '#5B3FD9', hint: 'Klaar voor een collega om na te kijken' },
  { key: 'klant', label: 'Bij klant', color: '#1A5FC4', hint: 'Versie staat klaar in de feedbacklink' },
  { key: 'aanpassen', label: 'Aanpassen', color: '#CC4A25', hint: 'Klant of collega vraagt om aanpassingen' },
  { key: 'goedgekeurd', label: 'Goedgekeurd', color: '#13A06B', hint: 'Akkoord van de klant' },
  { key: 'live', label: 'Live', color: '#1B213B', hint: 'Staat online of draait als advertentie' },
]
export const statusOf = (s?: string | null) => STATUSES.find((x) => x.key === s) || STATUSES[0]

export async function setStatus(designId: string, status: DesignStatus, userId: string) {
  const { error } = await supabase.from('designs').update({ status, status_at: new Date().toISOString(), updated_by: userId }).eq('id', designId)
  if (error) throw new Error('Status wijzigen lukt niet')
}

export async function listVersions(designId: string, withData = false) {
  const { data } = await supabase.from('design_versions').select(withData ? '*' : 'id,design_id,number,note,thumbnail,created_by,created_at').eq('design_id', designId).order('number', { ascending: false })
  return (data || []) as unknown as DesignVersion[]
}
export async function getVersion(id: string) {
  const { data } = await supabase.from('design_versions').select('*').eq('id', id).single()
  return data as DesignVersion
}
export async function createVersion(designId: string, doc: DesignDoc, note: string, thumbnail: string | null, userId: string) {
  const { data: last } = await supabase.from('design_versions').select('number').eq('design_id', designId).order('number', { ascending: false }).limit(1)
  const number = ((last || [])[0]?.number || 0) + 1
  const { data, error } = await supabase.from('design_versions').insert({ design_id: designId, number, note: note.trim() || null, data: doc, thumbnail, created_by: userId }).select('id,design_id,number,note,thumbnail,created_by,created_at').single()
  if (error) throw new Error('Versie opslaan lukt niet')
  return data as DesignVersion
}
export async function listApprovals(designId: string) {
  const { data } = await supabase.from('approvals').select('*').eq('design_id', designId).order('created_at', { ascending: false })
  return (data || []) as Approval[]
}
export async function addApproval(designId: string, a: { version: number | null; decision: 'approved' | 'changes'; name: string; note?: string }, userId: string) {
  const { error } = await supabase.from('approvals').insert({ design_id: designId, ...a, note: a.note?.trim() || null, by_user: userId })
  if (error) throw new Error('Opslaan lukt niet')
  await setStatus(designId, a.decision === 'approved' ? 'goedgekeurd' : 'aanpassen', userId)
}

/** Versie vastzetten, status op "Bij klant" en een feedbacklink klaarzetten. Geeft de link terug. */
export async function sendToClient(designId: string, doc: DesignDoc, note: string, thumbnail: string | null, userId: string) {
  const v = await createVersion(designId, doc, note, thumbnail, userId)
  await setStatus(designId, 'klant', userId)
  const links = await listLinks(designId)
  const link = links.find((l) => l.can_comment) || (await createLink(designId, 'Klant', true))
  return { version: v, url: reviewUrl(link.token) }
}
