import JSZip from 'jszip'
import { GIFEncoder, quantize, applyPalette } from 'gifenc'
import Konva from 'konva'
import type { El, Frame, InAnim, EmphAnim } from './types'
import { createOffscreen } from './render'
import { slideDistance } from './anim'

export function slug(s: string) {
  return s.toLowerCase().normalize('NFD').replace(/[̀-ͯ]/g, '').replace(/[^a-z0-9]+/g, '-').replace(/^-|-$/g, '') || 'ontwerp'
}

export function canvasToBlob(c: HTMLCanvasElement, type = 'image/png', q = 0.9): Promise<Blob> {
  return new Promise((res, rej) => c.toBlob((b) => (b ? res(b) : rej(new Error('Export mislukt'))), type, q))
}

export function downloadBlob(blob: Blob, name: string) {
  const url = URL.createObjectURL(blob)
  const a = document.createElement('a')
  a.href = url
  a.download = name
  document.body.appendChild(a)
  a.click()
  a.remove()
  setTimeout(() => URL.revokeObjectURL(url), 4000)
}

export async function exportImage(frame: Frame, type: 'png' | 'jpg', scale = 1, quality = 0.9, atEnd = true) {
  const off = await createOffscreen(frame)
  try {
    const c = off.canvasAt(atEnd ? null : 0, scale)
    if (type === 'jpg') {
      // JPG heeft geen transparantie: wit eronder
      const c2 = document.createElement('canvas')
      c2.width = c.width; c2.height = c.height
      const ctx = c2.getContext('2d')!
      ctx.fillStyle = '#fff'; ctx.fillRect(0, 0, c2.width, c2.height); ctx.drawImage(c, 0, 0)
      return await canvasToBlob(c2, 'image/jpeg', quality)
    }
    return await canvasToBlob(c, 'image/png')
  } finally { off.destroy() }
}

export async function thumbnail(frame: Frame, maxSide = 360) {
  const off = await createOffscreen(frame)
  try {
    const r = Math.min(1, maxSide / Math.max(frame.w, frame.h))
    const c = off.canvasAt(null, r)
    const c2 = document.createElement('canvas')
    c2.width = c.width; c2.height = c.height
    const ctx = c2.getContext('2d')!
    ctx.fillStyle = '#fff'; ctx.fillRect(0, 0, c2.width, c2.height); ctx.drawImage(c, 0, 0)
    return c2.toDataURL('image/jpeg', 0.72)
  } finally { off.destroy() }
}

export async function exportGif(frame: Frame, opts: { fps: number; scale: number; loops: number; onProgress?: (p: number) => void }) {
  const off = await createOffscreen(frame)
  try {
    const total = Math.max(1, Math.round(frame.duration * opts.fps))
    const delay = Math.round(1000 / opts.fps)
    const gif = GIFEncoder()
    const w = Math.round(frame.w * opts.scale), h = Math.round(frame.h * opts.scale)
    const flat = document.createElement('canvas')
    flat.width = w; flat.height = h
    const fctx = flat.getContext('2d', { willReadFrequently: true })!
    let palette: number[][] | null = null
    for (let i = 0; i < total; i++) {
      const t = i / opts.fps
      const c = off.canvasAt(t, opts.scale)
      fctx.fillStyle = '#fff'; fctx.fillRect(0, 0, w, h); fctx.drawImage(c, 0, 0, w, h)
      const data = fctx.getImageData(0, 0, w, h).data
      if (!palette || i % 10 === 0) palette = quantize(data, 256)
      const index = applyPalette(data, palette)
      // gifenc: repeat 0 = oneindig, -1 = eenmalig, n = n herhalingen
      gif.writeFrame(index, w, h, { palette, delay, repeat: i === 0 ? (opts.loops === 0 ? 0 : opts.loops - 1 || -1) : undefined })
      opts.onProgress?.((i + 1) / total)
      if (i % 4 === 0) await new Promise((r) => setTimeout(r, 0))
    }
    gif.finish()
    return new Blob([gif.bytes()], { type: 'image/gif' })
  } finally { off.destroy() }
}

export async function exportVideo(frame: Frame, opts: { scale: number; fps: number; onProgress?: (p: number) => void }) {
  const off = await createOffscreen(frame)
  try {
    const w = Math.round(frame.w * opts.scale / 2) * 2, h = Math.round(frame.h * opts.scale / 2) * 2
    const c = document.createElement('canvas')
    c.width = w; c.height = h
    const ctx = c.getContext('2d')!
    const stream = c.captureStream(opts.fps)
    const types = ['video/mp4;codecs=avc1', 'video/mp4', 'video/webm;codecs=vp9', 'video/webm']
    const mime = types.find((t) => MediaRecorder.isTypeSupported(t)) || 'video/webm'
    const rec = new MediaRecorder(stream, { mimeType: mime, videoBitsPerSecond: 8_000_000 })
    const chunks: Blob[] = []
    rec.ondataavailable = (e) => e.data.size && chunks.push(e.data)
    const done = new Promise<void>((r) => (rec.onstop = () => r()))
    const draw = (t: number) => {
      const src = off.canvasAt(t, opts.scale)
      ctx.fillStyle = '#fff'; ctx.fillRect(0, 0, w, h); ctx.drawImage(src, 0, 0, w, h)
    }
    draw(0)
    rec.start()
    const start = performance.now()
    await new Promise<void>((resolve) => {
      const tick = () => {
        const t = (performance.now() - start) / 1000
        draw(Math.min(t, frame.duration))
        opts.onProgress?.(Math.min(1, t / frame.duration))
        if (t < frame.duration) requestAnimationFrame(tick)
        else resolve()
      }
      requestAnimationFrame(tick)
    })
    rec.stop()
    await done
    return { blob: new Blob(chunks, { type: mime.split(';')[0] }), ext: mime.includes('mp4') ? 'mp4' : 'webm' }
  } finally { off.destroy() }
}

/* ---------- HTML5 banners ---------- */

function inKeyframes(type: InAnim, dist: number, name: string) {
  const from: Record<InAnim, string> = {
    none: 'opacity:1', fade: 'opacity:0',
    slideUp: `opacity:0;transform:translateY(${dist}px)`, slideDown: `opacity:0;transform:translateY(${-dist}px)`,
    slideLeft: `opacity:0;transform:translateX(${dist}px)`, slideRight: `opacity:0;transform:translateX(${-dist}px)`,
    zoomIn: 'opacity:0;transform:scale(.6)', zoomOut: 'opacity:0;transform:scale(1.4)', pop: 'opacity:0;transform:scale(0)',
    spin: 'opacity:0;transform:rotate(-120deg) scale(.3)',
  }
  const mid = type === 'pop' ? `60%{opacity:1;transform:scale(1.1)}` : ''
  return `@keyframes ${name}{0%{${from[type]}}${mid}100%{opacity:1;transform:none}}`
}
function outKeyframes(type: InAnim, dist: number, name: string) {
  return inKeyframes(type, dist, name).replace(/0%\{([^}]*)\}(.*)100%\{([^}]*)\}/, '0%{$3}$2100%{$1}')
}
function emphKeyframes(type: EmphAnim, name: string) {
  const k: Record<EmphAnim, string> = {
    none: '',
    pulse: '0%,100%{transform:scale(1)}50%{transform:scale(1.06)}',
    wiggle: '0%,100%{transform:rotate(0)}25%{transform:rotate(4deg)}75%{transform:rotate(-4deg)}',
    float: '0%,100%{transform:translateY(0)}50%{transform:translateY(-8px)}',
    blink: '0%,100%{opacity:1}50%{opacity:.35}',
  }
  return `@keyframes ${name}{${k[type]}}`
}

/** Rendert één element los (zonder achtergrond) als PNG of JPG. */
async function rasterEl(frame: Frame, el: El, density: number) {
  const solo: Frame = { ...frame, background: { type: 'solid', color: 'rgba(0,0,0,0)', color2: '', angle: 0 }, elements: [{ ...el, anim: undefined, rotation: 0, opacity: 1 }] }
  const off = await createOffscreen(solo)
  try {
    const g = off.renderer.nodes.get(el.id)!
    const h = g.getAttr('h') ?? el.height
    const pad = el.shadow?.enabled ? Math.ceil(el.shadow.blur + Math.max(Math.abs(el.shadow.x), Math.abs(el.shadow.y))) : Math.ceil(el.strokeWidth / 2) + 1
    const box = { x: el.x - pad, y: el.y - pad, width: el.width + pad * 2, height: h + pad * 2 }
    off.layer.draw()
    const c = off.stage.toCanvas({ ...box, pixelRatio: density })
    const photo = el.type === 'image' && !el.cornerRadius && !el.shadow?.enabled
    const blob = photo ? await canvasToBlob(c, 'image/jpeg', 0.82) : await canvasToBlob(c, 'image/png')
    return { blob, ext: photo ? 'jpg' : 'png', box, h }
  } finally { off.destroy() }
}

export async function exportHtml5(frame: Frame, opts: { clickTag: string; loops: number; density: number }) {
  const zip = new JSZip()
  const dist = slideDistance(frame)
  const css: string[] = []
  const html: string[] = []
  let bgCss = `background:${frame.background.color};`
  if (frame.background.type === 'gradient') bgCss = `background:linear-gradient(${(frame.background.angle || 0) + 90}deg,${frame.background.color},${frame.background.color2});`
  if (frame.background.type === 'image' && frame.background.src) {
    const off = await createOffscreen({ ...frame, elements: [] })
    const b = await canvasToBlob(off.canvasAt(null, opts.density), 'image/jpeg', 0.8)
    off.destroy()
    zip.file('bg.jpg', b)
    bgCss = `background:url(bg.jpg) center/cover;`
  }
  let n = 0
  for (const el of frame.elements) {
    if (!el.visible) continue
    n++
    const { blob, ext, box } = await rasterEl(frame, el, opts.density)
    const file = `e${n}.${ext}`
    zip.file(file, blob)
    const a = el.anim
    const ani: string[] = []
    let wrapIn = '', wrapOut = '', wrapEm = ''
    if (a && a.in.type !== 'none') {
      css.push(inKeyframes(a.in.type, dist, `i${n}`))
      wrapIn = `animation:i${n} ${a.in.duration}s cubic-bezier(.33,1,.68,1) ${a.in.delay}s both;`
    }
    if (a && a.out.type !== 'none') {
      css.push(outKeyframes(a.out.type, dist, `o${n}`))
      const start = Math.max(0, frame.duration - a.out.duration - a.out.delay)
      wrapOut = `animation:o${n} ${a.out.duration}s cubic-bezier(.32,0,.67,0) ${start}s both;`
    }
    if (a && a.emph.type !== 'none') {
      css.push(emphKeyframes(a.emph.type, `m${n}`))
      const startE = a.in.type !== 'none' ? a.in.delay + a.in.duration : 0
      const period = 1.6 / (a.emph.speed || 1)
      const count = Math.max(1, Math.floor((frame.duration - startE) / period))
      wrapEm = `animation:m${n} ${period}s ease-in-out ${startE}s ${count};`
    }
    ani.push(wrapIn)
    const rot = el.rotation ? `transform:rotate(${el.rotation}deg);` : ''
    const blend = el.blend && el.blend !== 'source-over' ? `mix-blend-mode:${el.blend};` : ''
    html.push(
      `<div class="p" style="left:${box.x}px;top:${box.y}px;width:${box.width}px;height:${box.height}px;opacity:${el.opacity};${rot}${blend}">` +
      `<div class="w" style="${wrapIn}"><div class="w" style="${wrapOut}"><div class="w" style="${wrapEm}">` +
      `<img src="${file}" width="${box.width}" height="${box.height}" alt=""></div></div></div></div>`,
    )
  }
  const loops = Math.max(1, Math.min(3, opts.loops))
  const doc = `<!DOCTYPE html>
<html lang="nl"><head><meta charset="utf-8">
<meta name="ad.size" content="width=${frame.w},height=${frame.h}">
<meta name="viewport" content="width=${frame.w},height=${frame.h}">
<title>${frame.name}</title>
<script>var clickTag = "${opts.clickTag.replace(/"/g, '')}";</script>
<style>
*{margin:0;padding:0;box-sizing:border-box}
html,body{width:${frame.w}px;height:${frame.h}px;overflow:hidden}
#ad{position:relative;width:${frame.w}px;height:${frame.h}px;overflow:hidden;cursor:pointer;${bgCss}border:0}
.p{position:absolute}.w{width:100%;height:100%}img{display:block}
#ad:not(.play) .w{animation:none!important}
${css.join('\n')}
</style></head>
<body><div id="ad" class="play">${html.join('')}</div>
<script>
(function(){var ad=document.getElementById('ad'),n=1,max=${loops},d=${frame.duration * 1000};
ad.addEventListener('click',function(){window.open(window.clickTag,'_blank');});
function loop(){if(n>=max)return;setTimeout(function(){n++;ad.classList.remove('play');void ad.offsetWidth;ad.classList.add('play');loop();},d);}
loop();})();
</script></body></html>`
  zip.file('index.html', doc)
  // backup-afbeelding (eindbeeld) voor platforms die dat vragen
  const backup = await exportImage(frame, 'jpg', 1, 0.8)
  const blob = await zip.generateAsync({ type: 'blob', compression: 'DEFLATE', compressionOptions: { level: 9 } })
  return { blob, backup }
}

export { Konva }
