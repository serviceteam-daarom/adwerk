import { useState } from 'react'
import { ChevronDown, LogOut, Sparkles, Bell, BellOff, Palette } from 'lucide-react'
import { supabase } from '../lib/supabase'
import { useSession, displayName } from '../store/session'
import { useChat, enableNotifications } from '../lib/chat'
import { ThemeToggle } from './ThemeToggle'
import { ConnectAIDialog } from './ConnectAI'
import { Avatar, Popover, PopoverTrigger, PopoverContent, cn } from './ui'

/** Account en instellingen: weergave, Claude koppelen, meldingen en uitloggen. */
export function AccountMenu({ compact, dark, side = 'top', align = 'start' }: { compact?: boolean; dark?: boolean; side?: 'top' | 'bottom' | 'right'; align?: 'start' | 'end' }) {
  const { user, profile } = useSession()
  const perm = useChat((s) => s.notifyPerm)
  const [open, setOpen] = useState(false)
  const [ai, setAi] = useState(false)
  const name = displayName(profile, user)
  const item = 'flex w-full items-center gap-3 rounded-lg px-2.5 py-2 text-left text-sm hover:bg-sunk'
  return (
    <>
      <Popover open={open} onOpenChange={setOpen}>
        <PopoverTrigger asChild>
          {compact ? (
            <button className={cn('grid h-9 w-9 place-items-center rounded-full transition', dark ? 'hover:bg-white/10' : 'hover:bg-sunk')} aria-label="Account en instellingen">
              <Avatar name={name} color={profile?.color} src={profile?.avatar_url} size={32} />
            </button>
          ) : (
            <button className="flex w-full items-center gap-2.5 rounded-xl px-2 py-2 text-left transition hover:bg-sunk" aria-label="Account en instellingen">
              <Avatar name={name} color={profile?.color} src={profile?.avatar_url} size={34} />
              <span className="min-w-0 flex-1"><span className="block truncate text-sm font-semibold">{name}</span><span className="block truncate text-xs text-muted">{user?.email}</span></span>
              <ChevronDown size={16} className={cn('shrink-0 text-muted transition-transform', open && 'rotate-180')} />
            </button>
          )}
        </PopoverTrigger>
        <PopoverContent side={side} align={align} className="w-72 p-1.5">
          <div className="flex items-center gap-3 px-2.5 py-2">
            <Avatar name={name} color={profile?.color} src={profile?.avatar_url} size={36} />
            <span className="min-w-0"><span className="block truncate text-sm font-semibold">{name}</span><span className="block truncate text-xs text-muted">{user?.email}</span></span>
          </div>
          <div className="my-1 h-px bg-line" />
          <div className="flex items-center gap-3 px-2.5 py-1.5 text-sm"><Palette size={17} className="text-muted" /><span className="flex-1">Weergave</span><ThemeToggle /></div>
          <button className={item} onClick={() => { setOpen(false); setAi(true) }}><Sparkles size={17} className="text-muted" /> Claude koppelen</button>
          {perm !== 'unsupported' && (
            <button className={item} disabled={perm !== 'default'} onClick={() => enableNotifications()}>
              {perm === 'granted' ? <Bell size={17} className="text-mint" /> : perm === 'denied' ? <BellOff size={17} className="text-muted" /> : <Bell size={17} className="text-muted" />}
              <span className="flex-1">{perm === 'granted' ? 'Meldingen staan aan' : perm === 'denied' ? 'Meldingen geblokkeerd in je browser' : 'Meldingen aanzetten'}</span>
            </button>
          )}
          <div className="my-1 h-px bg-line" />
          <button className={cn(item, 'text-accent-fg')} onClick={() => supabase.auth.signOut()}><LogOut size={17} /> Uitloggen</button>
        </PopoverContent>
      </Popover>
      <ConnectAIDialog open={ai} onOpenChange={setAi} />
    </>
  )
}
