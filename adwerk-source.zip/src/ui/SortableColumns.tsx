import { useEffect, useLayoutEffect, useRef, useState } from 'react'
import { cn } from './ui'

type Pt = { x: number; y: number }
export type Columns = Record<string, string[]>

/**
 * Kanban: kaarten slepen binnen een kolom en tussen kolommen. Kaart tilt op en volgt de muis, de rest schuift
 * soepel opzij (FLIP, alleen transforms) en bij loslaten glijdt de kaart in zijn plek. Toetsenbord: Alt + pijltjes.
 */
export function SortableColumns({ columns, items, renderColumn, renderItem, onChange, className, columnClassName, liftClassName }: {
  columns: { id: string }[]; items: Columns
  renderColumn: (col: string, body: React.ReactNode, s: { over: boolean; count: number; active: boolean }) => React.ReactNode
  renderItem: (id: string, s: { dragging: boolean }) => React.ReactNode
  onChange: (next: Columns, moved: { id: string; from: string; to: string }) => void
  className?: string; columnClassName?: string; liftClassName?: string
}) {
  const [preview, setPreview] = useState<Columns | null>(null)
  const [dragId, setDragId] = useState<string | null>(null)
  const [settling, setSettling] = useState(false)
  const [overCol, setOverCol] = useState<string | null>(null)
  const cols = preview || items
  const colsRef = useRef(cols); colsRef.current = cols
  const itemsRef = useRef(items); itemsRef.current = items
  const refs = useRef(new Map<string, HTMLDivElement>())
  const bodies = useRef(new Map<string, HTMLDivElement>())
  const live = useRef<{ id: string; from: string; pointer: number; start: Pt; grab: Pt; size: Pt; pos: Pt; active: boolean } | null>(null)
  const applied = useRef<Pt>({ x: 0, y: 0 })
  const flipFrom = useRef<Map<string, DOMRect> | null>(null)
  const suppress = useRef(false)

  const colOf = (c: Columns, id: string) => Object.keys(c).find((k) => c[k].includes(id))!

  const placeDragged = () => {
    const l = live.current; if (!l?.active) return
    const el = refs.current.get(l.id); if (!el) return
    const r = el.getBoundingClientRect()
    const slot = { x: r.left - applied.current.x, y: r.top - applied.current.y }
    const t = { x: l.pos.x - l.grab.x - slot.x, y: l.pos.y - l.grab.y - slot.y }
    applied.current = t
    el.style.transition = 'none'
    el.style.transform = `translate3d(${t.x}px, ${t.y}px, 0)`
  }

  useLayoutEffect(() => {
    const from = flipFrom.current
    flipFrom.current = null
    if (from) refs.current.forEach((el, id) => {
      if (live.current?.active && id === live.current.id) return
      const prev = from.get(id); if (!prev) return
      el.style.transition = 'none'; el.style.transform = ''
      const cur = el.getBoundingClientRect()
      const dx = prev.left - cur.left, dy = prev.top - cur.top
      if (Math.abs(dx) < 0.5 && Math.abs(dy) < 0.5) return
      el.style.transform = `translate3d(${dx}px, ${dy}px, 0)`
      void el.offsetWidth
      el.style.transition = 'transform 280ms var(--ease-drawer)'
      el.style.transform = ''
    })
    // het gesleepte element kan net opnieuw zijn aangemaakt (andere kolom): zonder transform beginnen
    const l = live.current
    if (l?.active) { const el = refs.current.get(l.id); if (el && !el.style.transform) applied.current = { x: 0, y: 0 } }
    placeDragged()
  })

  const snapshot = () => { const m = new Map<string, DOMRect>(); refs.current.forEach((el, id) => m.set(id, el.getBoundingClientRect())); flipFrom.current = m }

  const locate = (p: Pt, l: NonNullable<typeof live.current>) => {
    // kolom: die onder de muis, anders de dichtstbijzijnde
    let best = '', bd = Infinity
    bodies.current.forEach((b, k) => { const r = b.getBoundingClientRect(); const d = p.x < r.left ? r.left - p.x : p.x > r.right ? p.x - r.right : 0; if (d < bd) { bd = d; best = k } })
    const body = bodies.current.get(best)!
    const br = body.getBoundingClientRect()
    const centerY = p.y - l.grab.y + l.size.y / 2 - br.top + body.scrollTop
    const others = (colsRef.current[best] || []).filter((x) => x !== l.id)
    let idx = 0
    others.forEach((id) => { const el = refs.current.get(id); if (el && el.offsetTop + el.offsetHeight / 2 < centerY) idx++ })
    return { col: best, idx }
  }

  const begin = (e: React.PointerEvent, id: string) => {
    if (e.button !== 0 || (e.target as HTMLElement).closest('input, textarea, select, [data-nodrag], [role=combobox]')) return
    const el = refs.current.get(id); if (!el) return
    const r = el.getBoundingClientRect()
    live.current = { id, from: colOf(colsRef.current, id), pointer: e.pointerId, start: { x: e.clientX, y: e.clientY }, grab: { x: e.clientX - r.left, y: e.clientY - r.top }, size: { x: r.width, y: r.height }, pos: { x: e.clientX, y: e.clientY }, active: false }
    applied.current = { x: 0, y: 0 }
    const move = (ev: PointerEvent) => {
      const l = live.current; if (!l || ev.pointerId !== l.pointer) return
      l.pos = { x: ev.clientX, y: ev.clientY }
      if (!l.active) {
        if (Math.hypot(ev.clientX - l.start.x, ev.clientY - l.start.y) < 5) return
        l.active = true
        document.body.classList.add('is-sorting')
        setDragId(l.id); setSettling(false)
      }
      ev.preventDefault()
      const { col, idx } = locate(l.pos, l)
      setOverCol((o) => (o === col ? o : col))
      const cur = colsRef.current
      const fromCol = colOf(cur, l.id)
      const curIdx = cur[col].indexOf(l.id)
      if (fromCol === col && curIdx === idx) { placeDragged(); return }
      const next: Columns = {}
      Object.keys(cur).forEach((k) => (next[k] = cur[k].filter((x) => x !== l.id)))
      next[col] = [...next[col].slice(0, idx), l.id, ...next[col].slice(idx)]
      snapshot(); setPreview(next)
    }
    const up = (ev: PointerEvent) => {
      const l = live.current
      if (!l || ev.pointerId !== l.pointer) return
      window.removeEventListener('pointermove', move); window.removeEventListener('pointerup', up); window.removeEventListener('pointercancel', up)
      document.body.classList.remove('is-sorting')
      setOverCol(null)
      if (!l.active) { live.current = null; return }
      suppress.current = true; setTimeout(() => (suppress.current = false), 60)
      const el = refs.current.get(l.id)
      live.current = { ...l, active: false }
      setSettling(true)
      if (el) { el.style.transition = 'transform 280ms var(--ease-drawer)'; el.style.transform = '' }
      applied.current = { x: 0, y: 0 }
      const final = colsRef.current
      window.setTimeout(() => {
        live.current = null
        if (el) el.style.transition = ''
        setDragId(null); setSettling(false)
        const to = colOf(final, l.id)
        const changed = Object.keys(final).some((k) => final[k].join() !== (itemsRef.current[k] || []).join())
        if (changed) onChange(final, { id: l.id, from: l.from, to })
        setPreview(null)
      }, 290)
    }
    window.addEventListener('pointermove', move, { passive: false })
    window.addEventListener('pointerup', up)
    window.addEventListener('pointercancel', up)
  }

  const keyMove = (e: React.KeyboardEvent, id: string) => {
    if (!e.altKey || !['ArrowUp', 'ArrowDown', 'ArrowLeft', 'ArrowRight'].includes(e.key)) return
    e.preventDefault()
    const cur = colsRef.current, keys = columns.map((c) => c.id)
    const from = colOf(cur, id), i = cur[from].indexOf(id)
    const next: Columns = {}; keys.forEach((k) => (next[k] = [...(cur[k] || [])]))
    let to = from
    if (e.key === 'ArrowUp' || e.key === 'ArrowDown') {
      const j = e.key === 'ArrowUp' ? i - 1 : i + 1
      if (j < 0 || j >= cur[from].length) return
      next[from].splice(i, 1); next[from].splice(j, 0, id)
    } else {
      const k = keys.indexOf(from) + (e.key === 'ArrowLeft' ? -1 : 1)
      if (k < 0 || k >= keys.length) return
      to = keys[k]; next[from].splice(i, 1); next[to].splice(Math.min(i, next[to].length), 0, id)
    }
    snapshot()
    onChange(next, { id, from, to })
    requestAnimationFrame(() => refs.current.get(id)?.querySelector<HTMLElement>('a, button')?.focus())
  }

  useEffect(() => () => document.body.classList.remove('is-sorting'), [])

  return (
    <div className={className} onClickCapture={(e) => { if (suppress.current) { e.preventDefault(); e.stopPropagation() } }}>
      {columns.map(({ id: col }) => {
        const list = cols[col] || []
        const body = (
          <div ref={(el) => { if (el) bodies.current.set(col, el); else bodies.current.delete(col) }} className={cn('relative', columnClassName)} role="list">
            {list.map((id) => {
              const isDrag = dragId === id
              return (
                <div key={id} role="listitem" ref={(el) => { if (el) refs.current.set(id, el); else refs.current.delete(id) }}
                  onPointerDown={(e) => begin(e, id)} onKeyDown={(e) => keyMove(e, id)} onDragStart={(e) => e.preventDefault()}
                  className={cn('sortable-item relative select-none touch-manipulation', isDrag && 'z-30')}>
                  <div className={cn('sortable-lift rounded-xl', isDrag && !settling && cn('is-lifted', liftClassName))}>{renderItem(id, { dragging: isDrag })}</div>
                </div>
              )
            })}
          </div>
        )
        return <div key={col} className="contents">{renderColumn(col, body, { over: overCol === col && !!dragId, count: list.length, active: !!dragId })}</div>
      })}
    </div>
  )
}
