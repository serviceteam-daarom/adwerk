import { MessageSquareText, X } from 'lucide-react'
import { useNotices, dismissNotice } from '../lib/notices'
import { Button, cn } from './ui'

export function Notices() {
  const list = useNotices((s) => s.list)
  if (!list.length) return null
  return (
    <div className="pointer-events-none fixed bottom-4 right-3 z-[110] grid w-[min(340px,calc(100vw-24px))] gap-2" aria-live="polite">
      {list.map((n) => (
        <div key={n.id} style={{ animation: n.leaving ? 'toastOut .2s var(--ease-in) forwards' : 'noticeIn .32s var(--ease-out)' }} className="pointer-events-auto flex gap-3 rounded-2xl border border-line bg-surface p-3 shadow-pop">
          <span className={cn('grid h-9 w-9 shrink-0 place-items-center rounded-full text-white', n.tone === 'client' ? 'bg-[#CC4A25]' : 'bg-[#1A5FC4]')}><MessageSquareText size={17} /></span>
          <div className="min-w-0 flex-1">
            <div className="flex items-start gap-2"><span className="min-w-0 flex-1 text-sm font-semibold leading-snug">{n.title}</span>
              <button onClick={() => dismissNotice(n.id)} className="rounded p-0.5 text-muted hover:text-ink" aria-label="Sluiten"><X size={14} /></button></div>
            {n.body && <p className="mt-0.5 line-clamp-2 text-sm text-muted">{n.body}</p>}
            {n.action && <Button size="sm" className="mt-2" onClick={() => { n.action!.run(); dismissNotice(n.id) }}>{n.action.label}</Button>}
          </div>
        </div>
      ))}
    </div>
  )
}
