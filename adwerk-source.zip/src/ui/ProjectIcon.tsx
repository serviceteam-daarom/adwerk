import { useEffect, useId, useState } from 'react'
import type { Folder } from '../lib/types'

export const faviconFor = (url?: string | null) => {
  try { if (!url) return null; const d = new URL(/^https?:/.test(url) ? url : 'https://' + url).hostname; return `https://www.google.com/s2/favicons?domain=${d}&sz=128` } catch { return null }
}

const ok = new Map<string, boolean>()
/** Laadt de favicon vooraf; Google geeft bij onbekende sites een grijze wereldbol van 16px, die tellen we als "geen favicon". */
function useFavicon(url: string | null) {
  const [state, setState] = useState<boolean | null>(url ? ok.get(url) ?? null : false)
  useEffect(() => {
    if (!url) { setState(false); return }
    if (ok.has(url)) { setState(ok.get(url)!); return }
    let alive = true
    const img = new Image()
    img.onload = () => { const v = img.naturalWidth > 16; ok.set(url, v); if (alive) setState(v) }
    img.onerror = () => { ok.set(url, false); if (alive) setState(false) }
    img.src = url
    return () => { alive = false }
  }, [url])
  return state
}

// Kaarten van het Adwerk-beeldmerk (viewBox 100×100): achter, midden, voor
const BACK = 'M41,8H84A9,9 0 0 1 93,17V69A9,9 0 0 1 84,78H41A9,9 0 0 1 32,69V17A9,9 0 0 1 41,8Z'
const MID = 'M28,19H71A9,9 0 0 1 80,28V76A9,9 0 0 1 71,85H28A9,9 0 0 1 19,76V28A9,9 0 0 1 28,19Z'
const FRONT = 'M17,32H57A9,9 0 0 1 66,41V83A9,9 0 0 1 57,92H17A9,9 0 0 1 8,83V41A9,9 0 0 1 17,32Z'
const CUT1 = 'M28,16.6H71A11.4,11.4 0 0 1 82.4,28V76A11.4,11.4 0 0 1 71,87.4H28A11.4,11.4 0 0 1 16.6,76V28A11.4,11.4 0 0 1 28,16.6Z'
const CUT2 = 'M17,29.6H57A11.4,11.4 0 0 1 68.4,41V83A11.4,11.4 0 0 1 57,94.4H17A11.4,11.4 0 0 1 5.6,83V41A11.4,11.4 0 0 1 17,29.6Z'

/** Projecticoon in de vorm van het Adwerk-beeldmerk: de favicon van de klant is de voorste kaart, de projectkleur de middelste. */
export function ProjectIcon({ f, size = 28, className }: { f: Pick<Folder, 'name' | 'website' | 'color'>; size?: number; className?: string }) {
  const id = useId().replace(/:/g, '')
  const fav = faviconFor(f.website)
  const has = useFavicon(fav)
  const color = f.color || '#1A5FC4'
  const initials = f.name.replace(/[^\p{L}\p{N} ]/gu, '').split(/\s+/).filter(Boolean).slice(0, 2).map((w) => w[0]).join('').toUpperCase() || '?'
  return (
    <svg width={size} height={size} viewBox="0 0 100 100" className={className} aria-hidden style={{ flexShrink: 0 }}>
      <defs>
        <mask id={`a${id}`}><rect width="100" height="100" fill="#fff" /><path d={CUT1} fill="#000" /></mask>
        <mask id={`b${id}`}><rect width="100" height="100" fill="#fff" /><path d={CUT2} fill="#000" /></mask>
        <clipPath id={`c${id}`}><path d={FRONT} /></clipPath>
      </defs>
      <path d={BACK} fill="#A2D6ED" mask={`url(#a${id})`} />
      <path d={MID} fill={color} mask={`url(#b${id})`} />
      <g clipPath={`url(#c${id})`}>
        {/* zonder favicon (of met doorzichtige randen) vult de projectkleur de kaart, nooit wit */}
        <rect x="8" y="32" width="58" height="60" fill={has ? color : '#1B213B'} />
        {has && <rect x="8" y="32" width="58" height="60" fill="#1B213B" opacity=".18" />}
        {has
          ? <image href={fav!} x="8" y="32" width="58" height="60" preserveAspectRatio="xMidYMid slice" />
          : size >= 22 && <text x="37" y="62" textAnchor="middle" dominantBaseline="central" fill="#fff" fontSize={initials.length > 1 ? 26 : 32} fontWeight="800" fontFamily="Figtree, Poppins, sans-serif">{initials}</text>}
      </g>
    </svg>
  )
}
