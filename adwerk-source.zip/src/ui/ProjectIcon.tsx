import { useEffect, useId, useState } from 'react'
import type { Folder } from '../lib/types'
import { supabase, SUPABASE_URL, SUPABASE_KEY } from '../lib/supabase'

const domainOf = (url?: string | null) => { try { return url ? new URL(/^https?:/.test(url) ? url : 'https://' + url).hostname.replace(/^www\./, '') : null } catch { return null } }
export const faviconFor = (url?: string | null) => { const d = domainOf(url); return d ? `https://www.google.com/s2/favicons?domain=${d}&sz=128` : null }

/** Resultaat van de favicon-analyse. tile = favicon is zelf al een gevuld vlak; anders een bijgesneden logo op een passende kaartkleur. */
export type Fav = { src: string; bg: string; tile: boolean }
const VERSION = 2
const memo = new Map<string, Promise<Fav | null>>()
const done = new Map<string, Fav | null>()

const hex = (r: number, g: number, b: number) => '#' + [r, g, b].map((v) => Math.round(Math.max(0, Math.min(255, v))).toString(16).padStart(2, '0')).join('')
const lum = (r: number, g: number, b: number) => (0.2126 * r + 0.7152 * g + 0.0722 * b) / 255

async function loadBlob(url: string): Promise<Blob | null> {
  try {
    const { data: s } = await supabase.auth.getSession()
    if (!s.session) return null
    const r = await fetch(`${SUPABASE_URL}/functions/v1/brand-scan`, { method: 'POST', headers: { 'Content-Type': 'application/json', apikey: SUPABASE_KEY, Authorization: `Bearer ${s.session.access_token}` }, body: JSON.stringify({ proxy: url }) })
    return r.ok ? await r.blob() : null
  } catch { return null }
}

/** Haalt de favicon op (via onze eigen proxy, zodat we de pixels mogen lezen) en bepaalt hoe hij het mooist op de kaart past. */
async function analyse(domain: string): Promise<Fav | null> {
  const key = `adwerk-fav-${VERSION}:${domain}`
  try { const c = localStorage.getItem(key); if (c) return c === 'none' ? null : JSON.parse(c) } catch { /* */ }
  const blob = await loadBlob(`https://www.google.com/s2/favicons?domain=${domain}&sz=128`)
  if (!blob) return null // geen sessie of proxy: niet cachen, later opnieuw
  let definitive = true // alleen een echte uitkomst onthouden, geen netwerkfout
  if (!/^image\//.test(blob.type)) return null
  const out = await new Promise<Fav | null>((resolve) => {
    const img = new Image()
    const u = URL.createObjectURL(blob)
    img.onload = () => {
      try {
        const n = img.naturalWidth
        if (n <= 16) return resolve(null) // Google's standaard wereldbol
        const S = 128
        const cv = document.createElement('canvas'); cv.width = S; cv.height = S
        const cx = cv.getContext('2d', { willReadFrequently: true })!
        cx.imageSmoothingQuality = 'high'
        cx.drawImage(img, 0, 0, S, S)
        const d = cx.getImageData(0, 0, S, S).data
        const at = (x: number, y: number) => (y * S + x) * 4
        // rand: hoeveel van de buitenste pixels zijn dekkend?
        let edge = 0, edgeOpaque = 0, er = 0, eg = 0, eb = 0
        for (let i = 0; i < S; i++) for (const [x, y] of [[i, 1], [i, S - 2], [1, i], [S - 2, i]] as const) {
          const p = at(x, y); edge++
          if (d[p + 3] > 220) { edgeOpaque++; er += d[p]; eg += d[p + 1]; eb += d[p + 2] }
        }
        // bounding box van alles wat zichtbaar is, en de gemiddelde kleur van het logo
        let x0 = S, y0 = S, x1 = -1, y1 = -1, cr = 0, cg = 0, cb = 0, cn = 0
        for (let y = 0; y < S; y++) for (let x = 0; x < S; x++) {
          const p = at(x, y); const a = d[p + 3]
          if (a > 28) { if (x < x0) x0 = x; if (x > x1) x1 = x; if (y < y0) y0 = y; if (y > y1) y1 = y }
          if (a > 200) { cr += d[p]; cg += d[p + 1]; cb += d[p + 2]; cn++ }
        }
        if (x1 < 0) return resolve(null)
        if (edgeOpaque / edge > 0.82) {
          // gevuld vlak (bijv. wit vierkant met logo): als geheel tonen, kaartkleur = randkleur
          return resolve({ src: cv.toDataURL('image/png'), bg: hex(er / edgeOpaque, eg / edgeOpaque, eb / edgeOpaque), tile: true })
        }
        // doorzichtige marge wegsnijden en vierkant maken
        const w = x1 - x0 + 1, h = y1 - y0 + 1, side = Math.max(w, h)
        const o = document.createElement('canvas'); o.width = 128; o.height = 128
        const ox = o.getContext('2d')!
        ox.imageSmoothingQuality = 'high'
        ox.drawImage(cv, x0 - (side - w) / 2, y0 - (side - h) / 2, side, side, 0, 0, 128, 128)
        const r = cr / Math.max(1, cn), g = cg / Math.max(1, cn), b = cb / Math.max(1, cn)
        // licht logo: donkere kaart; anders een zachte tint van de logokleur
        const bg = lum(r, g, b) > 0.72 ? '#1B213B' : hex(r + (255 - r) * 0.9, g + (255 - g) * 0.9, b + (255 - b) * 0.9)
        resolve({ src: o.toDataURL('image/png'), bg, tile: false })
      } catch { definitive = false; resolve(null) } finally { URL.revokeObjectURL(u) }
    }
    img.onerror = () => { URL.revokeObjectURL(u); definitive = false; resolve(null) }
    img.src = u
  })
  if (definitive) try { localStorage.setItem(key, out ? JSON.stringify(out) : 'none') } catch { /* vol */ }
  return out
}

function useFav(website?: string | null) {
  const domain = domainOf(website)
  const [fav, setFav] = useState<Fav | null | undefined>(domain ? done.get(domain) : null)
  useEffect(() => {
    if (!domain) { setFav(null); return }
    if (done.has(domain)) { setFav(done.get(domain)!); return }
    let alive = true
    if (!memo.has(domain)) memo.set(domain, analyse(domain).then((r) => { if (r) done.set(domain, r); else memo.delete(domain); return r }))
    memo.get(domain)!.then((r) => alive && setFav(r))
    return () => { alive = false }
  }, [domain])
  return fav
}

// Kaarten van het Adwerk-beeldmerk (viewBox 100×100): achter, midden, voor
const BACK = 'M41,8H84A9,9 0 0 1 93,17V69A9,9 0 0 1 84,78H41A9,9 0 0 1 32,69V17A9,9 0 0 1 41,8Z'
const MID = 'M28,19H71A9,9 0 0 1 80,28V76A9,9 0 0 1 71,85H28A9,9 0 0 1 19,76V28A9,9 0 0 1 28,19Z'
const FRONT = 'M17,32H57A9,9 0 0 1 66,41V83A9,9 0 0 1 57,92H17A9,9 0 0 1 8,83V41A9,9 0 0 1 17,32Z'
const CUT1 = 'M28,16.6H71A11.4,11.4 0 0 1 82.4,28V76A11.4,11.4 0 0 1 71,87.4H28A11.4,11.4 0 0 1 16.6,76V28A11.4,11.4 0 0 1 28,16.6Z'
const CUT2 = 'M17,29.6H57A11.4,11.4 0 0 1 68.4,41V83A11.4,11.4 0 0 1 57,94.4H17A11.4,11.4 0 0 1 5.6,83V41A11.4,11.4 0 0 1 17,29.6Z'

/** Projecticoon in de vorm van het Adwerk-beeldmerk: de favicon van de klant past precies op de voorste kaart, de projectkleur is de middelste. */
export function ProjectIcon({ f, size = 28, className }: { f: Pick<Folder, 'name' | 'website' | 'color'>; size?: number; className?: string }) {
  const id = useId().replace(/:/g, '')
  const fav = useFav(f.website)
  const color = f.color || '#1A5FC4'
  const initials = f.name.replace(/[^\p{L}\p{N} ]/gu, '').split(/\s+/).filter(Boolean).slice(0, 2).map((w) => w[0]).join('').toUpperCase() || '?'
  // voorste kaart: x 8..66, y 32..92 (58×60). Een logo krijgt marge rondom, een gevuld vlak vult de hele kaart.
  const pad = fav && !fav.tile ? 10 : 0
  return (
    <svg width={size} height={size} viewBox="0 0 100 100" className={className} aria-hidden style={{ flexShrink: 0 }}>
      <defs>
        <mask id={`a${id}`}><rect width="100" height="100" fill="#fff" /><path d={CUT1} fill="#000" /></mask>
        <mask id={`b${id}`}><rect width="100" height="100" fill="#fff" /><path d={CUT2} fill="#000" /></mask>
        <clipPath id={`c${id}`}><path d={FRONT} /></clipPath>
      </defs>
      <path d={BACK} fill="#A2D6ED" mask={`url(#a${id})`} />
      <path d={MID} fill={color} mask={`url(#b${id})`} />
      <g clipPath={`url(#c${id})`}>
        <rect x="8" y="32" width="58" height="60" fill={fav ? fav.bg : '#1B213B'} style={{ transition: 'fill .3s' }} />
        {fav
          ? (fav.tile
            ? <image href={fav.src} x="8" y="32" width="58" height="60" preserveAspectRatio="xMidYMid slice" />
            : <image href={fav.src} x={8 + pad} y={32 + pad + 1} width={58 - pad * 2} height={58 - pad * 2} preserveAspectRatio="xMidYMid meet" />)
          : size >= 22 && <text x="37" y="62" textAnchor="middle" dominantBaseline="central" fill="#fff" fontSize={initials.length > 1 ? 26 : 32} fontWeight="800" fontFamily="Figtree, Poppins, sans-serif">{initials}</text>}
      </g>
      {/* fijne rand zodat een lichte kaart niet wegvalt tegen een witte achtergrond */}
      {fav && <path d={FRONT} fill="none" stroke="#1B213B" strokeOpacity=".12" strokeWidth="1.2" />}
    </svg>
  )
}
