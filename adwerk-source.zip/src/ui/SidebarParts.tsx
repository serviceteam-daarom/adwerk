import { useEffect, useLayoutEffect, useRef, useState } from 'react'
import { Lock, Pin, PinOff, GripVertical } from 'lucide-react'
import type { Folder } from '../lib/types'
import { Label, Tip, cn } from './ui'
import { ProjectIcon } from './ProjectIcon'

/** Label dat vervaagt bij inklappen; komt bij uitklappen iets later terug, zodat de breedte eerst ruimte maakt. */
export const fade = (mini?: boolean) => cn('transition-opacity', mini ? 'pointer-events-none opacity-0 duration-150' : 'opacity-100 duration-300 delay-150')

/** Menu-item voor in- en uitgeklapt: alleen breedte en label animeren, de structuur blijft gelijk. */
export function NavItem({ to, icon, label, mini, active, trailing, className }: { to: string; icon: React.ReactNode; label: string; mini?: boolean; active?: boolean; trailing?: React.ReactNode; className?: string }) {
  return (
    <Tip label={label} side="right" disabled={!mini}>
      <a href={`#${to}`} aria-current={active ? 'page' : undefined} aria-label={label} draggable={false}
        className={cn('drawer-t flex h-10 items-center gap-2.5 overflow-hidden rounded-full pl-[7px] pr-2 text-[14px] font-medium', mini ? 'ml-1 max-w-[40px]' : 'ml-0 max-w-full', active ? 'bg-accent-soft text-accent-fg' : 'text-ink hover:bg-sunk', className)}>
        <span className="grid w-[26px] shrink-0 place-items-center">{icon}</span>
        <span className={cn('min-w-0 flex-1 truncate whitespace-nowrap', fade(mini))} title={label}>{label}</span>
        {trailing && <span className={cn('shrink-0', fade(mini))}>{trailing}</span>}
      </a>
    </Tip>
  )
}

/** Kopje boven een groep: uitgeklapt tekst met ademruimte, ingeklapt een kort streepje op dezelfde plek. */
export function SectionHead({ mini, children, icon, action }: { mini: boolean; children: React.ReactNode; icon?: React.ReactNode; action?: React.ReactNode }) {
  return (
    <div className="relative mb-2 mt-7 h-5">
      <div className={cn('absolute inset-0 flex items-center gap-1.5 pl-3 pr-1', fade(mini))}>
        {icon}<Label className="leading-none">{children}</Label>
        {action && <span className="ml-auto">{action}</span>}
      </div>
      <div className={cn('drawer-t absolute left-1 top-1/2 h-px w-10 -translate-y-1/2 bg-line', mini ? 'opacity-100' : 'opacity-0')} />
    </div>
  )
}

/** Inklapbaar blok: hoogte en zichtbaarheid vloeiend. */
export function Collapse({ hide, children, className }: { hide: boolean; children: React.ReactNode; className?: string }) {
  return (
    <div className={cn('drawer-t grid', hide ? 'grid-rows-[0fr] opacity-0' : 'grid-rows-[1fr] opacity-100', className)} aria-hidden={hide || undefined}>
      <div className="min-h-0 overflow-hidden">{children}</div>
    </div>
  )
}

/** Eén projectregel in de zijbalk, met vastzet-knop. */
export function ProjectRow({ f, mini, active, pinned, onTogglePin, dragging, handle }: { f: Folder; mini: boolean; active: boolean; pinned: boolean; onTogglePin: () => void; dragging?: boolean; handle?: boolean }) {
  return (
    <div className="group/proj relative min-w-0">
      <NavItem mini={mini} to={`/folder/${f.id}`} label={f.name} active={active} icon={<ProjectIcon f={f} size={26} />}
        className={cn(dragging && '!bg-surface')}
        trailing={<span className="flex shrink-0 items-center gap-1 pr-6">{f.visibility === 'private' && <Lock size={13} className="shrink-0 text-muted" aria-label="Privé project" />}</span>} />
      {handle && !mini && (
        <span aria-hidden className={cn('pointer-events-none absolute -left-[13px] top-1/2 grid h-6 w-3 -translate-y-1/2 place-items-center text-muted/70 transition-opacity duration-200', dragging ? 'opacity-100' : 'opacity-0 group-hover/proj:opacity-100')}><GripVertical size={12} /></span>
      )}
      <Tip label={pinned ? 'Losmaken' : 'Vastzetten bovenaan'} side="right" disabled={mini}>
        <button data-nodrag onPointerDown={(e) => e.stopPropagation()} onClick={(e) => { e.preventDefault(); e.stopPropagation(); onTogglePin() }} aria-label={pinned ? `${f.name} losmaken` : `${f.name} vastzetten`} tabIndex={mini ? -1 : undefined}
          className={cn('absolute right-1.5 top-1/2 grid h-7 w-7 -translate-y-1/2 place-items-center rounded-full text-muted opacity-0 transition hover:bg-surface hover:text-ink hover:shadow-card focus-visible:opacity-100 max-md:opacity-100', mini || dragging ? 'pointer-events-none !opacity-0' : 'group-hover/proj:opacity-100')}>
          {pinned ? <PinOff size={14} /> : <Pin size={14} />}
        </button>
      </Tip>
    </div>
  )
}

/**
 * Sorteerbare lijst met de muis of vinger: het item tilt op en volgt je, de andere schuiven soepel opzij,
 * en bij loslaten glijdt het in zijn nieuwe plek. Met het toetsenbord: Alt + pijl omhoog/omlaag.
 * Alleen transforms, dus vloeiend, ook op Safari.
 */
export function SortableList<T extends { id: string }>({ items, onReorder, render, className, label }: { items: T[]; onReorder: (ids: string[]) => void; render: (item: T, state: { dragging: boolean }) => React.ReactNode; className?: string; label: string }) {
  const refs = useRef(new Map<string, HTMLDivElement>())
  const [drag, setDrag] = useState<{ id: string; dy: number; target: number; from: number; settling: boolean } | null>(null)
  const geo = useRef<{ tops: number[]; heights: number[]; startY: number; pointer: number; active: boolean; id: string; from: number } | null>(null)
  const suppressClick = useRef(false)
  const ids = items.map((i) => i.id)

  // FLIP voor wijzigingen van buitenaf (vastzetten, losmaken, toetsenbord): items glijden naar hun nieuwe plek
  const prevTops = useRef(new Map<string, number>())
  useLayoutEffect(() => {
    if (drag) return
    const now = new Map<string, number>()
    refs.current.forEach((el, id) => now.set(id, el.getBoundingClientRect().top))
    now.forEach((top, id) => {
      const before = prevTops.current.get(id)
      const el = refs.current.get(id)
      if (before === undefined || !el || Math.abs(before - top) < 1) return
      el.style.transition = 'none'
      el.style.transform = `translate3d(0, ${before - top}px, 0)`
      void el.offsetHeight
      el.style.transition = 'transform 320ms var(--ease-drawer)'
      el.style.transform = ''
    })
    prevTops.current = now
  })

  const begin = (e: React.PointerEvent, id: string) => {
    if (e.button !== 0 || (e.target as HTMLElement).closest('button')) return
    const tops: number[] = [], heights: number[] = []
    ids.forEach((x) => { const r = refs.current.get(x)!.getBoundingClientRect(); tops.push(r.top); heights.push(r.height) })
    geo.current = { tops, heights, startY: e.clientY, pointer: e.pointerId, active: false, id, from: ids.indexOf(id) }
    const move = (ev: PointerEvent) => {
      const g = geo.current
      if (!g || ev.pointerId !== g.pointer) return
      const dy = ev.clientY - g.startY
      if (!g.active) {
        if (Math.abs(dy) < 5) return
        g.active = true
        document.body.classList.add('is-sorting')
      }
      ev.preventDefault()
      // doelpositie: waar het midden van het gesleepte item nu valt
      const minDy = g.tops[0] - g.tops[g.from], maxDy = g.tops[g.tops.length - 1] + g.heights[g.heights.length - 1] - (g.tops[g.from] + g.heights[g.from])
      const cdy = Math.max(minDy - 10, Math.min(maxDy + 10, dy))
      const center = g.tops[g.from] + g.heights[g.from] / 2 + cdy
      let target = g.from
      g.tops.forEach((t, i) => { const mid = t + g.heights[i] / 2; if (i < g.from && center < mid) target = Math.min(target, i); if (i > g.from && center > mid) target = Math.max(target, i) })
      setDrag({ id: g.id, dy: cdy, target, from: g.from, settling: false })
    }
    const up = (ev: PointerEvent) => {
      const g = geo.current
      window.removeEventListener('pointermove', move)
      window.removeEventListener('pointerup', up)
      window.removeEventListener('pointercancel', up)
      document.body.classList.remove('is-sorting')
      if (!g || ev.pointerId !== g.pointer) return
      geo.current = null
      if (!g.active) return
      suppressClick.current = true
      setTimeout(() => (suppressClick.current = false), 50)
      setDrag((d) => {
        if (!d) return d
        // glijd naar de nieuwe plek en zet dan pas de volgorde om
        const slotDy = d.target === d.from ? 0 : d.target > d.from
          ? g.tops[d.target] + g.heights[d.target] - (g.tops[d.from] + g.heights[d.from])
          : g.tops[d.target] - g.tops[d.from]
        window.setTimeout(() => {
          if (d.target !== d.from) {
            const next = ids.filter((x) => x !== d.id)
            next.splice(d.target, 0, d.id)
            // de nieuwe layout staat op dezelfde plek als waar het item naartoe gleed: zonder animatie omzetten
            refs.current.forEach((el) => { el.style.transition = 'none'; el.style.transform = '' })
            prevTops.current = new Map()
            onReorder(next)
          }
          setDrag(null)
        }, 260)
        return { ...d, dy: slotDy, settling: true }
      })
    }
    window.addEventListener('pointermove', move, { passive: false })
    window.addEventListener('pointerup', up)
    window.addEventListener('pointercancel', up)
  }

  const keyMove = (e: React.KeyboardEvent, id: string) => {
    if (!e.altKey || (e.key !== 'ArrowUp' && e.key !== 'ArrowDown')) return
    e.preventDefault()
    const i = ids.indexOf(id), j = e.key === 'ArrowUp' ? i - 1 : i + 1
    if (j < 0 || j >= ids.length) return
    const next = [...ids]; next.splice(i, 1); next.splice(j, 0, id)
    onReorder(next)
    requestAnimationFrame(() => refs.current.get(id)?.querySelector<HTMLElement>('a')?.focus())
  }

  useEffect(() => () => document.body.classList.remove('is-sorting'), [])

  return (
    <div className={cn('relative grid gap-0.5', className)} role="list" aria-label={label} onClickCapture={(e) => { if (suppressClick.current) { e.preventDefault(); e.stopPropagation() } }}>
      {items.map((it, i) => {
        const g = geo.current
        const isDrag = drag?.id === it.id
        let shift = 0
        if (drag && !isDrag) {
          const h = (g?.heights[drag.from] ?? 40) + 2
          if (drag.target > drag.from && i > drag.from && i <= drag.target) shift = -h
          if (drag.target < drag.from && i < drag.from && i >= drag.target) shift = h
        }
        return (
          <div key={it.id} role="listitem" ref={(el) => { if (el) refs.current.set(it.id, el); else refs.current.delete(it.id) }}
            onPointerDown={(e) => begin(e, it.id)} onKeyDown={(e) => keyMove(e, it.id)} onDragStart={(e) => e.preventDefault()}
            className={cn('sortable-item relative touch-pan-y select-none', isDrag && 'z-20')}
            style={isDrag
              ? { transform: `translate3d(0, ${drag!.dy}px, 0)`, transition: drag!.settling ? 'transform 260ms var(--ease-drawer)' : 'none', cursor: 'grabbing' }
              : drag ? { transform: `translate3d(0, ${shift}px, 0)`, transition: 'transform 260ms var(--ease-drawer)' } : undefined}>
            <div className="rounded-full transition-[transform,box-shadow,background-color] duration-200 [transition-timing-function:var(--ease-out)]"
              style={isDrag && !drag!.settling ? { transform: 'scale(1.035)', boxShadow: '0 16px 32px -14px rgba(27,33,59,.38), 0 0 0 1px rgb(var(--line))', backgroundColor: 'rgb(var(--surface))' } : undefined}>
              {render(it, { dragging: isDrag })}
            </div>
          </div>
        )
      })}
    </div>
  )
}
