import { useEffect, useState } from 'react'
import { Sparkles, Copy, Check, Trash2, Plus } from 'lucide-react'
import { supabase, SUPABASE_URL } from '../lib/supabase'
import { Button, Dialog, Input, Label } from './ui'

interface TokenRow { id: string; name: string; token_hint: string | null; created_at: string; last_used_at: string | null }

const MCP_BASE = `${SUPABASE_URL}/functions/v1/adwerk-mcp`

async function sha256(s: string) {
  const b = await crypto.subtle.digest('SHA-256', new TextEncoder().encode(s))
  return [...new Uint8Array(b)].map((x) => x.toString(16).padStart(2, '0')).join('')
}
function newToken() {
  const abc = 'ABCDEFGHJKLMNPQRSTUVWXYZabcdefghijkmnopqrstuvwxyz23456789'
  const r = crypto.getRandomValues(new Uint8Array(40))
  return 'adw_' + [...r].map((x) => abc[x % abc.length]).join('')
}
const when = (iso: string | null) => (iso ? new Date(iso).toLocaleString('nl-NL', { day: 'numeric', month: 'short', hour: '2-digit', minute: '2-digit' }) : 'nog niet')

/** Koppel Claude (of een andere AI-agent) via MCP, zodat die live in Adwerk kan ontwerpen. */
export function ConnectAIDialog({ open, onOpenChange }: { open: boolean; onOpenChange: (o: boolean) => void }) {
  const [rows, setRows] = useState<TokenRow[]>([])
  const [name, setName] = useState('Claude')
  const [fresh, setFresh] = useState<string | null>(null)
  const [copied, setCopied] = useState(false)
  const [busy, setBusy] = useState(false)
  const load = async () => { const { data } = await supabase.from('api_tokens').select('id,name,token_hint,created_at,last_used_at').order('created_at', { ascending: false }); setRows((data || []) as TokenRow[]) }
  useEffect(() => { if (open) { load(); setFresh(null); setCopied(false) } }, [open])

  const create = async () => {
    setBusy(true)
    try {
      const t = newToken()
      const { error } = await supabase.from('api_tokens').insert({ name: name.trim() || 'Claude', token_hash: await sha256(t), token_hint: t.slice(-4) })
      if (error) throw error
      setFresh(`${MCP_BASE}/${t}`)
      load()
    } finally { setBusy(false) }
  }
  const copy = async () => { if (!fresh) return; await navigator.clipboard.writeText(fresh); setCopied(true); setTimeout(() => setCopied(false), 2000) }

  return (
    <Dialog open={open} onOpenChange={onOpenChange} title="Claude koppelen" description="Laat Claude live met je meewerken in Adwerk: ontwerpen maken, teksten en beelden plaatsen, aanpassen en animeren. Je ziet de cursor van Claude bewegen zoals bij een collega.">
      <div className="grid gap-5">
        {fresh ? (
          <div className="grid gap-3 rounded-[20px] bg-mist p-4 dark:bg-sunk">
            <Label>Jouw persoonlijke koppeling</Label>
            <div className="flex gap-2">
              <Input readOnly value={fresh} onFocus={(e) => e.target.select()} className="font-mono text-xs" aria-label="Koppel-URL" />
              <Button variant="primary" onClick={copy} className="shrink-0">{copied ? <Check size={16} /> : <Copy size={16} />} {copied ? 'Gekopieerd' : 'Kopieer'}</Button>
            </div>
            <p className="text-xs text-accent-fg">Deze link zie je maar één keer. Deel hem met niemand: wie hem heeft, kan namens jou ontwerpen.</p>
            <ol className="grid list-decimal gap-1.5 pl-5 text-sm">
              <li>Open Claude en ga naar <strong className="font-semibold">Instellingen, Connectors</strong>.</li>
              <li>Kies <strong className="font-semibold">Aangepaste connector toevoegen</strong>, noem hem "Adwerk" en plak de link.</li>
              <li>Zet de connector aan in een gesprek en vraag bijvoorbeeld: "Maak in Adwerk een social ad set voor de herfstactie".</li>
              <li>Open de link die Claude teruggeeft om live mee te kijken.</li>
            </ol>
          </div>
        ) : (
          <div className="grid gap-2">
            <Label>Naam van de koppeling</Label>
            <div className="flex gap-2">
              <Input value={name} onChange={(e) => setName(e.target.value)} placeholder="Claude" aria-label="Naam van de koppeling" />
              <Button variant="primary" onClick={create} disabled={busy} className="shrink-0"><Plus size={16} /> Maak koppeling</Button>
            </div>
            <p className="text-xs text-muted">Deze naam staat bij de cursor van de agent, bijvoorbeeld "Claude".</p>
          </div>
        )}
        <div className="grid gap-2">
          <Label>Actieve koppelingen</Label>
          {!rows.length && <p className="text-sm text-muted">Nog geen koppelingen.</p>}
          {rows.map((r) => (
            <div key={r.id} className="flex items-center gap-3 rounded-xl border border-line px-3 py-2">
              <span className="grid h-8 w-8 place-items-center rounded-full bg-[#6D28D9] text-white"><Sparkles size={15} /></span>
              <span className="min-w-0 flex-1"><span className="block truncate text-sm font-semibold">{r.name} <span className="font-mono text-xs font-normal text-muted">…{r.token_hint}</span></span><span className="block text-xs text-muted">Laatst gebruikt: {when(r.last_used_at)}</span></span>
              <button onClick={async () => { await supabase.from('api_tokens').delete().eq('id', r.id); load() }} className="rounded-lg p-2 text-muted hover:bg-sunk hover:text-ink" aria-label={`Koppeling ${r.name} intrekken`}><Trash2 size={16} /></button>
            </div>
          ))}
        </div>
      </div>
    </Dialog>
  )
}

export function ConnectAIButton() {
  const [open, setOpen] = useState(false)
  return (
    <>
      <button onClick={() => setOpen(true)} className="flex w-full items-center gap-3 rounded-full px-3 py-2 text-[15px] font-medium text-ink transition hover:bg-sunk">
        <Sparkles size={18} /> <span className="flex-1 text-left">Claude koppelen</span>
      </button>
      <ConnectAIDialog open={open} onOpenChange={setOpen} />
    </>
  )
}
