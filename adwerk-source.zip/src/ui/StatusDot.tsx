import { statusOf } from '../lib/workflow'

export function StatusDot({ status, size = 8 }: { status?: string | null; size?: number }) {
  const c = statusOf(status).color
  return <span className="inline-block shrink-0 rounded-full" style={{ width: size, height: size, background: c, boxShadow: `0 0 0 3px ${c}22` }} />
}
