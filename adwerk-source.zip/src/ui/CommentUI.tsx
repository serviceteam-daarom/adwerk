import { useEffect, useRef, useState } from 'react'
import { ArrowUp, Check, MoreHorizontal, RotateCcw, Trash2, X } from 'lucide-react'
import type { Comment } from '../lib/comments'
import { Avatar, cn, Popover, PopoverContent, PopoverTrigger } from './ui'

export function timeAgo(iso: string) {
  const s = Math.max(0, (Date.now() - new Date(iso).getTime()) / 1000)
  if (s < 50) return 'zojuist'
  if (s < 3600) return `${Math.round(s / 60)} min`
  if (s < 86400) return `${Math.round(s / 3600)} uur`
  if (s < 86400 * 7) { const d = Math.round(s / 86400); return d === 1 ? 'gisteren' : `${d} dagen` }
  return new Date(iso).toLocaleDateString('nl-NL', { day: 'numeric', month: 'short' })
}

/** Kleur van een punt: klanten oranje, collega's in hun eigen kleur. */
export const pinColor = (c: Comment) => (c.resolved ? '#6B6880' : c.author?.team === false ? '#CC4A25' : c.author?.color || '#1A5FC4')

export function Pin({ c, n, active, onClick, style }: { c: Comment; n: number; active?: boolean; onClick?: () => void; style?: React.CSSProperties }) {
  return (
    <div className="comment-pin z-30" style={style}>
      <button
        onClick={(e) => { e.stopPropagation(); onClick?.() }}
        onMouseDown={(e) => e.stopPropagation()}
        className={cn('press grid h-8 min-w-8 origin-bottom-left place-items-center rounded-[16px_16px_16px_3px] border-2 border-white px-1.5 text-[12px] font-bold text-white shadow-pop transition-[box-shadow,transform] duration-150 hover:scale-110', active && 'scale-110 ring-4 ring-violet/35', c.resolved && 'opacity-70')}
        style={{ background: pinColor(c) }}
        aria-label={`Opmerking ${n} van ${c.author?.name || 'onbekend'}`}
      >{c.resolved ? <Check size={14} strokeWidth={3} /> : n}</button>
    </div>
  )
}

export function CommentItem({ c, onDelete, compact }: { c: Comment; onDelete?: () => void; compact?: boolean }) {
  const a = c.author || { name: c.guest_name || 'Gast', team: false }
  return (
    <div className="group flex gap-2.5">
      <Avatar name={a.name} color={a.team ? a.color : '#CC4A25'} src={a.avatar} size={compact ? 24 : 28} />
      <div className="min-w-0 flex-1">
        <div className="flex items-center gap-1.5 text-[13px] leading-tight">
          <span className="truncate font-semibold">{a.name}</span>
          {!a.team && <span className="shrink-0 rounded bg-[#CC4A25]/12 px-1 py-px text-[10px] font-bold uppercase tracking-wide text-[#CC4A25]">Klant</span>}
          <span className="shrink-0 text-xs text-muted">{timeAgo(c.created_at)}</span>
          {onDelete && (
            <Popover>
              <PopoverTrigger asChild><button className="ml-auto rounded p-0.5 text-muted opacity-0 transition hover:text-ink focus:opacity-100 group-hover:opacity-100" aria-label="Meer"><MoreHorizontal size={15} /></button></PopoverTrigger>
              <PopoverContent align="end" className="w-44 p-1"><button onClick={onDelete} className="flex w-full items-center gap-2 rounded-md px-2 py-1.5 text-left text-sm text-accent-fg hover:bg-sunk"><Trash2 size={15} /> Verwijderen</button></PopoverContent>
            </Popover>
          )}
        </div>
        <p className="mt-0.5 whitespace-pre-wrap break-words text-sm leading-relaxed">{c.body}</p>
      </div>
    </div>
  )
}

export function CommentComposer({ placeholder = 'Schrijf een reactie…', onSend, autoFocus, onCancel, nameField }: { placeholder?: string; onSend: (body: string) => Promise<unknown> | void; autoFocus?: boolean; onCancel?: () => void; nameField?: React.ReactNode }) {
  const [val, setVal] = useState('')
  const [busy, setBusy] = useState(false)
  const ref = useRef<HTMLTextAreaElement>(null)
  useEffect(() => { if (autoFocus) setTimeout(() => ref.current?.focus(), 30) }, [autoFocus])
  useEffect(() => { const t = ref.current; if (!t) return; t.style.height = 'auto'; t.style.height = Math.min(160, t.scrollHeight) + 'px' }, [val])
  const send = async () => {
    if (!val.trim() || busy) return
    setBusy(true)
    try { await onSend(val.trim()); setVal('') } catch (e) { alert((e as Error).message) } finally { setBusy(false); ref.current?.focus() }
  }
  return (
    <div className="grid gap-2">
      {nameField}
      <div className="flex items-end gap-2 rounded-xl border border-line bg-surface px-2.5 py-1.5 transition focus-within:border-violet focus-within:ring-2 focus-within:ring-violet/20">
        <textarea
          ref={ref} rows={1} value={val} onChange={(e) => setVal(e.target.value)} placeholder={placeholder}
          onKeyDown={(e) => { e.stopPropagation(); if (e.key === 'Enter' && !e.shiftKey) { e.preventDefault(); send() } if (e.key === 'Escape') onCancel?.() }}
          className="max-h-40 min-h-[24px] flex-1 resize-none bg-transparent py-1 text-sm outline-none placeholder:text-muted focus-visible:outline-none"
        />
        <button onClick={send} disabled={!val.trim() || busy} className="press mb-0.5 grid h-7 w-7 shrink-0 place-items-center rounded-full bg-accent text-white transition disabled:bg-line disabled:text-muted" aria-label="Plaatsen"><ArrowUp size={16} strokeWidth={2.5} /></button>
      </div>
    </div>
  )
}

/** Een volledige draad: eerste opmerking, reacties en een veld om te reageren. */
export function Thread({ root, replies, n, onReply, onResolve, onDelete, canDelete, onClose, className, nameField }: {
  root: Comment; replies: Comment[]; n?: number; onReply?: (body: string) => Promise<unknown> | void; onResolve?: (r: boolean) => void
  onDelete?: (id: string) => void; canDelete?: (c: Comment) => boolean; onClose?: () => void; className?: string; nameField?: React.ReactNode
}) {
  const endRef = useRef<HTMLDivElement>(null)
  useEffect(() => { endRef.current?.scrollIntoView({ block: 'nearest' }) }, [replies.length])
  return (
    <div className={cn('flex max-h-[min(460px,70vh)] w-[320px] max-w-[calc(100vw-24px)] flex-col rounded-2xl border border-line bg-surface shadow-pop', className)} onMouseDown={(e) => e.stopPropagation()}>
      <div className="flex items-center gap-1 border-b border-line py-1.5 pl-3.5 pr-1.5">
        <span className="flex-1 text-xs font-semibold text-muted">{n ? `Punt ${n}` : 'Opmerking'}{root.resolved && <span className="text-mint"> · afgehandeld</span>}</span>
        {onResolve && (
          <button onClick={() => onResolve(!root.resolved)} className={cn('press flex h-7 items-center gap-1 rounded-full px-2.5 text-xs font-semibold transition', root.resolved ? 'text-muted hover:bg-sunk' : 'bg-mint/15 text-[#137A52] hover:bg-mint/25')}>
            {root.resolved ? <><RotateCcw size={13} /> Heropenen</> : <><Check size={14} /> Afhandelen</>}
          </button>
        )}
        {onClose && <button onClick={onClose} className="grid h-7 w-7 place-items-center rounded-full text-muted hover:bg-sunk hover:text-ink" aria-label="Sluiten"><X size={15} /></button>}
      </div>
      <div className="grid min-h-0 gap-3.5 overflow-auto px-3.5 py-3">
        <CommentItem c={root} onDelete={onDelete && canDelete?.(root) ? () => onDelete(root.id) : undefined} />
        {replies.map((r) => <div key={r.id} className="anim-msg"><CommentItem c={r} compact onDelete={onDelete && canDelete?.(r) ? () => onDelete(r.id) : undefined} /></div>)}
        <div ref={endRef} />
      </div>
      {onReply && <div className="border-t border-line p-2.5"><CommentComposer onSend={onReply} nameField={nameField} /></div>}
    </div>
  )
}
