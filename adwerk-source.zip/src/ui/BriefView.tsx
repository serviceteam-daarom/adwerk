import { Copy, Check, ExternalLink } from 'lucide-react'
import { useState } from 'react'
import type { Brief } from '../lib/types'
import { filled } from '../lib/brief'
import { cn } from './ui'

/** Leesweergave van de brief (voor de klant in de feedbacklink). Alleen ingevulde, niet-interne velden. */
export function BriefView({ brief, className }: { brief: Brief; className?: string }) {
  const fields = brief.fields.filter((f) => !f.hidden && filled(f))
  const [copied, setCopied] = useState<string | null>(null)
  const copy = async (key: string, text: string) => { try { await navigator.clipboard.writeText(text); setCopied(key); setTimeout(() => setCopied(null), 1400) } catch { /* */ } }
  if (!fields.length) return null
  const short = fields.filter((f) => f.kind === 'text' || f.kind === 'url')
  const long = fields.filter((f) => f.kind === 'longtext' || f.kind === 'list')
  return (
    <div className={cn('grid gap-5', className)}>
      {short.length > 0 && (
        <dl className="grid grid-cols-2 gap-x-4 gap-y-4">
          {short.map((f) => (
            <div key={f.id} className={cn('grid min-w-0 content-start gap-1', (f.kind === 'url' || f.value.length > 28) && 'col-span-2')}>
              <dt className="text-[11px] font-bold uppercase tracking-[0.08em] text-muted">{f.label}</dt>
              <dd className="min-w-0 text-sm font-medium leading-snug">
                {f.kind === 'url' ? <a href={f.value.trim()} target="_blank" rel="noreferrer" className="inline-flex max-w-full items-center gap-1 text-violet hover:underline"><span className="truncate">{f.value.replace(/^https?:\/\/(www\.)?/, '').replace(/\/$/, '')}</span><ExternalLink size={13} className="shrink-0" /></a> : <span className="break-words">{f.value}</span>}
              </dd>
            </div>
          ))}
        </dl>
      )}
      {long.map((f) => (
        <section key={f.id} className="grid gap-2">
          <h4 className="text-[11px] font-bold uppercase tracking-[0.08em] text-muted">{f.label}</h4>
          {f.kind === 'longtext' ? <p className="whitespace-pre-wrap text-sm leading-relaxed">{f.value}</p> : (
            <ol className="grid gap-2">
              {(f.items || []).filter((x) => x.trim()).map((it, i) => (
                <li key={i} className="group relative flex gap-2.5 rounded-xl bg-sunk/70 p-3 pr-9">
                  <span className="text-xs font-bold tabular-nums text-accent-fg">{i + 1}</span>
                  <span className="min-w-0 whitespace-pre-wrap text-sm leading-relaxed">{it}</span>
                  <button onClick={() => copy(f.id + i, it)} className="absolute right-1.5 top-1.5 grid h-7 w-7 place-items-center rounded-md text-muted opacity-0 transition hover:bg-surface hover:text-ink focus:opacity-100 group-hover:opacity-100 max-md:opacity-60" aria-label="Kopiëren">{copied === f.id + i ? <Check size={14} className="text-mint" /> : <Copy size={14} />}</button>
                </li>
              ))}
            </ol>
          )}
        </section>
      ))}
    </div>
  )
}
