import { ALL_FORMATS, type SETS } from '../lib/formats'
import { PlatformLogos } from './PlatformLogo'
import { cn } from './ui'

type Set = (typeof SETS)[number]

/** Kleine schets van een advertentie binnen een formaat: beeldvlak, kop, knop. */
function MiniAd({ w, h }: { w: number; h: number }) {
  const wide = w / h > 2.2
  const tall = h / w > 1.6
  return (
    <span className="relative block overflow-hidden rounded-[4px] border-[1.5px] border-ink/70 bg-surface shadow-card transition group-hover:border-ink" style={{ width: w, height: h }}>
      {wide ? (
        <span className="absolute inset-[18%] flex items-center gap-[8%]">
          <span className="h-full w-[22%] rounded-[2px] bg-sky/70" />
          <span className="h-[30%] flex-1 rounded-full bg-ink/20" />
          <span className="h-[55%] w-[22%] rounded-full bg-orange" />
        </span>
      ) : (
        <>
          <span className="absolute inset-x-0 top-0 bg-sky/60" style={{ height: tall ? '48%' : '42%' }} />
          <span className="absolute left-[12%] h-[7%] rounded-full bg-ink/25" style={{ top: tall ? '56%' : '52%', width: '62%' }} />
          <span className="absolute left-[12%] h-[7%] rounded-full bg-ink/15" style={{ top: tall ? '66%' : '64%', width: '44%' }} />
          <span className="absolute bottom-[10%] left-[12%] h-[11%] w-[36%] rounded-full bg-orange" />
        </>
      )}
    </span>
  )
}

export function SetPreview({ formats, maxH = 64, maxW = 220 }: { formats: string[]; maxH?: number; maxW?: number }) {
  const list = formats.slice(0, 5).map((k) => ALL_FORMATS.find((f) => f.key === k)!).filter(Boolean)
  const gap = 8
  const k0 = maxH / Math.max(...list.map((f) => f.h))
  const total = list.reduce((s, f) => s + f.w * k0, 0) + gap * (list.length - 1)
  const k = total > maxW ? k0 * ((maxW - gap * (list.length - 1)) / (total - gap * (list.length - 1))) : k0
  return (
    <span className="flex items-end justify-center" style={{ gap }}>
      {list.map((f) => <MiniAd key={f.key} w={Math.max(10, Math.round(f.w * k))} h={Math.max(10, Math.round(f.h * k))} />)}
    </span>
  )
}

export function SetCard({ set, onClick, disabled, className }: { set: Set; onClick: () => void; disabled?: boolean; className?: string }) {
  return (
    <button
      onClick={onClick}
      disabled={disabled}
      className={cn('group grid min-w-0 content-start overflow-hidden rounded-[20px] border border-line bg-surface text-left transition hover:-translate-y-0.5 hover:border-ink/40 hover:shadow-pop disabled:opacity-60', className)}
    >
      <span className="grid h-28 place-items-center bg-mist px-4 pt-3 dark:bg-sunk"><SetPreview formats={set.formats} /></span>
      <span className="grid gap-1 p-4">
        <span className="flex items-center justify-between gap-2">
          <span className="truncate font-semibold">{set.name}</span>
          <PlatformLogos platforms={set.logos} size={16} />
        </span>
        <span className="text-xs text-muted">{set.description}</span>
      </span>
    </button>
  )
}
