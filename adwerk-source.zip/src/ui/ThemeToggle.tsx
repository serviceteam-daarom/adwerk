import { Sun, Moon, Monitor } from 'lucide-react'
import { useTheme, type ThemeMode } from '../lib/theme'
import { cn, Tip } from './ui'

export function ThemeToggle({ dark }: { dark?: boolean }) {
  const { mode, setMode } = useTheme()
  const opts: { v: ThemeMode; icon: React.ReactNode; label: string }[] = [
    { v: 'light', icon: <Sun size={15} />, label: 'Licht' },
    { v: 'dark', icon: <Moon size={15} />, label: 'Donker' },
    { v: 'system', icon: <Monitor size={15} />, label: 'Zoals je systeem' },
  ]
  return (
    <div role="radiogroup" aria-label="Weergave" className={cn('flex gap-0.5 rounded-full p-[3px]', dark ? 'bg-white/10' : 'bg-sunk')}>
      {opts.map((o) => (
        <Tip key={o.v} label={o.label}>
          <button role="radio" aria-checked={mode === o.v} aria-label={o.label} onClick={() => setMode(o.v)}
            className={cn('grid h-7 w-7 place-items-center rounded-full transition', mode === o.v ? (dark ? 'bg-white/20 text-white' : 'bg-surface text-ink shadow-card') : (dark ? 'text-white/60 hover:text-white' : 'text-muted hover:text-ink'))}>
            {o.icon}
          </button>
        </Tip>
      ))}
    </div>
  )
}
