import { siMeta, siFacebook, siInstagram, siGoogleads, siTiktok, siPinterest, siYoutube, siLinkedin } from 'simple-icons'

// Officiële merkiconen via Simple Icons (CC0). Alleen gebruikt om het platform aan te duiden.
const MAP: Record<string, { path: string; hex: string; title: string }> = {
  Meta: siMeta, Facebook: siFacebook, Instagram: siInstagram, 'Google Display': siGoogleads, 'Google Ads': siGoogleads,
  LinkedIn: siLinkedin, TikTok: siTiktok, Pinterest: siPinterest, YouTube: siYoutube,
}

export function PlatformLogo({ platform, size = 16, mono, className }: { platform: string; size?: number; mono?: string; className?: string }) {
  const icon = MAP[platform]
  if (!icon) return null
  return (
    <svg role="img" aria-label={platform} viewBox="0 0 24 24" width={size} height={size} className={className} style={{ flexShrink: 0 }}>
      <title>{platform}</title>
      <path d={icon.path} fill={mono || `#${icon.hex}`} />
    </svg>
  )
}

export function PlatformLogos({ platforms, size = 16, mono }: { platforms: string[]; size?: number; mono?: string }) {
  const uniq = [...new Set(platforms)].filter((p) => MAP[p])
  return <span className="inline-flex items-center gap-1">{uniq.map((p) => <PlatformLogo key={p} platform={p} size={size} mono={mono} />)}</span>
}
