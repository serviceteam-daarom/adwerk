import * as React from 'react'
import * as RTooltip from '@radix-ui/react-tooltip'
import * as RPopover from '@radix-ui/react-popover'
import * as RDialog from '@radix-ui/react-dialog'
import * as RSlider from '@radix-ui/react-slider'
import * as RMenu from '@radix-ui/react-dropdown-menu'
import clsx from 'clsx'
import { X, Pipette } from 'lucide-react'

export const cn = clsx

type BtnProps = React.ButtonHTMLAttributes<HTMLButtonElement> & { variant?: 'primary' | 'secondary' | 'ghost' | 'dark' | 'danger'; size?: 'sm' | 'md' | 'lg' }
export const Button = React.forwardRef<HTMLButtonElement, BtnProps>(({ variant = 'secondary', size = 'md', className, ...p }, ref) => (
  <button
    ref={ref}
    className={cn(
      'inline-flex items-center justify-center gap-2 font-medium rounded-full transition-colors disabled:opacity-50 disabled:pointer-events-none focus-visible:outline focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-violet whitespace-nowrap',
      size === 'sm' && 'h-8 px-3.5 text-[13px]',
      size === 'md' && 'h-10 px-5 text-sm',
      size === 'lg' && 'h-12 px-7 text-base',
      variant === 'primary' && 'bg-accent text-white hover:bg-accent-dark',
      variant === 'secondary' && 'bg-white text-ink border border-line hover:bg-sunk',
      variant === 'ghost' && 'text-ink hover:bg-sunk',
      variant === 'dark' && 'bg-ink text-white hover:bg-black',
      variant === 'danger' && 'bg-white text-red-600 border border-line hover:bg-red-50',
      className,
    )}
    {...p}
  />
))

export function Tip({ label, children, side = 'bottom' }: { label: React.ReactNode; children: React.ReactNode; side?: 'top' | 'bottom' | 'left' | 'right' }) {
  return (
    <RTooltip.Root delayDuration={350}>
      <RTooltip.Trigger asChild>{children}</RTooltip.Trigger>
      <RTooltip.Portal>
        <RTooltip.Content side={side} sideOffset={6} className="z-[100] rounded-md bg-ink px-2.5 py-1.5 text-xs font-medium text-white shadow-pop">
          {label}
        </RTooltip.Content>
      </RTooltip.Portal>
    </RTooltip.Root>
  )
}

export const IconBtn = React.forwardRef<HTMLButtonElement, React.ButtonHTMLAttributes<HTMLButtonElement> & { label: string; active?: boolean; dark?: boolean }>(
  ({ label, active, dark, className, ...p }, ref) => (
    <Tip label={label}>
      <button
        ref={ref}
        aria-label={label}
        className={cn(
          'inline-flex h-9 w-9 items-center justify-center rounded-lg transition-colors disabled:opacity-40 focus-visible:outline focus-visible:outline-2 focus-visible:outline-violet',
          dark ? 'text-white/85 hover:bg-white/10' : 'text-ink hover:bg-sunk',
          active && (dark ? 'bg-white/15' : 'bg-accent-soft text-accent'),
          className,
        )}
        {...p}
      />
    </Tip>
  ),
)

export function Label({ children, className }: { children: React.ReactNode; className?: string }) {
  return <div className={cn('text-[11px] font-bold uppercase tracking-[0.08em] text-muted', className)}>{children}</div>
}

export const Input = React.forwardRef<HTMLInputElement, React.InputHTMLAttributes<HTMLInputElement>>(({ className, ...p }, ref) => (
  <input ref={ref} className={cn('h-9 w-full rounded-lg bg-sunk px-3 text-sm text-ink outline-none ring-violet placeholder:text-muted focus:ring-2', className)} {...p} />
))

export function NumberField({ label, value, onChange, step = 1, min, max, suffix }: { label: string; value: number; onChange: (v: number) => void; step?: number; min?: number; max?: number; suffix?: string }) {
  const [v, setV] = React.useState(String(Math.round(value * 100) / 100))
  React.useEffect(() => setV(String(Math.round(value * 100) / 100)), [value])
  const commit = () => {
    let n = parseFloat(v.replace(',', '.'))
    if (isNaN(n)) return setV(String(value))
    if (min !== undefined) n = Math.max(min, n)
    if (max !== undefined) n = Math.min(max, n)
    onChange(n)
  }
  return (
    <label className="flex h-9 min-w-0 items-center gap-1.5 rounded-lg bg-sunk px-2.5 text-sm focus-within:ring-2 focus-within:ring-violet">
      <span className="shrink-0 text-[11px] font-bold text-muted">{label}</span>
      <input
        className="w-full min-w-0 bg-transparent text-right tabular-nums outline-none"
        value={v}
        onChange={(e) => setV(e.target.value)}
        onBlur={commit}
        onKeyDown={(e) => {
          if (e.key === 'Enter') commit()
          if (e.key === 'ArrowUp' || e.key === 'ArrowDown') {
            e.preventDefault()
            const n = value + (e.key === 'ArrowUp' ? 1 : -1) * step * (e.shiftKey ? 10 : 1)
            onChange(Math.min(max ?? Infinity, Math.max(min ?? -Infinity, n)))
          }
        }}
      />
      {suffix && <span className="text-xs text-muted">{suffix}</span>}
    </label>
  )
}

export function Slider({ label, value, onChange, onCommit, min = 0, max = 100, step = 1, format }: { label: string; value: number; onChange: (v: number) => void; onCommit?: (v: number) => void; min?: number; max?: number; step?: number; format?: (v: number) => string }) {
  return (
    <div className="grid gap-1.5">
      <div className="flex items-center justify-between text-[13px]">
        <span className="font-medium text-ink">{label}</span>
        <span className="tabular-nums text-muted">{format ? format(value) : value}</span>
      </div>
      <RSlider.Root className="relative flex h-5 touch-none select-none items-center" value={[value]} min={min} max={max} step={step} onValueChange={(v) => onChange(v[0])} onValueCommit={(v) => onCommit?.(v[0])}>
        <RSlider.Track className="relative h-1.5 grow rounded-full bg-sunk">
          <RSlider.Range className="absolute h-full rounded-full bg-accent" />
        </RSlider.Track>
        <RSlider.Thumb aria-label={label} className="block h-4 w-4 rounded-full border-2 border-accent bg-white shadow focus:outline-none focus-visible:ring-2 focus-visible:ring-violet" />
      </RSlider.Root>
    </div>
  )
}

export function Segmented<T extends string>({ value, onChange, options }: { value: T; onChange: (v: T) => void; options: { value: T; label: React.ReactNode; title?: string }[] }) {
  return (
    <div className="flex gap-0.5 rounded-lg bg-sunk p-[3px]">
      {options.map((o) => (
        <button
          key={o.value}
          title={o.title}
          aria-pressed={value === o.value}
          onClick={() => onChange(o.value)}
          className={cn('flex h-7 flex-1 items-center justify-center rounded-md px-2 text-[13px] font-semibold text-muted transition', value === o.value && 'bg-white text-ink shadow-card')}
        >
          {o.label}
        </button>
      ))}
    </div>
  )
}

export function Select({ value, onChange, options, className }: { value: string; onChange: (v: string) => void; options: { value: string; label: string }[]; className?: string }) {
  return (
    <select value={value} onChange={(e) => onChange(e.target.value)} className={cn('h-9 w-full rounded-lg bg-sunk px-2.5 text-sm text-ink outline-none focus:ring-2 focus:ring-violet', className)}>
      {options.map((o) => <option key={o.value} value={o.value}>{o.label}</option>)}
    </select>
  )
}

export const Popover = RPopover.Root
export const PopoverTrigger = RPopover.Trigger
export function PopoverContent({ children, className, side = 'bottom', align = 'start' }: { children: React.ReactNode; className?: string; side?: 'top' | 'bottom' | 'left' | 'right'; align?: 'start' | 'center' | 'end' }) {
  return (
    <RPopover.Portal>
      <RPopover.Content side={side} align={align} sideOffset={8} collisionPadding={12} className={cn('z-[90] rounded-xl border border-line bg-white p-3 shadow-pop outline-none', className)}>
        {children}
      </RPopover.Content>
    </RPopover.Portal>
  )
}

export function Dialog({ open, onOpenChange, title, description, children, wide }: { open: boolean; onOpenChange: (o: boolean) => void; title: string; description?: string; children: React.ReactNode; wide?: boolean }) {
  return (
    <RDialog.Root open={open} onOpenChange={onOpenChange}>
      <RDialog.Portal>
        <RDialog.Overlay className="fixed inset-0 z-[80] bg-ink/40 backdrop-blur-[2px]" />
        <RDialog.Content className={cn('fixed left-1/2 top-1/2 z-[81] max-h-[88vh] w-[calc(100vw-32px)] -translate-x-1/2 -translate-y-1/2 overflow-auto rounded-[20px] bg-white p-6 shadow-pop outline-none', wide ? 'max-w-3xl' : 'max-w-lg')}>
          <div className="mb-4 flex items-start justify-between gap-4">
            <div>
              <RDialog.Title className="font-display text-2xl font-semibold text-ink">{title}<span className="text-accent">.</span></RDialog.Title>
              {description && <RDialog.Description className="mt-1 text-sm text-muted">{description}</RDialog.Description>}
            </div>
            <RDialog.Close className="rounded-lg p-1.5 text-muted hover:bg-sunk" aria-label="Sluiten"><X size={18} /></RDialog.Close>
          </div>
          {children}
        </RDialog.Content>
      </RDialog.Portal>
    </RDialog.Root>
  )
}

export const Menu = RMenu.Root
export const MenuTrigger = RMenu.Trigger
export function MenuContent({ children, align = 'end' }: { children: React.ReactNode; align?: 'start' | 'end' }) {
  return (
    <RMenu.Portal>
      <RMenu.Content align={align} sideOffset={6} className="z-[90] min-w-[200px] rounded-xl border border-line bg-white p-1.5 shadow-pop">
        {children}
      </RMenu.Content>
    </RMenu.Portal>
  )
}
export function MenuItem({ children, onSelect, danger }: { children: React.ReactNode; onSelect: () => void; danger?: boolean }) {
  return (
    <RMenu.Item onSelect={onSelect} className={cn('flex cursor-pointer items-center gap-2.5 rounded-lg px-2.5 py-2 text-sm outline-none data-[highlighted]:bg-sunk', danger ? 'text-red-600' : 'text-ink')}>
      {children}
    </RMenu.Item>
  )
}
export const MenuSep = () => <RMenu.Separator className="my-1 h-px bg-line" />

/* ---------- Kleurkiezer ---------- */

const DEFAULT_SWATCHES = ['#FFFFFF', '#F6F5FA', '#D9D6E3', '#6B6880', '#1B213B', '#000000', '#EA5F39', '#E0337A', '#FFC233', '#13B58C', '#1F8FE5', '#1A5FC4']

export function ColorPicker({ value, onChange, docColors = [], brandColors = [], label }: { value: string; onChange: (c: string) => void; docColors?: string[]; brandColors?: string[]; label?: string }) {
  const [hex, setHex] = React.useState(value)
  React.useEffect(() => setHex(value), [value])
  const eyedrop = async () => {
    const ED = (window as unknown as { EyeDropper?: new () => { open: () => Promise<{ sRGBHex: string }> } }).EyeDropper
    if (!ED) return
    try { const r = await new ED().open(); onChange(r.sRGBHex) } catch { /* geannuleerd */ }
  }
  const Sw = ({ c }: { c: string }) => (
    <button title={c} onClick={() => onChange(c)} className={cn('h-7 w-7 rounded-md border border-line', c.toLowerCase() === value.toLowerCase() && 'ring-2 ring-violet ring-offset-1')} style={{ background: c }} />
  )
  return (
    <Popover>
      <PopoverTrigger asChild>
        <button className="flex h-9 w-full items-center gap-2 rounded-lg bg-sunk px-2 text-sm" aria-label={label || 'Kleur kiezen'}>
          <span className="h-6 w-6 rounded-md border border-line" style={{ background: value }} />
          <span className="font-mono text-xs uppercase text-ink">{value}</span>
        </button>
      </PopoverTrigger>
      <PopoverContent className="w-[260px]">
        <div className="grid gap-3">
          <div className="flex items-center gap-2">
            <input type="color" value={/^#[0-9a-f]{6}$/i.test(value) ? value : '#000000'} onChange={(e) => onChange(e.target.value)} className="h-10 w-12 cursor-pointer rounded-md border border-line bg-white p-0.5" />
            <Input value={hex} onChange={(e) => setHex(e.target.value)} onBlur={() => /^#([0-9a-f]{3}|[0-9a-f]{6}|[0-9a-f]{8})$/i.test(hex) && onChange(hex)} onKeyDown={(e) => e.key === 'Enter' && /^#([0-9a-f]{3}|[0-9a-f]{6})$/i.test(hex) && onChange(hex)} className="font-mono uppercase" />
            {'EyeDropper' in window && <IconBtn label="Kleur van scherm pakken" onClick={eyedrop}><Pipette size={16} /></IconBtn>}
          </div>
          {brandColors.length > 0 && (<div className="grid gap-1.5"><Label>Merkkleuren</Label><div className="flex flex-wrap gap-1.5">{brandColors.map((c, i) => <Sw key={c + i} c={c} />)}</div></div>)}
          {docColors.length > 0 && (<div className="grid gap-1.5"><Label>In dit ontwerp</Label><div className="flex flex-wrap gap-1.5">{docColors.slice(0, 18).map((c, i) => <Sw key={c + i} c={c} />)}</div></div>)}
          <div className="grid gap-1.5"><Label>Standaard</Label><div className="flex flex-wrap gap-1.5">{DEFAULT_SWATCHES.map((c) => <Sw key={c} c={c} />)}</div></div>
        </div>
      </PopoverContent>
    </Popover>
  )
}

export function Avatar({ name, color, src, size = 28, ring }: { name: string; color?: string | null; src?: string | null; size?: number; ring?: string }) {
  const initials = name.split(/[\s.@]+/).filter(Boolean).slice(0, 2).map((s) => s[0]?.toUpperCase()).join('')
  return (
    <span className="relative inline-grid shrink-0 place-items-center overflow-hidden rounded-full text-[11px] font-bold text-white" style={{ width: size, height: size, background: color || '#1A5FC4', boxShadow: ring ? `0 0 0 2px ${ring}` : undefined }} title={name}>
      {src ? <img src={src} alt="" referrerPolicy="no-referrer" className="h-full w-full object-cover" /> : initials}
    </span>
  )
}

export function Toast({ text }: { text: string | null }) {
  if (!text) return null
  return <div role="status" className="fixed bottom-6 left-1/2 z-[120] -translate-x-1/2 rounded-xl bg-ink px-4 py-2.5 text-sm font-medium text-white shadow-pop">{text}</div>
}

export const TooltipProvider = RTooltip.Provider
