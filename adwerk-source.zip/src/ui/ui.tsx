import * as React from 'react'
import * as RTooltip from '@radix-ui/react-tooltip'
import * as RPopover from '@radix-ui/react-popover'
import * as RDialog from '@radix-ui/react-dialog'
import * as RSlider from '@radix-ui/react-slider'
import * as RMenu from '@radix-ui/react-dropdown-menu'
import clsx, { type ClassValue } from 'clsx'
import { extendTailwindMerge } from 'tailwind-merge'
import { X, Pipette, Check, ChevronDown, ChevronsLeft, ChevronsRight } from 'lucide-react'

// tailwind-merge kent onze eigen kleuren, radius en schaduwen, zodat "w-full" en "w-20" of "px-5" en "p-0" elkaar netjes overschrijven
const twMerge = extendTailwindMerge({
  extend: {
    theme: { colors: ['ink', 'mist', 'sunk', 'line', 'muted', 'surface', 'navy', 'accent', 'accent-soft', 'accent-dark', 'accent-fg', 'violet', 'violet-soft', 'warn', 'orange', 'lila', 'sky', 'mint', 'sun'], borderRadius: ['card', 'blob'] },
    classGroups: { shadow: [{ shadow: ['pop', 'card'] }], 'font-family': [{ font: ['display', 'hand', 'sans'] }] },
  },
})
export const cn = (...v: ClassValue[]) => twMerge(clsx(...v))

type BtnProps = React.ButtonHTMLAttributes<HTMLButtonElement> & { variant?: 'primary' | 'secondary' | 'ghost' | 'dark' | 'danger'; size?: 'sm' | 'md' | 'lg' }
export const Button = React.forwardRef<HTMLButtonElement, BtnProps>(({ variant = 'secondary', size = 'md', className, ...p }, ref) => (
  <button
    ref={ref}
    className={cn(
      'press inline-flex items-center justify-center gap-2 font-medium rounded-full transition-[color,background-color,transform] disabled:opacity-50 disabled:pointer-events-none focus-visible:outline focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-violet whitespace-nowrap',
      size === 'sm' && 'h-8 px-3.5 text-[13px]',
      size === 'md' && 'h-10 px-5 text-sm',
      size === 'lg' && 'h-12 px-7 text-base',
      variant === 'primary' && 'bg-accent text-white hover:bg-accent-dark',
      variant === 'secondary' && 'bg-surface text-ink border border-line hover:bg-sunk',
      variant === 'ghost' && 'text-ink hover:bg-sunk',
      variant === 'dark' && 'bg-navy text-white hover:bg-black dark:border dark:border-line',
      variant === 'danger' && 'bg-surface text-red-600 border border-line hover:bg-red-50',
      className,
    )}
    {...p}
  />
))

export function Tip({ label, children, side = 'bottom' }: { label: React.ReactNode; children: React.ReactNode; side?: 'top' | 'bottom' | 'left' | 'right' }) {
  return (
    <RTooltip.Root delayDuration={350}>
      <RTooltip.Trigger asChild>{children}</RTooltip.Trigger>
      <RTooltip.Portal>
        <RTooltip.Content side={side} sideOffset={6} className="anim-tip z-[100] rounded-md bg-navy px-2.5 py-1.5 text-xs font-medium text-white shadow-pop">
          {label}
        </RTooltip.Content>
      </RTooltip.Portal>
    </RTooltip.Root>
  )
}

export const IconBtn = React.forwardRef<HTMLButtonElement, React.ButtonHTMLAttributes<HTMLButtonElement> & { label: string; active?: boolean; dark?: boolean }>(
  ({ label, active, dark, className, ...p }, ref) => (
    <Tip label={label}>
      <button
        ref={ref}
        aria-label={label}
        className={cn(
          'inline-flex h-9 w-9 items-center justify-center rounded-lg transition-colors disabled:opacity-40 focus-visible:outline focus-visible:outline-2 focus-visible:outline-violet',
          dark ? 'text-white/85 hover:bg-white/10' : 'text-ink hover:bg-sunk',
          active && (dark ? 'bg-white/15' : 'bg-accent-soft text-accent-fg'),
          className,
        )}
        {...p}
      />
    </Tip>
  ),
)

export function Label({ children, className }: { children: React.ReactNode; className?: string }) {
  return <div className={cn('text-[11px] font-bold uppercase tracking-[0.08em] text-muted', className)}>{children}</div>
}

export const Input = React.forwardRef<HTMLInputElement, React.InputHTMLAttributes<HTMLInputElement>>(({ className, ...p }, ref) => (
  <input ref={ref} className={cn('h-9 w-full rounded-lg bg-sunk px-3 text-sm text-ink outline-none ring-violet placeholder:text-muted focus:ring-2', className)} {...p} />
))

export function NumberField({ label, value, onChange, step = 1, min, max, suffix }: { label: string; value: number; onChange: (v: number) => void; step?: number; min?: number; max?: number; suffix?: string }) {
  const [v, setV] = React.useState(String(Math.round(value * 100) / 100))
  React.useEffect(() => setV(String(Math.round(value * 100) / 100)), [value])
  const commit = () => {
    let n = parseFloat(v.replace(',', '.'))
    if (isNaN(n)) return setV(String(value))
    if (min !== undefined) n = Math.max(min, n)
    if (max !== undefined) n = Math.min(max, n)
    onChange(n)
  }
  return (
    <label className="flex h-9 min-w-0 items-center gap-1.5 rounded-lg bg-sunk px-2.5 text-sm focus-within:ring-2 focus-within:ring-violet">
      <span className="shrink-0 text-[11px] font-bold text-muted">{label}</span>
      <input
        className="w-full min-w-0 bg-transparent text-right tabular-nums outline-none"
        value={v}
        onChange={(e) => setV(e.target.value)}
        onBlur={commit}
        onKeyDown={(e) => {
          if (e.key === 'Enter') commit()
          if (e.key === 'ArrowUp' || e.key === 'ArrowDown') {
            e.preventDefault()
            const n = value + (e.key === 'ArrowUp' ? 1 : -1) * step * (e.shiftKey ? 10 : 1)
            onChange(Math.min(max ?? Infinity, Math.max(min ?? -Infinity, n)))
          }
        }}
      />
      {suffix && <span className="text-xs text-muted">{suffix}</span>}
    </label>
  )
}

export function Slider({ label, value, onChange, onCommit, min = 0, max = 100, step = 1, format }: { label: string; value: number; onChange: (v: number) => void; onCommit?: (v: number) => void; min?: number; max?: number; step?: number; format?: (v: number) => string }) {
  return (
    <div className="grid gap-1.5">
      <div className="flex items-center justify-between text-[13px]">
        <span className="font-medium text-ink">{label}</span>
        <span className="tabular-nums text-muted">{format ? format(value) : value}</span>
      </div>
      <RSlider.Root className="relative flex h-5 touch-none select-none items-center" value={[value]} min={min} max={max} step={step} onValueChange={(v) => onChange(v[0])} onValueCommit={(v) => onCommit?.(v[0])}>
        <RSlider.Track className="relative h-1.5 grow rounded-full bg-sunk">
          <RSlider.Range className="absolute h-full rounded-full bg-accent" />
        </RSlider.Track>
        <RSlider.Thumb aria-label={label} className="block h-4 w-4 rounded-full border-2 border-accent bg-surface shadow focus:outline-none focus-visible:ring-2 focus-visible:ring-violet" />
      </RSlider.Root>
    </div>
  )
}

export function Segmented<T extends string>({ value, onChange, options }: { value: T; onChange: (v: T) => void; options: { value: T; label: React.ReactNode; title?: string }[] }) {
  return (
    <div className="flex gap-0.5 rounded-lg bg-sunk p-[3px]">
      {options.map((o) => (
        <button
          key={o.value}
          title={o.title}
          aria-pressed={value === o.value}
          onClick={() => onChange(o.value)}
          className={cn('flex h-7 flex-1 items-center justify-center rounded-md px-2 text-[13px] font-semibold text-muted transition', value === o.value && 'bg-surface text-ink shadow-card')}
        >
          {o.label}
        </button>
      ))}
    </div>
  )
}

export interface SelectOption { value: string; label: string; hint?: string; dot?: string; icon?: React.ReactNode; group?: string; disabled?: boolean }
/** Eigen keuzelijst: zelfde vormtaal als de rest van Adwerk, met toetsenbord, zoeken op letter en animatie. */
export function Select({ value, onChange, options, className, variant = 'sunk', size = 'md', ariaLabel, placeholder = 'Kies…', align = 'start', renderValue, menuClassName, fullWidth = true }: {
  value: string; onChange: (v: string) => void; options: SelectOption[]; className?: string
  variant?: 'sunk' | 'surface' | 'ghost' | 'pill'; size?: 'xs' | 'sm' | 'md' | 'lg'; ariaLabel?: string; placeholder?: string
  align?: 'start' | 'end' | 'center'; renderValue?: (o: SelectOption | undefined) => React.ReactNode; menuClassName?: string; fullWidth?: boolean
}) {
  const [open, setOpen] = React.useState(false)
  const [hi, setHi] = React.useState(0)
  const list = React.useRef<HTMLDivElement>(null)
  const typed = React.useRef({ s: '', t: 0 })
  const cur = options.find((o) => o.value === value)
  const enabled = options.map((o, i) => (o.disabled ? -1 : i)).filter((i) => i >= 0)
  React.useEffect(() => { if (open) { const i = Math.max(0, options.findIndex((o) => o.value === value)); setHi(i); requestAnimationFrame(() => list.current?.querySelector<HTMLElement>(`[data-i="${i}"]`)?.scrollIntoView({ block: 'nearest' })) } }, [open]) // eslint-disable-line react-hooks/exhaustive-deps
  const move = (d: number) => { const pos = enabled.indexOf(hi); const n = enabled[Math.min(enabled.length - 1, Math.max(0, (pos < 0 ? 0 : pos) + d))]; if (n !== undefined) { setHi(n); list.current?.querySelector<HTMLElement>(`[data-i="${n}"]`)?.scrollIntoView({ block: 'nearest' }) } }
  const pick = (o: SelectOption) => { if (o.disabled) return; onChange(o.value); setOpen(false) }
  const onKey = (e: React.KeyboardEvent) => {
    e.stopPropagation()
    if (!open) { if (['ArrowDown', 'ArrowUp', 'Enter', ' '].includes(e.key)) { e.preventDefault(); setOpen(true) } return }
    if (e.key === 'ArrowDown') { e.preventDefault(); move(1) } else if (e.key === 'ArrowUp') { e.preventDefault(); move(-1) }
    else if (e.key === 'Home') { e.preventDefault(); setHi(enabled[0] ?? 0) } else if (e.key === 'End') { e.preventDefault(); setHi(enabled[enabled.length - 1] ?? 0) }
    else if (e.key === 'Enter' || e.key === ' ') { e.preventDefault(); const o = options[hi]; if (o) pick(o) }
    else if (e.key.length === 1) {
      const now = Date.now(); typed.current.s = (now - typed.current.t > 700 ? '' : typed.current.s) + e.key.toLowerCase(); typed.current.t = now
      const i = options.findIndex((o) => !o.disabled && o.label.toLowerCase().startsWith(typed.current.s)); if (i >= 0) { setHi(i); list.current?.querySelector<HTMLElement>(`[data-i="${i}"]`)?.scrollIntoView({ block: 'nearest' }) }
    }
  }
  const sizes = { xs: 'h-7 px-2 text-xs gap-1.5', sm: 'h-8 px-2.5 text-[13px] gap-1.5', md: 'h-9 px-3 text-sm gap-2', lg: 'h-10 px-3.5 text-sm gap-2' }
  const variants = { sunk: 'rounded-lg bg-sunk hover:bg-line/50', surface: 'rounded-lg border border-line bg-surface hover:border-muted/40', ghost: 'rounded-lg bg-transparent hover:bg-sunk', pill: 'rounded-full bg-surface shadow-sm hover:shadow-card' }
  let lastGroup: string | undefined
  return (
    <RPopover.Root open={open} onOpenChange={setOpen}>
      <RPopover.Trigger type="button" role="combobox" aria-expanded={open} aria-label={ariaLabel} onKeyDown={onKey} title={cur?.label}
        className={cn('group/sel flex min-w-0 items-center text-left font-medium text-ink outline-none ring-violet transition focus-visible:ring-2 data-[state=open]:ring-2', fullWidth && 'w-full', sizes[size], variants[variant], className)}>
        {renderValue ? renderValue(cur) : (
          <>
            {cur?.dot && <span className="h-2 w-2 shrink-0 rounded-full" style={{ background: cur.dot }} />}
            {cur?.icon && <span className="grid shrink-0 place-items-center text-muted">{cur.icon}</span>}
            <span className={cn('min-w-0 flex-1 truncate', !cur && 'text-muted')}>{cur?.label ?? placeholder}</span>
          </>
        )}
        <ChevronDown size={size === 'xs' ? 12 : 14} className="shrink-0 text-muted transition-transform duration-200 group-data-[state=open]/sel:rotate-180" />
      </RPopover.Trigger>
      <RPopover.Portal>
        <RPopover.Content align={align} sideOffset={6} collisionPadding={12} onKeyDown={onKey} onOpenAutoFocus={(e) => { e.preventDefault(); (e.currentTarget as HTMLElement).focus() }} tabIndex={-1}
          className={cn('anim-pop z-[95] max-h-[min(340px,var(--radix-popover-content-available-height))] min-w-[max(var(--radix-popover-trigger-width),160px)] max-w-[min(360px,calc(100vw-24px))] overflow-y-auto overscroll-contain rounded-xl border border-line bg-surface p-1.5 shadow-pop outline-none', menuClassName)}>
          <div ref={list} role="listbox" aria-label={ariaLabel}>
            {options.map((o, i) => {
              const head = o.group && o.group !== lastGroup ? o.group : null
              lastGroup = o.group
              const sel = o.value === value
              return (
                <React.Fragment key={o.value + i}>
                  {head && <div className={cn('px-2.5 pb-1 text-[11px] font-semibold uppercase tracking-wide text-muted', i > 0 ? 'pt-2.5' : 'pt-1')}>{head}</div>}
                  <div role="option" aria-selected={sel} aria-disabled={o.disabled} data-i={i} onMouseEnter={() => !o.disabled && setHi(i)} onClick={() => pick(o)}
                    className={cn('flex min-w-0 cursor-pointer items-center gap-2.5 rounded-lg px-2.5 py-2 text-sm transition-colors', i === hi && !o.disabled && 'bg-sunk', sel && 'font-semibold', o.disabled && 'cursor-default opacity-40')}>
                    {o.dot && <span className="h-2 w-2 shrink-0 rounded-full" style={{ background: o.dot }} />}
                    {o.icon && <span className="grid shrink-0 place-items-center text-muted">{o.icon}</span>}
                    <span className="min-w-0 flex-1 truncate" title={o.label}>{o.label}</span>
                    {o.hint && <span className="shrink-0 text-xs font-normal tabular-nums text-muted">{o.hint}</span>}
                    <Check size={14} className={cn('shrink-0 text-accent-fg transition', sel ? 'scale-100 opacity-100' : 'scale-50 opacity-0')} />
                  </div>
                </React.Fragment>
              )
            })}
          </div>
        </RPopover.Content>
      </RPopover.Portal>
    </RPopover.Root>
  )
}

export const Popover = RPopover.Root
export const PopoverTrigger = RPopover.Trigger
export function PopoverContent({ children, className, side = 'bottom', align = 'start' }: { children: React.ReactNode; className?: string; side?: 'top' | 'bottom' | 'left' | 'right'; align?: 'start' | 'center' | 'end' }) {
  return (
    <RPopover.Portal>
      <RPopover.Content side={side} align={align} sideOffset={8} collisionPadding={12} className={cn('anim-pop z-[90] rounded-xl border border-line bg-surface p-3 shadow-pop outline-none', className)}>
        {children}
      </RPopover.Content>
    </RPopover.Portal>
  )
}

export function Dialog({ open, onOpenChange, title, description, children, wide, xl }: { open: boolean; onOpenChange: (o: boolean) => void; title: string; description?: string; children: React.ReactNode; wide?: boolean; xl?: boolean }) {
  const [compact, setCompact] = React.useState(false)
  React.useEffect(() => { if (open) setCompact(false) }, [open])
  return (
    <RDialog.Root open={open} onOpenChange={onOpenChange}>
      <RDialog.Portal>
        <RDialog.Overlay className="anim-overlay fixed inset-0 z-[80] bg-navy/60 backdrop-blur-[2px]" />
        <RDialog.Content className={cn('anim-dialog fixed left-1/2 top-1/2 z-[81] flex max-h-[88vh] w-[calc(100vw-32px)] -translate-x-1/2 -translate-y-1/2 flex-col overflow-hidden rounded-[20px] bg-surface shadow-pop outline-none', xl ? 'max-w-5xl' : wide ? 'max-w-3xl' : 'max-w-lg')}>
          <div className="min-h-0 flex-1 overflow-y-auto overscroll-contain" onScroll={(e) => { const c = (e.currentTarget as HTMLDivElement).scrollTop > 12; if (c !== compact) setCompact(c) }}>
            <div className={cn('glass-head sticky top-0 z-20 flex items-start justify-between gap-4 px-6 transition-[padding,background-color,box-shadow,backdrop-filter] duration-300 [transition-timing-function:var(--ease-out)]', compact ? 'is-compact py-3' : 'pb-4 pt-6')}>
              <div className="min-w-0">
                <RDialog.Title className={cn('truncate font-display font-semibold text-ink transition-[font-size,line-height] duration-300 [transition-timing-function:var(--ease-out)]', compact ? 'text-[17px] leading-7' : 'text-2xl leading-8')} title={title}>{title}<span className="text-accent-fg">.</span></RDialog.Title>
                {description && (
                  <div className={cn('grid transition-[grid-template-rows,opacity,margin] duration-300 [transition-timing-function:var(--ease-out)]', compact ? 'mt-0 grid-rows-[0fr] opacity-0' : 'mt-1 grid-rows-[1fr] opacity-100')}>
                    <RDialog.Description className="overflow-hidden text-sm text-muted">{description}</RDialog.Description>
                  </div>
                )}
              </div>
              <RDialog.Close className={cn('grid shrink-0 place-items-center rounded-full text-muted transition-all duration-300 hover:bg-sunk hover:text-ink', compact ? 'h-8 w-8 bg-surface/70 shadow-sm' : 'h-9 w-9 -mr-1.5 -mt-1')} aria-label="Sluiten"><X size={compact ? 16 : 18} /></RDialog.Close>
            </div>
            <div className="px-6 pb-6">{children}</div>
          </div>
        </RDialog.Content>
      </RDialog.Portal>
    </RDialog.Root>
  )
}

export const Menu = RMenu.Root
export const MenuTrigger = RMenu.Trigger
export function MenuContent({ children, align = 'end' }: { children: React.ReactNode; align?: 'start' | 'end' }) {
  return (
    <RMenu.Portal>
      <RMenu.Content align={align} sideOffset={6} className="anim-pop z-[90] min-w-[200px] rounded-xl border border-line bg-surface p-1.5 shadow-pop">
        {children}
      </RMenu.Content>
    </RMenu.Portal>
  )
}
export function MenuItem({ children, onSelect, danger }: { children: React.ReactNode; onSelect: () => void; danger?: boolean }) {
  return (
    <RMenu.Item onSelect={onSelect} className={cn('flex cursor-pointer items-center gap-2.5 rounded-lg px-2.5 py-2 text-sm outline-none data-[highlighted]:bg-sunk', danger ? 'text-red-600' : 'text-ink')}>
      {children}
    </RMenu.Item>
  )
}
export const MenuSep = () => <RMenu.Separator className="my-1 h-px bg-line" />

/* ---------- Kleurkiezer ---------- */

const DEFAULT_SWATCHES = ['#FFFFFF', '#F6F5FA', '#D9D6E3', '#6B6880', '#1B213B', '#000000', '#EA5F39', '#E0337A', '#FFC233', '#13B58C', '#1F8FE5', '#1A5FC4']

export function ColorPicker({ value, onChange, docColors = [], brandColors = [], label }: { value: string; onChange: (c: string) => void; docColors?: string[]; brandColors?: string[]; label?: string }) {
  const [hex, setHex] = React.useState(value)
  React.useEffect(() => setHex(value), [value])
  const eyedrop = async () => {
    const ED = (window as unknown as { EyeDropper?: new () => { open: () => Promise<{ sRGBHex: string }> } }).EyeDropper
    if (!ED) return
    try { const r = await new ED().open(); onChange(r.sRGBHex) } catch { /* geannuleerd */ }
  }
  const Sw = ({ c }: { c: string }) => (
    <button title={c} onClick={() => onChange(c)} className={cn('h-7 w-7 rounded-md border border-line', c.toLowerCase() === value.toLowerCase() && 'ring-2 ring-violet ring-offset-1')} style={{ background: c }} />
  )
  return (
    <Popover>
      <PopoverTrigger asChild>
        <button className="flex h-9 w-full items-center gap-2 rounded-lg bg-sunk px-2 text-sm" aria-label={label || 'Kleur kiezen'}>
          <span className="h-6 w-6 rounded-md border border-line" style={{ background: value }} />
          <span className="font-mono text-xs uppercase text-ink">{value}</span>
        </button>
      </PopoverTrigger>
      <PopoverContent className="w-[260px]">
        <div className="grid gap-3">
          <div className="flex items-center gap-2">
            <input type="color" value={/^#[0-9a-f]{6}$/i.test(value) ? value : '#000000'} onChange={(e) => onChange(e.target.value)} className="h-10 w-12 cursor-pointer rounded-md border border-line bg-surface p-0.5" />
            <Input value={hex} onChange={(e) => setHex(e.target.value)} onBlur={() => /^#([0-9a-f]{3}|[0-9a-f]{6}|[0-9a-f]{8})$/i.test(hex) && onChange(hex)} onKeyDown={(e) => e.key === 'Enter' && /^#([0-9a-f]{3}|[0-9a-f]{6})$/i.test(hex) && onChange(hex)} className="font-mono uppercase" />
            {'EyeDropper' in window && <IconBtn label="Kleur van scherm pakken" onClick={eyedrop}><Pipette size={16} /></IconBtn>}
          </div>
          {brandColors.length > 0 && (<div className="grid gap-1.5"><Label>Merkkleuren</Label><div className="flex flex-wrap gap-1.5">{brandColors.map((c, i) => <Sw key={c + i} c={c} />)}</div></div>)}
          {docColors.length > 0 && (<div className="grid gap-1.5"><Label>In dit ontwerp</Label><div className="flex flex-wrap gap-1.5">{docColors.slice(0, 18).map((c, i) => <Sw key={c + i} c={c} />)}</div></div>)}
          <div className="grid gap-1.5"><Label>Standaard</Label><div className="flex flex-wrap gap-1.5">{DEFAULT_SWATCHES.map((c) => <Sw key={c} c={c} />)}</div></div>
        </div>
      </PopoverContent>
    </Popover>
  )
}

export function Avatar({ name, color, src, size = 28, ring }: { name: string; color?: string | null; src?: string | null; size?: number; ring?: string }) {
  const initials = name.replace(/\(.*?\)/g, ' ').split(/[^\p{L}\p{N}]+/u).filter(Boolean).slice(0, 2).map((s) => s[0]?.toUpperCase()).join('')
  return (
    <span className="relative inline-grid shrink-0 place-items-center overflow-hidden rounded-full text-[11px] font-bold text-white" style={{ width: size, height: size, background: color || '#1A5FC4', boxShadow: ring ? `0 0 0 2px ${ring}` : undefined }} title={name}>
      {src ? <img src={src} alt="" referrerPolicy="no-referrer" className="h-full w-full object-cover" /> : initials}
    </span>
  )
}

export function Toast({ text }: { text: string | null }) {
  if (!text) return null
  return <div role="status" className="fixed bottom-6 left-1/2 z-[120] -translate-x-1/2 rounded-xl bg-navy px-4 py-2.5 text-sm font-medium text-white shadow-pop">{text}</div>
}

export const TooltipProvider = RTooltip.Provider

/** Houdt iets nog even in beeld tijdens de sluit-animatie. */
export function usePresence(open: boolean, ms = 220) {
  const [mounted, setMounted] = React.useState(open)
  const [shown, setShown] = React.useState(open)
  React.useEffect(() => {
    if (open) { setMounted(true); const r = requestAnimationFrame(() => requestAnimationFrame(() => setShown(true))); return () => cancelAnimationFrame(r) }
    setShown(false)
    const t = setTimeout(() => setMounted(false), ms)
    return () => clearTimeout(t)
  }, [open, ms])
  return { mounted, shown }
}

/** Zijpaneel met achtergrond: schuift in, klik op de achtergrond of Escape sluit het. */
export function Sheet({ open, onClose, side = 'right', className, children, label, z = 90, top = 0, onScrollCapture }: { open: boolean; onClose: () => void; side?: 'left' | 'right'; className?: string; children: React.ReactNode; label: string; z?: number; top?: number; onScrollCapture?: React.UIEventHandler<HTMLDivElement> }) {
  const { mounted, shown } = usePresence(open, 260)
  React.useEffect(() => {
    if (!open) return
    const onKey = (e: KeyboardEvent) => { if (e.key === 'Escape') onClose() }
    window.addEventListener('keydown', onKey)
    return () => window.removeEventListener('keydown', onKey)
  }, [open, onClose])
  if (!mounted) return null
  return (
    <div className="fixed inset-x-0 bottom-0" style={{ zIndex: z, top }} role="dialog" aria-modal="true" aria-label={label}>
      <div onClick={onClose} className={cn('absolute inset-0 transition-opacity duration-200', top ? 'bg-navy/25' : 'bg-navy/45 backdrop-blur-[2px]', shown ? 'opacity-100' : 'opacity-0')} />
      <div onScrollCapture={onScrollCapture} className={cn('absolute inset-y-0 flex flex-col bg-surface shadow-pop transition-transform duration-[260ms] [transition-timing-function:var(--ease-out)]', side === 'right' ? 'right-0' : 'left-0', shown ? 'translate-x-0' : side === 'right' ? 'translate-x-full' : '-translate-x-full', className)}>
        {children}
      </div>
    </div>
  )
}

/** Inklapknop op de rand van een paneel, plus een klikbare rand. De ouder moet "relative group/edge" hebben. */
export function EdgeToggle({ edge, collapsed, onToggle, label, kbd, always, top = 22, className, handleClassName }: { edge: 'left' | 'right'; collapsed: boolean; onToggle: () => void; label: string; kbd?: string; always?: boolean; top?: number; className?: string; handleClassName?: string }) {
  const Icon = (edge === 'right') === collapsed ? ChevronsRight : ChevronsLeft
  return (
    <>
      <Tip label={<span className="flex items-center gap-2">{label}{kbd && <kbd className="rounded bg-white/15 px-1.5 py-0.5 text-[10px] font-semibold">{kbd}</kbd>}</span>} side={edge === 'right' ? 'right' : 'left'}>
        <button onClick={onToggle} aria-label={label} aria-expanded={!collapsed} style={{ top }}
          className={cn('absolute z-40 grid h-7 w-7 place-items-center rounded-full border border-line bg-surface text-muted shadow-card transition-[opacity,transform,color] duration-200 [transition-timing-function:var(--ease-out)] hover:scale-110 hover:text-ink focus-visible:opacity-100', edge === 'right' ? '-right-3.5' : '-left-3.5', always ? 'opacity-90' : 'opacity-0 group-hover/edge:opacity-100', className, handleClassName)}>
          <Icon size={14} />
        </button>
      </Tip>
      <button onClick={onToggle} tabIndex={-1} aria-hidden title={label}
        className={cn('absolute top-0 z-30 h-full w-2 cursor-pointer after:absolute after:left-1/2 after:top-0 after:h-full after:w-0.5 after:-translate-x-1/2 after:bg-accent after:opacity-0 after:transition hover:after:opacity-40', edge === 'right' ? '-right-1' : '-left-1', className)} />
    </>
  )
}

/** Aan/uit-schakelaar. */
export function Switch({ checked, onChange, label, className }: { checked: boolean; onChange: (v: boolean) => void; label: string; className?: string }) {
  return (
    <button type="button" role="switch" aria-checked={checked} aria-label={label} onClick={() => onChange(!checked)}
      className={cn('relative inline-flex h-6 w-10 shrink-0 items-center rounded-full transition-colors duration-200', checked ? 'bg-accent' : 'bg-line', className)}>
      <span className={cn('absolute left-0.5 h-5 w-5 rounded-full bg-white shadow transition-transform duration-200 [transition-timing-function:var(--ease-out)]', checked && 'translate-x-4')} />
    </button>
  )
}
