import { useEffect, useLayoutEffect, useRef, useState } from 'react'
import { cn } from './ui'

type Axis = 'y' | 'x' | 'grid'
type Pt = { x: number; y: number }

/**
 * Sorteerbare lijst, strook of raster. Het item tilt op en volgt de muis of vinger, de rest schuift soepel opzij
 * (FLIP met alleen transforms, dus vloeiend, ook op Safari) en bij loslaten glijdt het in zijn plek.
 * Niet-sleepbare items (zoals kopjes) bewegen gewoon mee. Toetsenbord: Alt + pijltjes.
 */
export function Sortable<T>({ items, getId, render, onReorder, axis = 'y', canDrag = () => true, minIndex = 0, className, itemClassName, label, liftClassName, style }: {
  items: T[]; getId: (t: T) => string; render: (t: T, s: { dragging: boolean; active: boolean; index: number }) => React.ReactNode
  onReorder: (ids: string[]) => void; axis?: Axis; canDrag?: (t: T) => boolean; minIndex?: number
  className?: string; itemClassName?: string | ((t: T) => string); label: string; liftClassName?: string; style?: React.CSSProperties
}) {
  const box = useRef<HTMLDivElement>(null)
  const refs = useRef(new Map<string, HTMLDivElement>())
  const baseIds = items.map(getId)
  const byId = new Map(items.map((t) => [getId(t), t]))
  const [preview, setPreview] = useState<string[] | null>(null)
  const [dragId, setDragId] = useState<string | null>(null)
  const [settling, setSettling] = useState(false)
  const order = (preview || baseIds).filter((id) => byId.has(id))
  const live = useRef<{ id: string; pointer: number; start: Pt; startOff: Pt; size: Pt; delta: Pt; active: boolean } | null>(null)
  const flipFrom = useRef<Map<string, DOMRect> | null>(null)
  const lastOff = useRef(new Map<string, Pt>())
  const suppress = useRef(false)
  const orderRef = useRef(order); orderRef.current = order

  const off = (el: HTMLElement): Pt => ({ x: el.offsetLeft, y: el.offsetTop })
  const placeDragged = () => {
    const l = live.current; if (!l?.active) return
    const el = refs.current.get(l.id); if (!el) return
    const o = off(el)
    el.style.transform = `translate3d(${axis === 'y' ? 0 : l.startOff.x + l.delta.x - o.x}px, ${axis === 'x' ? 0 : l.startOff.y + l.delta.y - o.y}px, 0)`
  }

  // FLIP: na elke volgordewijziging (slepen of van buitenaf) glijden items van hun oude naar hun nieuwe plek
  useLayoutEffect(() => {
    const from = flipFrom.current
    flipFrom.current = null
    refs.current.forEach((el, id) => {
      if (live.current?.active && id === live.current.id) return
      const now = off(el)
      let dx = 0, dy = 0
      if (from?.has(id)) {
        const prev = from.get(id)!
        el.style.transition = 'none'; el.style.transform = ''
        const cur = el.getBoundingClientRect()
        dx = prev.left - cur.left; dy = prev.top - cur.top
      } else {
        const before = lastOff.current.get(id)
        if (before) { dx = before.x - now.x; dy = before.y - now.y }
      }
      if (Math.abs(dx) > 0.5 || Math.abs(dy) > 0.5) {
        el.style.transition = 'none'
        el.style.transform = `translate3d(${dx}px, ${dy}px, 0)`
        void el.offsetWidth
        el.style.transition = 'transform 280ms var(--ease-drawer)'
        el.style.transform = ''
      }
    })
    placeDragged()
    const m = new Map<string, Pt>(); refs.current.forEach((el, id) => m.set(id, off(el))); lastOff.current = m
  })

  const snapshot = () => { const m = new Map<string, DOMRect>(); refs.current.forEach((el, id) => m.set(id, el.getBoundingClientRect())); flipFrom.current = m }

  const targetIndex = (cur: string[], l: NonNullable<typeof live.current>) => {
    const c = { x: l.startOff.x + l.delta.x + l.size.x / 2, y: l.startOff.y + l.delta.y + l.size.y / 2 }
    const rest = cur.filter((id) => id !== l.id)
    let n = 0
    rest.forEach((id) => {
      const el = refs.current.get(id); if (!el) return
      const o = off(el), w = el.offsetWidth, h = el.offsetHeight
      const cx = o.x + w / 2, cy = o.y + h / 2
      const before = axis === 'y' ? cy < c.y : axis === 'x' ? cx < c.x : (cy < c.y - h / 2 || (Math.abs(cy - c.y) <= h / 2 && cx < c.x))
      if (before) n++
    })
    return Math.max(minIndex, n)
  }

  const begin = (e: React.PointerEvent, id: string) => {
    if (e.button !== 0 || (e.target as HTMLElement).closest('input, textarea, select, [contenteditable=true], [data-nodrag]')) return
    const el = refs.current.get(id); if (!el) return
    live.current = { id, pointer: e.pointerId, start: { x: e.clientX, y: e.clientY }, startOff: off(el), size: { x: el.offsetWidth, y: el.offsetHeight }, delta: { x: 0, y: 0 }, active: false }
    const move = (ev: PointerEvent) => {
      const l = live.current; if (!l || ev.pointerId !== l.pointer) return
      l.delta = { x: ev.clientX - l.start.x, y: ev.clientY - l.start.y }
      if (!l.active) {
        if (Math.hypot(l.delta.x, l.delta.y) < 5) return
        l.active = true
        document.body.classList.add('is-sorting')
        const d = refs.current.get(l.id); if (d) d.style.transition = 'none'
        setDragId(l.id); setSettling(false)
      }
      ev.preventDefault()
      const cur = orderRef.current
      const t = targetIndex(cur, l)
      const without = cur.filter((x) => x !== l.id)
      const next = [...without.slice(0, t), l.id, ...without.slice(t)]
      if (next.join() !== cur.join()) { snapshot(); setPreview(next) } else placeDragged()
    }
    const up = (ev: PointerEvent) => {
      const l = live.current
      if (!l || ev.pointerId !== l.pointer) return
      window.removeEventListener('pointermove', move); window.removeEventListener('pointerup', up); window.removeEventListener('pointercancel', up)
      document.body.classList.remove('is-sorting')
      if (!l.active) { live.current = null; return }
      suppress.current = true; setTimeout(() => (suppress.current = false), 60)
      const el = refs.current.get(l.id)
      live.current = { ...l, active: false }
      setSettling(true)
      if (el) { el.style.transition = 'transform 280ms var(--ease-drawer)'; el.style.transform = '' }
      const final = orderRef.current
      window.setTimeout(() => {
        live.current = null
        if (el) el.style.transition = ''
        setDragId(null); setSettling(false)
        if (final.join() !== baseIdsRef.current.join()) onReorder(final)
        setPreview(null)
      }, 290)
    }
    window.addEventListener('pointermove', move, { passive: false })
    window.addEventListener('pointerup', up)
    window.addEventListener('pointercancel', up)
  }
  const baseIdsRef = useRef(baseIds); baseIdsRef.current = baseIds

  const keyMove = (e: React.KeyboardEvent, id: string) => {
    const back = axis === 'x' ? 'ArrowLeft' : 'ArrowUp', fwd = axis === 'x' ? 'ArrowRight' : 'ArrowDown'
    if (!e.altKey || (e.key !== back && e.key !== fwd && e.key !== 'ArrowUp' && e.key !== 'ArrowDown')) return
    e.preventDefault()
    const i = order.indexOf(id), j = e.key === back || e.key === 'ArrowUp' ? i - 1 : i + 1
    if (j < minIndex || j >= order.length) return
    snapshot()
    const next = [...order]; next.splice(i, 1); next.splice(j, 0, id)
    onReorder(next)
    requestAnimationFrame(() => refs.current.get(id)?.querySelector<HTMLElement>('a, button, [tabindex]')?.focus())
  }

  useEffect(() => () => document.body.classList.remove('is-sorting'), [])

  return (
    <div ref={box} className={cn('relative', className)} style={style} role="list" aria-label={label}
      onClickCapture={(e) => { if (suppress.current) { e.preventDefault(); e.stopPropagation() } }}>
      {order.map((id, index) => {
        const t = byId.get(id)!
        const draggable = canDrag(t)
        const isDrag = dragId === id
        return (
          <div key={id} role="listitem" ref={(el) => { if (el) refs.current.set(id, el); else refs.current.delete(id) }}
            onPointerDown={draggable ? (e) => begin(e, id) : undefined} onKeyDown={draggable ? (e) => keyMove(e, id) : undefined} onDragStart={(e) => e.preventDefault()}
            className={cn('sortable-item relative select-none', draggable && 'touch-manipulation', isDrag && 'z-30', typeof itemClassName === 'function' ? itemClassName(t) : itemClassName)}>
            <div className={cn('sortable-lift h-full', isDrag && !settling && cn('is-lifted', liftClassName))}>
              {render(t, { dragging: isDrag, active: !!dragId, index })}
            </div>
          </div>
        )
      })}
    </div>
  )
}
