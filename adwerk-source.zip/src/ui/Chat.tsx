import { useEffect, useMemo, useState } from 'react'
import { MessageCircle, X, ChevronLeft, LifeBuoy, Bell, Users, AtSign } from 'lucide-react'
import { useChat, openChat, closeChat, threadOf, nameOf, unreadCount, acceptHelp, dismissToast, enableNotifications, requestHelp, tagInDesign, type Message, type Thread } from '../lib/chat'
import { useOnline } from '../lib/online'
import { navigate } from '../App'
import { Avatar, Button, Dialog, Input, Label, cn } from './ui'
import { Conversation } from './ChatConversation'

const time = (iso: string) => {
  const d = new Date(iso), now = new Date()
  const same = d.toDateString() === now.toDateString()
  return same ? d.toLocaleTimeString('nl-NL', { hour: '2-digit', minute: '2-digit' }) : d.toLocaleDateString('nl-NL', { day: 'numeric', month: 'short' }) + ' ' + d.toLocaleTimeString('nl-NL', { hour: '2-digit', minute: '2-digit' })
}

/** Knop met teller voor ongelezen berichten. */
export function ChatButton({ dark, className }: { dark?: boolean; className?: string }) {
  const messages = useChat((s) => s.messages)
  const read = useChat((s) => s.read)
  const n = useMemo(() => unreadCount(), [messages, read]) // eslint-disable-line react-hooks/exhaustive-deps
  return (
    <button onClick={() => (useChat.getState().open ? closeChat() : openChat(null))} aria-label={n ? `Chat, ${n} ongelezen` : 'Chat'}
      className={cn('relative inline-flex h-9 w-9 items-center justify-center rounded-lg transition-colors', dark ? 'text-white/85 hover:bg-white/10' : 'text-ink hover:bg-sunk', className)}>
      <MessageCircle size={19} />
      {n > 0 && <span className={cn('absolute -right-0.5 -top-0.5 grid h-[18px] min-w-[18px] place-items-center rounded-full bg-[#CC4A25] px-1 text-[10px] font-bold text-white ring-2', dark ? 'ring-navy' : 'ring-surface')}>{n > 99 ? '99+' : n}</span>}
    </button>
  )
}

/** Chatpaneel: teamkanaal en privégesprekken. */
export function ChatDrawer() {
  const { open, thread, messages, profiles, me, read, notifyPerm } = useChat()
  const online = useOnline((s) => s.users)
  const onlineIds = new Set(online.map((u) => u.id))
  const people = Object.values(profiles).filter((p) => p.id !== me).sort((a, b) => Number(onlineIds.has(b.id)) - Number(onlineIds.has(a.id)) || (a.full_name || a.email).localeCompare(b.full_name || b.email))

  useEffect(() => {
    if (!open) return
    const onKey = (e: KeyboardEvent) => { if (e.key === 'Escape') closeChat() }
    window.addEventListener('keydown', onKey)
    return () => window.removeEventListener('keydown', onKey)
  }, [open])

  if (!open || !me) return null
  const last = (t: Thread) => messages.filter((m) => threadOf(m, me) === t).slice(-1)[0]
  const unread = (t: Thread) => messages.filter((m) => m.sender_id !== me && threadOf(m, me) === t && m.created_at > (read[t] || '')).length

  return (
    <aside className="fixed inset-y-0 right-0 z-[90] flex w-full flex-col border-l border-line bg-surface shadow-pop sm:w-[380px]" aria-label="Teamchat">
      <header className="flex h-14 shrink-0 items-center gap-2 border-b border-line px-3">
        {thread ? (
          <>
            <button onClick={() => useChat.setState({ thread: null })} className="rounded-lg p-1.5 hover:bg-sunk" aria-label="Terug naar gesprekken"><ChevronLeft size={18} /></button>
            {thread === 'team' ? <span className="grid h-8 w-8 place-items-center rounded-full bg-navy text-white"><Users size={15} /></span> : <Avatar name={nameOf(thread)} color={profiles[thread]?.color} src={profiles[thread]?.avatar_url} size={32} />}
            <div className="min-w-0 flex-1">
              <div className="truncate font-semibold">{thread === 'team' ? 'Team daar-om.nl' : nameOf(thread)}</div>
              <div className="text-xs text-muted">{thread === 'team' ? `${online.length} online` : onlineIds.has(thread) ? 'Online' : 'Offline'}</div>
            </div>
          </>
        ) : (
          <h2 className="flex-1 pl-1 font-display text-lg font-semibold">Chat<span className="text-accent-fg">.</span></h2>
        )}
        <button onClick={closeChat} className="rounded-lg p-1.5 hover:bg-sunk" aria-label="Chat sluiten"><X size={18} /></button>
      </header>
      {!thread ? (
        <div className="min-h-0 flex-1 overflow-y-auto p-2">
          {notifyPerm === 'default' && (
            <button onClick={enableNotifications} className="mb-2 flex w-full items-center gap-3 rounded-xl bg-mist p-3 text-left text-sm dark:bg-sunk">
              <Bell size={18} className="shrink-0 text-accent-fg" /><span><strong className="font-semibold">Meldingen aanzetten</strong><br /><span className="text-muted">Ook een melding als Adwerk op de achtergrond staat.</span></span>
            </button>
          )}
          <ThreadRow t="team" title="Team daar-om.nl" sub={last('team')} unread={unread('team')} icon={<span className="grid h-10 w-10 place-items-center rounded-full bg-navy text-white"><Users size={17} /></span>} />
          <div className="px-2 pb-1 pt-4 text-[11px] font-bold uppercase tracking-wider text-muted">Collega's</div>
          {people.map((p) => (
            <ThreadRow key={p.id} t={p.id} title={p.full_name || p.email} sub={last(p.id)} unread={unread(p.id)}
              icon={<span className="relative"><Avatar name={p.full_name || p.email} color={p.color} src={p.avatar_url} size={40} />{onlineIds.has(p.id) && <span className="absolute bottom-0 right-0 h-3 w-3 rounded-full bg-mint ring-2 ring-surface" />}</span>} />
          ))}
        </div>
      ) : <Conversation thread={thread} renderCard={(m, mine) => <HelpCard m={m} mine={mine} />} />}
    </aside>
  )
}

function ThreadRow({ t, title, sub, unread, icon }: { t: Thread; title: string; sub?: Message; unread: number; icon: React.ReactNode }) {
  const me = useChat((s) => s.me)
  const typing = useChat((s) => s.typing)
  const typer = Object.entries(typing).find(([, x]) => x.thread === t && x.until > Date.now())?.[0]
  return (
    <button onClick={() => openChat(t)} className="flex w-full items-center gap-3 rounded-xl px-2 py-2 text-left hover:bg-sunk">
      {icon}
      <span className="min-w-0 flex-1">
        <span className="flex items-baseline gap-2"><span className={cn('truncate', unread ? 'font-bold' : 'font-semibold')}>{title}</span>{sub && <span className="ml-auto shrink-0 text-[11px] text-muted">{time(sub.created_at)}</span>}</span>
        {typer ? <span className="block truncate text-sm italic text-accent-fg">{nameOf(typer).split(' ')[0]} typt…</span> : <span className={cn('block truncate text-sm', unread ? 'text-ink' : 'text-muted')}>{sub ? `${sub.sender_id === me ? 'Jij: ' : t === 'team' ? nameOf(sub.sender_id).split(' ')[0] + ': ' : ''}${sub.kind === 'help' ? 'vraagt om hulp' : sub.kind === 'mention' ? 'deelde een ontwerp' : sub.body || (sub.attachments?.length ? (sub.attachments[0].type === 'gif' ? 'GIF' : 'Afbeelding') : '')}` : 'Nog geen berichten'}</span>}
      </span>
      {unread > 0 && <span className="grid h-5 min-w-5 place-items-center rounded-full bg-[#CC4A25] px-1.5 text-[11px] font-bold text-white">{unread}</span>}
    </button>
  )
}

function HelpCard({ m, mine }: { m: Message; mine: boolean }) {
  const [busy, setBusy] = useState(false)
  const [err, setErr] = useState<string | null>(null)
  const go = async () => {
    setBusy(true); setErr(null)
    try { const id = await acceptHelp(m); closeChat(); navigate(`/d/${id}`) } catch (e) { setErr((e as Error).message) } finally { setBusy(false) }
  }
  return (
    <div className="overflow-hidden rounded-2xl border border-line bg-surface">
      {m.kind === 'help'
        ? <div className="flex items-center gap-2 bg-[#CC4A25] px-3 py-2 text-sm font-semibold text-white"><LifeBuoy size={16} /> {mine ? 'Je vroeg om hulp' : 'Hulpverzoek'}</div>
        : <div className="flex items-center gap-2 bg-[#1A5FC4] px-3 py-2 text-sm font-semibold text-white"><AtSign size={16} /> {mine ? 'Je deelde een ontwerp' : 'Je bent getagd in een ontwerp'}</div>}
      <div className="px-3 py-2.5 text-sm">
        <div className="font-semibold">{m.design_title || 'Ontwerp'}</div>
        <p className="mt-0.5 whitespace-pre-wrap text-muted">{m.body}</p>
        {mine ? (
          m.design_id && <Button size="sm" className="mt-2" onClick={() => { closeChat(); navigate(`/d/${m.design_id}`) }}>Open ontwerp</Button>
        ) : (
          <Button size="sm" variant="primary" className="mt-2" onClick={go} disabled={busy}>{busy ? 'Openen…' : m.kind === 'help' ? 'Ga helpen' : 'Openen'}</Button>
        )}
        {err && <p className="mt-1 text-xs text-accent-fg">{err}</p>}
      </div>
    </div>
  )
}

/** Live meldingen rechtsboven: nieuwe berichten en hulpverzoeken. */
export function ChatToasts() {
  const toasts = useChat((s) => s.toasts)
  const profiles = useChat((s) => s.profiles)
  const me = useChat((s) => s.me)
  const [busy, setBusy] = useState<string | null>(null)
  if (!toasts.length || !me) return null
  return (
    <div className="pointer-events-none fixed right-3 top-16 z-[110] grid w-[min(360px,calc(100vw-24px))] gap-2" aria-live="polite">
      {toasts.map(({ id, msg: m }) => {
        const p = profiles[m.sender_id]
        const t = threadOf(m, me)
        return (
          <div key={id} className="pointer-events-auto animate-[toastIn_.25s_ease-out] overflow-hidden rounded-2xl border border-line bg-surface shadow-pop">
            {m.kind === 'help' && <div className="flex items-center gap-2 bg-[#CC4A25] px-3 py-1.5 text-xs font-semibold text-white"><LifeBuoy size={14} /> Hulpverzoek{m.recipient_id === null ? ' aan het team' : ''}</div>}
            {(m.kind === 'mention' || (m.mentions || []).includes(me)) && m.kind !== 'help' && <div className="flex items-center gap-2 bg-[#1A5FC4] px-3 py-1.5 text-xs font-semibold text-white"><AtSign size={14} /> {m.design_id ? 'Getagd in een ontwerp' : 'Je bent genoemd'}</div>}
            <div className="flex gap-3 p-3">
              <Avatar name={nameOf(m.sender_id)} color={p?.color} src={p?.avatar_url} size={36} />
              <div className="min-w-0 flex-1">
                <div className="flex items-center gap-2"><span className="truncate text-sm font-semibold">{nameOf(m.sender_id)}</span>{t === 'team' && m.kind !== 'help' && <span className="text-xs text-muted">in Team</span>}
                  <button onClick={() => dismissToast(id)} className="ml-auto rounded p-0.5 text-muted hover:text-ink" aria-label="Sluiten"><X size={14} /></button></div>
                <p className="line-clamp-2 text-sm text-muted">{m.design_id ? <><strong className="font-semibold text-ink">{m.design_title}</strong>: {m.body}</> : m.body || (m.attachments?.length ? (m.attachments[0].type === 'gif' ? 'Stuurde een GIF' : 'Stuurde een afbeelding') : '')}</p>
                <div className="mt-2 flex gap-2">
                  {m.design_id ? (
                    <>
                      <Button size="sm" variant="primary" disabled={busy === id} onClick={async () => { setBusy(id); try { const d = await acceptHelp(m); navigate(`/d/${d}`) } catch (e) { alert((e as Error).message) } finally { setBusy(null) } }}>{busy === id ? 'Openen…' : m.kind === 'help' ? 'Ga helpen' : 'Openen'}</Button>
                      <Button size="sm" onClick={() => { dismissToast(id); openChat(t) }}>Antwoorden</Button>
                    </>
                  ) : <Button size="sm" onClick={() => { dismissToast(id); openChat(t) }}>Openen</Button>}
                </div>
              </div>
            </div>
          </div>
        )
      })}
    </div>
  )
}

/** Hulp vragen aan een collega of het hele team, vanuit een ontwerp. */
export function HelpDialog({ open, onOpenChange, designId, designTitle }: { open: boolean; onOpenChange: (o: boolean) => void; designId: string; designTitle: string }) {
  const { profiles, me } = useChat()
  const online = useOnline((s) => s.users)
  const onlineIds = new Set(online.map((u) => u.id))
  const [to, setTo] = useState<Thread>('team')
  const [note, setNote] = useState('')
  const [busy, setBusy] = useState(false)
  const [done, setDone] = useState(false)
  const people = Object.values(profiles).filter((p) => p.id !== me).sort((a, b) => Number(onlineIds.has(b.id)) - Number(onlineIds.has(a.id)))
  useEffect(() => { if (open) { setDone(false); setNote('') } }, [open])
  const send = async () => {
    setBusy(true)
    try { await requestHelp(designId, designTitle, to, note); setDone(true); setTimeout(() => onOpenChange(false), 1400) } finally { setBusy(false) }
  }
  return (
    <Dialog open={open} onOpenChange={onOpenChange} title="Hulp vragen" description="Een collega krijgt direct een melding en kan met één klik meekijken in dit ontwerp.">
      {done ? <p className="rounded-xl bg-mist p-4 text-center font-semibold dark:bg-sunk">Verstuurd. Je krijgt een bericht zodra iemand komt helpen.</p> : (
        <div className="grid gap-4">
          <div className="grid gap-1.5"><Label>Aan wie</Label>
            <div className="grid max-h-56 gap-1 overflow-y-auto pr-1">
              <button onClick={() => setTo('team')} className={cn('flex items-center gap-3 rounded-xl border px-3 py-2 text-left', to === 'team' ? 'border-accent bg-accent-soft' : 'border-line hover:bg-sunk')}>
                <span className="grid h-8 w-8 place-items-center rounded-full bg-navy text-white"><Users size={15} /></span><span className="flex-1 text-sm font-semibold">Iedereen in het team</span><span className="text-xs text-muted">{online.length} online</span>
              </button>
              {people.map((p) => (
                <button key={p.id} onClick={() => setTo(p.id)} className={cn('flex items-center gap-3 rounded-xl border px-3 py-2 text-left', to === p.id ? 'border-accent bg-accent-soft' : 'border-line hover:bg-sunk')}>
                  <Avatar name={p.full_name || p.email} color={p.color} src={p.avatar_url} size={32} /><span className="min-w-0 flex-1 truncate text-sm font-semibold">{p.full_name || p.email}</span>
                  <span className={cn('text-xs', onlineIds.has(p.id) ? 'text-mint' : 'text-muted')}>{onlineIds.has(p.id) ? 'Online' : 'Offline'}</span>
                </button>
              ))}
            </div>
          </div>
          <div className="grid gap-1.5"><Label>Waarmee?</Label><Input value={note} onChange={(e) => setNote(e.target.value)} placeholder="Bijvoorbeeld: kun je kijken naar de story-versie?" onKeyDown={(e) => e.key === 'Enter' && send()} /></div>
          <p className="text-xs text-muted">Wie op Helpen klikt, krijgt toegang tot dit ontwerp.</p>
          <Button variant="primary" onClick={send} disabled={busy}><LifeBuoy size={17} /> {busy ? 'Versturen…' : 'Hulp vragen'}</Button>
        </div>
      )}
    </Dialog>
  )
}

/** Menu-item in de zijbalk met teller. */
export function ChatNavItem() {
  const messages = useChat((s) => s.messages)
  const read = useChat((s) => s.read)
  const n = useMemo(() => unreadCount(), [messages, read]) // eslint-disable-line react-hooks/exhaustive-deps
  return (
    <button onClick={() => openChat(null)} className="flex w-full items-center gap-3 rounded-full px-3 py-2 text-[15px] font-medium text-ink transition hover:bg-sunk">
      <MessageCircle size={18} /> <span className="flex-1 text-left">Teamchat</span>
      {n > 0 && <span className="grid h-5 min-w-5 place-items-center rounded-full bg-[#CC4A25] px-1.5 text-[11px] font-bold text-white">{n}</span>}
    </button>
  )
}

/** Collega's taggen in dit ontwerp: zij krijgen live een melding en met één klik toegang. */
export function TagDialog({ open, onOpenChange, designId, designTitle }: { open: boolean; onOpenChange: (o: boolean) => void; designId: string; designTitle: string }) {
  const { profiles, me } = useChat()
  const online = useOnline((s) => s.users)
  const onlineIds = new Set(online.map((u) => u.id))
  const [sel, setSel] = useState<string[]>([])
  const [q, setQ] = useState('')
  const [note, setNote] = useState('')
  const [busy, setBusy] = useState(false)
  const [done, setDone] = useState(false)
  const people = Object.values(profiles).filter((p) => p.id !== me && (p.full_name || p.email).toLowerCase().includes(q.toLowerCase())).sort((a, b) => Number(onlineIds.has(b.id)) - Number(onlineIds.has(a.id)))
  useEffect(() => { if (open) { setDone(false); setNote(''); setSel([]); setQ('') } }, [open])
  const send = async () => {
    if (!sel.length) return
    setBusy(true)
    try { await tagInDesign(designId, designTitle, sel, note); setDone(true); setTimeout(() => onOpenChange(false), 1200) } finally { setBusy(false) }
  }
  return (
    <Dialog open={open} onOpenChange={onOpenChange} title="Collega taggen" description="Wie je tagt, krijgt direct een melding met een link naar dit ontwerp en kan het openen.">
      {done ? <p className="rounded-xl bg-mist p-4 text-center font-semibold dark:bg-sunk">Getagd. Ze krijgen nu een melding.</p> : (
        <div className="grid gap-4">
          <Input value={q} onChange={(e) => setQ(e.target.value)} placeholder="@ Zoek een collega" aria-label="Zoek een collega" autoFocus />
          <div className="grid max-h-56 gap-1 overflow-y-auto pr-1">
            {people.map((p) => {
              const on = sel.includes(p.id)
              return (
                <button key={p.id} onClick={() => setSel(on ? sel.filter((x) => x !== p.id) : [...sel, p.id])} aria-pressed={on} className={cn('flex items-center gap-3 rounded-xl border px-3 py-2 text-left', on ? 'border-accent bg-accent-soft' : 'border-line hover:bg-sunk')}>
                  <Avatar name={p.full_name || p.email} color={p.color} src={p.avatar_url} size={32} /><span className="min-w-0 flex-1 truncate text-sm font-semibold">{p.full_name || p.email}</span>
                  <span className={cn('text-xs', onlineIds.has(p.id) ? 'text-mint' : 'text-muted')}>{onlineIds.has(p.id) ? 'Online' : 'Offline'}</span>
                </button>
              )
            })}
            {!people.length && <p className="text-sm text-muted">Niemand gevonden.</p>}
          </div>
          <div className="grid gap-1.5"><Label>Bericht</Label><Input value={note} onChange={(e) => setNote(e.target.value)} placeholder="Bijvoorbeeld: wil je de kop checken?" onKeyDown={(e) => e.key === 'Enter' && send()} /></div>
          <Button variant="primary" onClick={send} disabled={busy || !sel.length}><AtSign size={17} /> {busy ? 'Versturen…' : sel.length > 1 ? `${sel.length} collega's taggen` : 'Taggen'}</Button>
        </div>
      )}
    </Dialog>
  )
}
