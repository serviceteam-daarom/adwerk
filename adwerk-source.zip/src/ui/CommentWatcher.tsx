import { useEffect } from 'react'
import { useLive } from '../lib/live'
import { useSession } from '../store/session'
import { useComments } from '../lib/comments'
import { notice } from '../lib/notices'
import { supabase } from '../lib/supabase'
import { navigate } from '../App'

/** Meldt nieuwe feedback op je eigen ontwerpen, ook als je dat ontwerp niet open hebt. */
export function CommentWatcher() {
  const last = useLive((s) => s.last.comments)
  const { user } = useSession()
  useEffect(() => {
    const c = last?.new as { id?: string; design_id?: string; author_id?: string | null; guest_name?: string | null; body?: string; parent_id?: string | null } | undefined
    if (!c?.id || last?.event !== 'INSERT' || !user || c.author_id === user.id) return
    if (useComments.getState().designId === c.design_id) return // dat ontwerp is open: de editor meldt het al
    let alive = true
    supabase.from('designs').select('id,title,owner_id').eq('id', c.design_id!).maybeSingle().then(async ({ data: d }) => {
      if (!alive || !d || d.owner_id !== user.id) return
      let who = c.guest_name || 'Een collega'
      if (c.author_id) { const { data: p } = await supabase.from('profiles').select('full_name,email').eq('id', c.author_id).maybeSingle(); if (p) who = p.full_name || p.email.split('@')[0] }
      notice({ title: `${who} ${c.parent_id ? 'reageerde op' : 'gaf feedback op'} ${d.title}`, body: c.body, tone: c.author_id ? 'team' : 'client', action: { label: 'Bekijken', run: () => navigate(`/d/${d.id}?c=${c.parent_id || c.id}`) } })
    })
    return () => { alive = false }
  }, [last]) // eslint-disable-line react-hooks/exhaustive-deps
  return null
}
