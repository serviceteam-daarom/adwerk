import { MessageCircle, ArrowUpRight } from 'lucide-react'
import { useOnline } from '../lib/online'
import { useSession } from '../store/session'
import { openChat, useChat } from '../lib/chat'
import { Avatar, Label, Tip } from './ui'
import { navigate } from '../App'

/** Wie is er nu in Adwerk (live). Klik op iemand om te chatten, of spring naar het ontwerp waar die in werkt. */
export function OnlineList() {
  const users = useOnline((s) => s.users)
  const me = useSession((s) => s.user?.id)
  const typing = useChat((s) => s.typing)
  if (!users.length) return null
  return (
    <div className="grid gap-2 px-1">
      <div className="flex items-center justify-between px-2"><Label>Nu online</Label><span className="flex items-center gap-1.5 text-xs text-muted"><span className="h-2 w-2 animate-pulse rounded-full bg-mint" />{users.length}</span></div>
      <ul className="grid gap-0.5">
        {users.map((u) => {
          const self = u.id === me
          return (
            <li key={u.id} className="anim-rise group flex items-center gap-1 rounded-xl pr-1 transition hover:bg-sunk">
              <button disabled={self} onClick={() => openChat(u.id)} className="flex min-w-0 flex-1 items-center gap-2.5 px-2 py-1.5 text-left" aria-label={self ? 'Jij' : `Chat met ${u.name}`}>
                <span className="relative"><Avatar name={u.name} color={u.color} src={u.avatar} size={28} /><span className="absolute -bottom-0.5 -right-0.5 h-2.5 w-2.5 rounded-full border-2 border-surface bg-mint" /></span>
                <span className="min-w-0 flex-1">
                  <span className="block truncate text-[13px] font-medium">{u.name}{self ? ' (jij)' : ''}</span>
                  <span className="block truncate text-[11px] text-muted">{typing[u.id] && typing[u.id].until > Date.now() ? <span className="text-accent-fg">typt…</span> : u.designTitle ? `In ${u.designTitle}` : 'Op het overzicht'}</span>
                </span>
              </button>
              {!self && (
                <>
                  <Tip label={`Chat met ${u.name.split(' ')[0]}`}><button onClick={() => openChat(u.id)} className="rounded-lg p-1.5 text-muted opacity-0 transition hover:bg-surface hover:text-ink focus-visible:opacity-100 group-hover:opacity-100 max-md:opacity-100" aria-label={`Chat met ${u.name}`}><MessageCircle size={15} /></button></Tip>
                  {u.designId && <Tip label={`Naar ${u.designTitle || 'het ontwerp'}`}><button onClick={() => navigate(`/d/${u.designId}`)} className="rounded-lg p-1.5 text-muted opacity-0 transition hover:bg-surface hover:text-ink focus-visible:opacity-100 group-hover:opacity-100 max-md:opacity-100" aria-label={`Naar ${u.designTitle || 'het ontwerp'}`}><ArrowUpRight size={15} /></button></Tip>}
                </>
              )}
            </li>
          )
        })}
      </ul>
    </div>
  )
}

/** Compacte rij avatars van wie er online is (bovenbalk). */
export function OnlineStack({ max = 4 }: { max?: number }) {
  const users = useOnline((s) => s.users)
  const me = useSession((s) => s.user?.id)
  const others = users.filter((u) => u.id !== me)
  if (!others.length) return null
  return (
    <span className="flex items-center pr-1">
      {others.slice(0, max).map((u) => (
        <Tip key={u.id} label={`${u.name}: ${u.designTitle ? `in ${u.designTitle}` : 'online'}. Klik om te chatten`}>
          <button onClick={() => openChat(u.id)} className="-ml-1.5 rounded-full transition first:ml-0 hover:z-10 hover:-translate-y-0.5" aria-label={`Chat met ${u.name}`}><Avatar name={u.name} color={u.color} src={u.avatar} size={28} ring="rgb(var(--surface))" /></button>
        </Tip>
      ))}
      {others.length > max && <span className="ml-1 text-xs text-muted">+{others.length - max}</span>}
    </span>
  )
}

export function OnlineAvatars({ designId, max = 4 }: { designId: string; max?: number }) {
  const users = useOnline((s) => s.users.filter((u) => u.designId === designId))
  if (!users.length) return null
  return (
    <span className="flex">
      {users.slice(0, max).map((u) => (
        <Tip key={u.id} label={`${u.name} werkt hierin`}><span className="-ml-1.5 first:ml-0"><Avatar name={u.name} color={u.color} src={u.avatar} size={24} ring="rgb(var(--surface))" /></span></Tip>
      ))}
    </span>
  )
}
