import { useOnline } from '../lib/online'
import { useSession } from '../store/session'
import { Avatar, Label, Tip } from './ui'
import { navigate } from '../App'

/** Wie is er nu in Adwerk (live via Supabase Realtime presence). */
export function OnlineList() {
  const users = useOnline((s) => s.users)
  const me = useSession((s) => s.user?.id)
  if (!users.length) return null
  return (
    <div className="grid gap-2 px-1">
      <div className="flex items-center justify-between px-2"><Label>Nu online</Label><span className="flex items-center gap-1.5 text-xs text-muted"><span className="h-2 w-2 rounded-full bg-mint" />{users.length}</span></div>
      <ul className="grid gap-0.5">
        {users.map((u) => (
          <li key={u.id}>
            <button disabled={!u.designId || u.id === me} onClick={() => u.designId && navigate(`/d/${u.designId}`)} className="flex w-full items-center gap-2.5 rounded-xl px-2 py-1.5 text-left enabled:hover:bg-sunk">
              <span className="relative"><Avatar name={u.name} color={u.color} src={u.avatar} size={28} /><span className="absolute -bottom-0.5 -right-0.5 h-2.5 w-2.5 rounded-full border-2 border-surface bg-mint" /></span>
              <span className="min-w-0 flex-1">
                <span className="block truncate text-[13px] font-medium">{u.name}{u.id === me ? ' (jij)' : ''}</span>
                <span className="block truncate text-[11px] text-muted">{u.designTitle ? `In ${u.designTitle}` : 'Op het overzicht'}</span>
              </span>
            </button>
          </li>
        ))}
      </ul>
    </div>
  )
}

export function OnlineAvatars({ designId, max = 4 }: { designId: string; max?: number }) {
  const users = useOnline((s) => s.users.filter((u) => u.designId === designId))
  if (!users.length) return null
  return (
    <span className="flex">
      {users.slice(0, max).map((u) => (
        <Tip key={u.id} label={`${u.name} werkt hierin`}><span className="-ml-1.5 first:ml-0"><Avatar name={u.name} color={u.color} src={u.avatar} size={24} ring="rgb(var(--surface))" /></span></Tip>
      ))}
    </span>
  )
}
