import { useEffect, useMemo, useState } from 'react'
import { Globe2, MoreHorizontal, ThumbsUp, MessageCircle, Share2, Heart, Send, Bookmark, ChevronRight, ChevronLeft, ChevronUp, Music2, Repeat2, Loader2, AlertTriangle } from 'lucide-react'
import type { Brief, Frame } from '../lib/types'
import { createOffscreen } from '../lib/render'
import { cn } from './ui'

/* ---------- formaten renderen (met cache) ---------- */
const cache = new Map<string, string>()
export function useFrameImages(frames: Frame[]) {
  const [imgs, setImgs] = useState<Record<string, string>>({})
  const key = frames.map((f) => f.id + ':' + JSON.stringify(f).length).join('|')
  useEffect(() => {
    let alive = true
    ;(async () => {
      for (const f of frames) {
        const k = JSON.stringify(f)
        let url = cache.get(k)
        if (!url) {
          const off = await createOffscreen(f)
          try { url = off.canvasAt(null, Math.min(1, 1080 / Math.max(f.w, f.h))).toDataURL('image/jpeg', 0.86) } finally { off.destroy() }
          cache.set(k, url)
        }
        if (!alive) return
        setImgs((m) => (m[f.id] === url ? m : { ...m, [f.id]: url! }))
      }
    })().catch(() => { /* */ })
    return () => { alive = false }
  }, [key]) // eslint-disable-line react-hooks/exhaustive-deps
  return imgs
}

/* ---------- brief lezen ---------- */
const fieldVal = (b: Brief | undefined | null, ...labels: string[]) => {
  const f = b?.fields.find((x) => labels.some((l) => x.label.toLowerCase() === l || x.preset === l))
  return f ? (f.kind === 'list' ? (f.items || []).filter((x) => x.trim()) : f.value.trim() ? [f.value.trim()] : []) : []
}
export function adCopy(b?: Brief | null) {
  const koppen = fieldVal(b, 'koppen')
  const teksten = fieldVal(b, 'teksten')
  const landing = fieldVal(b, 'landing', 'landingspagina')[0] || ''
  const vorm = (fieldVal(b, 'vorm')[0] || '').toLowerCase()
  const doel = (fieldVal(b, 'doel', 'campagnedoelstelling')[0] || '').toLowerCase()
  const ctaField = fieldVal(b, 'call to action')[0]
  const cta = ctaField || (/lead|aanmeld/.test(doel) ? 'Aanmelden' : /verkoop|conversie|sales/.test(doel) ? 'Nu kopen' : /offerte/.test(doel) ? 'Offerte aanvragen' : 'Meer informatie')
  let domain = ''
  try { domain = landing ? new URL(landing).hostname.replace(/^www\./, '') : '' } catch { domain = landing.replace(/^https?:\/\//, '').split('/')[0] }
  const page = fieldVal(b, 'pagina', 'pagina-naam', 'paginanaam', 'account')[0] || ''
  const desc = fieldVal(b, 'beschrijving')[0] || ''
  return { koppen, teksten, domain, cta, carousel: /carrousel|carousel/.test(vorm), vorm, page, desc }
}

/* ---------- plaatsingen ---------- */
export type Placement = 'fb-feed' | 'ig-feed' | 'story' | 'reels' | 'linkedin'
export const PLACEMENTS: { key: Placement; label: string; ratios: number[] }[] = [
  { key: 'fb-feed', label: 'Facebook feed', ratios: [0.8, 1, 1.91] },
  { key: 'ig-feed', label: 'Instagram feed', ratios: [0.8, 1] },
  { key: 'story', label: 'Stories', ratios: [0.5625] },
  { key: 'reels', label: 'Reels', ratios: [0.5625] },
  { key: 'linkedin', label: 'LinkedIn', ratios: [1.91, 1, 0.8] },
]
/** Beste formaat voor een plaatsing (in volgorde van voorkeur); ok = de verhouding past echt. */
export function pickFrame(frames: Frame[], p: Placement) {
  const ratios = PLACEMENTS.find((x) => x.key === p)!.ratios
  for (const r of ratios) { const f = frames.find((x) => Math.abs(Math.log(x.w / x.h / r)) < 0.06); if (f) return { frame: f, ok: true } }
  const best = [...frames].sort((a, b) => Math.abs(Math.log(a.w / a.h / ratios[0])) - Math.abs(Math.log(b.w / b.h / ratios[0])))[0]
  return { frame: best, ok: false }
}

const clip = (t: string, n: number) => (t.length > n ? t.slice(0, n).replace(/\s+\S*$/, '').replace(/[\s.,;:!?]+$/, '') : t)
function Text({ text, max, className, prefix }: { text: string; max: number; className?: string; prefix?: React.ReactNode }) {
  const [open, setOpen] = useState(false)
  if (!text) return <p className={cn('italic text-[#8a8d91]', className)}>Nog geen tekst in de brief</p>
  const long = text.length > max
  return <p className={cn('whitespace-pre-wrap', className)}>{prefix}{open || !long ? text : clip(text, max)}{long && !open && <>… <button onClick={() => setOpen(true)} className="font-semibold text-[#65676b]">Meer weergeven</button></>}</p>
}
function Avatar({ name, logo, size = 36 }: { name: string; logo?: string | null; size?: number }) {
  return logo
    ? <img src={logo} alt="" className="shrink-0 rounded-full border border-black/10 bg-white object-contain p-0.5" style={{ width: size, height: size }} />
    : <span className="grid shrink-0 place-items-center rounded-full bg-[#1B213B] font-bold text-white" style={{ width: size, height: size, fontSize: size * 0.4 }}>{(name || '?').slice(0, 1).toUpperCase()}</span>
}
function Media({ src, frame, className, fit = 'cover' }: { src?: string; frame: Frame; className?: string; fit?: 'cover' | 'contain' }) {
  return (
    <div className={cn('relative w-full overflow-hidden bg-[#f0f2f5]', className)} style={{ aspectRatio: `${frame.w} / ${frame.h}` }}>
      {src ? <img src={src} alt={frame.name} className={cn('absolute inset-0 h-full w-full', fit === 'cover' ? 'object-cover' : 'object-contain')} draggable={false} /> : <span className="absolute inset-0 grid place-items-center"><Loader2 className="animate-spin text-[#8a8d91]" /></span>}
    </div>
  )
}

interface P { frames: Frame[]; imgs: Record<string, string>; brief?: Brief | null; pageName: string; logo?: string | null; placement: Placement; kop: number; tekst: number }

function Carousel({ cards, imgs, koppen, cta, domain, kop, size = 260, ig }: { cards: Frame[]; imgs: Record<string, string>; koppen: string[]; cta: string; domain: string; kop: number; size?: number; ig?: boolean }) {
  const [i, setI] = useState(0)
  return (
    <div className="relative">
      <div className="flex gap-2 overflow-hidden px-3 pb-1">
        {cards.map((f, n) => (
          <div key={f.id} className="shrink-0 overflow-hidden rounded-lg border border-black/10 transition-transform duration-300 [transition-timing-function:var(--ease-out)]" style={{ width: size, transform: `translateX(${-i * (size + 8)}px)` }}>
            <Media src={imgs[f.id]} frame={f} />
            {!ig && <div className="flex items-center gap-2 bg-[#f0f2f5] px-2.5 py-2"><div className="min-w-0 flex-1"><p className="truncate text-[13px] font-semibold text-[#050505]">{koppen.length ? koppen[(kop + n) % koppen.length] : 'Kop uit de brief'}</p>{domain && <p className="truncate text-[11px] text-[#65676b]">{domain}</p>}</div><span className="shrink-0 rounded-md bg-[#e4e6eb] px-2.5 py-1.5 text-[12px] font-semibold text-[#050505]">{cta}</span></div>}
          </div>
        ))}
      </div>
      {i > 0 && <button onClick={() => setI(i - 1)} className="absolute left-1 top-[40%] grid h-8 w-8 place-items-center rounded-full bg-white shadow" aria-label="Vorige kaart"><ChevronLeft size={18} /></button>}
      {i < cards.length - 1 && <button onClick={() => setI(i + 1)} className="absolute right-1 top-[40%] grid h-8 w-8 place-items-center rounded-full bg-white shadow" aria-label="Volgende kaart"><ChevronRight size={18} /></button>}
    </div>
  )
}

/** Eén advertentie zoals hij op het platform verschijnt. */
export function AdMock({ frames, imgs, brief, pageName, logo, placement, kop, tekst }: P) {
  const c = adCopy(brief)
  const name = c.page || pageName
  const { frame, ok } = pickFrame(frames, placement)
  const headline = c.koppen.length ? c.koppen[kop % c.koppen.length] : ''
  const body = c.teksten.length ? c.teksten[tekst % c.teksten.length] : ''
  const cards = c.carousel ? frames.filter((f) => Math.abs(f.w / f.h - frame.w / frame.h) < 0.02) : [frame]
  const carousel = c.carousel && cards.length > 1 && placement !== 'story' && placement !== 'reels'
  const warn = !ok && <p className="flex items-center gap-1.5 bg-[#fff4e5] px-3 py-1.5 text-[11px] font-medium text-[#8a4b00]"><AlertTriangle size={13} /> Geen passend formaat voor {PLACEMENTS.find((p) => p.key === placement)!.label}; dichtstbijzijnde getoond</p>

  if (placement === 'story' || placement === 'reels') {
    const reels = placement === 'reels'
    return (
      <div className="relative mx-auto w-[300px] overflow-hidden rounded-[28px] border-[6px] border-[#111] bg-black shadow-pop" style={{ aspectRatio: '9 / 16' }}>
        {imgs[frame.id] ? <img src={imgs[frame.id]} alt="" className={cn('absolute inset-0 h-full w-full', ok ? 'object-cover' : 'object-contain')} /> : <span className="absolute inset-0 grid place-items-center"><Loader2 className="animate-spin text-white/60" /></span>}
        {!ok && <div className="absolute inset-x-0 top-12">{warn}</div>}
        <div className="absolute inset-x-0 top-0 bg-gradient-to-b from-black/50 to-transparent p-3 pt-2.5">
          {!reels && <div className="mb-2.5 flex gap-1">{[0, 1, 2].map((n) => <span key={n} className="h-0.5 flex-1 overflow-hidden rounded bg-white/35">{n === 0 && <span className="block h-full w-2/3 bg-white" />}</span>)}</div>}
          <div className="flex items-center gap-2 text-white"><Avatar name={name} logo={logo} size={28} /><div className="min-w-0 leading-tight"><p className="truncate text-[13px] font-semibold">{name}</p><p className="text-[11px] text-white/80">Gesponsord</p></div><MoreHorizontal size={18} className="ml-auto" /></div>
        </div>
        {reels && <div className="absolute bottom-24 right-2.5 grid justify-items-center gap-4 text-white">{[Heart, MessageCircle, Send, MoreHorizontal].map((I, n) => <I key={n} size={24} />)}</div>}
        <div className="absolute inset-x-0 bottom-0 bg-gradient-to-t from-black/70 via-black/30 to-transparent px-3 pb-4 pt-10 text-white">
          {reels && <><div className="mb-1.5 flex items-center gap-2"><Avatar name={name} logo={logo} size={24} /><span className="text-[13px] font-semibold">{name}</span></div><Text text={body} max={60} className="mb-2 pr-10 text-[12px] leading-snug" /><p className="mb-2.5 flex items-center gap-1.5 text-[11px]"><Music2 size={12} /> Gesponsord · Originele audio</p></>}
          <div className="grid justify-items-center">
            {!reels && <ChevronUp size={18} className="animate-bounce" />}
            <span className={cn('flex items-center gap-1 rounded-full bg-white px-4 py-2 text-[13px] font-semibold text-[#050505] shadow', reels && 'w-full justify-center rounded-md')}>{c.cta}</span>
          </div>
        </div>
      </div>
    )
  }

  if (placement === 'ig-feed') {
    return (
      <div className="mx-auto w-full max-w-[400px] overflow-hidden rounded-xl border border-black/10 bg-white text-[#000] shadow-card">
        <div className="flex items-center gap-2.5 px-3 py-2.5"><Avatar name={name} logo={logo} size={32} /><div className="min-w-0 flex-1 leading-tight"><p className="truncate text-[13px] font-semibold">{name.toLowerCase().replace(/\s+/g, '')}</p><p className="text-[11px] text-[#737373]">Gesponsord</p></div><MoreHorizontal size={18} /></div>
        {warn}
        {carousel ? <Carousel cards={cards} imgs={imgs} koppen={c.koppen} cta={c.cta} domain={c.domain} kop={kop} size={340} ig /> : <Media src={imgs[frame.id]} frame={frame} fit={ok ? 'cover' : 'contain'} />}
        <div className="flex items-center justify-between bg-[#efefef] px-3 py-2.5 text-[13px] font-semibold"><span>{c.cta}</span><ChevronRight size={16} /></div>
        <div className="flex items-center gap-4 px-3 pt-2.5">{[Heart, MessageCircle, Send].map((I, n) => <I key={n} size={22} />)}<Bookmark size={22} className="ml-auto" /></div>
        <div className="px-3 pb-3 pt-2 text-[13px] leading-snug"><Text text={body} max={125} prefix={<span className="mr-1 font-semibold">{name.toLowerCase().replace(/\s+/g, '')}</span>} /></div>
      </div>
    )
  }

  if (placement === 'linkedin') {
    return (
      <div className="mx-auto w-full max-w-[500px] overflow-hidden rounded-lg border border-black/10 bg-white text-[#000000e6] shadow-card">
        <div className="flex items-start gap-2.5 px-3 pt-3"><Avatar name={name} logo={logo} size={48} /><div className="min-w-0 flex-1 leading-tight"><p className="truncate text-[14px] font-semibold">{name}</p><p className="text-[12px] text-[#00000099]">Gepromoot</p></div><MoreHorizontal size={20} className="text-[#00000099]" /></div>
        <div className="px-3 py-2.5 text-[14px] leading-snug"><Text text={body} max={150} /></div>
        {warn}
        {carousel ? <Carousel cards={cards} imgs={imgs} koppen={c.koppen} cta={c.cta} domain={c.domain} kop={kop} /> : <Media src={imgs[frame.id]} frame={frame} fit={ok ? 'cover' : 'contain'} />}
        {!carousel && <div className="flex items-center gap-3 bg-[#eef3f8] px-3 py-2.5"><div className="min-w-0 flex-1"><p className="line-clamp-2 text-[14px] font-semibold">{headline || 'Kop uit de brief'}</p>{c.domain && <p className="truncate text-[12px] text-[#00000099]">{c.domain}</p>}</div><span className="shrink-0 rounded-full border border-[#0a66c2] px-4 py-1.5 text-[14px] font-semibold text-[#0a66c2]">{c.cta}</span></div>}
        <div className="flex justify-around border-t border-black/10 py-1.5 text-[13px] font-semibold text-[#00000099]">{[[ThumbsUp, 'Interessant'], [MessageCircle, 'Reageren'], [Repeat2, 'Reposten'], [Send, 'Verzenden']].map(([I, l]) => { const Ic = I as typeof ThumbsUp; return <span key={l as string} className="flex items-center gap-1.5 px-2 py-1.5"><Ic size={16} /><span className="max-sm:hidden">{l as string}</span></span> })}</div>
      </div>
    )
  }

  // Facebook feed
  return (
    <div className="mx-auto w-full max-w-[500px] overflow-hidden rounded-lg border border-black/10 bg-white text-[#050505] shadow-card">
      <div className="flex items-center gap-2.5 px-3 pt-3"><Avatar name={name} logo={logo} /><div className="min-w-0 flex-1 leading-tight"><p className="truncate text-[15px] font-semibold">{name}</p><p className="flex items-center gap-1 text-[13px] text-[#65676b]">Gesponsord · <Globe2 size={12} /></p></div><MoreHorizontal size={20} className="text-[#65676b]" /></div>
      <div className="px-3 py-2.5 text-[15px] leading-snug"><Text text={body} max={125} /></div>
      {warn}
      {carousel ? <Carousel cards={cards} imgs={imgs} koppen={c.koppen} cta={c.cta} domain={c.domain} kop={kop} /> : <Media src={imgs[frame.id]} frame={frame} fit={ok ? 'cover' : 'contain'} />}
      {!carousel && (
        <div className="flex items-center gap-3 bg-[#f0f2f5] px-3 py-2.5">
          <div className="min-w-0 flex-1">{c.domain && <p className="truncate text-[12px] uppercase text-[#65676b]">{c.domain}</p>}<p className="line-clamp-2 text-[16px] font-semibold leading-tight">{headline || 'Kop uit de brief'}</p>{c.desc && <p className="truncate text-[13px] text-[#65676b]">{c.desc}</p>}</div>
          <span className="shrink-0 rounded-md bg-[#e4e6eb] px-3 py-2 text-[14px] font-semibold">{c.cta}</span>
        </div>
      )}
      <div className="flex justify-around border-t border-black/10 py-1 text-[14px] font-semibold text-[#65676b]">{[[ThumbsUp, 'Vind ik leuk'], [MessageCircle, 'Reageren'], [Share2, 'Delen']].map(([I, l]) => { const Ic = I as typeof ThumbsUp; return <span key={l as string} className="flex items-center gap-1.5 px-2 py-1.5"><Ic size={17} />{l as string}</span> })}</div>
    </div>
  )
}

/** Advertentievoorbeelden met keuze voor plaatsing en variant (kop/tekst uit de brief). */
export function AdPreviewer({ frames, brief, pageName, logo, compact }: { frames: Frame[]; brief?: Brief | null; pageName: string; logo?: string | null; compact?: boolean }) {
  const imgs = useFrameImages(frames)
  const c = useMemo(() => adCopy(brief), [brief])
  const usable = PLACEMENTS.filter((p) => pickFrame(frames, p.key).ok)
  const [placement, setPlacement] = useState<Placement>((usable[0] || PLACEMENTS[0]).key)
  const [kop, setKop] = useState(0)
  const [tekst, setTekst] = useState(0)
  if (!frames.length) return null
  return (
    <div className="grid gap-4">
      <div className={cn('flex flex-wrap items-center gap-x-4 gap-y-2', compact && 'justify-center')}>
        <div className="flex flex-wrap gap-1 rounded-xl bg-sunk p-1" role="tablist" aria-label="Plaatsing">
          {PLACEMENTS.map((p) => {
            const okp = pickFrame(frames, p.key).ok
            return <button key={p.key} role="tab" aria-selected={placement === p.key} onClick={() => setPlacement(p.key)} title={okp ? '' : 'Geen passend formaat in dit ontwerp'} className={cn('rounded-lg px-3 py-1.5 text-xs font-semibold transition', placement === p.key ? 'bg-surface text-ink shadow-card' : 'text-muted hover:text-ink', !okp && 'opacity-60')}>{p.label}</button>
          })}
        </div>
        {c.koppen.length > 1 && <Variant label="Kop" n={c.koppen.length} value={kop} onChange={setKop} />}
        {c.teksten.length > 1 && <Variant label="Tekst" n={c.teksten.length} value={tekst} onChange={setTekst} />}
      </div>
      <div key={placement + kop + tekst} className="anim-tabswap"><AdMock frames={frames} imgs={imgs} brief={brief} pageName={pageName} logo={logo} placement={placement} kop={kop} tekst={tekst} /></div>
      {!c.koppen.length && !c.teksten.length && <p className="text-center text-xs text-muted">Vul koppen en teksten in de brief in, dan verschijnen ze hier in de advertentie.</p>}
    </div>
  )
}
function Variant({ label, n, value, onChange }: { label: string; n: number; value: number; onChange: (v: number) => void }) {
  return (
    <div className="flex items-center gap-1.5 text-xs"><span className="font-semibold text-muted">{label}</span>
      <div className="flex rounded-lg bg-sunk p-0.5">{Array.from({ length: n }).map((_, i) => <button key={i} onClick={() => onChange(i)} className={cn('h-7 min-w-7 rounded-md px-2 font-semibold tabular-nums transition', i === value ? 'bg-surface text-ink shadow-card' : 'text-muted hover:text-ink')}>{i + 1}</button>)}</div>
    </div>
  )
}
