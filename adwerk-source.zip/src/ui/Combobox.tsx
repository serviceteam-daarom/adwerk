import { useEffect, useRef, useState } from 'react'
import { Check, ChevronDown, Pencil } from 'lucide-react'
import { cn } from './ui'

/** Vrij tekstveld met een lijst suggesties eronder (typen mag altijd, de lijst is een snelkeuze). */
export function Combobox({ value, onChange, suggestions, placeholder, className, ariaLabel, custom = true }: { value: string; onChange: (v: string) => void; suggestions: string[]; placeholder?: string; className?: string; ariaLabel?: string; custom?: boolean }) {
  const input = useRef<HTMLInputElement>(null)
  const [own, setOwn] = useState(false)
  const [open, setOpen] = useState(false)
  const [hi, setHi] = useState(0)
  const [typed, setTyped] = useState(false)
  const box = useRef<HTMLDivElement>(null)
  const q = value.trim().toLowerCase()
  const list = typed && q ? suggestions.filter((s) => s.toLowerCase().includes(q) && s.toLowerCase() !== q) : suggestions
  useEffect(() => {
    if (!open) return
    const off = (e: MouseEvent) => { if (!box.current?.contains(e.target as Node)) setOpen(false) }
    window.addEventListener('mousedown', off)
    return () => window.removeEventListener('mousedown', off)
  }, [open])
  const pick = (s: string) => { onChange(s); setOpen(false); setTyped(false) }
  return (
    <div ref={box} className={cn('relative min-w-0', className)}>
      <div className="flex h-9 items-center rounded-lg bg-sunk ring-violet focus-within:ring-2">
        <input ref={input} value={value} placeholder={own ? 'Typ je eigen waarde' : placeholder} aria-label={ariaLabel} role="combobox" aria-expanded={open} aria-autocomplete="list"
          onChange={(e) => { onChange(e.target.value); setTyped(true); setOpen(true); setHi(0) }}
          onFocus={() => setOpen(true)}
          onKeyDown={(e) => {
            if (e.key === 'ArrowDown') { e.preventDefault(); setOpen(true); setHi((h) => Math.min(list.length - 1, h + 1)) }
            if (e.key === 'ArrowUp') { e.preventDefault(); setHi((h) => Math.max(0, h - 1)) }
            if (e.key === 'Enter' && open && list[hi]) { e.preventDefault(); pick(list[hi]) }
            if (e.key === 'Escape') setOpen(false)
            e.stopPropagation()
          }}
          className="h-full min-w-0 flex-1 bg-transparent pl-3 text-sm outline-none placeholder:text-muted focus-visible:outline-none" />
        <button type="button" tabIndex={-1} onMouseDown={(e) => { e.preventDefault(); setTyped(false); setOpen(!open) }} className="grid h-full w-8 place-items-center text-muted hover:text-ink" aria-label="Suggesties tonen">
          <ChevronDown size={15} className={cn('transition-transform duration-200', open && 'rotate-180')} />
        </button>
      </div>
      {open && (list.length > 0 || custom) && (
        <ul role="listbox" className="anim-pop absolute inset-x-0 top-[calc(100%+4px)] z-50 max-h-60 overflow-auto rounded-xl border border-line bg-surface p-1 shadow-pop" data-state="open">
          {list.map((s, i) => (
            <li key={s} role="option" aria-selected={s === value}>
              <button type="button" onMouseDown={(e) => { e.preventDefault(); pick(s) }} onMouseEnter={() => setHi(i)}
                className={cn('flex w-full items-center gap-2 rounded-lg px-2.5 py-1.5 text-left text-sm', i === hi ? 'bg-sunk' : '')}>
                <span className="flex-1">{s}</span>{s === value && <Check size={14} className="text-accent-fg" />}
              </button>
            </li>
          ))}
          {custom && (
            <li className="mt-1 border-t border-line pt-1">
              <button type="button" onMouseDown={(e) => { e.preventDefault(); onChange(''); setOwn(true); setOpen(false); setTyped(false); setTimeout(() => input.current?.focus(), 0) }}
                className="flex w-full items-center gap-2 rounded-lg px-2.5 py-1.5 text-left text-sm font-medium text-violet hover:bg-sunk">
                <Pencil size={14} /> Anders, zelf invullen
              </button>
            </li>
          )}
        </ul>
      )}
    </div>
  )
}
