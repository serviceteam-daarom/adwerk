import { useEffect, useMemo, useRef, useState } from 'react'
import { Send, Smile, ImagePlus, X, Loader2, Link2 } from 'lucide-react'
import { useChat, markRead, sendMessage, threadOf, nameOf, sendTyping, uploadChatImage, searchGifs, type Message, type Thread, type Attachment, type Gif } from '../lib/chat'
import { EMOJI, recentEmoji, pushRecent } from '../lib/emoji'
import { useEditor } from '../store/editor'
import { Avatar, Input, cn } from './ui'

const time = (iso: string) => {
  const d = new Date(iso), now = new Date()
  return d.toDateString() === now.toDateString() ? d.toLocaleTimeString('nl-NL', { hour: '2-digit', minute: '2-digit' }) : d.toLocaleDateString('nl-NL', { day: 'numeric', month: 'short' }) + ' ' + d.toLocaleTimeString('nl-NL', { hour: '2-digit', minute: '2-digit' })
}
const first = (id: string) => nameOf(id).split(' ')[0]
const onlyEmoji = (s: string) => /^\p{Extended_Pictographic}(\p{Emoji_Modifier}|‍\p{Extended_Pictographic}|️)*(\s*\p{Extended_Pictographic}(\p{Emoji_Modifier}|‍\p{Extended_Pictographic}|️)*){0,2}$/u.test(s.trim())

/** Tekst met gemarkeerde @vermeldingen en klikbare links. */
function Body({ m, mine }: { m: Message; mine: boolean }) {
  const me = useChat((s) => s.me)
  const names = (m.mentions || []).map((id) => ({ id, label: '@' + first(id) }))
  const parts: React.ReactNode[] = []
  const re = new RegExp(`(${[...names.map((n) => n.label.replace(/[.*+?^${}()|[\]\\]/g, '\\$&')), 'https?://\\S+'].join('|')})`, 'g')
  m.body.split(re).forEach((p, i) => {
    const n = names.find((x) => x.label === p)
    if (n) parts.push(<span key={i} className={cn('rounded px-0.5 font-semibold', n.id === me ? 'bg-[#E6A4FF] text-[#1B213B]' : mine ? 'text-[#A2D6ED]' : 'text-[#1A5FC4] dark:text-[#A2D6ED]')}>{p}</span>)
    else if (/^https?:\/\//.test(p)) parts.push(<a key={i} href={p} target="_blank" rel="noreferrer" className="underline underline-offset-2">{p}</a>)
    else parts.push(p)
  })
  return <>{parts}</>
}

export function Conversation({ thread, renderCard }: { thread: Thread; renderCard: (m: Message, mine: boolean) => React.ReactNode }) {
  const { messages, me, profiles, typing } = useChat()
  const list = messages.filter((m) => threadOf(m, me!) === thread)
  const endRef = useRef<HTMLDivElement>(null)
  useEffect(() => { endRef.current?.scrollIntoView({ block: 'end' }); markRead(thread) }, [list.length, thread])
  const typers = Object.entries(typing).filter(([, t]) => t.thread === thread && t.until > Date.now()).map(([id]) => id)
  const [zoom, setZoom] = useState<Attachment | null>(null)

  return (
    <>
      <div className="min-h-0 flex-1 overflow-y-auto px-3 py-4">
        {!list.length && <p className="mt-10 text-center text-sm text-muted">Nog geen berichten. Zeg hallo! 👋</p>}
        {list.map((m, i) => {
          const mine = m.sender_id === me
          const prev = list[i - 1]
          const grouped = prev && prev.sender_id === m.sender_id && new Date(m.created_at).getTime() - new Date(prev.created_at).getTime() < 5 * 60e3 && !m.design_id && !prev.design_id
          const p = profiles[m.sender_id]
          const big = !m.attachments?.length && onlyEmoji(m.body)
          return (
            <div key={m.id} className={cn('anim-msg flex gap-2', mine ? 'justify-end' : 'justify-start', grouped ? 'mt-1' : 'mt-3')}>
              {!mine && <span className="w-7 shrink-0">{!grouped && <Avatar name={nameOf(m.sender_id)} color={p?.color} src={p?.avatar_url} size={28} />}</span>}
              <div className={cn('flex max-w-[80%] flex-col', mine ? 'items-end' : 'items-start')}>
                {!grouped && <div className="mb-0.5 text-[11px] text-muted">{mine ? 'Jij' : first(m.sender_id)} · {time(m.created_at)}</div>}
                {m.design_id ? renderCard(m, mine) : null}
                {(m.attachments || []).map((a, k) => (
                  <button key={k} onClick={() => setZoom(a)} className="mb-1 block overflow-hidden rounded-2xl border border-line bg-sunk" aria-label={a.title || 'Afbeelding'}>
                    <img src={a.url} alt={a.title || ''} loading="lazy" className="max-h-60 max-w-full object-contain" style={a.w && a.h ? { aspectRatio: `${a.w} / ${a.h}`, width: Math.min(260, a.w) } : { width: 240 }} />
                    {a.type === 'gif' && <span className="block bg-surface px-2 py-0.5 text-left text-[10px] text-muted">via GIPHY</span>}
                  </button>
                ))}
                {!m.design_id && m.body && (big
                  ? <div className="text-4xl leading-tight">{m.body}</div>
                  : <div className={cn('whitespace-pre-wrap break-words px-3 py-2 text-sm', mine ? 'rounded-2xl rounded-tr-md bg-navy text-white dark:bg-[#1A5FC4]' : 'rounded-2xl rounded-tl-md bg-sunk text-ink', (m.mentions || []).includes(me!) && !mine && 'ring-2 ring-[#E6A4FF]')}><Body m={m} mine={mine} /></div>)}
              </div>
            </div>
          )
        })}
        {typers.length > 0 && (
          <div className="mt-3 flex items-center gap-2 text-xs text-muted" aria-live="polite">
            <span className="flex gap-1 rounded-2xl rounded-tl-md bg-sunk px-3 py-2.5">{[0, 1, 2].map((d) => <span key={d} className="h-1.5 w-1.5 animate-bounce rounded-full bg-muted" style={{ animationDelay: `${d * 0.15}s` }} />)}</span>
            {typers.map(first).join(', ')} {typers.length > 1 ? 'typen' : 'typt'}…
          </div>
        )}
        <div ref={endRef} />
      </div>
      <Composer thread={thread} />
      {zoom && (
        <div className="fixed inset-0 z-[130] grid place-items-center bg-black/80 p-6" onClick={() => setZoom(null)} role="dialog" aria-label="Afbeelding">
          <img src={zoom.url} alt={zoom.title || ''} className="max-h-full max-w-full rounded-lg object-contain" />
          <button className="absolute right-4 top-4 rounded-full bg-white/15 p-2 text-white" aria-label="Sluiten"><X size={20} /></button>
          <a href={zoom.url} target="_blank" rel="noreferrer" onClick={(e) => e.stopPropagation()} className="absolute bottom-4 rounded-full bg-white/15 px-4 py-2 text-sm text-white">Open in nieuw tabblad</a>
        </div>
      )}
    </>
  )
}

function Composer({ thread }: { thread: Thread }) {
  const { profiles, me } = useChat()
  const design = useEditor((s) => s.design)
  const [text, setText] = useState('')
  const [mentions, setMentions] = useState<string[]>([])
  const [atts, setAtts] = useState<Attachment[]>([])
  const [busy, setBusy] = useState(0)
  const [err, setErr] = useState<string | null>(null)
  const [panel, setPanel] = useState<'emoji' | 'gif' | null>(null)
  const [shareDesign, setShareDesign] = useState(false)
  const [mq, setMq] = useState<{ q: string; start: number } | null>(null)
  const [mi, setMi] = useState(0)
  const ta = useRef<HTMLTextAreaElement>(null)
  const file = useRef<HTMLInputElement>(null)
  const inEditor = !!design && location.hash.startsWith('#/d/')

  const people = useMemo(() => Object.values(profiles).filter((p) => p.id !== me && (thread === 'team' || p.id === thread || true)), [profiles, me, thread])
  const options = mq ? people.filter((p) => (p.full_name || p.email).toLowerCase().includes(mq.q.toLowerCase())).slice(0, 6) : []

  useEffect(() => { const t = ta.current; if (!t) return; t.style.height = 'auto'; t.style.height = Math.min(128, t.scrollHeight) + 'px' }, [text])

  const onChange = (v: string) => {
    setText(v); setErr(null)
    if (v.trim()) sendTyping(thread)
    const pos = ta.current?.selectionStart ?? v.length
    const m = v.slice(0, pos).match(/(^|\s)@([\p{L}-]{0,20})$/u)
    if (m) { setMq({ q: m[2], start: pos - m[2].length - 1 }); setMi(0) } else setMq(null)
  }
  const pick = (id: string) => {
    if (!mq) return
    const label = '@' + first(id) + ' '
    const pos = ta.current?.selectionStart ?? text.length
    const v = text.slice(0, mq.start) + label + text.slice(pos)
    setText(v); setMentions((x) => [...new Set([...x, id])]); setMq(null)
    requestAnimationFrame(() => { const t = ta.current!; t.focus(); const c = mq.start + label.length; t.setSelectionRange(c, c) })
  }
  const insert = (s: string) => {
    const t = ta.current, pos = t?.selectionStart ?? text.length
    const v = text.slice(0, pos) + s + text.slice(t?.selectionEnd ?? pos)
    setText(v)
    requestAnimationFrame(() => { t?.focus(); t?.setSelectionRange(pos + s.length, pos + s.length) })
  }
  const addFiles = async (files: FileList | File[]) => {
    const list = Array.from(files).filter((f) => f.type.startsWith('image/'))
    if (!list.length) return
    setBusy((b) => b + list.length)
    for (const f of list) { try { const a = await uploadChatImage(f); setAtts((x) => [...x, a]) } catch (e) { setErr((e as Error).message) } finally { setBusy((b) => b - 1) } }
  }
  const send = async (extra: Attachment[] = []) => {
    const body = text.trim(), all = [...atts, ...extra]
    if (!body && !all.length && !shareDesign) return
    const used = mentions.filter((id) => body.includes('@' + first(id)))
    const d = shareDesign && design ? { kind: 'mention' as const, design_id: design.id, design_title: design.title } : {}
    setText(''); setAtts([]); setMentions([]); setPanel(null); setShareDesign(false)
    try { await sendMessage(thread, body || (shareDesign ? 'Kijk je even mee in dit ontwerp?' : ''), { mentions: used, attachments: all, ...d }) }
    catch (e) { setErr((e as Error).message); setText(body); setAtts(all) }
  }

  return (
    <div className="relative border-t border-line">
      {panel === 'emoji' && <EmojiPanel onPick={(e) => { insert(e); pushRecent(e) }} />}
      {panel === 'gif' && <GifPanel onPick={(g) => send([{ type: 'gif', url: g.url, still: g.still, w: g.w, h: g.h, title: g.title }])} />}
      {mq && options.length > 0 && (
        <div className="absolute bottom-full left-3 right-3 mb-1 overflow-hidden rounded-xl border border-line bg-surface shadow-pop" role="listbox" aria-label="Collega noemen">
          {options.map((p, i) => (
            <button key={p.id} role="option" aria-selected={i === mi} onMouseDown={(e) => { e.preventDefault(); pick(p.id) }} className={cn('flex w-full items-center gap-2 px-3 py-2 text-left text-sm', i === mi ? 'bg-accent-soft' : 'hover:bg-sunk')}>
              <Avatar name={p.full_name || p.email} color={p.color} src={p.avatar_url} size={24} /> <span className="font-semibold">{p.full_name || p.email}</span>
            </button>
          ))}
        </div>
      )}
      {(atts.length > 0 || busy > 0 || shareDesign) && (
        <div className="flex flex-wrap gap-2 px-3 pt-3">
          {atts.map((a, i) => (
            <span key={i} className="relative h-16 w-16 overflow-hidden rounded-lg border border-line bg-sunk">
              <img src={a.url} alt="" className="h-full w-full object-cover" />
              <button onClick={() => setAtts((x) => x.filter((_, j) => j !== i))} className="absolute right-0.5 top-0.5 rounded-full bg-navy/80 p-0.5 text-white" aria-label="Verwijderen"><X size={12} /></button>
            </span>
          ))}
          {busy > 0 && <span className="grid h-16 w-16 place-items-center rounded-lg border border-dashed border-line"><Loader2 size={18} className="animate-spin text-muted" /></span>}
          {shareDesign && design && <span className="flex items-center gap-2 rounded-lg bg-mist px-3 py-2 text-xs dark:bg-sunk"><Link2 size={14} /> {design.title}<button onClick={() => setShareDesign(false)} aria-label="Niet delen"><X size={12} /></button></span>}
        </div>
      )}
      {err && <p role="alert" className="px-3 pt-2 text-sm text-accent-fg">{err}</p>}
      <form onSubmit={(e) => { e.preventDefault(); send() }} className="flex items-end gap-1.5 p-3"
        onDragOver={(e) => { if (e.dataTransfer.types.includes('Files')) e.preventDefault() }} onDrop={(e) => { if (e.dataTransfer.files.length) { e.preventDefault(); e.stopPropagation(); addFiles(e.dataTransfer.files) } }}>
        <div className="flex shrink-0 items-center">
          <ToolBtn label="Emoji" active={panel === 'emoji'} onClick={() => setPanel(panel === 'emoji' ? null : 'emoji')}><Smile size={19} /></ToolBtn>
          <ToolBtn label="GIF zoeken" active={panel === 'gif'} onClick={() => setPanel(panel === 'gif' ? null : 'gif')}><span className="text-[11px] font-extrabold tracking-tight">GIF</span></ToolBtn>
          <ToolBtn label="Afbeelding delen" onClick={() => file.current?.click()}><ImagePlus size={19} /></ToolBtn>
          {inEditor && <ToolBtn label="Dit ontwerp delen" active={shareDesign} onClick={() => setShareDesign(!shareDesign)}><Link2 size={18} /></ToolBtn>}
          <input ref={file} type="file" accept="image/*" multiple hidden onChange={(e) => { if (e.target.files) addFiles(e.target.files); e.target.value = '' }} />
        </div>
        <textarea ref={ta} value={text} rows={1} onChange={(e) => onChange(e.target.value)} aria-label="Bericht"
          placeholder={thread === 'team' ? 'Bericht aan het team, @ om iemand te noemen' : `Bericht aan ${first(thread)}`}
          onPaste={(e) => { const f = Array.from(e.clipboardData.files); if (f.length) { e.preventDefault(); addFiles(f) } }}
          onKeyDown={(e) => {
            if (mq && options.length) {
              if (e.key === 'ArrowDown') { e.preventDefault(); setMi((i) => (i + 1) % options.length); return }
              if (e.key === 'ArrowUp') { e.preventDefault(); setMi((i) => (i - 1 + options.length) % options.length); return }
              if (e.key === 'Enter' || e.key === 'Tab') { e.preventDefault(); pick(options[mi].id); return }
              if (e.key === 'Escape') { setMq(null); return }
            }
            if (e.key === 'Enter' && !e.shiftKey) { e.preventDefault(); send() }
          }}
          className="max-h-32 min-h-[40px] min-w-0 flex-1 resize-none rounded-xl border border-line bg-mist px-3 py-2.5 text-sm outline-none focus:border-[#1A5FC4] dark:bg-sunk" />
        <button type="submit" aria-label="Versturen" disabled={!text.trim() && !atts.length && !shareDesign}
          className="grid h-10 w-10 shrink-0 place-items-center rounded-full bg-[#CC4A25] text-white transition hover:bg-[#B23C18] disabled:bg-sunk disabled:text-muted">
          <Send size={17} className="-ml-0.5" />
        </button>
      </form>
    </div>
  )
}

function ToolBtn({ label, active, onClick, children }: { label: string; active?: boolean; onClick: () => void; children: React.ReactNode }) {
  return <button type="button" onClick={onClick} aria-label={label} title={label} className={cn('grid h-9 w-9 place-items-center rounded-lg text-muted transition hover:bg-sunk hover:text-ink', active && 'bg-accent-soft text-accent-fg')}>{children}</button>
}

function EmojiPanel({ onPick }: { onPick: (e: string) => void }) {
  const [cat, setCat] = useState(recentEmoji().length ? -1 : 0)
  const recent = recentEmoji()
  const list = cat === -1 ? recent : EMOJI[cat].list
  return (
    <div className="border-b border-line bg-surface">
      <div className="flex gap-0.5 overflow-x-auto px-2 pt-2">
        {recent.length > 0 && <button onClick={() => setCat(-1)} className={cn('rounded-lg px-2 py-1 text-lg', cat === -1 && 'bg-sunk')} title="Recent" aria-label="Recent gebruikt">🕘</button>}
        {EMOJI.map((c, i) => <button key={c.name} onClick={() => setCat(i)} className={cn('rounded-lg px-2 py-1 text-lg', cat === i && 'bg-sunk')} title={c.name} aria-label={c.name}>{c.icon}</button>)}
      </div>
      <div className="grid max-h-48 grid-cols-8 gap-0.5 overflow-y-auto p-2">
        {list.map((e, i) => <button key={e + i} onClick={() => onPick(e)} className="grid h-9 place-items-center rounded-lg text-xl hover:bg-sunk" aria-label={e}>{e}</button>)}
      </div>
    </div>
  )
}

function GifPanel({ onPick }: { onPick: (g: Gif) => void }) {
  const [q, setQ] = useState('')
  const [gifs, setGifs] = useState<Gif[]>([])
  const [busy, setBusy] = useState(false)
  const [err, setErr] = useState<string | null>(null)
  useEffect(() => {
    let alive = true
    const t = setTimeout(async () => { setBusy(true); setErr(null); try { const r = await searchGifs(q); if (alive) setGifs(r) } catch (e) { if (alive) setErr((e as Error).message) } finally { if (alive) setBusy(false) } }, 350)
    return () => { alive = false; clearTimeout(t) }
  }, [q])
  return (
    <div className="border-b border-line bg-surface p-2">
      <Input value={q} onChange={(e) => setQ(e.target.value)} placeholder="Zoek op GIPHY" aria-label="Zoek GIF's" autoFocus />
      {err && <p className="mt-2 text-xs text-accent-fg">{err}</p>}
      <div className="mt-2 grid max-h-56 grid-cols-3 gap-1 overflow-y-auto">
        {gifs.map((g) => <button key={g.id} onClick={() => onPick(g)} className="overflow-hidden rounded-lg bg-sunk" title={g.title} aria-label={g.title || 'GIF'}><img src={g.url} alt={g.title} loading="lazy" className="h-24 w-full object-cover" /></button>)}
        {busy && !gifs.length && Array.from({ length: 6 }).map((_, i) => <span key={i} className="h-24 animate-pulse rounded-lg bg-sunk" />)}
      </div>
      <p className="mt-1 text-right text-[10px] font-bold tracking-wide text-muted">POWERED BY GIPHY</p>
    </div>
  )
}
