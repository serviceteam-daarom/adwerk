/** @type {import('tailwindcss').Config} */
export default {
  content: ['./index.html', './src/**/*.{ts,tsx}'],
  theme: {
    extend: {
      colors: {
        ink: '#1A1726', mist: '#F6F5FA', sunk: '#EEEDF4', line: '#E2E0EA', muted: '#6B6880',
        accent: { DEFAULT: '#FF5B2E', soft: '#FFE9E2', dark: '#E8481C' },
        violet: { DEFAULT: '#5B3FD9', soft: '#ECE8FD' },
        mint: '#13B58C', sun: '#FFC233',
      },
      fontFamily: {
        display: ['"Bricolage Grotesque"', 'ui-sans-serif', 'system-ui', 'sans-serif'],
        sans: ['Figtree', 'ui-sans-serif', 'system-ui', '-apple-system', 'Segoe UI', 'sans-serif'],
      },
      boxShadow: { pop: '0 12px 32px -12px rgba(26,23,38,.28)', card: '0 1px 2px rgba(26,23,38,.06)' },
    },
  },
  plugins: [],
}
