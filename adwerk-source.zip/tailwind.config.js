/** @type {import('tailwindcss').Config} */
// Kleuren gemeten op www.daar-om.nl; thema-variabelen staan in src/index.css (licht en donker)
const v = (name) => `rgb(var(--${name}) / <alpha-value>)`
export default {
  darkMode: 'class',
  content: ['./index.html', './src/**/*.{ts,tsx}'],
  theme: {
    extend: {
      colors: {
        ink: v('ink'), mist: v('mist'), sunk: v('sunk'), line: v('line'), muted: v('muted'), surface: v('surface'),
        navy: v('navy'),
        accent: { DEFAULT: v('accent'), soft: v('accent-soft'), dark: v('accent-dark'), fg: v('accent-fg') },
        violet: { DEFAULT: v('violet'), soft: v('violet-soft') },
        warn: v('warn'), orange: '#EA5F39', lila: '#E6A4FF', sky: '#A2D6ED', mint: v('mint'), sun: '#E6A4FF',
      },
      fontFamily: {
        display: ['Poppins', 'ui-sans-serif', 'system-ui', 'sans-serif'],
        sans: ['Poppins', 'ui-sans-serif', 'system-ui', '-apple-system', 'Segoe UI', 'sans-serif'],
        hand: ['Caveat', 'cursive'],
      },
      borderRadius: { card: '20px', blob: '8px 60px 8px 8px' },
      boxShadow: { pop: '0 12px 32px -12px rgb(var(--shadow) / .32)', card: '0 1px 2px rgb(var(--shadow) / .08)' },
    },
  },
  plugins: [],
}
