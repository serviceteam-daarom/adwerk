/** @type {import('tailwindcss').Config} */
// Kleuren en fonts gemeten op www.daar-om.nl (homepage en /team, oktober 2026)
export default {
  content: ['./index.html', './src/**/*.{ts,tsx}'],
  theme: {
    extend: {
      colors: {
        ink: '#1B213B',        // donkerblauw: tekst en donkere secties
        mist: '#F1F9FC',       // lichtblauw vlak (reviewtegels)
        sunk: '#EBF4F8',       // invoervelden en werkvlak (afgeleid van #F1F9FC)
        line: '#DCEBF2',       // randen (afgeleid van #E0F1F7)
        muted: '#6B7280',      // grijze tekst (stappen-beschrijving)
        accent: { DEFAULT: '#EA5F39', soft: '#FDEBE5', dark: '#D14C27' }, // oranje knoppen en punten
        violet: { DEFAULT: '#1A5FC4', soft: '#E6EFFB' },                   // blauw: secundaire knop, selectie
        lila: '#E6A4FF',       // lila accentpunt en beeldmerk
        sky: '#A2D6ED',        // lichtblauw stappen
        mint: '#13B58C', sun: '#E6A4FF',
      },
      fontFamily: {
        display: ['Poppins', 'ui-sans-serif', 'system-ui', 'sans-serif'],
        sans: ['Poppins', 'ui-sans-serif', 'system-ui', '-apple-system', 'Segoe UI', 'sans-serif'],
        hand: ['Caveat', 'cursive'],
      },
      borderRadius: { card: '20px', blob: '8px 60px 8px 8px' },
      boxShadow: { pop: '0 12px 32px -12px rgba(27,33,59,.28)', card: '0 1px 2px rgba(27,33,59,.06)' },
    },
  },
  plugins: [],
}
